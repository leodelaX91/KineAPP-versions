# -*- coding: utf-8 -*-
"""Signale les noms de médicaments qui n'existent pas — sans jamais les corriger.

Les pires erreurs des comptes rendus ne viennent pas du modèle mais de la transcription :
« liprane » pour Doliprane, « cortensil » pour Cortancyl, « cachou » pour un cachet. Les six
modèles du banc du 05/10/2026 les ont tous repris comme de vrais médicaments, et le contrôle
des nombres ne pouvait rien voir : ce sont des mots, pas des chiffres.

Deux principes, qui expliquent la forme du module :

  - on SIGNALE, on ne corrige pas. La transcription est la seule archive (l'audio est
    supprimé) : y substituer « Doliprane » effacerait la trace du doute. Le lexique produit
    une ligne de « À vérifier », rien d'autre.
  - on ne regarde que le MOT DE TÊTE d'un libellé de médicament, ou un mot en capitale.
    Un nom de spécialité se trouve là. Chercher partout ferait signaler « association »,
    « renouvellement » ou n'importe quel mot absent d'une base de médicaments, et la section
    « À vérifier » deviendrait illisible — donc plus lue du tout.
"""
import os, re, unicodedata

DOSSIER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lexique")
FICHIER = os.path.join(DOSSIER, "medicaments.txt")

# Classes, molécules génériques et traitements désignés sans nom de marque : légitimes dans un
# bilan, absents d'une base de spécialités. Leur présence en tête d'un libellé suffit.
CLASSES = {
    "antalgique", "antalgiques", "antidouleur", "antidouleurs", "anti-inflammatoire",
    "anti-inflammatoires", "ains", "corticoide", "corticoides", "corticotherapie", "cortisone",
    "chimiotherapie", "radiotherapie", "immunotherapie", "hormonotherapie", "biotherapie",
    "anticoagulant", "anticoagulants", "antibiotique", "antibiotiques", "antidepresseur",
    "antidepresseurs", "anxiolytique", "anxiolytiques", "somnifere", "somniferes",
    "antihypertenseur", "antihypertenseurs", "betabloquant", "betabloquants", "statine",
    "statines", "antidiabetique", "antidiabetiques", "insuline", "myorelaxant", "myorelaxants",
    "decontractant", "decontractants", "opioide", "opioides", "morphinique", "morphiniques",
    "vitamine", "vitamines", "magnesium", "calcium", "potassium", "probiotique", "probiotiques",
    "veinotonique", "veinotoniques", "diuretique", "diuretiques", "laxatif", "laxatifs",
    "antiacide", "antiacides", "antihistaminique", "antihistaminiques", "bronchodilatateur",
    "anti-epileptique", "antiepileptique", "neuroleptique", "neuroleptiques", "antiemetique",
    "oligoelements", "complement", "complements", "homeopathie", "phytotherapie",
}
# Formes, rythmes, repères de temps et mots de remplissage : ni preuve ni soupçon.
NEUTRES = {
    "comprime", "comprimes", "gelule", "gelules", "sachet", "sachets", "goutte", "gouttes",
    "patch", "patchs", "pommade", "creme", "gel", "sirop", "suppositoire", "suppositoires",
    "injection", "injections", "injectable", "perfusion", "perfusions", "piqure", "piqures",
    "ampoule", "ampoules", "spray", "inhalateur", "collyre", "poudre", "solution", "buvable",
    "lente", "lentes", "rapide", "rapides", "retard", "effervescent", "effervescente",
    "liberation", "prolongee", "orale", "voie", "locale", "local", "cutanee", "generique",
    "matin", "midi", "soir", "nuit", "jour", "jours", "semaine", "semaines", "mois", "annee",
    "annees", "quotidien", "quotidienne", "ponctuel", "ponctuelle", "ponctuellement",
    "occasionnel", "occasionnelle", "parfois", "rarement", "souvent", "besoin", "demande",
    "traitement", "traitements", "medicament", "medicaments", "medicaments", "dose", "doses",
    "posologie", "prise", "prises", "cure", "cures", "arret", "arrete", "arretee", "arretes",
    "depuis", "pendant", "avant", "apres", "actuel", "actuelle", "actuellement", "encore",
    "transcrit", "entendu", "confirmer", "verifier", "preciser", "precise", "precisee",
    "inconnu", "inconnue", "evalue", "evaluee", "aucun", "aucune", "plus", "fois", "deux",
    "trois", "quatre", "cinq", "selon", "pour", "dans", "avec", "sans", "autre", "autres",
    "association", "renouvellement", "ordonnance", "prescrit", "prescrite", "prescription",
    "nouveau", "nouvelle", "ancien", "ancienne", "divers", "diverses", "type", "genre",
}
_CACHE = {}
MOT = re.compile(r"[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'\-]{3,}")


def _sans_accent(t):
    return "".join(c for c in unicodedata.normalize("NFD", t or "")
                   if not unicodedata.combining(c)).lower()


def charge():
    """Noms connus. Fichier absent : ensemble vide, et le module ne signale alors rien."""
    if "noms" not in _CACHE:
        noms = set()
        try:
            with open(FICHIER, encoding="utf-8") as f:
                for ligne in f:
                    ligne = ligne.strip()
                    if ligne and not ligne.startswith("#"):
                        noms.add(ligne)
        except OSError:
            pass
        _CACHE["noms"] = noms
    return _CACHE["noms"]


def disponible():
    return bool(charge())


def _candidats(libelle):
    """Mots qui occupent la place d'un nom de produit : celui de tête, et les capitalisés."""
    mots = [(m.group(0), m.start()) for m in MOT.finditer(libelle or "")]
    if not mots:
        return []
    out, vus = [], set()
    for mot, position in mots:
        tete = position == mots[0][1]
        capitale = mot[:1].isupper()
        if not (tete or capitale):
            continue
        n = _sans_accent(mot).strip("'-")
        if n and n not in vus:
            vus.add(n)
            out.append((mot, n))
    return out


def inconnus(extraction):
    """Noms de médicaments absents du lexique. Renvoie (liste de signalements, nb vérifiés).

    Ne regarde que antecedents.medicaments[].libelle : c'est le seul champ dont le contenu
    est, par construction du schéma, un nom de produit. Les allergies ou l'examen clinique
    contiennent des mots légitimes qui ne sont pas des médicaments."""
    noms = charge()
    if not noms:
        return [], 0
    items = ((extraction or {}).get("antecedents") or {}).get("medicaments")
    if not isinstance(items, list):
        return [], 0
    trouves, verifies = [], 0
    for i, item in enumerate(items, 1):
        if not isinstance(item, dict):
            continue
        libelle = str(item.get("libelle") or "").strip()
        if not libelle or _sans_accent(libelle) in ("non evalue", "aucun", "aucune"):
            continue
        for mot, n in _candidats(libelle):
            if n in NEUTRES or n in CLASSES:
                continue
            verifies += 1
            if n in noms or any(p in noms for p in n.split("-")):
                continue
            # Orthographe internationale ou à une lettre finale près (« Voltaren » pour
            # Voltarène, banc du 12/10/2026) : le produit est connu, rien à signaler.
            if len(n) >= 6 and (n + "e" in noms or (n.endswith("e") and n[:-1] in noms)):
                continue
            trouves.append({
                "champ": f"antecedents.medicaments[{i}].libelle", "valeur": libelle,
                "probleme": f"« {mot} » ne figure pas dans la base des médicaments — "
                            f"nom probablement déformé par la transcription, à confirmer"})
    return trouves, verifies
