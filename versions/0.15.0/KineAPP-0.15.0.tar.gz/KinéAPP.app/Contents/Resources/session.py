# -*- coding: utf-8 -*-
"""Session de la page de KinéAPP, propre à chaque lancement.

La fenêtre native reçoit au lancement un secret (entrée standard du serveur, jamais l'environnement)
et le présente dans l'en-tête X-Fenetre. Avec lui, elle demande un code d'entrée (usage unique,
2 minutes), qui ouvre la page : le serveur l'échange contre un cookie de session (HttpOnly,
SameSite=Strict). Toute l'API exige ce cookie ou le secret de la fenêtre ; un autre programme du Mac
qui trouverait le port n'a ni l'un ni l'autre."""
import hmac, secrets, threading, time
from http.cookies import CookieError, SimpleCookie

NOM_COOKIE = "kineapp_session"
SECRET_FENETRE = {"v": ""}                 # remis par la fenêtre au lancement
SESSION_PAGE = {"jeton": "", "entrees": {}}
_VERROU = threading.Lock()


def jeton_session():
    with _VERROU:
        if not SESSION_PAGE["jeton"]:
            SESSION_PAGE["jeton"] = secrets.token_urlsafe(32)
        return SESSION_PAGE["jeton"]


def code_entree():
    code = secrets.token_urlsafe(24)
    with _VERROU:
        t = time.time()
        SESSION_PAGE["entrees"] = {c: e for c, e in SESSION_PAGE["entrees"].items() if e > t}
        SESSION_PAGE["entrees"][code] = t + 120
    return code


def entree_valide(code):
    """Code d'entrée de la fenêtre : valable une fois, 2 minutes."""
    with _VERROU:
        fin = SESSION_PAGE["entrees"].pop(str(code or ""), 0)
    return fin > time.time()


def session_valide(entetes):
    try:
        c = SimpleCookie(entetes.get("Cookie") or "")
    except CookieError:
        return False
    v = c[NOM_COOKIE].value if NOM_COOKIE in c else ""
    return bool(v) and hmac.compare_digest(v.encode(), jeton_session().encode())


def canal_fenetre(entetes):
    """Requête de la fenêtre native : le secret qu'elle a remis au lancement, comparé en temps constant."""
    return bool(SECRET_FENETRE["v"]) and hmac.compare_digest(str(entetes.get("X-Fenetre") or "").encode(), SECRET_FENETRE["v"].encode())
