#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Convertit un compte-rendu Markdown en .docx SANS dépendance (stdlib zipfile).
Gère : titres ## / ###, puces "-", gras **texte**.

    docx_octets(markdown) -> bytes      dans le programme (le document peut être écrit chiffré)
    python3 make_docx.py <cr.md> <sortie.docx>"""
import html, io, re, sys, zipfile


def esc(s): return html.escape(s, quote=False)


def inline_runs(text):
    parts = re.split(r'(\*\*)', text)
    bold, out = False, []
    for p in parts:
        if p == '**':
            bold = not bold; continue
        if not p: continue
        rpr = '<w:rPr><w:b/></w:rPr>' if bold else ''
        out.append(f'<w:r>{rpr}<w:t xml:space="preserve">{esc(p)}</w:t></w:r>')
    return ''.join(out) or '<w:r><w:t/></w:r>'


def para(text, size=None, bold=False, bullet=False, indent=0, before=0):
    ppr = '<w:pPr>'
    if before: ppr += f'<w:spacing w:before="{before}"/>'
    if bullet: ppr += f'<w:ind w:left="{360+indent}" w:hanging="360"/>'
    ppr += '</w:pPr>'
    if bullet: text = "• " + text
    if size or bold:
        rpr = '<w:rPr>' + ('<w:b/>' if bold else '') + (f'<w:sz w:val="{size}"/>' if size else '') + '</w:rPr>'
        r = f'<w:r>{rpr}<w:t xml:space="preserve">{esc(text.replace("**",""))}</w:t></w:r>'
    else:
        r = inline_runs(text)
    return f'<w:p>{ppr}{r}</w:p>'


CONTENT_TYPES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
  '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
  '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
  '<Default Extension="xml" ContentType="application/xml"/>'
  '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
  '</Types>')
RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
  '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
  '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
  '</Relationships>')


def docx_octets(markdown):
    body = []
    for raw in (markdown or "").split("\n"):
        line = raw.rstrip()
        if not line.strip():
            continue
        if line.startswith('### '):
            body.append(para(line[4:], size=26, bold=True, before=120))
        elif line.startswith('## '):
            body.append(para(line[3:], size=30, bold=True, before=200))
        elif line.startswith('# '):
            body.append(para(line[2:], size=34, bold=True, before=200))
        else:
            m = re.match(r'^(\s*)-\s+(.*)$', line)
            if m:
                body.append(para(m.group(2), bullet=True, indent=(360 if len(m.group(1)) >= 2 else 0)))
            else:
                body.append(para(line))
    document = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'
      + ''.join(body) + '<w:sectPr/></w:body></w:document>')
    tampon = io.BytesIO()
    with zipfile.ZipFile(tampon, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', CONTENT_TYPES)
        z.writestr('_rels/.rels', RELS)
        z.writestr('word/document.xml', document)
    return tampon.getvalue()


if __name__ == "__main__":
    md_path, docx_path = sys.argv[1], sys.argv[2]
    with open(docx_path, "wb") as f:
        f.write(docx_octets(open(md_path, encoding="utf-8").read()))
    print("écrit", docx_path)
