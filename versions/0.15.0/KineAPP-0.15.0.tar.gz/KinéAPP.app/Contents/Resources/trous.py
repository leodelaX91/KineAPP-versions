# -*- coding: utf-8 -*-
"""Transcription par tranches, pendant ou après la séance, avec reprise des passages ratés.

Bilan du 07/10/2026 : Whisper a écrit « Merci. » trois fois puis sauté 14 minutes de séance
(2 170 mots : historique, examen, explications). Le compte rendu a été rédigé sans elles et
rien ne le signalait ; le même audio, retranscrit le lendemain, sortait complet : le défaut est
aléatoire. Le 08/10, en mode horodaté, Whisper a répété 861 fois la même phrase et perdu toute
la fin de la séance. Un décrochage, sur un enregistrement d'un seul tenant, contamine la suite.

Donc : l'audio est coupé en tranches d'environ TRANCHE_S, dans les silences, et chaque tranche
est transcrite séparément — PENDANT la séance quand c'est possible (Transcripteur.avancer, sur
le fichier qu'ffmpeg est en train d'écrire), sinon après. Une défaillance reste confinée à sa
tranche. À la fin (Transcripteur.terminer), une tranche qui contient de la parole (énergie par
trames de 100 ms) mais un texte anormalement court par rapport au débit médian de la séance, ou
un texte en boucle, est retranscrite par la fonction de REPRISE — sans recherche en faisceau :
le faisceau rend Whisper déterministe, un nouvel essai identique redonnerait le même échec,
alors que sans faisceau son tirage aléatoire de secours a une chance de rattraper le passage.
Le meilleur essai est gardé, et le passage est signalé dans tous les cas."""
import array
import os
import re
import statistics
import struct
import tempfile
import wave

try:
    import audioop                       # Python ≤ 3.12 : calcul en C
except ImportError:                       # pragma: no cover
    audioop = None

TRAME_S = 0.1
TRANCHE_S = 300.0                         # cible ; la coupe tombe dans le silence le plus proche
FENETRE_S = 20.0                          # recherche du silence de part et d'autre de la cible
PAROLE_MIN_S = 30.0                       # en dessous, une tranche n'est pas jugée
DEBIT_MIN = 0.35                          # part du débit médian de la séance (mots par s parlée)
ESSAIS = 2                                # nouvelles transcriptions d'une tranche suspecte
REMPLISSAGE = re.compile(r"^(merci( beaucoup)?|sous-titrage.*|\.+|…|\[.*\]|\(.*\)|musique|silence)$", re.I)


# ── Lecture d'un WAV, même en cours d'écriture par ffmpeg ────────────────────
def entete(chemin):
    """(début des données, fréquence, canaux, octets par échantillon). La taille annoncée du
    bloc de données n'est pas lue : tant qu'ffmpeg écrit, elle est fausse ou nulle."""
    with open(chemin, "rb") as f:
        tete = f.read(65536)
    if tete[:4] != b"RIFF" or tete[8:12] != b"WAVE":
        raise wave.Error("fichier WAV attendu")
    i, fmt = 12, None
    while i + 8 <= len(tete):
        bloc, taille = tete[i:i + 4], struct.unpack("<I", tete[i + 4:i + 8])[0]
        if bloc == b"fmt ":
            _, canaux, sr, _, _, bits = struct.unpack("<HHIIHH", tete[i + 8:i + 24])
            fmt = (sr, canaux, bits // 8)
        elif bloc == b"data":
            if not fmt:
                raise wave.Error("format absent avant les données")
            return (i + 8,) + fmt
        i += 8 + taille + (taille & 1)
    raise wave.Error("bloc de données introuvable")


def reparer_entete(chemin):
    """Réécrit les tailles RIFF et data d'après la longueur réelle du fichier. Un ffmpeg tué
    sans pouvoir refermer son fichier (application fermée en pleine séance, SIGKILL) laisse
    des tailles nulles ou fausses : la plupart des lecteurs, Whisper compris, s'arrêtent
    alors au début ou rejettent le fichier. Sans effet sur un fichier déjà correct."""
    debut, sr, canaux, larg = entete(chemin)
    trame = canaux * larg
    total = os.path.getsize(chemin)
    donnees = max(0, total - debut) // trame * trame
    with open(chemin, "r+b") as f:
        if debut + donnees < total:              # trame incomplète en fin de fichier
            f.truncate(debut + donnees)
        f.seek(4)
        f.write(struct.pack("<I", min(0xFFFFFFFF, debut + donnees - 8)))
        f.seek(debut - 4)
        f.write(struct.pack("<I", min(0xFFFFFFFF, donnees)))
    return donnees // trame / float(sr)


def ajouter(chemin, suite):
    """Met les échantillons de `suite` au bout de `chemin` (même format exigé), puis répare
    l'en-tête. Sert à recoller les segments d'un enregistrement relancé après une coupure du
    micro : la transcription voit une seule séance, sans le temps perdu."""
    _, sr, canaux, larg = entete(chemin)
    debut2, sr2, canaux2, larg2 = entete(suite)
    if (sr, canaux, larg) != (sr2, canaux2, larg2):
        raise wave.Error("formats différents")
    trame = canaux * larg
    reparer_entete(chemin)                       # tronque une éventuelle trame incomplète
    with open(suite, "rb") as src, open(chemin, "ab") as dst:
        src.seek(debut2)
        reste = b""
        while True:
            bloc = src.read(1 << 20)
            if not bloc:
                break
            bloc = reste + bloc
            coupe = len(bloc) // trame * trame
            dst.write(bloc[:coupe])
            reste = bloc[coupe:]
    return reparer_entete(chemin)


def duree_dispo(chemin):
    debut, sr, canaux, larg = entete(chemin)
    return max(0, os.path.getsize(chemin) - debut) // (canaux * larg) / float(sr)


def lire(chemin, debut_s, fin_s):
    """Échantillons bruts entre deux instants (bornés à ce qui est déjà écrit)."""
    debut, sr, canaux, larg = entete(chemin)
    trame = canaux * larg
    a = debut + int(max(0.0, debut_s) * sr) * trame
    n = max(0, int((fin_s - max(0.0, debut_s)) * sr)) * trame
    with open(chemin, "rb") as f:
        f.seek(a)
        donnees = f.read(n)
    return donnees[: len(donnees) // trame * trame], (sr, canaux, larg)


def _rms(bloc, largeur):
    if audioop:
        return audioop.rms(bloc, largeur)
    a = array.array("h", bloc[: len(bloc) // 2 * 2])[::4]
    return (sum(x * x for x in a) / max(1, len(a))) ** 0.5


def activite(chemin, depuis_s=0.0):
    """Énergie de chaque trame de 100 ms à partir de `depuis_s`, et durée disponible."""
    duree = duree_dispo(chemin)
    donnees, (sr, canaux, larg) = lire(chemin, depuis_s, duree)
    pas = int(sr * TRAME_S) * canaux * larg
    energies = []
    for i in range(0, len(donnees), pas):
        bloc = donnees[i:i + pas]
        if canaux > 1 and audioop:
            bloc = audioop.tomono(bloc, larg, 0.5, 0.5)
        energies.append(_rms(bloc, larg))
    return energies, duree


def seuil_parole(energies):
    """Trois fois le bruit de fond, pris au 5e centile : une séance compte toujours au moins
    5 % de pauses, alors qu'au 20e centile une séance très parlée donnait un « bruit de fond »
    fait de parole, et plus aucune trame n'était jugée parlée."""
    if not energies:
        return 0
    tri = sorted(energies)
    return max(1.0, tri[int(len(tri) * 0.05)] * 3)


def decouper(energies, duree, depuis=0.0, final=True):
    """Bornes des tranches à partir de `depuis` (énergies comptées depuis cet instant), coupées
    sur la trame la plus calme près de chaque cible. En direct (final=False), une coupe n'est
    posée que si l'audio qui la suit est déjà là ; le reste attend."""
    bornes, t = [depuis], depuis + TRANCHE_S
    while (t < duree - TRANCHE_S / 3) if final else (t + FENETRE_S <= duree):
        a, b = int((t - FENETRE_S - depuis) / TRAME_S), int((t + FENETRE_S - depuis) / TRAME_S)
        fenetre = energies[max(0, a):b]
        i = max(0, a) + min(range(len(fenetre)), key=fenetre.__getitem__) if fenetre else int((t - depuis) / TRAME_S)
        bornes.append(depuis + i * TRAME_S)
        t = bornes[-1] + TRANCHE_S
    if final and duree > bornes[-1] + 0.5:
        bornes.append(duree)
    return list(zip(bornes, bornes[1:]))


def extraire(chemin, debut, fin, destination):
    donnees, (sr, canaux, larg) = lire(chemin, debut, fin)
    with wave.open(destination, "wb") as o:
        o.setnchannels(canaux); o.setsampwidth(larg); o.setframerate(sr)
        o.writeframes(donnees)


# ── Qualité d'un texte de tranche ────────────────────────────────────────────
def mots_reels(texte):
    """Mots du texte, hors remplissage (« Merci. », « … ») et hors répétitions de lignes."""
    vues, total = set(), 0
    for ligne in re.split(r"[\n.!?…]+", texte or ""):
        l = ligne.strip(" ,")
        if not l or REMPLISSAGE.match(l) or l.lower() in vues:
            continue
        vues.add(l.lower())
        total += len(l.split())
    return total


def en_boucle(texte):
    """Vrai si une même phrase revient au point de former l'essentiel du texte."""
    phrases = [p.strip().lower() for p in re.split(r"[\n.!?…]+", texte or "") if len(p.split()) >= 3]
    if len(phrases) < 8:
        return False
    plus = max(phrases.count(p) for p in set(phrases))
    return plus >= 5 and plus / len(phrases) >= 0.3


# ── Transcription ────────────────────────────────────────────────────────────
class Transcripteur:
    """`premier(chemin) → texte` : premier essai de chaque tranche ; `reprise(chemin) → texte` :
    nouveaux essais d'une tranche suspecte (par défaut, le même)."""

    def __init__(self, chemin, premier, reprise=None):
        self.chemin, self.premier, self.reprise = chemin, premier, reprise or premier
        self.tranches = []

    @property
    def fait_jusqua(self):
        return self.tranches[-1]["fin"] if self.tranches else 0.0

    def _transcrire(self, fonction, debut, fin):
        fd, tmp = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        try:
            extraire(self.chemin, debut, fin, tmp)
            return fonction(tmp) or ""
        finally:
            try: os.remove(tmp)
            except OSError: pass

    def avancer(self, final=False, progres=None):
        """Transcrit les tranches complètes déjà enregistrées (toutes si `final`). Renvoie le
        nombre de tranches ajoutées."""
        energies, duree = activite(self.chemin, self.fait_jusqua)
        bornes = decouper(energies, duree, self.fait_jusqua, final)
        for n, (debut, fin) in enumerate(bornes):
            self.tranches.append({"debut": debut, "fin": fin, "texte": self._transcrire(self.premier, debut, fin)})
            if progres:
                progres(n + 1, len(bornes))
        return len(bornes)

    def terminer(self, progres=None):
        """Dernières tranches, puis reprise des passages ratés. → (texte, passages repris)."""
        self.avancer(final=True, progres=progres)
        energies, _ = activite(self.chemin)
        seuil = seuil_parole(energies)
        for r in self.tranches:
            trames = energies[int(r["debut"] / TRAME_S):int(r["fin"] / TRAME_S)]
            r["parole"] = sum(1 for e in trames if e >= seuil) * TRAME_S
        debits = [mots_reels(r["texte"]) / r["parole"] for r in self.tranches if r["parole"] >= PAROLE_MIN_S]
        median = statistics.median(debits) if debits else 0

        def raison(r):
            if en_boucle(r["texte"]):
                return "texte en boucle"
            if r["parole"] >= PAROLE_MIN_S and median and mots_reels(r["texte"]) < DEBIT_MIN * median * r["parole"]:
                return "parole sans texte"
            return None

        rapport = []
        for r in self.tranches:
            pourquoi = raison(r)
            if not pourquoi:
                continue
            avant = mots_reels(r["texte"])
            for _ in range(ESSAIS):
                essai = self._transcrire(self.reprise, r["debut"], r["fin"])
                if not en_boucle(essai) and mots_reels(essai) > mots_reels(r["texte"]):
                    r["texte"] = essai
                if not raison(r):
                    break
            rapport.append({"debut_s": round(r["debut"]), "fin_s": round(r["fin"]), "raison": pourquoi,
                            "repare": raison(r) is None, "mots_avant": avant, "mots_apres": mots_reels(r["texte"])})
        return "\n".join(r["texte"].strip() for r in self.tranches if r["texte"].strip()), rapport


def transcrire_par_tranches(chemin, transcrire_wav, progres=None, reprendre_wav=None):
    """Tout l'enregistrement d'un coup (après la séance)."""
    return Transcripteur(chemin, transcrire_wav, reprendre_wav).terminer(progres)


def minutes(s):
    s = int(round(s))
    return f"{s // 60} min {s % 60:02d}"
