# -*- coding: utf-8 -*-
"""Contre-lecture des MESURES : une passe dédiée relit les mesures, le code CONFRONTE.

Pourquoi. Les mesures de l'extraction principale varient d'une version de prompt à l'autre :
sur le banc du 07/10/2026, la même transcription donnait la série de force juste (v4), puis
« 67 N à gauche » et deux valeurs perdues (v6) ; ailleurs deux périmètres inversés. Une passe
courte qui ne relève QUE les mesures (prompts/03_mesures_system.md) semblait mieux lire les
séries (13 justes sur 13 au premier essai), mais avec une seule ligne de consigne en plus elle
a INVERSÉ cette même série, inventé une force à partir d'une année (« 78 ») et pris les bornes
d'une échelle (« 0 c'est aucune douleur, 10 la pire ») pour des valeurs. Ses ajouts ne sont
donc pas fiables ; ses DÉSACCORDS avec l'extraction, si : chaque fois que les deux lectures
donnaient deux côtés opposés pour une même valeur, l'une des deux se trompait.

Règle : la passe n'ajoute rien et ne modifie aucune valeur. Pour une même valeur relevée par
les deux lectures (même catégorie, même moment, mesures semblables) :
  - côtés OPPOSÉS : le côté est retiré (« côté non précisé ») et la discordance va dans
    « À vérifier » — un côté retiré se complète à la relecture, un côté faux passe inaperçu ;
  - unités différentes : signalé, jamais converti.
Une erreur de la passe ne peut donc coûter qu'un côté juste retiré (et signalé) ou un
signalement de trop ; jamais une valeur ou un côté faux dans le compte rendu. Deux lectures
qui se trompent DANS LE MÊME SENS ne sont pas détectées : la passe ne remplace pas la relecture.
"""
import re
import unicodedata


def _plat(t):
    t = (t or "").replace("œ", "oe")
    return "".join(c for c in unicodedata.normalize("NFD", t) if not unicodedata.combining(c)).lower()


# L'ordre compte : « cotation musculaire de la flexion dorsale » est une cotation, pas une
# amplitude ; « EVA sur 10 » une douleur.
CATEGORIES = [
    ("douleur", r"douleur|\beva\b|\ben\b|echelle|/\s*10|sur 10"),
    ("perimetre", r"perimetre|circonference|tour de|centimetrie"),
    ("cotation", r"cotation|testing|/\s*5\b|sur 5"),
    ("force", r"force|dynamo|isometr|\bkg\b|kilo|newton|^n$"),
    ("amplitude", r"amplitude|flexion|extension|abduction|adduction|rotation|inclinaison|°|degre"),
]
NOMMES = ("droit", "gauche")
VIDES = {"", "non precise", "non precisee", "non evalue"}
# Mots qui ne distinguent pas deux mesures entre elles.
GENERIQUES = set("""perimetre perimetres force forces cotation cotations douleur douleurs amplitude
amplitudes mesure mesures test tests valeur valeurs precise precisee evalue droite droit gauche
gauches droites bilateral dessus dessous avec sans pour dans""".split())


def categorie(item):
    t = _plat(f"{item.get('mesure', '')} {item.get('unite', '')}")
    return next((c for c, motif in CATEGORIES if re.search(motif, t)), "autre")


def valeurs(item):
    """Valeurs relevées : sans les parenthèses (« arrondi à 30 »), sans la valeur retenue
    redite (« meilleure : 51 »), sans l'échelle (« 2 sur 5 » vaut 2)."""
    t = re.sub(r"\([^)]*\)", " ", str(item.get("valeurs") or ""))
    t = re.sub(r"(meilleure|retenue|moyenne|pic)\s*:?\s*[\d.,]+", " ", t, flags=re.I)
    t = re.sub(r"(sur|/)\s*(5|10|20|100)\b", " ", t)
    return [float(x.replace(",", ".")) for x in re.findall(r"(?<![\d,.])\d+(?:[.,]\d+)?", t)]


def _moment(item):
    return "jour" if item.get("moment") == "ce jour" else "anterieur"


def _unite(item):
    # Synonymes d'une même échelle (audit des contrôles du 07/11/2026 : « cotation MRC » / « /5 », « EVA » / « /10 »
    # et « kg (implicite, valeur numérique) » / « kg » signalés comme unités discordantes, à tort 3 fois sur 3).
    u = re.sub(r"\(.*?\)", "", _plat(item.get("unite"))).strip()
    if re.search(r"\beva\b|\ben\b|/\s*10\b|sur 10\b", u):
        return "/10"
    if re.search(r"\bmrc\b|cotation|testing|/\s*5\b|sur 5\b", u):
        return "/5"
    return {"kilos": "kg", "kilo": "kg", "kgs": "kg", "newtons": "n", "newton": "n", "degres": "°", "degre": "°"}.get(u, u)


def _mots(item):
    t = _plat(f"{item.get('mesure', '')} {item.get('site', '')}")
    return {w for w in re.findall(r"[a-z]{4,}", t) if w not in GENERIQUES}


def _semblables(x, y):
    """Même mesure ? Deux périmètres de 41 cm, l'un « à 5 cm au-dessus de la rotule », l'autre
    « du quadriceps », sont deux mesures. Sans mot distinctif d'un côté, on ne peut exclure."""
    a, b = _mots(x), _mots(y)
    return not a or not b or bool(a & b)


# Le côté est souvent répété dans le site (« Cuisse gauche ») : le retirer du seul champ
# « cote » laissait « (Cuisse gauche) : 57 cm (côté non précisé) » dans le compte rendu,
# toujours faux et désormais contradictoire (banc du 07/10/2026). « Angle droit » n'est pas un côté.
COTE_DANS_TEXTE = [re.compile(r"\s*\b(du |au )?c[oô]t[ée] (droit|gauche)\b", re.I),
                   re.compile(r"(?<!angle)\s+(droite?s?|gauches?)\b", re.I)]


def _sans_cote(texte):
    for motif in COTE_DANS_TEXTE:
        texte = motif.sub("", texte)
    return texte.strip(" ,;-") or "non précisé"


def _nb(v):
    return f"{v:g}".replace(".", ",")


def confronter(principale, dediee):
    """→ (mesures de l'extraction, côtés discordants retirés ; discordances au format des
    contrôles de verification.py). Les valeurs vues par une seule lecture sont ignorées : les
    valeurs perdues par l'extraction sont signalées par verification.mesures_manquantes."""
    principale = [dict(x) for x in (principale or []) if isinstance(x, dict)]
    dediee = [x for x in (dediee or []) if isinstance(x, dict)]
    discordances = []
    atomes = [{"x": x, "v": v, "cat": categorie(x), "moment": _moment(x), "pris": False}
              for x in dediee for v in valeurs(x)]
    # Appariement en deux temps : même côté d'abord, puis mesures semblables. En un seul
    # temps, le « 39 cm à droite » d'une lecture prenait le « 39 cm à gauche » de l'autre et
    # laissait son vrai partenaire sans paire : fausse discordance.
    paires = []
    for phase in (1, 2):
        for item in principale:
            for v in valeurs(item):
                if any(p[0] is item and abs(p[1] - v) < 0.01 for p in paires):
                    continue
                cands = [a for a in atomes if not a["pris"] and abs(a["v"] - v) < 0.01
                         and a["cat"] == categorie(item) and a["moment"] == _moment(item)
                         and (a["x"].get("cote") == item.get("cote") if phase == 1
                              else _semblables(item, a["x"]))]
                if cands:
                    cands[0]["pris"] = True
                    paires.append((item, v, cands[0]["x"]))
    unites = {}
    for item, v, autre in paires:
        libelle = f"{item.get('mesure') or 'mesure'} : {_nb(v)}"
        cb, ca = item.get("cote"), autre.get("cote")
        if cb in NOMMES and ca in NOMMES and cb != ca:
            item["cote"] = "côté non précisé"
            for champ in ("site", "mesure"):
                if isinstance(item.get(champ), str):
                    item[champ] = _sans_cote(item[champ])
            discordances.append({"champ": "examen_clinique.mesures", "valeur": libelle,
                                 "probleme": f"côté retiré : deux lectures de la transcription donnent "
                                             f"des côtés opposés ({cb} / {ca}) — à préciser"})
        ub, ua = _unite(item), _unite(autre)
        if ub not in VIDES and ua not in VIDES and ub != ua:
            # Une ligne par couple d'unités : « 67 N » et « 64 N » sont la même erreur.
            cle = (categorie(item), item.get("unite"), autre.get("unite"))
            unites.setdefault(cle, []).append(_nb(v))
    for (cat, ub, ua), vals in unites.items():
        discordances.append({"champ": "examen_clinique.mesures", "valeur": f"{cat} : {' ; '.join(vals)}",
                             "probleme": f"unité discordante entre deux lectures ({ub} / {ua}) — à vérifier"})
    vues, uniques = set(), []
    for d in discordances:
        if (d["valeur"], d["probleme"]) not in vues:
            vues.add((d["valeur"], d["probleme"]))
            uniques.append(d)
    return principale, uniques


def schema_passe(schema_extraction):
    """Schéma de la passe : le tableau « mesures » de l'extraction, seul."""
    item = schema_extraction["properties"]["examen_clinique"]["properties"]["mesures"]
    return {"type": "object", "additionalProperties": False, "required": ["mesures"],
            "properties": {"mesures": item}}
