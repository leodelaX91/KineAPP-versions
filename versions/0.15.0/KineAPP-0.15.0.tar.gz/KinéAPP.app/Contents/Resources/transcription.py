# -*- coding: utf-8 -*-
"""Nettoyage prudent des transcriptions Whisper.

On ne retire que ce qui n'a jamais été dit :
- les phrases « fantômes » que Whisper invente sur les silences (génériques de sous-titres,
  formules de vidéos YouTube, etc.) ;
- les annotations de bruits (« *tousse* », « [MUSIQUE] ») ;
- les boucles : une même phrase répétée à la suite au-delà de 3 fois (dans une ligne)
  ou une même ligne répétée au-delà de 2 fois. Les premières occurrences sont gardées,
  si bien qu'une vraie répétition (« fort, fort, fort ») reste lisible.
Tout le reste est conservé tel quel, y compris les phrases courtes (« merci », « au revoir »).
"""
import re, unicodedata

FANTOMES = re.compile(
    r"sous-?titr|amara\.org|ST' ?501|merci d'avoir regard|abonnez-vous|n'oubliez pas de (vous abonner|liker)"
    r"|radio-canada|cette vid[ée]o|[àa] la prochaine vid[ée]o|like et partag",
    re.I)
ANNOTATION = re.compile(r"^\s*(\*[^*\n]{1,60}\*|\[[^\]\n]{1,40}\]|\([^)\n]{1,40}\)|♪+|[.…\s]+)\s*$")
ANNOT_INLINE = re.compile(r"\*[^*\n]{1,60}\*|\[(?:SILENCE|BLANK_AUDIO|MUSIQUE|MUSIC|INAUDIBLE|Musique|Rires?|Applaudissements)\]|♪")
MAX_REPET_LIGNE = 3      # « c'est bon, c'est bon, c'est bon » : au plus 3 fois de suite dans une ligne
# Un générique de sous-titres est une phrase courte et isolée. Au-delà de ce nombre de mots,
# la ligne est de la vraie parole qui contient par hasard un de ces motifs (« j'ai vu une vidéo
# qui montrait l'exercice ») : on la GARDE, en la signalant dans le rapport de nettoyage.
MAX_MOTS_FANTOME = 12


def _cle(t):
    t = unicodedata.normalize("NFC", t.lower())
    return re.sub(r"[^\w']+", " ", t).strip()


def _boucles_dans_ligne(ligne):
    """Réduit une séquence de 1 à 12 mots répétée plus de MAX_REPET_LIGNE fois de suite."""
    jetons = re.findall(r"\S+", ligne)
    if len(jetons) < 4:
        return ligne, 0
    norm = [_cle(j) for j in jetons]
    retires, i, out = 0, 0, []
    while i < len(jetons):
        fait = False
        for n in range(1, 13):
            if i + n * (MAX_REPET_LIGNE + 1) > len(jetons):
                break
            motif = norm[i:i + n]
            if not any(motif):
                continue
            k = 1
            while norm[i + k * n:i + (k + 1) * n] == motif:
                k += 1
            if k > MAX_REPET_LIGNE:
                out.extend(jetons[i:i + n * MAX_REPET_LIGNE])
                retires += n * (k - MAX_REPET_LIGNE)
                i += n * k
                fait = True
                break
        if not fait:
            out.append(jetons[i])
            i += 1
    return " ".join(out), retires


PHRASE = re.compile(r"[^.!?…]+[.!?…]*\s*")
MAX_PHRASES_IDENTIQUES = 3   # même phrase à la suite, même répartie sur plusieurs lignes


def nettoyer(texte):
    """Renvoie (texte nettoyé, statistiques).

    stats["retires"] garde le TEXTE de chaque ligne écartée et stats["suspects"] celui des
    lignes gardées malgré un motif de générique : le nettoyage devient vérifiable, on peut
    relire ce qui a disparu au lieu de le croire sur parole."""
    stats = {"fantomes": 0, "annotations": 0, "mots_boucles": 0, "retires": [], "suspects": []}
    lignes = []
    for brute in (texte or "").splitlines():
        ligne = brute.strip()
        if not ligne:
            continue
        if FANTOMES.search(ligne):
            if len(ligne.split()) <= MAX_MOTS_FANTOME:
                stats["fantomes"] += 1
                stats["retires"].append(ligne)
                continue
            stats["suspects"].append(ligne)      # trop longue pour un générique : gardée
        if ANNOTATION.match(ligne):
            stats["annotations"] += 1
            stats["retires"].append(ligne)
            continue
        sans = ANNOT_INLINE.sub(" ", ligne)
        if sans != ligne:
            stats["annotations"] += 1
            ligne = re.sub(r"\s{2,}", " ", sans).strip()
            if not _cle(ligne):
                stats["retires"].append(brute.strip())
                continue
        ligne, n = _boucles_dans_ligne(ligne)
        stats["mots_boucles"] += n
        lignes.append(ligne)
    # Boucles de phrases qui enjambent les lignes (« Bonne journée à toi. » × 300)
    sortie, precedente, repet = [], None, 0
    for ligne in lignes:
        gardees = []
        for ph in PHRASE.findall(ligne):
            cle = _cle(ph)
            if not cle:
                gardees.append(ph)
                continue
            repet = repet + 1 if cle == precedente else 1
            precedente = cle
            if repet > MAX_PHRASES_IDENTIQUES:
                stats["mots_boucles"] += len(ph.split())
                continue
            gardees.append(ph)
        ligne = "".join(gardees).strip()
        if _cle(ligne):
            sortie.append(ligne)
    return "\n".join(sortie) + ("\n" if sortie else ""), stats
