# -*- coding: utf-8 -*-
"""Le Mac sur lequel tourne l'app : mémoire, puce, disque libre, version de macOS."""
import functools, os, shutil, subprocess

import journal as JO


def _sysctl(cle):
    try:
        return subprocess.run(["sysctl", "-n", cle], capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception as e_tol:
        JO.ignoree(e_tol)
        return ""


@functools.lru_cache(maxsize=1)
def ram_go():
    """Mémoire du Mac, en Go entiers (24 pour un Mac vendu « 24 Go »)."""
    try:
        return max(1, round(int(_sysctl("hw.memsize")) / 2**30))
    except ValueError:
        return 24


def puce():
    return _sysctl("machdep.cpu.brand_string") or "Apple Silicon"


def disque_libre_go(chemin="~"):
    try:
        return shutil.disk_usage(os.path.expanduser(chemin)).free / 1e9
    except OSError:
        return 0.0


def macos():
    """Version de macOS, en tuple comparable : (26, 4)."""
    try:
        v = subprocess.run(["sw_vers", "-productVersion"], capture_output=True, text=True, timeout=5).stdout.strip()
        return tuple(int(x) for x in v.split(".")[:2])
    except (OSError, ValueError, subprocess.SubprocessError) as e_tol:
        JO.ignoree(e_tol)
        return (0, 0)


# Marge laissée au système et aux autres apps : un modèle plus gros que la RAM moins cette marge
# ne tient pas en mémoire (sous llama.cpp, un MoE passe alors en mode SSD, voir moteurs.py).
MARGE_SYSTEME_GO = 6


def tient_en_memoire(besoin_go, ram=None):
    return besoin_go <= (ram or ram_go()) - MARGE_SYSTEME_GO


def resume():
    ram = ram_go()
    return {"ram_go": ram, "puce": puce(), "disque_libre_go": round(disque_libre_go(), 1), "trop_petit": ram < 16}
