# -*- coding: utf-8 -*-
"""Garde-fous de confidentialité : contrôle automatique du code AVANT toute installation.

L'installateur le lance sur le code à installer avec la version DÉJÀ installée de ce contrôleur :
une mise à jour (même fautive, même écrite par un programme malveillant de la session) ne peut
pas affaiblir les contrôles qui la jugent. Les tests le lancent aussi pendant le développement.

    python3 outils/garde_fous.py RACINE_DU_CODE        (code 0 : conforme ; 1 : refusé)

Règles
  1. Aucune adresse Internet hors des domaines connus de l'app (PubMed, recherche HAS, modèles,
     versions des moteurs, espaces de noms des documents), tests et documentation exceptés.
  2. Aucun outil réseau lancé par l'app (curl, wget, nc, ssh, scp, ftp, telnet) ; dans les scripts
     d'installation, curl vers la boucle locale seulement.
  3. Aucune bibliothèque de mesure d'audience ni de télémétrie.
  4. Serveur de l'app : écoute 127.0.0.1 ; garde réseau installé au démarrage ; politique de contenu
     de la page (connexions vers lui seul, aucun formulaire ailleurs, pas d'affichage en cadre).
  5. Coffre : écoute 127.0.0.1 ; aucune bibliothèque de connexion sortante ; hôte contrôlé ; jeton
     exigé ; jeton d'essai réservé au mode d'essai ; politique de contenu de ses pages.
  6. Fenêtre native : données web non persistantes, inspection désactivée, navigation bornée,
     jeton remis aux seuls cadres du coffre, serveur lancé en Python isolé.
  7. Pages : aucun script, feuille de style ou police chargé d'ailleurs.
  8. Échanges git avec un dépôt distant (fetch, pull, clone, push, ls-remote) : seulement la
     recherche des mises à jour, sur demande (ui/server.py), et la publication (outils/publier.sh).
"""
import os, re, sys

DOMAINES = ("127.0.0.1", "localhost", "127",                       # boucle locale
            "ncbi.nlm.nih.gov", "duckduckgo.com",                    # PubMed, recherche HAS
            "has-sante.fr",
            "huggingface.co", "hf.co",                               # modèles de transcription et de rédaction
            "github.com", "githubusercontent.com",                   # versions publiées de Splash et llama.cpp
            "schemas.openxmlformats.org", "schemas.microsoft.com",   # espaces de noms (.docx)
            "www.w3.org", "purl.org", "www.apple.com")               # espaces de noms (XML, plist)
EXTENSIONS = (".py", ".swift", ".html", ".js", ".css", ".sh", ".json", ".command")
EXCLUS = {"tests", "docs", ".git", "__pycache__", "whisper-cpp", "llama-cpp", "splash"}
OUTILS_RESEAU = re.compile(r"""["'](curl|wget|nc|ncat|ssh|scp|sftp|ftp|telnet)["']""")
GIT_DISTANT = re.compile(r"""["'](fetch|pull|clone|push|ls-remote)["']""")
GIT_DISTANT_SH = re.compile(r"\b(?:git|G)\b(?:\s+(?:-c\s+\S+|-{1,2}[\w-]+(?:=\S+)?))*\s+(fetch|pull|clone|push|ls-remote)\b")
GIT_PERMIS = {"ui/server.py", "outils/publier.sh"}
TELEMETRIE = re.compile(r"sentry_sdk|sentry\.io|mixpanel|posthog|google-analytics|googletagmanager|amplitude\.com|"
                        r"segment\.(io|com)|datadoghq|newrelic|bugsnag|appcenter", re.I)


def fichiers(racine):
    for d, dirs, noms in os.walk(racine):
        dirs[:] = [x for x in dirs if x not in EXCLUS]
        for n in noms:
            if n.endswith(EXTENSIONS) and n != "garde_fous.py":      # sa propre liste de motifs
                yield os.path.join(d, n)


def lire(p):
    try:
        return open(p, encoding="utf-8").read()
    except (OSError, UnicodeDecodeError):
        return ""


def domaine_permis(d):
    d = d.lower().rstrip(".")
    return any(d == x or d.endswith("." + x) for x in DOMAINES)


def controler(racine):
    fautes = []

    def faute(p, ligne, message):
        fautes.append(f"{os.path.relpath(p, racine)}:{ligne} : {message}")

    for p in fichiers(racine):
        t = lire(p)
        for i, l in enumerate(t.splitlines(), 1):
            for m in re.finditer(r"https?://([A-Za-z0-9.-]+)", l):
                if not domaine_permis(m.group(1)):
                    faute(p, i, f"adresse Internet inconnue ({m.group(1)})")
            if TELEMETRIE.search(l):
                faute(p, i, "bibliothèque de télémétrie ou de mesure d'audience")
            if p.endswith((".py", ".swift")) and OUTILS_RESEAU.search(l):
                faute(p, i, f"outil réseau lancé par l'app ({OUTILS_RESEAU.search(l).group(1)})")
            if p.endswith((".sh", ".command")) and re.search(r"\b(curl|wget)\b", l) and not l.lstrip().startswith("#") \
                    and "127.0.0.1" not in l:
                faute(p, i, "curl/wget vers autre chose que la boucle locale")
            rel = os.path.relpath(p, racine)
            if rel not in GIT_PERMIS and not l.lstrip().startswith("#") and (
                    (p.endswith((".py", ".swift")) and GIT_DISTANT.search(l))
                    or (p.endswith((".sh", ".command")) and GIT_DISTANT_SH.search(l.split(" #")[0]))):
                faute(p, i, "échange git avec un dépôt distant hors de la recherche des mises à jour")
            if p.endswith(".html") and re.search(r"""<(script|link|img|iframe)[^>]+(src|href)\s*=\s*["']https?://""", l, re.I):
                faute(p, i, "ressource chargée d'ailleurs")
            if p.endswith((".html", ".css")) and re.search(r"@import\s+url\(\s*['\"]?https?://|url\(\s*['\"]?https?://", l, re.I):
                faute(p, i, "feuille de style ou police chargée d'ailleurs")

    serveur = lire(os.path.join(racine, "ui", "server.py"))
    for motif, message in ((r'(?m)^HOST\s*=\s*"127\.0\.0\.1"', "le serveur de l'app n'écoute plus sur 127.0.0.1 seulement"),
                           (r"(?m)^RN\.installer\(\)", "garde réseau non installé au démarrage du serveur"),
                           (r"connect-src 'self'", "politique de contenu : connexions non limitées au serveur"),
                           (r"script-src 'self';", "politique de contenu : code en ligne permis dans la page"),
                           (r"form-action 'none'", "politique de contenu : formulaires non bloqués"),
                           (r"frame-ancestors 'none'", "politique de contenu : page affichable en cadre"),
                           (r'"Content-Security-Policy": csp_page\(\)', "politique de contenu non envoyée avec la page")):
        if not re.search(motif, serveur):
            fautes.append(f"ui/server.py : {message}")

    reseau = lire(os.path.join(racine, "reseau.py"))
    if "install_opener(urllib.request.build_opener(_Garde()))" not in reseau:
        fautes.append("reseau.py : le garde des sorties réseau a disparu")

    coffre = lire(os.path.join(racine, "coffre", "coffre.py"))
    if coffre:
        for motif, message in ((r'(?m)^HOTE\s*=\s*"127\.0\.0\.1"', "le coffre n'écoute plus sur 127.0.0.1 seulement"),
                               (r"def _hote_refuse", "contrôle de l'hôte du coffre absent"),
                               (r"if self\._hote_refuse\(\):", "contrôle de l'hôte non appliqué"),
                               (r"if not self\._jeton_ok\(\):", "jeton du coffre non exigé"),
                               (r'if TEST and chemin == "/api/jeton-test"', "jeton d'essai délivré hors du mode d'essai"),
                               (r"frame-ancestors http://127\.0\.0\.1", "politique de contenu des pages du coffre affaiblie"),
                               (r"default-src 'none'", "politique de contenu des pages du coffre affaiblie")):
            if not re.search(motif, coffre):
                fautes.append(f"coffre/coffre.py : {message}")
        if coffre.count("if self._hote_refuse():") < 2 or coffre.count("if not self._jeton_ok():") < 2:
            fautes.append("coffre/coffre.py : contrôle de l'hôte ou du jeton manquant sur une méthode HTTP")
        if re.search(r"(?m)^\s*(import|from)\s+(urllib\.request|http\.client|requests|smtplib|ftplib|ssl|telnetlib)\b", coffre) \
                or re.search(r"urllib\.request|http\.client|create_connection\(|\.connect\(\(", coffre):
            fautes.append("coffre/coffre.py : bibliothèque de connexion sortante dans le coffre")

    fenetre = lire(os.path.join(racine, "source", "KineAPP.swift"))
    for motif, message in ((r"websiteDataStore = \.nonPersistent\(\)", "données web écrites sur le disque"),
                           (r"isInspectable = false", "inspection de la page autorisée"),
                           (r"func estCoffre", "navigation vers le coffre non bornée"),
                           (r'case "jeton" where duCoffre', "jeton du coffre remis à d'autres pages que les siennes"),
                           (r'\["-I", SCRIPT\]', "serveur lancé hors du mode isolé de Python"),
                           (r"environnementPropre\(\)", "serveur lancé avec l'environnement de la session")):
        if fenetre and not re.search(motif, fenetre):
            fautes.append(f"source/KineAPP.swift : {message}")
    return fautes


def main():
    racine = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    fautes = controler(racine)
    if fautes:
        print(f"Garde-fous de confidentialité : {len(fautes)} point(s) refusé(s) — rien n'est installé.")
        for f in fautes:
            print("  ✕ " + f)
        return 1
    print("Garde-fous de confidentialité : conformes.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
