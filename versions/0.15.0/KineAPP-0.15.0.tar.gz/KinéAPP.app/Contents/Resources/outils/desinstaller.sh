#!/bin/bash
# Arrête le coffre d'identité et retire son service, sans rien effacer :
#   - les données du coffre (noms, sauvegardes, archives) restent dans
#     /Library/Application Support/KineAPP (lisibles par le compte _kinecoffre seulement) ;
#   - le compte _kinecoffre est gardé (ses fichiers lui appartiennent) ;
#   - l'app reste installée ; sans coffre, elle repasse en mode « noms en clair ».
# Pour remettre une version précédente de l'app : /Library/Application Support/KineAPP/Versions.
#     sudo ./outils/desinstaller.sh
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "À lancer avec sudo : sudo $0"; exit 1; }
SUPPORT="/Library/Application Support/KineAPP"
DAEMON=/Library/LaunchDaemons/fr.kineapp.coffre.plist
launchctl bootout system/fr.kineapp.coffre 2>/dev/null || true
if [ -f "$DAEMON" ]; then
  mkdir -p "$SUPPORT/Désinstallé"
  mv "$DAEMON" "$SUPPORT/Désinstallé/fr.kineapp.coffre.plist.$(date +%Y-%m-%d_%H%M%S)"
fi
# Sans configuration publique, l'app ne cherche plus le coffre (elle est gardée à côté).
if [ -f "$SUPPORT/coffre-public.json" ]; then
  mv "$SUPPORT/coffre-public.json" "$SUPPORT/Désinstallé/coffre-public.json.$(date +%Y-%m-%d_%H%M%S)"
fi
echo "Coffre arrêté. Ses données restent dans $SUPPORT (rien n'est effacé)."
echo "Tapez maintenant :  sudo -k"
