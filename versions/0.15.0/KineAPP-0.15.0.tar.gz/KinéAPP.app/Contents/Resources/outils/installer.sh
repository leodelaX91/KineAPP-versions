#!/bin/bash
# Installation protégée de KinéAPP (refonte du 13/10/2026 : coffre d'identité).
#
#   - L'app devient du code du système (propriétaire root) : ni vous sans mot de passe
#     administrateur, ni aucune app ou agent de votre session ne peut la modifier.
#   - Le coffre d'identité tourne sous un compte système dédié (_kinecoffre), lancé par launchd ;
#     ses données (noms des patients, lien nom <-> code) ne sont lisibles que par ce compte.
#   - Splash, llama.cpp et Whisper sont recopiés dans l'app.
#   - Une fois : les noms des données existantes sont remplacés par des codes (migration), les
#     originaux partant aux archives du coffre. Rien n'est effacé.
#
# À lancer dans le Terminal de macOS (pas dans un terminal partagé avec un assistant), app fermée :
#     sudo ./outils/installer.sh
# puis « sudo -k » pour oublier le mot de passe administrateur.
#
# Répétition sans droits administrateur, tout dans un dossier d'essai :
#     KINECOFFRE_MDP_ESSAI=… ./outils/installer.sh --essai /chemin/essai [--sans-migration]
#
# Migration seule (app déjà installée), par exemple une fois l'app Claude fermée, pour ses
# transcripts et l'historique git du code :
#     sudo ./outils/installer.sh --migration-seule
#
# MISE À JOUR (le code seulement : ni migration, ni mot de passe, données intactes) — d'ordinaire
# par le bouton de l'app (Paramètres → Mises à jour), qui lance la copie INSTALLÉE de ce script :
#     sudo "/Applications/KinéAPP.app/Contents/Resources/outils/installer.sh" --mise-a-jour
# Conditions : commit sans modification en attente, tests réussis sur ce commit précis
# (tests/test_kineapp.py note leur réussite), garde-fous de confidentialité conformes — jugés par
# la version déjà installée du contrôleur. La version remplacée est gardée.
# Retour à la version précédente :
#     sudo "/Applications/KinéAPP.app/Contents/Resources/outils/installer.sh" --revenir
#
# AUTRES MAC (canal GitHub, docs/INSTALLATION.md) : depuis un clone du dépôt,
#     sudo ./outils/installer.sh --distribution
# installe la dernière version PUBLIÉE (étiquette vX.Y.Z signée par la clé de publication de
# l'éditeur, outils/publication/signataires_autorises), sans migration. Les mises à jour suivantes
# (bouton de l'app) n'installent qu'une étiquette plus récente, signée par une clé que connaît l'app
# DÉJÀ installée : un compte GitHub volé ne suffit pas à faire installer du code. L'installateur ne
# se connecte jamais à Internet ; c'est l'app qui récupère les étiquettes, sur votre demande.
#
# PAQUET (Mac des collègues, sans Terminal ni outils de développement) : une version DÉJÀ construite par
# l'éditeur (outils/construire_version.sh) : archive de l'app + manifeste signé (ssh-keygen -Y sign,
# espace « kineapp-version »). Première installation par le paquet .pkg (outils/construire_pkg.sh, dont le
# script postinstall lance ce mode) ; mises à jour par le bouton de l'app, qui télécharge la version :
#     installer.sh [--mise-a-jour] --paquet DOSSIER      (DOSSIER : manifeste.json, manifeste.json.sig, archive)
# Ni git, ni compilation, ni Python du système : celui de l'archive. Signature vérifiée avec les clés de l'app
# DÉJÀ installée (à la première installation : celles du paquet), version plus récente exigée, garde-fous
# jugés par la version installée. Le mot de passe du coffre est choisi dans l'app, au premier lancement.
set -euo pipefail

SRC="$(cd "$(dirname "$0")/.." && pwd)"
ESSAI=""; PORT=47821; MIGRER=1; SEULE=0; MAJ=0; REVENIR=0; MOTEURS_SEULS=0; DEPUIS_APP=0; UTIL_DONNE=""; DISTRIBUTION=0; PAQUET=""
SIGNATAIRES_PAQUET=""
while [ $# -gt 0 ]; do
  case "$1" in
    --essai) ESSAI="${2%/}"; shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    --sans-migration) MIGRER=0; shift ;;
    --migration-seule) SEULE=1; shift ;;
    --mise-a-jour) MAJ=1; MIGRER=0; shift ;;
    --revenir) REVENIR=1; shift ;;
    --moteurs-seuls) MOTEURS_SEULS=1; MIGRER=0; shift ;;       # version de moteur reçue par l'app, sans toucher au code
    --depuis-app) DEPUIS_APP=1; shift ;;                       # lancé par le bouton de l'app (sans terminal)
    --utilisateur) UTIL_DONNE="$2"; shift 2 ;;
    --distribution) DISTRIBUTION=1; MIGRER=0; shift ;;                  # autre Mac : canal GitHub
    --paquet) PAQUET="${2%/}"; MIGRER=0; shift 2 ;;                     # version construite et signée (Mac des collègues)
    --signataires) SIGNATAIRES_PAQUET="$2"; shift 2 ;;                 # première installation par le .pkg : clés du paquet
    *) echo "Option inconnue : $1"; exit 2 ;;
  esac
done

P="$ESSAI"                                   # préfixe : vide en vrai
APP="$P/Applications/KinéAPP.app"
SUPPORT="$P/Library/Application Support/KineAPP"
COFFRE="$SUPPORT/Coffre"
SAUV="$SUPPORT/Sauvegardes du coffre"
VERSIONS="$SUPPORT/Versions"
LOGS="$P/Library/Logs/KineAPP"
DAEMON="$P/Library/LaunchDaemons/fr.kineapp.coffre.plist"
COMPTE=_kinecoffre
PY=/usr/bin/python3
# Paquet : jamais le Python du système (sans les outils de développement d'Apple, il ouvre une fenêtre
# d'installation) ; celui de l'app installée, ou plus bas celui de l'archive vérifiée.
if [ -n "$PAQUET" ] && [ -x "$APP/Contents/Resources/python/bin/python3" ]; then PY="$APP/Contents/Resources/python/bin/python3"; fi

titre() { printf '\n== %s\n' "$1"; }
oui() { case "$1" in o|O|oui|Oui|OUI) return 0 ;; *) return 1 ;; esac; }    # « oui » valait « non » (14/10/2026)
racine() { [ -z "$ESSAI" ]; }

if racine; then
  [ "$(id -u)" = 0 ] || { echo "À lancer avec sudo : sudo $0"; exit 1; }
  UTIL="${SUDO_USER:-$UTIL_DONNE}"
  { [ -n "$UTIL" ] && [ "$UTIL" != root ] && id "$UTIL" >/dev/null 2>&1; } \
    || { echo "Lancez l'installation avec sudo depuis votre session."; exit 1; }
else
  UTIL="$(id -un)"
fi
# Dépôt git et copie de développement : notés à l'installation (depot.json), pour que la copie
# INSTALLÉE de ce script (bouton de l'app) sache où prendre une mise à jour.
DEPOT_JSON="$SUPPORT/depot.json"
lire_depot() { "$PY" -c 'import json,sys; print(json.load(open(sys.argv[1])).get(sys.argv[2], ""))' "$DEPOT_JSON" "$1" 2>/dev/null || true; }
# Copie installée (bouton de l'app) : on compare les dossiers eux-mêmes, pas leurs noms. Le chemin
# donné par l'app peut écrire « é » en deux caractères (e + accent) : une comparaison de textes
# échouait (14/10/2026 : l'app installée prise pour la copie de développement).
if [ -d "$APP" ] && [ "$(dirname "$(dirname "$SRC")")" -ef "$APP" ]; then
  SRC="$(lire_depot travail)"
  [ -n "$SRC" ] || [ "$REVENIR" = 1 ] || [ "$MOTEURS_SEULS" = 1 ] || [ -n "$PAQUET" ] || { echo "Copie de développement inconnue (depot.json)."; exit 1; }
fi

# ── Paquet : signature et archive vérifiées AVANT de lire quoi que ce soit dedans (outils du système seuls) ──
if [ -n "$PAQUET" ]; then
  MANIF="$PAQUET/manifeste.json"
  [ -f "$MANIF" ] && [ -f "$MANIF.sig" ] || { echo "Paquet incomplet (manifeste ou signature absents)."; exit 1; }
  SIGN_P="$APP/Contents/Resources/outils/publication/signataires_autorises"
  if [ ! -f "$SIGN_P" ]; then                        # première installation : clés livrées avec le paquet
    SIGN_P="$SIGNATAIRES_PAQUET"
    [ -n "$SIGN_P" ] && [ -f "$SIGN_P" ] || { echo "Clés de publication introuvables."; exit 1; }
  fi
  IDENT=$(grep -v '^#' "$SIGN_P" | awk 'NF {print $1; exit}')
  /usr/bin/ssh-keygen -Y verify -f "$SIGN_P" -I "$IDENT" -n kineapp-version -s "$MANIF.sig" < "$MANIF" >/dev/null 2>&1 \
    || { echo "Version non signée par l'éditeur de KinéAPP : rien n'est installé."; exit 1; }
  champ() { /usr/bin/plutil -extract "$1" raw -o - "$MANIF" 2>/dev/null || true; }
  VPAQ=$(champ version); SHA_P=$(champ sha256); ARCH_P="$PAQUET/KineAPP-$VPAQ.tar.gz"
  [[ "$VPAQ" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$SHA_P" =~ ^[0-9a-f]{64}$ ]] || { echo "Manifeste invalide."; exit 1; }
  [ -f "$ARCH_P" ] || { echo "Archive absente : $ARCH_P"; exit 1; }
  [ "$(/usr/bin/shasum -a 256 "$ARCH_P" | awk '{print $1}')" = "$SHA_P" ] || { echo "Archive altérée (empreinte différente) : rien n'est installé."; exit 1; }
  PTMP=$(mktemp -d /tmp/kineapp-paquet.XXXXXX)
  trap 'rm -rf "$PTMP"' EXIT
  /usr/bin/tar -xzf "$ARCH_P" -C "$PTMP"
  [ -d "$PTMP/KinéAPP.app/Contents/Resources" ] || { echo "Archive sans KinéAPP.app."; exit 1; }
  [ -z "$(find "$PTMP" -type l -not -path "*/python/*")" ] || { echo "Liens symboliques dans l'archive : refusé."; exit 1; }
  # Python : celui de l'app installée s'il existe, sinon celui de l'archive (vérifiée) ; jamais celui du
  # système, absent sans les outils de développement d'Apple.
  if [ -x "$APP/Contents/Resources/python/bin/python3" ]; then PY="$APP/Contents/Resources/python/bin/python3"
  else PY="$PTMP/KinéAPP.app/Contents/Resources/python/bin/python3"; fi
  VCODE_P=$("$PY" -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["version"])' "$PTMP/KinéAPP.app/Contents/Resources/version.json")
  [ "$VCODE_P" = "$VPAQ" ] || { echo "Version du manifeste ($VPAQ) et du code ($VCODE_P) différentes : refusé."; exit 1; }
fi
VRAIE_MAISON=$(dscl . -read "/Users/$UTIL" NFSHomeDirectory | awk '{print $2}')
# En essai, la migration travaille sur un dossier personnel FICTIF ($ESSAI/maison), jamais sur le vrai.
if racine; then MAISON="$VRAIE_MAISON"; else MAISON="$ESSAI/maison"; fi
comme_util() { if racine; then sudo -u "$UTIL" "$@"; else "$@"; fi; }
comme_coffre() { if racine; then (cd / && sudo -u "$COMPTE" "$@"); else "$@"; fi; }

DEMANDE_MOTEURS="$MAISON/Library/Application Support/BilanKine/moteurs_a_reprendre.json"
demande_moteur() { "$PY" -I -c 'import json,sys; print((json.load(open(sys.argv[1])).get(sys.argv[2]) or {}).get("quoi", ""))' "$DEMANDE_MOTEURS" "$1" 2>/dev/null || true; }
copier_moteur() {      # SOURCE DESTINATION : un dossier de moteur entier, sans liens
  rm -rf "$2"; mkdir -p "$2"; cp -RL "$1/." "$2/"
  [ -z "$(find "$2" -type l)" ] || { echo "Liens symboliques dans $(basename "$2") : refusé."; exit 1; }
}
champ_demande() { "$PY" -I -c 'import json,sys; print((json.load(open(sys.argv[1])).get(sys.argv[2]) or {}).get(sys.argv[3], ""))' "$DEMANDE_MOTEURS" "$1" "$2" 2>/dev/null || true; }
recevoir_moteur() {    # CLÉ DESTINATION BINAIRE DOSSIER_DES_OUTILS : version téléchargée par l'app, vérifiée ici
  "$PY" -I "$4/moteur_recu.py" "$(champ_demande "$1" archive)" "$(champ_demande "$1" sha256)" \
    "$MAISON/Library/Application Support/BilanKine/moteurs_recus" "$3" "$2" "$(champ_demande "$1" version)" \
    "$(champ_demande "$1" archive_ggml)" "$(champ_demande "$1" sha256_ggml)"
}
signer_moteurs() {     # DOSSIER_DES_OUTILS
  local WD
  for WD in "$1/"{whisper,llama}-cpp{,-precedent}; do
    # Bibliothèques des moteurs signées une à une, sans runtime durci : signées sans équipe, elles ne
    # pourraient pas être chargées par un programme durci. Splash garde la signature de son archive.
    if [ -d "$WD" ]; then
      find "$WD" -type f \( -name '*.dylib' -o -name whisper-server -o -name llama-server \) -exec codesign --force --sign - {} \;
    fi
  done
}
if [ "$MOTEURS_SEULS" = 1 ]; then
  # Bouton de l'app : la version de moteur reçue (ou la précédente) remplace l'actuelle ; le code de
  # l'app ne change pas. Sans tests ni garde-fous : ils jugent le code, et le moteur en reste séparé
  # (programme à part, écoute sur 127.0.0.1, connexions surveillées, --offline pour Splash).
  RES="$APP/Contents/Resources"
  [ -d "$RES/outils" ] || { echo "App introuvable."; exit 1; }
  titre "Moteurs"
  FAIT=0
  for L in "splash splash install/launcher.py" "llama llama-cpp llama-server" "whisper whisper-cpp whisper-server"; do
    read -r CLE D BIN <<< "$L"
    W="$RES/outils/$D"
    case "$(demande_moteur "$CLE")" in
      telecharge)
        recevoir_moteur "$CLE" "$W.nouveau" "$BIN" "$RES/outils" || { echo "Rien n'est installé."; rm -rf "$W.nouveau"; exit 1; }
        rm -rf "$W-precedent"
        if [ -e "$W" ]; then mv "$W" "$W-precedent"; fi
        mv "$W.nouveau" "$W"
        FAIT=1; echo "$D : version $(champ_demande "$CLE" version) installée" ;;
      precedent)
        if [ -f "$W-precedent/$BIN" ]; then
          mv "$W" "$W.echange"; mv "$W-precedent" "$W"; mv "$W.echange" "$W-precedent"
          FAIT=1; echo "$D : retour à la version précédente"
        fi ;;
    esac
  done
  [ "$FAIT" = 1 ] || { echo "Déjà à jour."; exit 0; }
  signer_moteurs "$RES/outils"
  codesign --force --sign - --options runtime --entitlements "$RES/outils/bundle/KineAPP.entitlements" "$APP"
  codesign --verify --strict "$APP"
  if racine; then chown -R root:wheel "$APP"; chmod -R u+rwX,go+rX,go-w "$APP"; fi
  titre "Terminé"
  echo "Moteurs installés."
  exit 0
fi

ranger() {
  # Tous les fichiers de l'app dans le dossier KinéAPP (Documents, ou Bureau si choisi dans l'app ;
  # déplacés, jamais copiés ni effacés), sous
  # le compte de l'utilisateur : le rangement n'a besoin d'aucun droit administrateur.
  titre "Rangement dans le dossier KinéAPP"
  comme_util "$PY" -I "$R_OUTILS/ranger.py" --maison "$MAISON"
}

migrer() {
  titre "Migration des données existantes vers des codes"
  HIST=()
  for h in "$MAISON/Documents/KinéAPP/Bancs" "$MAISON/Documents/KinéAPP/Rapports" \
           "$MAISON/Desktop/KinéAPP/Bancs" "$MAISON/Desktop/KinéAPP/Rapports" \
           "$MAISON/.claude/projects/-Users-$UTIL-Desktop-Claude/memory" \
           "$MAISON/Documents/KineAPP-bancs" "$MAISON/Desktop/heidi.md"; do       # anciens emplacements, s'il en reste
    [ -e "$h" ] && HIST+=(--historique "$h")
  done
  for h in "$MAISON/Desktop/Claude/"*KinéAPP*.md "$MAISON/Desktop/Claude/"*Heidi*.md "$MAISON/Desktop/Claude/Analyse des comptes rendus"*.md; do
    [ -e "$h" ] && HIST+=(--historique "$h")
  done
  # Transcripts de Claude Code et historique git du code : noms remplacés par les codes (le lien
  # avec le dossier est gardé, le nom n'y est plus). Claude doit être fermé : il écrit ses
  # transcripts en continu, et le dépôt git ne doit pas changer pendant la réécriture.
  CLAUDE=()
  if racine && pgrep -f "/Applications/Claude.app/Contents/MacOS/Claude|(^|/)claude( |$)" >/dev/null; then
    echo "L'app Claude (ou Claude Code) est ouverte : ses transcripts et l'historique git du code seront"
    echo "traités plus tard. Quittez-la, puis lancez :  sudo ./outils/installer.sh --migration-seule"
  else
    for c in "$MAISON/.claude/projects" "$MAISON/.claude/file-history" \
             "$MAISON/Library/Application Support/Claude/claude-code-sessions"; do
      [ -e "$c" ] && CLAUDE+=(--claude "$c")
    done
    if racine; then DEPOT_MIG="$DEPOT"; TRAVAIL_MIG="$SRC"
    else DEPOT_MIG="$MAISON/Developer/Essai.git"; TRAVAIL_MIG="$MAISON/Developer/essai"; fi   # jamais le vrai dépôt en essai
    [ -d "$DEPOT_MIG" ] && CLAUDE+=(--depot-git "$DEPOT_MIG" --travail "$TRAVAIL_MIG")
    if racine; then CLAUDE+=(--claude-ferme); fi           # vérifié ci-dessus : aucun transcript en cours
  fi
  MIG="$APP/Contents/Resources/outils/migration.py"
  echo "Répétition à blanc (rien n'est écrit) :"
  "$PY" -I "$MIG" --utilisateur "$UTIL" --maison "$MAISON" --coffre "$COFFRE" ${HIST[@]+"${HIST[@]}"} \
        ${CLAUDE[@]+"${CLAUDE[@]}"} --essai
  if [ -n "$ESSAI" ]; then R=o; else read -r -p "Lancer la migration ? (o/N) " R; fi
  if oui "$R"; then
    "$PY" -I "$MIG" --utilisateur "$UTIL" --maison "$MAISON" --coffre "$COFFRE" ${HIST[@]+"${HIST[@]}"} \
          ${CLAUDE[@]+"${CLAUDE[@]}"}
  else
    echo "ATTENTION : migration non lancée. Les noms des patients restent en clair dans vos dossiers, lisibles par"
    echo "toute app de votre session. Pour la faire, KinéAPP fermée :"
    echo "  sudo \"/Applications/KinéAPP.app/Contents/Resources/outils/installer.sh\" --migration-seule"
  fi
  if racine; then chown -R "$COMPTE:$COMPTE" "$COFFRE"; chmod -R go-rwx "$COFFRE"; fi
}

titre "Vérifications"
if racine && [ "$DEPUIS_APP" = 1 ]; then
  # Lancé par l'app : sa fenêtre reste ouverte, mais elle a arrêté son serveur (aucune séance en cours).
  if pgrep -f "Resources/ui/server.py" >/dev/null; then
    echo "Le serveur de KinéAPP tourne encore : mise à jour impossible pendant une séance ou un traitement."; exit 1
  fi
elif racine && pgrep -f "Contents/MacOS/KineAPP|Resources/ui/server.py" >/dev/null; then   # sans accent : écrit de deux façons
  echo "KinéAPP est ouverte : quittez-la (séance terminée), puis relancez l'installation."; exit 1
fi
if racine && [ "$MAJ" = 1 ] && pgrep -f "banc_|enchainer" >/dev/null; then
  echo "Un banc d'essai tourne (il utilise les moteurs) : mise à jour remise à plus tard."; exit 1
fi
[ "$(uname -m)" = arm64 ] || { echo "Mac Apple Silicon requis."; exit 1; }
"$PY" -c 'import sys; assert sys.version_info >= (3, 9)' || { echo "Python 3.9+ du système requis (xcode-select --install)."; exit 1; }
if [ -n "$PAQUET" ]; then SRC="paquet $VPAQ"; fi
echo "Utilisateur : $UTIL ; source : $SRC${ESSAI:+ ; ESSAI dans $ESSAI}"

redemarrer_coffre() {
  if racine && [ -f "$DAEMON" ]; then
    launchctl bootout system/fr.kineapp.coffre 2>/dev/null || true
    launchctl bootstrap system "$DAEMON"
    launchctl enable system/fr.kineapp.coffre
    sleep 2
    if curl -s --max-time 3 "http://127.0.0.1:$PORT/api/sante" | grep -q '"ok": true'; then
      echo "coffre en service sur 127.0.0.1:$PORT"
    else
      echo "ATTENTION : le coffre ne répond pas. Journal : $LOGS/coffre.log"
    fi
  fi
}

elaguer_versions() {
  # Cinq versions protégées gardées (≈ 30 Mo chacune) ; les plus anciennes vont à la Corbeille
  # (jamais effacées). Un échec ici n'affecte pas l'installation, déjà faite.
  local n=0 v d
  for v in "$VERSIONS"/KinéAPP*.app; do
    if [ -f "$v/Contents/Resources/VERSION" ]; then n=$((n+1)); fi
  done
  for v in "$VERSIONS"/KinéAPP*.app; do
    if [ "$n" -le 5 ]; then break; fi
    if [ -f "$v/Contents/Resources/VERSION" ]; then
      d="$MAISON/.Trash/$(basename "$v")"
      if [ ! -e "$d" ] && mkdir -p "$MAISON/.Trash" && mv "$v" "$d"; then
        if racine; then chown -R "$UTIL" "$d" || true; fi
        echo "ancienne version mise à la Corbeille : $(basename "$v")"
      else
        echo "ancienne version à mettre à la Corbeille à la main : $v"
      fi
      n=$((n-1))
    fi
  done
  return 0
}

if [ "$REVENIR" = 1 ]; then
  titre "Retour à la version précédente"
  PREC=""
  # La plus récente, hors versions remplacées par un retour, et seulement une version protégée
  # (installée par cet installateur : elle porte un fichier VERSION).
  for v in "$VERSIONS"/KinéAPP*.app; do
    case "$v" in *"(remplacée)"*) ;; *) if [ -f "$v/Contents/Resources/VERSION" ]; then PREC="$v"; fi ;; esac
  done
  [ -n "$PREC" ] || { echo "Aucune version précédente protégée n'est gardée."; exit 1; }
  mv "$APP" "$VERSIONS/KinéAPP $(date +%Y-%m-%d_%H%M%S) (remplacée).app"
  mv "$PREC" "$APP"
  ANCIENNE=$(cut -d' ' -f1 "$APP/Contents/Resources/VERSION" 2>/dev/null || echo inconnue)
  echo "$ANCIENNE" > "$SUPPORT/version-installee.txt"
  echo "version remise : $ANCIENNE ($(basename "$PREC"))"
  redemarrer_coffre
  titre "Terminé"
  echo "Version précédente remise en place. La version remplacée est gardée dans $VERSIONS."
  exit 0
fi

if [ "$SEULE" = 1 ]; then
  [ -f "$APP/Contents/Resources/outils/migration.py" ] && [ -d "$COFFRE" ] \
    || { echo "KinéAPP et son coffre doivent d'abord être installés (sudo ./outils/installer.sh)."; exit 1; }
  DEPOT="${KINEAPP_DEPOT:-$VRAIE_MAISON/Developer/KineAPP.git}"
  G() { comme_util git --git-dir="$DEPOT" --work-tree="$SRC" "$@"; }
  R_OUTILS="$APP/Contents/Resources/outils"
  ranger
  migrer
  if [ -d "$DEPOT" ] && [ -f "$SUPPORT/version-installee.txt" ]; then
    # Histoire réécrite : le même code porte un autre identifiant de commit.
    G rev-parse --short HEAD > "$SUPPORT/version-installee.txt" 2>/dev/null || true
  fi
  titre "Terminé"
  echo "Migration faite. Tapez maintenant :  sudo -k"
  exit 0
fi

if [ "$MAJ" = 1 ] && { [ ! -d "$APP" ] || [ ! -d "$COFFRE" ]; }; then
  echo "KinéAPP et son coffre doivent d'abord être installés (installation complète)."; exit 1
fi

titre "Compte système du coffre ($COMPTE)"
if racine; then
  if dscl . -read "/Users/$COMPTE" >/dev/null 2>&1; then
    echo "déjà présent"
  else
    PRIS=$( (dscl . -list /Users UniqueID; dscl . -list /Groups PrimaryGroupID) | awk '{print $2}')
    ID=""
    for i in $(seq 401 499); do echo "$PRIS" | grep -qx "$i" || { ID=$i; break; }; done
    [ -n "$ID" ] || { echo "Aucun identifiant libre entre 401 et 499."; exit 1; }
    dscl . -create "/Groups/$COMPTE"
    dscl . -create "/Groups/$COMPTE" PrimaryGroupID "$ID"
    dscl . -create "/Groups/$COMPTE" RealName "Coffre KinéAPP"
    dscl . -create "/Groups/$COMPTE" Password '*'
    dscl . -create "/Users/$COMPTE"
    dscl . -create "/Users/$COMPTE" UniqueID "$ID"
    dscl . -create "/Users/$COMPTE" PrimaryGroupID "$ID"
    dscl . -create "/Users/$COMPTE" UserShell /usr/bin/false
    dscl . -create "/Users/$COMPTE" NFSHomeDirectory /var/empty
    dscl . -create "/Users/$COMPTE" RealName "Coffre KinéAPP"
    dscl . -create "/Users/$COMPTE" Password '*'
    dscl . -create "/Users/$COMPTE" IsHidden 1
    echo "créé (identifiant $ID, sans mot de passe de connexion, sans dossier personnel)"
  fi
else
  echo "(essai : pas de compte créé)"
fi

titre "Version à installer"
if [ -n "$PAQUET" ]; then
  # Version construite et signée par l'éditeur : plus récente que celle installée, sinon rien.
  VINST=$("$PY" -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["version"])' "$APP/Contents/Resources/version.json" 2>/dev/null || echo "")
  if [ -n "$VINST" ] && ! "$PY" -I -c 'import sys; a,b=[tuple(map(int,x.split("."))) for x in sys.argv[1:]]; sys.exit(0 if a>b else 1)' "$VPAQ" "$VINST"; then
    echo "Déjà à jour : la version $VINST est installée (version reçue : $VPAQ)."; exit 0
  fi
  VERSION=$(champ commit); [[ "$VERSION" =~ ^[0-9a-f]{4,40}$ ]] || VERSION="$VPAQ"
  echo "KinéAPP $VPAQ (version signée par l'éditeur, tests passés avant publication)"
  "$PY" -I -c 'import json,sys; [print("  - " + c) for c in json.load(open(sys.argv[1])).get("changements", [])[:40]]' "$MANIF" || true
  PRECEDENTE=$(cat "$SUPPORT/version-installee.txt" 2>/dev/null || true)
  DEPOT=""; CANAL=paquet; REV=""
  if racine && [ "$DEPUIS_APP" = 0 ] && [ -t 0 ]; then
    read -r -p "Installer cette version ? (o/N) " REP
    oui "$REP" || { echo "Rien n'est installé."; exit 1; }
  fi
else
# Le code installé devient du code du système : on installe exactement les fichiers suivis par git
# d'un commit, après les avoir montrés (un programme de la session qui modifierait la copie de
# développement ne passe pas inaperçu).
DEPOT="${KINEAPP_DEPOT:-$(lire_depot depot)}"
[ -n "$DEPOT" ] || { [ -d "$SRC/.git" ] && DEPOT="$SRC/.git"; } || true          # clone ordinaire (autre Mac)
[ -n "$DEPOT" ] || DEPOT="$VRAIE_MAISON/Developer/KineAPP.git"
[ -d "$DEPOT" ] || { echo "Dépôt git introuvable : $DEPOT"; exit 1; }
G() { comme_util git --git-dir="$DEPOT" --work-tree="$SRC" "$@"; }
CANAL="$(lire_depot canal)"
if [ "$DISTRIBUTION" = 1 ]; then CANAL=github; fi
[ -n "$CANAL" ] || CANAL=local
REV=HEAD
if [ "$CANAL" = github ]; then
  # Dernière étiquette publiée, signée par une clé connue : celle de l'app installée (mise à jour),
  # ou, à la première installation, celle du clone (empreinte montrée, à comparer à celle donnée par
  # l'éditeur).
  SIGNATAIRES="$APP/Contents/Resources/outils/publication/signataires_autorises"
  if [ ! -f "$SIGNATAIRES" ]; then
    SIGNATAIRES="$SRC/outils/publication/signataires_autorises"
    [ -f "$SIGNATAIRES" ] || { echo "Clé de publication introuvable dans le clone."; exit 1; }
    echo "Première installation : clé de publication du clone, à comparer avec celle que l'éditeur vous a donnée :"
    grep -v '^#' "$SIGNATAIRES" | awk '{print $3" "$4}' | ssh-keygen -lf - 2>/dev/null | sed 's/^/  /' || true
  fi
  VERIF=$(mktemp)
  cp "$SIGNATAIRES" "$VERIF"; chmod 644 "$VERIF"
  REV=""
  for t in $(G tag -l 'v[0-9]*.[0-9]*.[0-9]*' --sort=-version:refname); do
    if G -c gpg.format=ssh -c gpg.ssh.allowedSignersFile="$VERIF" verify-tag "$t" >/dev/null 2>&1; then REV="$t"; break; fi
    echo "étiquette $t ignorée : signature absente ou inconnue"
  done
  rm -f "$VERIF"
  [ -n "$REV" ] || { echo "Aucune version publiée et signée par l'éditeur : rien n'est installé."; exit 1; }
  # Le numéro de l'étiquette doit être celui du code, et plus récent que la version installée :
  # une ancienne version signée, ré-étiquetée, ne peut pas revenir par ce chemin.
  VTAG="${REV#v}"
  VCODE=$(G show "$REV:version.json" | "$PY" -c 'import json,sys; print(json.load(sys.stdin)["version"])')
  [ "$VTAG" = "$VCODE" ] || { echo "Étiquette $REV et version du code ($VCODE) différentes : refusé."; exit 1; }
  VINST=$("$PY" -c 'import json,sys; print(json.load(open(sys.argv[1]))["version"])' "$APP/Contents/Resources/version.json" 2>/dev/null || echo "")
  if [ -n "$VINST" ] && ! "$PY" -c 'import sys; a,b=[tuple(map(int,x.split("."))) for x in sys.argv[1:]]; sys.exit(0 if a>b else 1)' "$VTAG" "$VINST"; then
    echo "Déjà à jour : la version $VINST est installée (dernière publiée : $VTAG)."; exit 0
  fi
  echo "Version publiée signée : $REV"
elif [ -n "$(G status --porcelain --untracked-files=no)" ]; then
  echo "Des fichiers suivis ont des modifications non enregistrées (git commit) : rien n'est installé."; exit 1
fi
# Un lien symbolique dans l'app protégée pourrait pointer vers un fichier que la session modifie.
if [ -n "$(G ls-tree -r "$REV" | awk '$1 == "120000"')" ]; then
  echo "Le commit contient des liens symboliques : refusé (l'app protégée ne doit contenir que des fichiers)."; exit 1
fi
VERSION=$(G rev-parse --short "$REV^{commit}")
echo "Commit : $(G log -1 --format='%h %s' "$REV")"
PRECEDENTE=$(cat "$SUPPORT/version-installee.txt" 2>/dev/null || true)
if [ "$MAJ" = 1 ] && [ "$PRECEDENTE" = "$VERSION" ]; then
  echo "Déjà à jour : la version $VERSION est installée."; exit 0
fi
if [ -n "$PRECEDENTE" ] && G cat-file -e "$PRECEDENTE^{commit}" 2>/dev/null; then
  echo "Changements depuis la version installée ($PRECEDENTE) :"
  G log --format='  %h %s' "$PRECEDENTE..$REV" | head -40
fi
# Fiabilité : les tests automatiques doivent avoir réussi sur CE commit (tests/test_kineapp.py note
# l'arbre qu'il a validé). Pour la confidentialité, ce sont les garde-fous qui jugent (plus bas).
# Canal GitHub : l'éditeur ne signe qu'un commit testé (outils/publier.sh) ; la signature en tient lieu.
ARBRE=$(G rev-parse "$REV^{tree}")
if [ "$CANAL" = github ]; then
  echo "Tests passés par l'éditeur avant publication (version signée)."
elif "$PY" -c 'import json,sys; d=json.load(open(sys.argv[1])); sys.exit(0 if d.get("arbre")==sys.argv[2] and d.get("echecs")==0 else 1)' \
     "$SRC/.tests-reussis.json" "$ARBRE" 2>/dev/null; then
  echo "Tests automatiques réussis sur ce commit ($("$PY" -c 'import json,sys; d=json.load(open(sys.argv[1])); print(d.get("reussis"), "contrôles, le", d.get("date"))' "$SRC/.tests-reussis.json"))."
elif [ "$MAJ" = 1 ]; then
  echo "Les tests automatiques n'ont pas été passés (ou pas réussis) sur ce commit : rien n'est installé."
  echo "Demandez à Claude de lancer les tests (python3 tests/test_kineapp.py) et de valider (commit) exactement"
  echo "le code testé."; exit 1
else
  echo "ATTENTION : pas de réussite des tests notée pour ce commit."
fi
if racine && [ "$DEPUIS_APP" = 0 ]; then
  read -r -p "Installer cette version ? (o/N) " REP
  oui "$REP" || { echo "Rien n'est installé."; exit 1; }
fi
fi

titre "Assemblage"
if [ -n "$PAQUET" ]; then
  # L'app construite par l'éditeur (fenêtre compilée, Python embarqué), sortie de l'archive vérifiée.
  B="$PTMP/KinéAPP.app"
  R="$B/Contents/Resources"
  [ -x "$B/Contents/MacOS/KineAPP" ] && file -b "$B/Contents/MacOS/KineAPP" | grep -q "Mach-O 64-bit executable arm64" \
    || { echo "Archive sans fenêtre compilée pour ce Mac : refusé."; exit 1; }
  VSEM="$VPAQ"
  echo "KinéAPP $VSEM (commit $VERSION)"
else
# Dossier de travail accessible au seul administrateur : rien ne peut y être substitué pendant
# l'installation.
TMP=$(mktemp -d /tmp/kineapp-installation.XXXXXX)
trap 'rm -rf "$TMP"' EXIT
B="$TMP/KinéAPP.app"
R="$B/Contents/Resources"
mkdir -p "$B/Contents/MacOS" "$R"
# Contenu exact du commit (et non des fichiers du dossier, modifiables entre-temps).
G archive --format=tar "$REV" | tar -x -C "$R"
cp "$R/outils/bundle/Info.plist" "$B/Contents/Info.plist"
echo "$VERSION $(date +%d/%m/%Y)" > "$R/VERSION"
VSEM=$("$PY" -c 'import json,sys; print(json.load(open(sys.argv[1]))["version"])' "$R/version.json" 2>/dev/null || echo 0.0.0)
plutil -replace CFBundleShortVersionString -string "$VSEM" "$B/Contents/Info.plist"
plutil -replace CFBundleVersion -string "$VSEM" "$B/Contents/Info.plist"
echo "$(G ls-tree -r --name-only "$REV" | wc -l | tr -d ' ') fichiers du commit $VERSION (KinéAPP $VSEM)"
fi

titre "Garde-fous de confidentialité"
# Jugés par le contrôleur de la version DÉJÀ installée : une mise à jour ne peut pas assouplir
# les règles qui la jugent (à la première installation, celui du commit).
GF="$APP/Contents/Resources/outils/garde_fous.py"
[ -f "$GF" ] || GF="$R/outils/garde_fous.py"
# Paquet : le Python livré (bibliothèque standard) est jugé par son empreinte, pas par les garde-fous du code de l'app,
# comme dans l'installation habituelle où il est ajouté après eux.
if [ -n "$PAQUET" ]; then mv "$R/python" "$PTMP/python-de-cote"; GFPY="$PTMP/python-de-cote/bin/python3"
  [ -x "$APP/Contents/Resources/python/bin/python3" ] && GFPY="$APP/Contents/Resources/python/bin/python3"; PY="$GFPY"; fi
if ! "$PY" -I "$GF" "$R"; then
  # Une version qui assouplit les règles elles-mêmes (un nouveau site, par exemple) n'est jamais
  # installée par le bouton de l'app : seulement dans le Terminal, après lecture du changement.
  if [ "$DEPUIS_APP" = 1 ] || [ -n "$PAQUET" ] || [ "$GF" = "$R/outils/garde_fous.py" ] \
     || ! "$PY" -I "$R/outils/garde_fous.py" "$R" >/dev/null; then
    echo "Rien n'est installé."; exit 1
  fi
  echo "Cette version change les règles des garde-fous elles-mêmes. Changement des règles :"
  if [ -n "$PRECEDENTE" ] && G cat-file -e "$PRECEDENTE^{commit}" 2>/dev/null; then
    G --no-pager diff "$PRECEDENTE..$REV" -- outils/garde_fous.py || true
  fi
  if racine; then read -r -p "Accepter ces nouvelles règles ? (o/N) " REP; else REP="${KINEAPP_ACCEPTER_REGLES:-n}"; fi
  oui "$REP" || { echo "Rien n'est installé."; exit 1; }
fi

if [ -n "$PAQUET" ]; then
  mv "$PTMP/python-de-cote" "$R/python"
  if [ -x "$APP/Contents/Resources/python/bin/python3" ]; then PY="$APP/Contents/Resources/python/bin/python3"; else PY="$R/python/bin/python3"; fi
fi

titre "Compilation de la fenêtre native"
if [ -n "$PAQUET" ]; then
  echo "déjà compilée par l'éditeur (version signée)"
else
  xcrun swiftc -parse-as-library -O -target arm64-apple-macos12.0 -o "$B/Contents/MacOS/KineAPP" "$R/source/KineAPP.swift"
  echo "ok"
fi
# Moteurs intégrés (Splash, llama.cpp, whisper.cpp) : DANS l'app, sans liens symboliques (-L : leur
# contenu), pour qu'aucun renvoi vers un dossier modifiable par la session ne subsiste dans l'app
# protégée. Une mise à jour garde la version installée, sauf demande du praticien dans l'app
# (moteurs_a_reprendre.json, moteurs_integres.py) : « telecharge » installe la version reçue,
# « precedent » remet celle d'avant. La version remplacée est gardée à côté (<dossier>-precedent).
# Un moteur absent se télécharge depuis l'app (Paramètres → IA), comme ses mises à jour.
integrer_moteur() {    # CLÉ NOM DOSSIER BINAIRE [SOURCE_LOCALE : première installation, si elle existe]
  local cle=$1 nom=$2 d=$3 bin=$4 src=${5:-}
  local WD="$R/outils/$d" ANC="$APP/Contents/Resources/outils/$d" ANCP="$APP/Contents/Resources/outils/$d-precedent"
  local voulu; voulu=$(demande_moteur "$cle")
  if [ "$voulu" = telecharge ]; then
    recevoir_moteur "$cle" "$WD" "$bin" "$R/outils"
    if [ -f "$ANC/$bin" ]; then copier_moteur "$ANC" "$WD-precedent"; fi
    echo "$nom : version $(champ_demande "$cle" version) installée"
  elif [ "$voulu" = precedent ] && [ -f "$ANCP/$bin" ]; then
    copier_moteur "$ANCP" "$WD"
    if [ -f "$ANC/$bin" ]; then copier_moteur "$ANC" "$WD-precedent"; fi
    echo "$nom : retour à la version précédente"
  elif [ -f "$ANC/$bin" ]; then
    copier_moteur "$ANC" "$WD"
    if [ -f "$ANCP/$bin" ]; then copier_moteur "$ANCP" "$WD-precedent"; fi
    echo "$nom repris de l'app installée"
  elif [ -n "$src" ] && [ -f "$src/$bin" ]; then
    copier_moteur "$src" "$WD"
    echo "$nom repris de $src ($(du -sh "$WD" | cut -f1))"
  else
    echo "$nom absent : à télécharger dans Paramètres → IA."
  fi
}
integrer_moteur whisper whisper.cpp whisper-cpp whisper-server
integrer_moteur llama llama.cpp llama-cpp llama-server
if [ -n "$PAQUET" ]; then integrer_moteur splash Splash splash install/launcher.py
else integrer_moteur splash Splash splash install/launcher.py /opt/homebrew/opt/splash/libexec; fi

titre "Python embarqué"
# Python 3.13 autonome dans l'app : le Python du système (3.9) ne reçoit plus de correctifs. Repris
# de l'app installée (protégée) s'il est à la bonne version, sinon copié depuis celui d'uv, élagué,
# et seulement avec l'empreinte inscrite dans le code (outils/python_embarque.json).
PE="$R/python"
PI="$APP/Contents/Resources/python"
VPE=$("$PY" -c 'import json,sys; print(json.load(open(sys.argv[1]))["version"])' "$R/outils/python_embarque.json")
if [ -n "$PAQUET" ]; then
  [ -x "$PE/bin/python3" ] && [ "$(cat "$PE/.version-kineapp" 2>/dev/null)" = "$VPE" ] \
    || { echo "Archive sans Python $VPE : rien n'est installé."; exit 1; }
  echo "Python $VPE livré avec la version"
elif [ -x "$PI/bin/python3" ] && [ "$(cat "$PI/.version-kineapp" 2>/dev/null)" = "$VPE" ]; then
  cp -RP "$PI" "$PE"
  echo "Python $VPE repris de l'app installée"
else
  SPY=$("$PY" -I "$R/outils/python_embarque.py" --trouver "$VRAIE_MAISON")
  if [ -z "$SPY" ]; then
    echo "Python $VPE introuvable. Dans le Terminal : uv python install $VPE (uv : brew install uv), puis relancez."
    echo "Rien n'est installé."; exit 1
  fi
  "$PY" -I "$R/outils/python_embarque.py" --copier "$SPY" "$PE"
fi
"$PE/bin/python3" -I -c 'import sqlite3, ssl, ctypes' || { echo "Python embarqué inutilisable. Rien n'est installé."; exit 1; }

titre "Signature (runtime durci)"
# Python embarqué : binaires et bibliothèques signés un à un, sans runtime durci (comme whisper.cpp).
find "$PE" -type f \( -name '*.so' -o -name '*.dylib' -o -perm -u+x \) -print0 \
  | while IFS= read -r -d '' f; do if file -b "$f" | grep -q Mach-O; then codesign --force --sign - "$f"; fi; done
codesign --force --sign - --options runtime --entitlements "$R/outils/bundle/enregistreur.entitlements" "$R/outils/enregistreur"
codesign --force --sign - --options runtime "$R/outils/html2pdf"
signer_moteurs "$R/outils"
codesign --force --sign - --options runtime --entitlements "$R/outils/bundle/KineAPP.entitlements" "$B"
codesign --verify --strict "$B"                 # échec = arrêt (set -e)
echo "signature vérifiée"

titre "Installation de l'app"
if [ -d "$APP" ]; then
  mkdir -p "$VERSIONS"
  ANCIEN="$VERSIONS/KinéAPP $(date +%Y-%m-%d_%H%M%S).app"
  mv "$APP" "$ANCIEN"
  echo "version précédente gardée : $ANCIEN"
fi
mkdir -p "$(dirname "$APP")"
mv "$B" "$APP"
if racine; then
  chown -R root:wheel "$APP"; chmod -R u+rwX,go+rX,go-w "$APP"
  if [ -d "$VERSIONS" ]; then chown -R root:wheel "$VERSIONS"; chmod -R go-w "$VERSIONS"; fi
fi
echo "ok : $APP"
# Paquet : le Python de l'archive était dans un dossier temporaire réservé à l'administrateur ; la suite
# (rangement sous le compte du praticien) prend celui de l'app installée.
if [ -n "$PAQUET" ]; then PY="$APP/Contents/Resources/python/bin/python3"; fi

titre "Dossiers du coffre"
mkdir -p "$SUPPORT" "$COFFRE" "$SAUV" "$LOGS"
if racine; then
  chown root:wheel "$SUPPORT"; chmod 755 "$SUPPORT"
  chown "$COMPTE:$COMPTE" "$COFFRE" "$LOGS"; chmod 700 "$COFFRE" "$LOGS"
  chown "$COMPTE:$COMPTE" "$SAUV"; chmod 755 "$SAUV"
fi
echo "ok"

SCRIPT_COFFRE="$APP/Contents/Resources/coffre/coffre.py"
PYD="$APP/Contents/Resources/python/bin/python3"   # le coffre tourne avec le Python embarqué
ecrire_service_coffre() {
  mkdir -p "$(dirname "$DAEMON")"
  "$PY" - "$DAEMON" "$PYD" "$SCRIPT_COFFRE" "$COFFRE" "$SAUV" "$SUPPORT/coffre-public.json" "$LOGS" "$PORT" "$COMPTE" <<'PYEOF'
import plistlib, sys
d, py, script, coffre, sauv, public, logs, port, compte = sys.argv[1:]
plistlib.dump({
    "Label": "fr.kineapp.coffre",
    "ProgramArguments": [py, "-I", script],
    "UserName": compte, "GroupName": compte,
    "Umask": 0o077,
    "RunAtLoad": True, "KeepAlive": True, "ProcessType": "Background",
    # Le port est ouvert par launchd au démarrage du Mac et reste tenu pendant un redémarrage du
    # service : aucun autre programme ne peut prendre la place du coffre.
    "Sockets": {"Coffre": {"SockNodeName": "127.0.0.1", "SockServiceName": port,
                           "SockType": "stream", "SockFamily": "IPv4"}},
    "EnvironmentVariables": {"KINECOFFRE_DATA": coffre, "KINECOFFRE_SAUVEGARDES": sauv,
                             "KINECOFFRE_PUBLIC": public, "KINECOFFRE_LAUNCHD": "1", "HOME": "/var/empty",
                             "PYTHONDONTWRITEBYTECODE": "1"},
    "StandardErrorPath": logs + "/coffre.log",
}, open(d, "wb"))
PYEOF
  plutil -lint "$DAEMON" >/dev/null               # échec = arrêt (set -e)
  if racine; then chown root:wheel "$DAEMON"; chmod 644 "$DAEMON"; fi
}
ecrire_depot() {
  if [ -n "$PAQUET" ]; then DEPOT=""; SRC=""; CANAL=paquet; fi
  "$PY" - "$DEPOT_JSON" "$DEPOT" "$SRC" "$CANAL" <<'PYEOF'
import json, sys
json.dump({"depot": sys.argv[2], "travail": sys.argv[3], "canal": sys.argv[4]}, open(sys.argv[1], "w"), ensure_ascii=False)
PYEOF
  if racine; then chown root:wheel "$DEPOT_JSON"; chmod 644 "$DEPOT_JSON"; fi
}
if [ "$MAJ" = 1 ]; then
  # Mise à jour : le code seulement. Ni mot de passe, ni rangement, ni migration ; le service du
  # coffre est relancé avec son nouveau code.
  titre "Service du coffre"
  if [ -f "$DAEMON" ]; then ecrire_service_coffre; fi   # nouveau Python : le service le suit
  redemarrer_coffre
  ecrire_depot
  echo "$VERSION" > "$SUPPORT/version-installee.txt"
  elaguer_versions
  titre "Terminé"
  echo "Mise à jour $VERSION installée (version précédente gardée dans $VERSIONS)."
  exit 0
fi

titre "Mot de passe du coffre"
if comme_coffre env KINECOFFRE_DATA="$COFFRE" "$PYD" -I "$SCRIPT_COFFRE" --verifier | grep -q "mot de passe défini"; then
  echo "déjà défini (il se change dans Paramètres → Coffre d'identité)"
elif [ -n "$PAQUET" ]; then
  # Paquet .pkg : pas de Terminal. Le praticien le choisit dans l'app au premier lancement ; le coffre ne
  # l'accepte que tant que ce fichier existe (posé ici, retiré dès que le mot de passe est choisi).
  : > "$COFFRE/initialisation_ouverte"
  if racine; then chown "$COMPTE:$COMPTE" "$COFFRE/initialisation_ouverte"; chmod 600 "$COFFRE/initialisation_ouverte"; fi
  echo "à choisir dans KinéAPP, au premier lancement"
else
  if [ -n "$ESSAI" ]; then
    MDP="${KINECOFFRE_MDP_ESSAI:?KINECOFFRE_MDP_ESSAI requis en essai}"
  else
    echo "Choisissez le mot de passe du coffre (10 caractères au moins). Il protège les noms de vos patients :"
    echo "notez-le hors de ce Mac (sans lui, les noms des sauvegardes du coffre sont irrécupérables)."
    while true; do
      read -r -s -p "Mot de passe : " MDP; echo
      read -r -s -p "Confirmez : " MDP2; echo
      if [ "$MDP" != "$MDP2" ]; then echo "Différents, recommencez."; continue; fi
      if [ ${#MDP} -lt 10 ]; then echo "Trop court (10 caractères au moins)."; continue; fi
      break
    done
    unset MDP2
  fi
  printf '%s\n' "$MDP" | comme_coffre env KINECOFFRE_DATA="$COFFRE" "$PYD" -I "$SCRIPT_COFFRE" --definir-mot-de-passe
  unset MDP
fi

titre "Configuration publique du coffre"
"$PY" - "$SUPPORT/coffre-public.json" "$PORT" "$SAUV" <<'PYEOF'
import json, sys
json.dump({"port": int(sys.argv[2]), "sauvegardes": sys.argv[3]}, open(sys.argv[1], "w"), ensure_ascii=False)
PYEOF
if racine; then chown root:wheel "$SUPPORT/coffre-public.json"; chmod 644 "$SUPPORT/coffre-public.json"; fi
echo "port $PORT"

R_OUTILS="$APP/Contents/Resources/outils"
ranger
if [ "$MIGRER" = 1 ]; then migrer; fi

titre "Service du coffre (launchd)"
ecrire_service_coffre
echo "fichier du service valide"
if racine; then
  redemarrer_coffre
else
  echo "(essai : service non lancé)"
fi
ecrire_depot

if [ -z "$PAQUET" ]; then VERSION=$(G rev-parse --short "$REV^{commit}"); fi   # histoire git réécrite : nouvel identifiant, même code
echo "$VERSION" > "$SUPPORT/version-installee.txt"
if racine; then chown root:wheel "$SUPPORT/version-installee.txt"; chmod 644 "$SUPPORT/version-installee.txt"; fi
elaguer_versions
titre "Terminé"
if [ -n "$PAQUET" ]; then
  echo "KinéAPP $VPAQ est installée. Ouvrez-la : elle vous demandera de choisir le mot de passe du coffre,"
  echo "puis vous guidera pour télécharger les moteurs et un modèle (Paramètres → IA)."
  exit 0
fi
cat <<EOF
- Ouvrez KinéAPP : macOS redemandera l'accès au micro (nouvelle signature de l'app).
- Au lancement, KinéAPP demande le mot de passe du coffre ; menu Coffre pour le verrouiller.
- Tapez maintenant :  sudo -k   (oubli du mot de passe administrateur dans ce terminal)
- Si la migration a remis à plus tard les transcripts de Claude et l'historique git : quittez
  l'app Claude, puis lancez :  sudo ./outils/installer.sh --migration-seule
EOF
