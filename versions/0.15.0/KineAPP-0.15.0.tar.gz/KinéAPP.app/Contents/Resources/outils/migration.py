# -*- coding: utf-8 -*-
"""Migration vers le coffre d'identité : les noms des patients quittent les données de la session.

Lancée une fois par l'installateur (root), app fermée. Pour chaque patient trouvé dans les données
de l'app (bilans, brouillons, dossiers patients, ordonnances, notes), le coffre crée une fiche et
un code ; partout où le nom apparaît — noms de fichiers et de dossiers, textes, .docx —, il est
remplacé par ce code (« Mme Dupont » -> « Mme P-K7Q3MX »).

Règles
  - Rien n'est effacé : chaque fichier modifié ou renommé est d'abord copié dans les archives du
    coffre (lisibles par le compte du coffre seulement), avec un manifeste des anciens chemins.
  - Rien de nominatif n'est affiché : seulement des nombres.
  - Les dates de modification sont conservées (la liste des bilans est triée par date).
  - Les notes dont le titre ne permet pas de reconnaître le patient (pas de civilité) sont mises
    dans les archives du coffre plutôt que laissées avec un nom possible.
  - Historique (--historique : bancs d'essai, rapports, mémoire de l'assistant) : le nom seul est
    remplacé aussi (« heidi_dupont.txt »), ce qu'on évite dans les textes cliniques.
  - Lancée en administrateur, elle ne touche QUE des fichiers ordinaires appartenant à
    l'utilisateur, dans son dossier personnel, sans jamais suivre un lien symbolique : un réglage
    ou une fiche modifiés par un programme de la session ne peuvent pas lui faire écrire ailleurs.

    python3 migration.py --utilisateur NOM --coffre /Library/…/Coffre [--historique DOSSIER]… [--essai]
"""
import argparse, datetime, io, json, os, pwd, re, shutil, stat, subprocess, sys, tempfile, time, unicodedata, zipfile

ICI = os.path.dirname(os.path.abspath(__file__))
RACINE_APP = os.path.dirname(ICI)
CIVILITES = {"mme": "Mme", "madame": "Mme", "mlle": "Mlle", "mademoiselle": "Mlle",
             "m": "M", "m.": "M", "mr": "M", "monsieur": "M"}
CODE = re.compile(r"P-[23456789BCDFGHJKMNPQRSTVWXZ]{6}")
DATE_BILAN = re.compile(r"^(.*?)_(\d{2}-\d{2}-\d{4})(?:_\d+)?$")
TEXTE = {".md", ".txt", ".json", ".jsonl", ".csv", ".log", ".html", ".py", ".sh", ".swift", ".js", ".tsv", ""}
IGNORES = {".DS_Store", "bibliotheque.sqlite"}
DOSSIERS_IGNORES = {"models", ".git", "__pycache__", "node_modules"}
MAX_TEXTE = 20_000_000
LETTRE = "A-Za-zÀ-ÖØ-öø-ÿ0-9"
SURETE = {"uid": os.getuid(), "maison": "/"}      # fixés par main() : propriétaire et dossier personnel


def a_lui(chemin, dossier=False):
    """Fichier ordinaire (ou dossier) de l'utilisateur, sans lien symbolique, dans son dossier personnel."""
    try:
        st = os.lstat(chemin)
    except OSError:
        return False
    if st.st_uid != SURETE["uid"] or not (stat.S_ISDIR(st.st_mode) if dossier else stat.S_ISREG(st.st_mode)):
        return False
    reel = os.path.realpath(chemin)
    return reel == SURETE["maison"] or reel.startswith(SURETE["maison"] + os.sep)


def lire_octets(chemin):
    fd = os.open(chemin, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as f:
        if not stat.S_ISREG(os.fstat(f.fileno()).st_mode) or os.fstat(f.fileno()).st_uid != SURETE["uid"]:
            raise OSError("pas un fichier de l'utilisateur")
        return f.read()


def racine_sure(r):
    """Dossier de départ : celui de l'utilisateur, une fois les liens résolus ; sinon ignoré."""
    if not r or not os.path.exists(r):
        return None
    reel = os.path.realpath(r)
    if os.path.isfile(reel):
        return reel if a_lui(reel) else None
    return reel if a_lui(reel, dossier=True) else None


def plat(t):
    t = unicodedata.normalize("NFD", t or "")
    t = "".join(c for c in t if unicodedata.category(c) != "Mn").lower()
    return " ".join(re.sub(r"[^a-z0-9]+", " ", t).split())


VARIANTES = {"a": "aàâäáã", "e": "eéèêë", "i": "iîïíì", "o": "oôöóò", "u": "uùûüú", "c": "cç", "y": "yÿ", "n": "nñ"}


def bas(t):
    """Texte sans accents, en minuscules, en un seul passage rapide (préfiltre des motifs)."""
    return unicodedata.normalize("NFD", t).encode("ascii", "ignore").decode("ascii").lower()


def aiguille(nom):
    """Mot le plus long du nom : s'il n'est pas dans le texte (bas()), aucun motif du nom ne peut y
    correspondre (motifs insensibles aux accents et à la casse, mot d'un seul tenant)."""
    return max(plat(nom).split() or [""], key=len)


PROGRES = {"n": 0}


def progres():
    """Les bancs d'essai comptent des milliers de fichiers : on montre que le travail avance."""
    PROGRES["n"] += 1
    if PROGRES["n"] % 500 == 0:
        print(f"  … {PROGRES['n']} fichiers examinés", file=sys.stderr, flush=True)


def motif_nom(nom):
    """« Lefèvre-Dupont » -> motif insensible aux accents, à la casse et aux séparateurs."""
    out = []
    for c in plat(nom):
        if c == " ":
            out.append(r"[\s'’_-]+")
        else:
            v = VARIANTES.get(c, c)
            out.append("[" + "".join(sorted(set(v + v.upper()))) + "]")
    return "".join(out)


def decouper(chaine):
    mots = " ".join(str(chaine or "").split()).split(" ")
    if len(mots) > 1 and mots[0].lower() in CIVILITES:
        return CIVILITES[mots[0].lower()], " ".join(mots[1:])
    return "", " ".join(mots)


# ── inventaire des patients ──────────────────────────────────────────────────
class Inventaire:
    def __init__(self):
        self.identites = {}                 # clé -> {"civ", "nom", "prenom", "naissance"}
        self.ambigues = []                  # notes sans patient reconnaissable

    def ajouter(self, chaine, prenom="", naissance=""):
        chaine = " ".join(str(chaine or "").replace("_", " ").split())
        if not chaine or CODE.search(chaine):
            return
        civ, nom = decouper(chaine)
        if len(plat(nom)) < 1:
            return
        cle = (civ, plat(nom))
        i = self.identites.setdefault(cle, {"civ": civ, "nom": nom, "prenom": "", "naissance": ""})
        if prenom and not i["prenom"]:
            i["prenom"] = " ".join(str(prenom).split())
        if naissance and not i["naissance"]:
            i["naissance"] = str(naissance).strip()


def lire_json(chemin, defaut=None):
    try:
        return json.loads(lire_octets(chemin).decode("utf-8"))
    except Exception:
        return defaut


def patient_de_bilan(nom):
    m = DATE_BILAN.match(nom or "")
    return m.group(1) if m else None


def titre_de_note(stem):
    """« Mme Dupont (2) », « Mme Dupont (déc2025) », « Mme Dupont2 » -> « Mme Dupont »."""
    t = re.sub(r"\s*\([^)]*\)\s*$", "", stem).strip()
    return re.sub(r"\s*\d+$", "", t).strip()


def lister(d, dossiers=False):
    """Entrées d'un dossier de l'utilisateur (fichiers ordinaires, ou sous-dossiers), liens exclus."""
    if not d or not a_lui(d, dossier=True):
        return []
    return [n for n in os.listdir(d) if a_lui(os.path.join(d, n), dossier=dossiers)]


def inventorier(cfg, donnees):
    inv = Inventaire()
    for n in lister(cfg.get("bilans_dir"), dossiers=True):
        inv.ajouter(patient_de_bilan(n))
    for sous in ("brouillons",):
        d = os.path.join(donnees, sous)
        for n in lister(d):
            m = re.match(r"^(.*?)_(?:\d{2}-\d{2}-\d{4}_)?\d{4}-\d{2}-\d{2}_\d{6}", n)
            if m:
                inv.ajouter(m.group(1))
    d = os.path.join(donnees, "entrees")
    for n in lister(d):
        if n.endswith(".job.json"):
            inv.ajouter((lire_json(os.path.join(d, n), {}) or {}).get("patient"))
    d = os.path.join(donnees, "patients")
    for n in lister(d):
        if n.endswith(".json"):
            inv.ajouter((lire_json(os.path.join(d, n), {}) or {}).get("nom"))
    d = os.path.join(donnees, "ordonnances")
    for n in lister(d):
        f = lire_json(os.path.join(d, n), {}) if n.endswith(".json") else None
        if f:
            p = f.get("patient") or {}
            if p.get("nom") and not CODE.fullmatch(str(p.get("nom")).strip()):
                inv.ajouter(f"{p.get('civilite') or ''} {p.get('nom')}", p.get("prenom"), p.get("naissance"))
            inv.ajouter(patient_de_bilan(f.get("bilan") or ""))
    d = os.path.join(donnees, "comptes_rendus")
    for n in lister(d):
        f = lire_json(os.path.join(d, n), {}) if n.endswith(".json") else None
        if f:
            inv.ajouter(patient_de_bilan(f.get("bilan") or ""))
    notes = cfg.get("notes_dir")
    for racine in ([notes, os.path.join(notes, "Archive")] if notes else []):
        for n in lister(racine):
            if n.endswith(".md"):
                titre = titre_de_note(n[:-3])
                if decouper(titre)[0]:
                    inv.ajouter(titre)
                elif not CODE.search(titre):
                    inv.ambigues.append(os.path.join(racine, n))
    trans = cfg.get("transcriptions_dir")
    for n in lister(trans):
        inv.ajouter(patient_de_bilan(os.path.splitext(n)[0]))
    return inv


# ── règles de remplacement ───────────────────────────────────────────────────
class Regles:
    """Remplacements, du plus long nom au plus court (« Dupont Marie » avant « Dupont »).

    Le nom SEUL (sans civilité) n'est remplacé que s'il n'est pas aussi un mot courant des textes
    cliniques : un patient nommé « Talon » ne doit pas faire disparaître le talon des bilans."""

    def __init__(self, identites, codes, mots_courants=frozenset()):
        self.cliniques, self.historiques = [], []
        surnoms = {}
        for cle, i in identites.items():
            surnoms.setdefault(plat(i["nom"]), []).append(cle)
        ordre = sorted(identites.items(), key=lambda kv: -len(kv[1]["nom"]))
        # « %20 » : un nom dans une adresse recopiée (…?name=Mme%20Dupont_12-10-2026)
        avant, apres = rf"(?:(?<=%20)|(?<![{LETTRE}]))", rf"(?![{LETTRE}])"
        civs_f = r"Mme|Madame|Mlle|Mademoiselle"
        civs_m = r"M\.?|Monsieur|Mr\.?"
        mots_noms = {}
        for cle, i in identites.items():
            for w in plat(i["nom"]).split():
                mots_noms.setdefault(w, set()).add(cle)
        for cle, i in ordre:
            code, nom = codes[cle], i["nom"]
            # Avec le prénom connu (ordonnances) : « Mme TALON Julie », « Mme Julie Talon » d'abord.
            if i["civ"] and i["prenom"]:
                civs = civs_m if i["civ"] == "M" else civs_f
                for forme in (f"{nom} {i['prenom']}", f"{i['prenom']} {nom}"):
                    r = re.compile(avant + rf"((?i:{civs}))((?:[\s_+-]|%20)+)" + motif_nom(forme) + apres)
                    self.cliniques.append((r, lambda m, c=code: m.group(1) + m.group(2)
                                           + (c.lower() if m.group(1).islower() and m.group(2).strip() else c),
                                           aiguille(nom)))
            mn = motif_nom(nom)
            if i["civ"]:
                civs = civs_m if i["civ"] == "M" else civs_f
                # « Mme Dupont », « Madame Dupont », « mme_dupont », « mme-dupont » (clés des dossiers)
                r = re.compile(avant + rf"((?i:{civs}))((?:[\s_+-]|%20)+)" + mn + apres)
                # « mme-dupont » (clé d'un dossier patient) -> « mme-p-k7q3mx », comme la clé que l'app calcule
                self.cliniques.append((r, lambda m, c=code: m.group(1) + m.group(2)
                                       + (c.lower() if m.group(1).islower() and m.group(2) in ("-", "_") else c),
                                       aiguille(nom)))
            else:
                # sans civilité : le nom complet tel quel (« Durand Marie »)
                self.cliniques.append((re.compile(avant + mn + apres), lambda m, c=code: c, aiguille(nom)))
            seul = re.compile(avant + mn + apres)
            unique = len(surnoms.get(plat(nom), [])) == 1
            if unique and len(plat(nom)) >= 4 and plat(nom) not in mots_courants:
                # nom seul, avec une majuscule : notes et textes cliniques (« Ankle go Dupont »)
                maj = re.compile(avant + "(?=[A-ZÀ-Ý])" + mn + apres)
                self.cliniques.append((maj, lambda m, c=code: c, aiguille(nom)))
                self.historiques.append((seul, lambda m, c=code: c, aiguille(nom)))   # historique : toute casse
            # Historique : chaque mot du nom, seul (« heidi_durand » pour « M Durand Pierre »), s'il
            # n'appartient qu'à ce patient et n'est pas un mot courant.
            for w in plat(nom).split():
                if len(w) >= 4 and w not in mots_courants and mots_noms.get(w) == {cle} and w != plat(nom):
                    self.historiques.append((re.compile(avant + motif_nom(w) + apres), lambda m, c=code: c, w))

    def appliquer(self, texte, historique=False):
        regles = self.cliniques + (self.historiques if historique else [])
        if len(texte) > 2000:                       # préfiltre : seuls les noms présents sont cherchés
            b = bas(texte)
            regles = [x for x in regles if x[2] in b]
        n = 0
        for r, f, _ in regles:
            texte, k = r.subn(f, texte)
            n += k
        return texte, n


def mots_courants(cfg):
    """Mots écrits en minuscules dans les bilans et transcriptions : des mots de la langue, pas des noms."""
    mots = set()
    for racine in (racine_sure(cfg.get("bilans_dir")), racine_sure(cfg.get("transcriptions_dir"))):
        for d, dirs, fichiers in os.walk(racine) if racine and os.path.isdir(racine) else []:
            for f in fichiers:
                if f.endswith((".md", ".txt")):
                    try:
                        t = lire_octets(os.path.join(d, f)).decode("utf-8")
                    except Exception:
                        continue
                    mots.update(plat(w) for w in re.findall(r"(?<![A-Za-zÀ-ÿ])[a-zà-ÿ][a-zà-ÿ'-]{3,}", t))
    return frozenset(mots)


# ── écriture prudente ────────────────────────────────────────────────────────
class Chantier:
    def __init__(self, archive, essai):
        self.archive, self.essai = archive, essai
        self.manifeste = []
        self.compte = {"textes": 0, "remplacements": 0, "renommes": 0, "docx": 0, "notes_archivees": 0,
                       "ordonnances": 0, "illisibles": 0, "restes": 0, "hors_maison": 0, "claude_fichiers": 0,
                       "claude_images": 0, "claude_actifs": 0, "git_blocs": 0, "git_erreur": 0}

    def garder(self, chemin):
        """Copie de l'original dans les archives du coffre, avant toute modification."""
        if self.essai:
            return
        dest = os.path.join(self.archive, "originaux", os.path.relpath(chemin, "/"))
        if os.path.exists(dest):
            return
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(lire_octets(chemin))

    def reecrire(self, chemin, contenu):
        """Même fichier (même propriétaire, mêmes droits), même date de modification."""
        if self.essai:
            return
        if not a_lui(chemin):
            raise OSError("pas un fichier de l'utilisateur")
        self.garder(chemin)
        fd = os.open(chemin, os.O_RDWR | os.O_NOFOLLOW)
        with os.fdopen(fd, "r+b") as f:
            st = os.fstat(f.fileno())
            if not stat.S_ISREG(st.st_mode) or st.st_uid != SURETE["uid"]:
                raise OSError("pas un fichier de l'utilisateur")
            f.write(contenu)
            f.truncate()
        os.utime(chemin, ns=(st.st_atime_ns, st.st_mtime_ns), follow_symlinks=False)

    def renommer(self, ancien, nouveau):
        if ancien == nouveau or not (a_lui(ancien) or a_lui(ancien, dossier=True)) \
                or not a_lui(os.path.dirname(ancien), dossier=True):
            return ancien
        base, ext = os.path.splitext(nouveau) if os.path.isfile(ancien) else (nouveau, "")
        i = 2
        while os.path.exists(nouveau):
            nouveau = f"{base} ({i}){ext}"
            i += 1
        self.compte["renommes"] += 1
        self.manifeste.append({"ancien": ancien, "nouveau": nouveau})
        if not self.essai:
            parent = os.path.dirname(ancien)
            st = os.stat(parent)
            os.rename(ancien, nouveau)
            os.utime(parent, ns=(st.st_atime_ns, st.st_mtime_ns))
        return nouveau

    def archiver(self, chemin, compte="notes_archivees"):
        """Fichier qui part entièrement dans le coffre (note dont le patient n'est pas reconnaissable,
        image d'un transcript)."""
        if not a_lui(chemin):
            return
        self.compte[compte] += 1
        self.manifeste.append({"archive": chemin})
        if self.essai:
            return
        dest = os.path.join(self.archive, "retires", os.path.relpath(chemin, "/"))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.move(chemin, dest)


def scruter_docx(chemin, regles, chantier):
    try:
        z = zipfile.ZipFile(io.BytesIO(lire_octets(chemin)))
        if len(z.infolist()) > 500 or sum(i.file_size for i in z.infolist()) > 100_000_000:
            raise ValueError("archive trop grosse")
        entrees = [(i, z.read(i.filename)) for i in z.infolist()]
        z.close()
    except Exception:
        chantier.compte["illisibles"] += 1
        return
    total, sortie = 0, io.BytesIO()
    with zipfile.ZipFile(sortie, "w", zipfile.ZIP_DEFLATED) as z:
        for info, d in entrees:
            if info.filename.endswith(".xml"):
                t, n = regles.appliquer(d.decode("utf-8"))
                total += n
                d = t.encode("utf-8")
            z.writestr(info, d)
    if total:
        chantier.compte["docx"] += 1
        chantier.compte["remplacements"] += total
        chantier.reecrire(chemin, sortie.getvalue())


def parcourir(racine):
    """(dossier, sous-dossiers, fichiers) ; un fichier isolé est traité comme un dossier d'un seul fichier."""
    if os.path.isfile(racine):
        yield os.path.dirname(racine), [], [os.path.basename(racine)]
    elif os.path.isdir(racine):
        yield from os.walk(racine, topdown=True)


def traiter_arbre(racine, regles, chantier, historique=False, exclure=()):
    """Contenus d'abord, puis noms (des plus profonds aux moins profonds)."""
    racine = racine_sure(racine)
    if not racine:
        chantier.compte["hors_maison"] += 1
        return
    chemins = []
    for d, dirs, fichiers in parcourir(racine):
        dirs[:] = [x for x in dirs if x not in DOSSIERS_IGNORES and os.path.join(d, x) not in exclure
                   and a_lui(os.path.join(d, x), dossier=True)]
        for f in fichiers:
            p = os.path.join(d, f)
            if f in IGNORES or not a_lui(p):
                continue
            progres()
            chemins.append(p)
            ext = os.path.splitext(f)[1].lower()
            try:
                if ext == ".docx":
                    scruter_docx(p, regles, chantier)
                elif ext in TEXTE and os.path.getsize(p) <= MAX_TEXTE:
                    brut = lire_octets(p)
                    try:
                        t = brut.decode("utf-8")
                    except UnicodeDecodeError:
                        continue
                    nouveau, n = regles.appliquer(t, historique)
                    if n:
                        chantier.compte["textes"] += 1
                        chantier.compte["remplacements"] += n
                        chantier.reecrire(p, nouveau.encode("utf-8"))
            except OSError:
                chantier.compte["illisibles"] += 1
        chemins += [os.path.join(d, x) for x in dirs]
    for p in sorted(chemins, key=lambda x: -x.count(os.sep)):
        nom = os.path.basename(p)
        nouveau, n = regles.appliquer(nom, historique)
        if n and os.path.exists(p):
            chantier.renommer(p, os.path.join(os.path.dirname(p), nouveau))


def migrer_ordonnances(donnees, codes_par_cle, chantier, entete):
    d = os.path.join(donnees, "ordonnances")
    if not a_lui(d, dossier=True):
        return
    sys.path.insert(0, RACINE_APP)
    try:
        import ordonnances as ORD
    except Exception:
        ORD = None
    for n in lister(d):
        p = os.path.join(d, n)
        f = lire_json(p) if n.endswith(".json") else None
        if not f:
            continue
        pat = f.get("patient") or {}
        if not pat.get("nom") or CODE.fullmatch(str(pat["nom"]).strip()):
            continue
        civ, nom = decouper(f"{pat.get('civilite') or ''} {pat.get('nom')}")
        code = codes_par_cle.get((civ, plat(nom)))
        if not code:
            continue
        complet = bool(pat.get("nom") and pat.get("prenom") and pat.get("naissance"))
        age = ORD.age(pat.get("naissance")) if ORD else None
        pat.update(nom=code, prenom="", naissance="")
        f["patient"] = pat
        f["identite_coffre"] = {"complet": complet, "age": age}
        chantier.compte["ordonnances"] += 1
        chantier.reecrire(p, json.dumps(f, ensure_ascii=False, indent=2).encode("utf-8"))
        # Le .docx nominatif part aux archives ; la version codée (jetons remplis à l'export) le remplace.
        doc = str(f.get("fichier") or "")
        if ORD and doc and a_lui(doc) and not chantier.essai:
            # Écrite d'abord dans un dossier à part, puis recopiée DANS le fichier de l'utilisateur
            # (même propriétaire, aucun lien suivi) : le chemin vient d'une fiche modifiable.
            with tempfile.TemporaryDirectory() as t:
                neuf = os.path.join(t, "ordonnance.docx")
                ORD.ecrire_docx(f, entete or {}, neuf)
                chantier.reecrire(doc, open(neuf, "rb").read())


# ── données de Claude Code (transcripts, copies de fichiers, sessions) ────────
IMAGE_RETIREE = "[image retirée lors de la pseudonymisation : elle pouvait montrer un nom]"
B64_IMAGE = re.compile(r"^(?:/9j/|iVBORw0KGgo|R0lGOD|UklGR|JVBERi0)")     # jpeg, png, gif, webp, pdf en base64
NON_TEXTE = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic", ".tif", ".tiff", ".pdf"}
ACTIF_S = 300                                  # fichier écrit il y a moins de 5 min : session ouverte
ACTIF = {"delai": True}                        # levé quand l'installateur a vérifié que Claude est fermé


def nettoyer_json(o, regles):
    """Textes pseudonymisés, images retirées (on ne peut pas y effacer un nom). Renvoie (objet, n)."""
    if isinstance(o, dict):
        if o.get("type") in ("image", "document"):
            return {"type": "text", "text": IMAGE_RETIREE}, 1
        out, n = {}, 0
        for k, v in o.items():
            k2, a = regles.appliquer(k, historique=True) if isinstance(k, str) else (k, 0)
            v2, b = nettoyer_json(v, regles)
            out[k2] = v2
            n += a + b
        return out, n
    if isinstance(o, list):
        l, n = [], 0
        for v in o:
            v2, k = nettoyer_json(v, regles)
            l.append(v2)
            n += k
        return l, n
    if isinstance(o, str):
        if len(o) > 2000 and B64_IMAGE.match(o):
            return IMAGE_RETIREE, 1
        return regles.appliquer(o, historique=True)
    return o, 0


def traiter_claude(racine, regles, chantier):
    """Transcripts (.jsonl) et réglages (.json) relus et réécrits en JSON valide ; autres textes
    comme l'historique ; images et PDF aux archives du coffre ; fichiers d'une session ouverte
    laissés pour une prochaine fois (Claude doit être fermé)."""
    racine = racine_sure(racine)
    if not racine:
        return
    for d, dirs, fichiers in os.walk(racine, topdown=True):
        dirs[:] = [x for x in dirs if a_lui(os.path.join(d, x), dossier=True)]
        for f in fichiers:
            p = os.path.join(d, f)
            if not a_lui(p):
                continue
            ext = os.path.splitext(f)[1].lower()
            try:
                if ACTIF["delai"] and time.time() - os.path.getmtime(p) < ACTIF_S:
                    chantier.compte["claude_actifs"] += 1
                    continue
                if ext in NON_TEXTE:
                    chantier.archiver(p, compte="claude_images")
                    continue
                brut = lire_octets(p)
                try:
                    t = brut.decode("utf-8")
                except UnicodeDecodeError:
                    continue
                n = 0
                if ext == ".jsonl":
                    lignes = []
                    for ligne in t.split("\n"):
                        try:
                            o = json.loads(ligne) if ligne.strip() else None
                        except ValueError:
                            o = None
                        if o is None:
                            ligne2, k = regles.appliquer(ligne, historique=True)
                        else:
                            o2, k = nettoyer_json(o, regles)
                            ligne2 = json.dumps(o2, ensure_ascii=False, separators=(",", ":")) if k else ligne
                        lignes.append(ligne2)
                        n += k
                    nouveau = "\n".join(lignes)
                elif ext == ".json":
                    try:
                        o2, n = nettoyer_json(json.loads(t), regles)
                        nouveau = json.dumps(o2, ensure_ascii=False, indent=2 if "\n " in t else None,
                                             separators=None if "\n " in t else (",", ":"))
                    except ValueError:
                        nouveau, n = regles.appliquer(t, historique=True)
                else:
                    nouveau, n = regles.appliquer(t, historique=True)
                if n:
                    chantier.compte["claude_fichiers"] += 1
                    chantier.compte["remplacements"] += n
                    chantier.reecrire(p, nouveau.encode("utf-8"))
            except OSError:
                chantier.compte["illisibles"] += 1


# ── historique git du code ───────────────────────────────────────────────────
def transformer_flux_git(flux, regles):
    """Flux de « git fast-export » : chaque bloc « data N » (contenu d'un fichier, message d'un
    commit) pseudonymisé, sa longueur recalculée. Renvoie (flux, nombre de blocs changés)."""
    out, i, changes = bytearray(), 0, 0
    while i < len(flux):
        fin = flux.find(b"\n", i)
        if fin < 0:
            out += flux[i:]
            break
        ligne = flux[i:fin + 1]
        i = fin + 1
        if ligne.startswith(b"data ") and not ligne.startswith(b"data <<"):
            n = int(ligne[5:].strip())
            contenu = flux[i:i + n]
            i += n
            try:
                t = contenu.decode("utf-8")
                # Formes sûres seulement (civilité + nom, nom propre) : un nom « tout en minuscules »
                # pourrait être un mot du code (module force.py et patient « Force »).
                t2, k = regles.appliquer(t, historique=False)
                if k:
                    contenu = t2.encode("utf-8")
                    changes += 1
            except UnicodeDecodeError:
                pass                                  # binaire (icône, exécutable) : tel quel
            out += b"data %d\n" % len(contenu) + contenu
        else:
            out += ligne
    return bytes(out), changes


def reecrire_git(depot, travail, regles, chantier):
    """Toute l'histoire du dépôt réécrite sans les noms ; l'original intégral va aux archives du
    coffre (rien n'est perdu), puis les anciens objets sont retirés du dépôt de l'utilisateur."""
    depot = racine_sure(depot)
    if not depot or not os.path.isdir(os.path.join(depot, "objects")):
        return
    # git lancé sous l'utilisateur (ses fichiers lui restent), avec SON dossier personnel.
    env = dict(os.environ, HOME=SURETE["maison"])
    utilisateur = {"user": SURETE["uid"], "group": pwd.getpwuid(SURETE["uid"]).pw_gid} if os.getuid() == 0 else {}
    git = ["git", "--git-dir", depot]
    lancer = lambda args, **k: subprocess.run(git + args, capture_output=True, timeout=600, env=env, **utilisateur, **k)
    exp = lancer(["fast-export", "--all", "--signed-tags=strip", "--reencode=yes"])
    if exp.returncode != 0:
        chantier.compte["git_erreur"] = 1
        return
    flux, n = transformer_flux_git(exp.stdout, regles)
    chantier.compte["git_blocs"] = n
    if chantier.essai or not n:
        return
    # Répétition dans un dépôt jetable : le code ACTUEL doit ressortir identique (même arbre) ;
    # sinon un mot du code aurait été pris pour un nom, et rien n'est réécrit.
    arbre = lancer(["rev-parse", "HEAD^{tree}"]).stdout.strip()
    branche = lancer(["symbolic-ref", "-q", "HEAD"]).stdout.strip() or b"refs/heads/main"
    essai = tempfile.mkdtemp(prefix="kineapp-git-")
    if utilisateur:
        os.chown(essai, SURETE["uid"], utilisateur["group"])
    git_essai = ["git", "--git-dir", os.path.join(essai, "d.git")]
    subprocess.run(git_essai + ["init", "--bare", "--quiet"], capture_output=True, env=env, **utilisateur)
    subprocess.run(git_essai + ["fast-import", "--quiet"], input=flux, capture_output=True, env=env, **utilisateur)
    nouvel_arbre = subprocess.run(git_essai + ["rev-parse", branche.decode() + "^{tree}"], capture_output=True,
                                  env=env, **utilisateur).stdout.strip()
    shutil.rmtree(essai, ignore_errors=True)
    if not arbre or nouvel_arbre != arbre:
        chantier.compte["git_erreur"] = 1
        return
    shutil.copytree(depot, os.path.join(chantier.archive, "depot-git-d-origine"), symlinks=True)
    imp = lancer(["fast-import", "--force", "--quiet"], input=flux)
    if imp.returncode != 0:
        chantier.compte["git_erreur"] = 1
        return
    for args in (["reflog", "expire", "--expire=now", "--all"], ["gc", "--prune=now", "--quiet"]):
        lancer(args)
    if travail and a_lui(travail, dossier=True):
        lancer(["--work-tree", travail, "reset", "--quiet"])


def restes(racines, identites):
    """Après coup : fichiers où un nom (avec civilité) apparaît encore. Compte seulement."""
    motifs = [(re.compile(rf"(?<![{LETTRE}])(?i:mme|madame|mlle|m\.?|monsieur)[\s_-]+" + motif_nom(i["nom"]) + rf"(?![{LETTRE}])"),
               aiguille(i["nom"])) for i in identites.values() if i["civ"]]
    n = 0
    for racine in map(racine_sure, racines):
        for d, dirs, fichiers in (parcourir(racine) if racine else []):
            dirs[:] = [x for x in dirs if x not in DOSSIERS_IGNORES and a_lui(os.path.join(d, x), dossier=True)]
            for f in fichiers:
                p = os.path.join(d, f)
                if f in IGNORES or not a_lui(p) or os.path.splitext(f)[1].lower() not in TEXTE \
                        or os.path.getsize(p) > MAX_TEXTE:
                    continue
                try:
                    t = lire_octets(p).decode("utf-8")
                except Exception:
                    continue
                b = bas(t + " " + f)
                if any(a in b and (m.search(t) or m.search(f)) for m, a in motifs):
                    n += 1
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--utilisateur", required=True)
    ap.add_argument("--coffre", required=True, help="dossier des données du coffre")
    ap.add_argument("--maison", help="dossier personnel (par défaut celui de l'utilisateur)")
    ap.add_argument("--historique", action="append", default=[])
    ap.add_argument("--claude", action="append", default=[], help="données de Claude Code (transcripts…)")
    ap.add_argument("--depot-git", help="dépôt git du code, dont l'histoire est réécrite sans les noms")
    ap.add_argument("--travail", help="copie de travail de ce dépôt (index remis à jour)")
    ap.add_argument("--claude-ferme", action="store_true", help="Claude vérifié fermé : aucun transcript en cours")
    ap.add_argument("--essai", action="store_true", help="compter seulement, ne rien écrire")
    a = ap.parse_args()

    maison = a.maison or pwd.getpwnam(a.utilisateur).pw_dir
    SURETE.update(uid=pwd.getpwnam(a.utilisateur).pw_uid, maison=os.path.realpath(maison))
    donnees = os.path.join(maison, "Library/Application Support/BilanKine")
    cfg = lire_json(os.path.join(donnees, "ui_config.json"), {}) or {}
    defauts = {"bilans_dir": "~/Documents/KinéAPP/Bilans", "notes_dir": "~/Documents/KinéAPP/Suivi Kiné",
               "transcriptions_dir": "~/Documents/KinéAPP/Transcriptions", "cr_dir": "~/Documents/KinéAPP/Comptes rendus",
               "ordonnances_dir": "~/Documents/KinéAPP/Ordonnances"}
    for k, v in defauts.items():
        cfg[k] = (cfg.get(k) or v).replace("~", maison, 1) if (cfg.get(k) or v).startswith("~") else (cfg.get(k) or v)

    os.environ["KINECOFFRE_DATA"] = a.coffre
    sys.path.insert(0, os.path.join(RACINE_APP, "coffre"))
    import coffre as C

    inv = inventorier(cfg, donnees)
    codes = {}
    crees = 0
    # Patients déjà dans le coffre : après une première migration, les données de l'app ne portent
    # plus que des codes ; c'est le coffre qui sait quels noms chercher (transcripts, historique…).
    for code, p in (C.lire().get("patients") or {}).items():
        civ, nom = decouper(p.get("nom_saisi", ""))
        if len(plat(nom)) < 1:
            continue
        cle = (civ, plat(nom))
        inv.identites.setdefault(cle, {"civ": civ, "nom": nom, "prenom": p.get("prenom", ""), "naissance": ""})
        codes[cle] = code
    for cle, i in inv.identites.items():
        nom_saisi = f"{i['civ']} {i['nom']}".strip()
        if cle in codes:
            continue
        if a.essai:
            codes[cle] = "P-" + "Z" * 6
            continue
        r = C.creer_ou_retrouver(nom_saisi)
        crees += not r["existant"]
        codes[cle] = r["code"]
        champs = {k: i[k] for k in ("prenom", "naissance") if i[k]}
        if champs:
            try:
                C.modifier(r["code"], champs)
            except ValueError:
                pass
    regles = Regles(inv.identites, codes, mots_courants(cfg))

    horodatage = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    archive = os.path.join(a.coffre, "archives", f"avant-migration_{horodatage}")
    chantier = Chantier(archive, a.essai)
    if not a.essai:
        os.makedirs(archive, mode=0o700, exist_ok=True)

    for p in inv.ambigues:
        chantier.archiver(p)
    migrer_ordonnances(donnees, codes, chantier, cfg.get("entete"))
    cliniques = [donnees, cfg["bilans_dir"], cfg["transcriptions_dir"], cfg["cr_dir"], cfg["ordonnances_dir"], cfg["notes_dir"]]
    for racine in cliniques:
        traiter_arbre(racine, regles, chantier)
    for racine in a.historique:
        traiter_arbre(os.path.expanduser(racine), regles, chantier, historique=True)
    ACTIF["delai"] = not a.claude_ferme
    for racine in a.claude:
        traiter_claude(os.path.expanduser(racine), regles, chantier)
    if a.depot_git:
        reecrire_git(os.path.expanduser(a.depot_git), a.travail, regles, chantier)
    chantier.compte["restes"] = 0 if a.essai else restes(cliniques + a.historique, inv.identites)

    if not a.essai:
        with open(os.path.join(archive, "manifeste.json"), "w", encoding="utf-8") as f:
            json.dump({"date": horodatage, "operations": chantier.manifeste}, f, ensure_ascii=False, indent=1)
    c = chantier.compte
    print(f"Patients : {len(inv.identites)} connus, {crees} nouvelles fiches dans le coffre.")
    print(f"Fichiers : {c['textes']} textes et {c['docx']} documents .docx réécrits ({c['remplacements']} remplacements), "
          f"{c['renommes']} noms de fichiers ou dossiers changés, {c['ordonnances']} ordonnances passées au coffre.")
    print(f"Notes sans patient reconnaissable mises aux archives du coffre : {c['notes_archivees']}.")
    if a.claude:
        print(f"Claude Code : {c['claude_fichiers']} fichiers pseudonymisés, {c['claude_images']} images ou PDF aux "
              f"archives du coffre" + (f", {c['claude_actifs']} fichiers d'une session ouverte laissés (quittez Claude "
                                      f"et relancez)" if c["claude_actifs"] else "") + ".")
    if a.depot_git:
        print("Historique git : " + ("non réécrit (dépôt inchangé) : la réécriture aurait modifié le code actuel, "
                                     "ou git a échoué. À examiner." if c["git_erreur"] else
                                     f"{c['git_blocs']} contenus ou messages réécrits."))
    if c["illisibles"]:
        print(f"Fichiers illisibles laissés tels quels : {c['illisibles']}.")
    if c["hors_maison"]:
        print(f"Dossiers ignorés (hors du dossier personnel, ou pas à vous) : {c['hors_maison']}.")
    if not a.essai:
        print(f"Fichiers où un nom apparaît encore : {c['restes']}" + (" (à vérifier)." if c["restes"] else "."))
        print("Originaux et manifeste : archives du coffre (lisibles par le compte du coffre seulement).")
    else:
        print("(essai : rien n'a été écrit)")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:                  # jamais de trace : elle citerait des chemins nominatifs
        print(f"Migration interrompue ({type(e).__name__}). Les originaux déjà touchés sont dans les archives "
              "du coffre ; rien d'autre n'a été modifié après l'erreur.", file=sys.stderr)
        sys.exit(1)
