#!/bin/bash
# Publication d'une version de KinéAPP pour les autres Mac (canal GitHub).
#
# Ne publie qu'un commit dont TOUS les tests ont réussi (tests/test_kineapp.py note l'arbre testé),
# avec des garde-fous conformes et un historique sans nom de patient (crochet pre-push). L'étiquette
# vX.Y.Z (numéro de version.json) est signée par la clé de publication (~/.ssh/kineapp_publication) :
# les autres Mac n'installent que des étiquettes signées par elle, vérifiées par leur app installée.
#
#     ./outils/publier.sh          (montre ce qui part, demande confirmation)
#     ./outils/publier.sh --oui    (sans question : seulement si l'utilisateur l'a demandé)
#     ./outils/publier.sh --versions-seules vX.Y.Z   (étiquette déjà publiée : version construite seulement)
#
# Ensuite, pour les Mac des collègues : la version est construite (outils/construire_version.sh), son manifeste
# signé (espace « kineapp-version »), le paquet .pkg fabriqué (outils/construire_pkg.sh), et le tout envoyé
# dans le dépôt PUBLIC des versions (outils/publication/canal.json), cloné dans ~/Developer/KineAPP-versions.
set -euo pipefail
ICI="$(cd "$(dirname "$0")/.." && pwd)"
DEPOT="${KINEAPP_DEPOT:-$HOME/Developer/KineAPP.git}"
CLE="${KINEAPP_CLE_PUBLICATION:-$HOME/.ssh/kineapp_publication}"
SIGNATAIRES="$ICI/outils/publication/signataires_autorises"
G() { git --git-dir="$DEPOT" --work-tree="$ICI" "$@"; }
OUI=0; [ "${1:-}" = "--oui" ] && OUI=1
VERSIONS_DIR="${KINEAPP_VERSIONS:-$HOME/Developer/KineAPP-versions}"
cle_de_signature() {
  ssh-add --apple-load-keychain >/dev/null 2>&1 || true
  if ssh-add -L 2>/dev/null | grep -q "$(cut -d' ' -f2 "$CLE.pub")"; then echo "$CLE.pub"; else echo "$CLE"; fi
}
publier_versions() {      # vX.Y.Z : version construite, signée, envoyée dans le dépôt public des versions
  local TAG="$1" V="${1#v}" SIGNER M
  if [ ! -d "$VERSIONS_DIR/.git" ]; then
    echo "Dépôt des versions absent ($VERSIONS_DIR) : la version $V n'est pas encore proposée aux collègues."
    echo "Créez-le (public, vide) sur GitHub, clonez-le là, puis : ./outils/publier.sh --versions-seules $TAG"
    return 1
  fi
  git -C "$VERSIONS_DIR" pull -q --ff-only || true
  "$ICI/outils/construire_version.sh" "$TAG" "$VERSIONS_DIR"
  SIGNER=$(cle_de_signature)
  M="$VERSIONS_DIR/versions/$V/KineAPP-$V.json"
  rm -f "$M.sig"
  ssh-keygen -Y sign -f "$SIGNER" -n kineapp-version "$M" >/dev/null
  ssh-keygen -Y verify -f "$SIGNATAIRES" -I "$(grep -v '^#' "$SIGNATAIRES" | awk 'NF {print $1; exit}')" \
    -n kineapp-version -s "$M.sig" < "$M" >/dev/null || { echo "Signature de la version non vérifiable : annulé."; return 1; }
  cp "$M" "$VERSIONS_DIR/derniere.json"; cp "$M.sig" "$VERSIONS_DIR/derniere.json.sig"
  "$ICI/outils/construire_pkg.sh" "$VERSIONS_DIR" "$V"
  sed "s/@VERSION@/$V/g; s/@EMPREINTE@/$(grep -v '^#' "$SIGNATAIRES" | awk 'NF {print $3" "$4; exit}' | ssh-keygen -lf - | awk '{print $2}')/g" \
    "$ICI/outils/paquet/LISEZMOI_versions.md" > "$VERSIONS_DIR/README.md"
  git -C "$VERSIONS_DIR" add -A
  git -C "$VERSIONS_DIR" commit -q -m "KinéAPP $V"
  git -C "$VERSIONS_DIR" push -q origin HEAD
  echo "Version $V proposée aux collègues (paquet d'installation et mise à jour depuis l'app)."
}
if [ "${1:-}" = "--versions-seules" ]; then
  T="${2:?étiquette vX.Y.Z attendue}"
  G -c gpg.format=ssh -c gpg.ssh.allowedSignersFile="$SIGNATAIRES" verify-tag "$T" >/dev/null 2>&1 \
    || { echo "Étiquette $T absente ou non signée."; exit 1; }
  publier_versions "$T"; exit $?
fi

[ -z "$(G status --porcelain --untracked-files=no)" ] || { echo "Modifications non validées : commit d'abord."; exit 1; }
[ "$(G rev-parse --abbrev-ref HEAD)" = main ] || { echo "Publier depuis la branche main seulement."; exit 1; }
ARBRE=$(G rev-parse "HEAD^{tree}")
/usr/bin/python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); sys.exit(0 if d.get("arbre")==sys.argv[2] and d.get("echecs")==0 else 1)' \
  "$ICI/.tests-reussis.json" "$ARBRE" 2>/dev/null || { echo "Tests non réussis sur ce commit : python3 tests/test_kineapp.py d'abord."; exit 1; }
/usr/bin/python3 -I "$ICI/outils/garde_fous.py" "$ICI" >/dev/null || { echo "Garde-fous non conformes."; exit 1; }
V=$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["version"])' "$ICI/version.json")
STATUT=$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("statut",""))' "$ICI/version.json")
[[ "$V" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "Numéro de version invalide dans version.json : $V"; exit 1; }
if G rev-parse -q --verify "refs/tags/v$V" >/dev/null; then echo "La version $V est déjà publiée : augmentez version.json."; exit 1; fi
DERNIERE=$(G tag -l 'v[0-9]*.[0-9]*.[0-9]*' --sort=-version:refname | head -1)
if [ -n "$DERNIERE" ] && ! /usr/bin/python3 -c 'import sys; a,b=[tuple(map(int,x.split("."))) for x in sys.argv[1:]]; sys.exit(0 if a>b else 1)' "$V" "${DERNIERE#v}"; then
  echo "La version $V n'est pas plus récente que $DERNIERE."; exit 1
fi
# Première publication : depuis le dernier envoi sur GitHub. -n plutôt que « | head » : avec pipefail, head qui
# ferme le tube arrêtait le script (code 141) dès que l'historique dépassait 60 lignes.
DEPUIS=${DERNIERE:-$(G rev-parse -q --verify origin/main 2>/dev/null || true)}
CHANGEMENTS=$(G log -n 60 --format='- %s' ${DEPUIS:+"$DEPUIS..HEAD"})
echo "Publication de KinéAPP $V ($STATUT), commit $(G rev-parse --short HEAD) :"
echo "$CHANGEMENTS"
if [ "$OUI" = 0 ]; then
  read -r -p "Signer et envoyer sur GitHub ? (o/N) " R
  case "$R" in o|O|oui|Oui|OUI) ;; *) echo "Rien n'est publié."; exit 1 ;; esac
fi
# Clé dans l'agent (phrase de passe gardée dans le trousseau) : signature par l'agent ; sinon la clé
# elle-même (phrase de passe demandée dans le Terminal).
SIGNER=$(cle_de_signature)
G -c gpg.format=ssh -c user.signingkey="$SIGNER" tag -s "v$V" -m "KinéAPP $V ($STATUT)" -m "$CHANGEMENTS"
G -c gpg.format=ssh -c gpg.ssh.allowedSignersFile="$SIGNATAIRES" verify-tag "v$V" >/dev/null 2>&1 \
  || { G tag -d "v$V" >/dev/null; echo "Signature non vérifiable avec outils/publication/signataires_autorises : annulé."; exit 1; }
G push origin main "v$V"
echo "KinéAPP $V publiée (code)."
publier_versions "v$V" || exit 1
