# -*- coding: utf-8 -*-
"""Range tous les fichiers de KinéAPP dans ~/Documents/KinéAPP, au lieu du Bureau.

    ~/Documents/KinéAPP/
        Bilans/  Suivi Kiné/  Transcriptions/  Comptes rendus/  Ordonnances/  Bibliothèque/
        Bancs/ (bancs d'essai, heidi.md, ancien benchmark)  Rapports/  Fiches de bilan/
        Anciennes versions/

Règles
  - Déplacement seulement (jamais de copie ni d'effacement) : dates, droits et contenus gardés.
  - Seuls des éléments connus de l'app ; rien d'autre du Bureau n'est touché. Si une destination
    existe déjà, l'élément reste où il est (signalé).
  - Réglages de l'app mis à jour (emplacements) ; anciens chemins réécrits dans les scripts des
    bancs, les rapports et la mémoire de l'assistant ; index de la bibliothèque recalé.
  - KinéAPP doit être fermée (son serveur garde les emplacements en mémoire).
  - Rien de nominatif affiché : seulement des nombres et les noms des dossiers de l'app.

    python3 outils/ranger.py [--essai] [--maison DIR]
"""
import argparse, glob, json, os, sqlite3, subprocess, sys

DESTINATION = "Documents/KinéAPP"


def destination(cfg):
    """Dossier KinéAPP choisi dans l'app (Documents par défaut, ou Bureau) : jamais déplacé d'ici."""
    return "Desktop/KinéAPP" if cfg.get("emplacement") == "bureau" else DESTINATION
CLES = (("bilans_dir", "~/Desktop/Bilans", "Bilans"),
        ("notes_dir", "~/Desktop/Suivi Kiné", "Suivi Kiné"),
        ("transcriptions_dir", "~/Documents/Transcriptions bilans", "Transcriptions"),
        ("cr_dir", "~/Desktop/Compte rendu", "Comptes rendus"),
        ("ordonnances_dir", "~/Desktop/Ordonnances", "Ordonnances"),
        ("bibliotheque_dir", "~/Documents/Bibliothèque KinéAPP", "Bibliothèque"))
# Éléments de l'app hors réglages : (motif sous le dossier personnel, destination sous KinéAPP).
AUTRES = (("Documents/KineAPP-bancs", "Bancs"),
          ("Desktop/heidi.md", "Bancs/heidi.md"),
          ("Desktop/Claude/benchmark", "Bancs/ancien benchmark"),
          ("Desktop/Claude/*KinéAPP*.md", "Rapports"),
          ("Desktop/Claude/Comparaison 27B 35B*.md", "Rapports"),
          ("Desktop/Claude/Analyse des comptes rendus*.md", "Rapports"),
          ("Desktop/Claude/Fiche Bilan *.pdf", "Fiches de bilan"),
          ("Documents/BilanKiné - stockage logiciel", "Anciennes versions/BilanKiné - stockage logiciel"),
          ("Documents/Bilans MD", "Anciennes versions/Bilans MD"))
TEXTES = (".py", ".sh", ".md", ".txt", ".json", ".log", ".jsonl", ".csv", ".command")


def developper(chemin, maison):
    return os.path.join(maison, chemin[2:]) if chemin.startswith("~/") else chemin


def app_ouverte():
    r = subprocess.run(["pgrep", "-f", "Contents/MacOS/KineAPP|Resources/ui/server.py"],        # sans accent
                       capture_output=True, text=True)
    return bool(r.stdout.strip())


def plan(maison, cfg):
    """[(source, destination, clé du réglage ou None)] ; la destination « Rapports » est un dossier."""
    cible = os.path.join(maison, destination(cfg))
    out = []
    for cle, defaut, nom in CLES:
        out.append((developper(cfg.get(cle) or defaut, maison), os.path.join(cible, nom), cle))
    for motif, dest in AUTRES:
        for src in sorted(glob.glob(os.path.join(maison, motif))):
            d = os.path.join(cible, dest)
            if dest in ("Rapports", "Fiches de bilan"):
                d = os.path.join(d, os.path.basename(src))
            out.append((src, d, None))
    return out


def reecrire_chemins(racines, correspondances, essai):
    """Anciens chemins (absolus et « ~/… ») remplacés dans les fichiers texte, dates gardées."""
    n = 0
    for racine in racines:
        for d, dirs, fichiers in os.walk(racine) if os.path.isdir(racine) else []:
            dirs[:] = [x for x in dirs if not os.path.islink(os.path.join(d, x))]
            for f in fichiers:
                p = os.path.join(d, f)
                if os.path.islink(p) or not f.endswith(TEXTES) or os.path.getsize(p) > 50_000_000:
                    continue
                try:
                    t = open(p, encoding="utf-8").read()
                except (UnicodeDecodeError, OSError):
                    continue
                t2 = t
                for ancien, nouveau in correspondances:
                    t2 = t2.replace(ancien, nouveau)
                if t2 != t:
                    n += 1
                    if not essai:
                        st = os.stat(p)
                        with open(p, "w", encoding="utf-8") as fh:
                            fh.write(t2)
                        os.utime(p, ns=(st.st_atime_ns, st.st_mtime_ns))
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--essai", action="store_true", help="dire ce qui serait fait, sans rien déplacer")
    ap.add_argument("--maison", default=os.path.expanduser("~"))
    a = ap.parse_args()
    maison = os.path.realpath(a.maison)
    bases = {maison, os.path.abspath(a.maison)}          # chemins écrits avec ou sans liens résolus
    donnees = os.path.join(maison, "Library/Application Support/BilanKine")
    config = os.path.join(donnees, "ui_config.json")
    if not a.essai and a.maison == os.path.expanduser("~") and app_ouverte():
        print("KinéAPP est ouverte : quittez-la (séance terminée), puis relancez le rangement.")
        return 1
    try:
        cfg = json.load(open(config, encoding="utf-8"))
    except (OSError, ValueError):
        cfg = {}
    cible = os.path.join(maison, destination(cfg))
    deplaces, deja, absents, occupes = [], 0, 0, []
    correspondances = []
    for src, dest, cle in plan(maison, cfg):
        if os.path.realpath(src) == os.path.realpath(dest) or (cle and not os.path.exists(src) and os.path.isdir(dest)):
            deja += 1
        elif not os.path.exists(src):
            absents += 1
        elif os.path.exists(dest):
            occupes.append(os.path.relpath(dest, cible))
        else:
            if not a.essai:
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                os.rename(src, dest)                      # même disque : un simple renommage
            deplaces.append(os.path.relpath(dest, cible))
            rel = os.path.relpath(os.path.realpath(os.path.dirname(src)), maison) + "/" + os.path.basename(src)
            for ancien in {src} | {os.path.join(base, rel) for base in bases}:
                correspondances.append((ancien, dest))
            correspondances.append(("~/" + rel, "~/" + os.path.relpath(dest, maison)))
        if cle:
            if not a.essai:
                os.makedirs(dest, exist_ok=True)
            cfg[cle] = dest
    # Le plus long d'abord : « …/Suivi Kiné/Archive » avant « …/Suivi Kiné ».
    correspondances.sort(key=lambda c: -len(c[0]))
    if not a.essai and os.path.isdir(donnees):
        tmp = config + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, config)
        base = os.path.join(donnees, "bibliotheque.sqlite")
        if os.path.isfile(base):
            with sqlite3.connect(base) as c:
                for ancien, nouveau in correspondances:
                    c.execute("UPDATE documents SET chemin = replace(chemin, ?, ?), dossier = replace(dossier, ?, ?)",
                              (ancien, nouveau, ancien, nouveau))
    memoire = glob.glob(os.path.join(maison, ".claude/projects/*/memory"))
    # Fiches d'ordonnances et de comptes rendus : chemin de leur .docx.
    fiches = [os.path.join(donnees, "ordonnances"), os.path.join(donnees, "comptes_rendus")]
    n = reecrire_chemins([os.path.join(cible, "Bancs"), os.path.join(cible, "Rapports")] + memoire + fiches,
                         correspondances, a.essai or not correspondances)
    print(("(essai) " if a.essai else "") + f"Rangement dans ~/{destination(cfg)} : {len(deplaces)} élément(s) déplacé(s)"
          + (f" ({', '.join(sorted(set(d.split('/')[0] for d in deplaces)))})" if deplaces else "")
          + f", {deja} déjà en place, {absents} absent(s).")
    if occupes:
        print(f"Laissés en place, destination déjà occupée : {', '.join(sorted(set(occupes)))}.")
    print(f"Réglages de l'app mis à jour ; anciens chemins réécrits dans {n} fichier(s) (bancs, rapports, mémoire).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
