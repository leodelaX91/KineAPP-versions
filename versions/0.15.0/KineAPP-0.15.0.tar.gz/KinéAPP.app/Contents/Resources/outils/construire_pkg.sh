#!/bin/bash
# Paquet d'installation macOS (.pkg) de KinéAPP pour le Mac d'un collègue : double-clic, « Continuer », mot de
# passe du Mac, et c'est installé (coffre d'identité compris). Aucun Terminal, aucun outil de développement.
# Le paquet contient la version construite et signée (outils/construire_version.sh + signature de publier.sh) ;
# son script postinstall lance l'installateur de cette version en mode --paquet, qui vérifie la signature.
#
#     outils/construire_pkg.sh DOSSIER_DES_VERSIONS X.Y.Z      → DOSSIER_DES_VERSIONS/KineAPP.pkg
set -euo pipefail
ICI="$(cd "$(dirname "$0")/.." && pwd)"
SORTIE="${1:?dossier des versions attendu}"; V="${2:?version attendue}"
D="$SORTIE/versions/$V"
for f in "KineAPP-$V.tar.gz" "KineAPP-$V.json" "KineAPP-$V.json.sig"; do
  [ -f "$D/$f" ] || { echo "Manquant : $D/$f (version construite et signée d'abord)."; exit 1; }
done
TMP=$(mktemp -d /tmp/kineapp-pkg.XXXXXX)
trap 'rm -rf "$TMP"' EXIT
CHARGE="$TMP/racine/Library/Application Support/KineAPP/Paquet d'installation"
mkdir -p "$CHARGE" "$TMP/scripts" "$TMP/ressources"
cp "$D/KineAPP-$V.tar.gz" "$CHARGE/"
cp "$D/KineAPP-$V.json" "$CHARGE/manifeste.json"
cp "$D/KineAPP-$V.json.sig" "$CHARGE/manifeste.json.sig"
# Installateur et clés de publication : ceux de l'archive elle-même (la version qu'on installe).
mkdir -p "$TMP/extrait"
tar -xzf "$D/KineAPP-$V.tar.gz" -C "$TMP/extrait" --include '*/Resources/outils/installer.sh' \
    --include '*/Resources/outils/publication/signataires_autorises'
INST=$(find "$TMP/extrait" -path '*/Resources/outils/installer.sh' | head -1)
SIGN=$(find "$TMP/extrait" -path '*/outils/publication/signataires_autorises' | head -1)
[ -f "$INST" ] && [ -f "$SIGN" ] || { echo "Installateur ou clés absents de l'archive."; exit 1; }
cp "$INST" "$CHARGE/installer.sh"
cp "$SIGN" "$CHARGE/signataires_autorises"
cp "$ICI/outils/paquet/preinstall" "$ICI/outils/paquet/postinstall" "$TMP/scripts/"
chmod 755 "$TMP/scripts/"*
cp "$ICI/outils/paquet/"*.html "$TMP/ressources/"
xattr -cr "$TMP/racine" "$TMP/scripts"                # sans attributs étendus (fichiers « ._ » dans le paquet)
COPYFILE_DISABLE=1 pkgbuild --quiet --root "$TMP/racine" --scripts "$TMP/scripts" --identifier fr.kineapp.installation --version "$V" \
  --install-location / --ownership recommended "$TMP/KineAPP-composant.pkg"
sed "s/@VERSION@/$V/g" "$ICI/outils/paquet/distribution.xml" > "$TMP/distribution.xml"
productbuild --quiet --distribution "$TMP/distribution.xml" --package-path "$TMP" --resources "$TMP/ressources" \
  "$SORTIE/KineAPP.pkg"
echo "Paquet : $SORTIE/KineAPP.pkg ($(( $(stat -f %z "$SORTIE/KineAPP.pkg") / 1048576 )) Mo)"
