#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Déchiffrement de secours des données de KinéAPP, SANS l'app : il suffit du code de secours noté
à l'activation du chiffrement (52 caractères, par groupes de 4) et du Python de macOS.

    python3 dechiffrer_secours.py SOURCE DESTINATION

SOURCE : le dossier KinéAPP (bilans, transcriptions, comptes rendus, ordonnances), ou le dossier
des données de l'app (~/Library/Application Support/BilanKine). Le code est demandé au clavier (il
ne s'affiche pas). DESTINATION (créée, vide) reçoit une copie EN CLAIR de tout, même arborescence ;
la base de l'app (kineapp.sqlite) y devient un dossier « base » avec un fichier JSON par fiche. Rien
n'est modifié dans SOURCE. Gardez la copie en clair en lieu sûr, et mettez-la à la Corbeille dès
qu'elle n'est plus utile.

Format (aussi lisible par openssl, voir le mode d'emploi) :
    « KENC1\\0 » | iv (16 octets) | AES-256-CBC (PKCS#7) | HMAC-SHA256 (32 octets)
    clé AES = HMAC-SHA256(clé, « kineapp-chiffrement »), clé HMAC = HMAC-SHA256(clé, « kineapp-authentification »)
"""
import base64, ctypes, getpass, hashlib, hmac, json, os, shutil, sqlite3, sys

MAGIC = b"KENC1\x00"


def cle_du_code(code):
    t = "".join(c for c in str(code or "").upper() if c.isalnum())
    t = t.replace("0", "O").replace("1", "I").replace("8", "B")
    cle = base64.b32decode(t + "=" * (-len(t) % 8))
    if len(cle) != 32:
        raise ValueError("code de secours incomplet")
    return cle


def _aes_dechiffrer(cle, iv, donnees):
    f = ctypes.CDLL("/usr/lib/system/libcommonCrypto.dylib").CCCrypt
    f.restype = ctypes.c_int32
    f.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p,
                  ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
    sortie = ctypes.create_string_buffer(len(donnees) + 16)
    n = ctypes.c_size_t(0)
    if f(1, 0, 1, cle, 32, iv, donnees, len(donnees), sortie, len(sortie), ctypes.byref(n)) != 0:
        raise ValueError("déchiffrement impossible")
    return sortie.raw[:n.value]


def dechiffrer(blob, cle):
    if blob[:len(MAGIC)] != MAGIC:
        return blob                                   # déjà en clair
    k_chif = hmac.new(cle, b"kineapp-chiffrement", hashlib.sha256).digest()
    k_auth = hmac.new(cle, b"kineapp-authentification", hashlib.sha256).digest()
    corps, tag = blob[:-32], blob[-32:]
    if not hmac.compare_digest(hmac.new(k_auth, corps, hashlib.sha256).digest(), tag):
        raise ValueError("code de secours incorrect, ou fichier abîmé")
    return _aes_dechiffrer(k_chif, corps[len(MAGIC):len(MAGIC) + 16], corps[len(MAGIC) + 16:])


def exporter_base(chemin, dest, cle):
    """La base est copiée (avec son journal) dans un dossier temporaire avant lecture : l'original
    n'est jamais ouvert en écriture."""
    import tempfile
    n, tmp = 0, tempfile.mkdtemp()
    for suffixe in ("", "-wal", "-shm"):
        if os.path.exists(chemin + suffixe):
            shutil.copyfile(chemin + suffixe, os.path.join(tmp, "base.sqlite" + suffixe))
    c = sqlite3.connect(os.path.join(tmp, "base.sqlite"))
    for genre, k, donnees in c.execute("SELECT genre, cle, donnees FROM documents"):
        d = os.path.join(dest, "base", genre)
        os.makedirs(d, exist_ok=True)
        doc = json.loads(dechiffrer(bytes(donnees), cle).decode("utf-8"))
        with open(os.path.join(d, os.path.basename(k) + ".json"), "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False, indent=1)
        n += 1
    c.close()
    shutil.rmtree(tmp, ignore_errors=True)            # copie de travail (chiffrée), pas l'original
    return n


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    source, dest = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
    if os.path.exists(dest) and os.listdir(dest):
        raise SystemExit("La destination doit être un dossier vide (rien n'est jamais écrasé).")
    code = getpass.getpass("Code de secours (il ne s'affiche pas) : ") if sys.stdin.isatty() else sys.stdin.readline()
    cle = cle_du_code(code)
    fichiers = base_docs = erreurs = 0
    for racine, dirs, noms in os.walk(source):
        dirs[:] = [x for x in dirs if not os.path.islink(os.path.join(racine, x))]
        for nom in noms:
            src = os.path.join(racine, nom)
            if os.path.islink(src) or nom.endswith(("-wal", "-shm")):
                continue
            rel = os.path.relpath(src, source)
            if nom == "kineapp.sqlite":
                base_docs += exporter_base(src, os.path.join(dest, os.path.dirname(rel)), cle)
                continue
            os.makedirs(os.path.dirname(os.path.join(dest, rel)), exist_ok=True)
            try:
                with open(src, "rb") as f:
                    donnees = dechiffrer(f.read(), cle)
                with open(os.path.join(dest, rel), "wb") as f:
                    f.write(donnees)
                shutil.copystat(src, os.path.join(dest, rel))
                fichiers += 1
            except ValueError as e:
                erreurs += 1
                print(f"illisible : {rel} ({e})")
    print(f"{fichiers} fichier(s) copiés en clair, {base_docs} fiche(s) de la base exportées, {erreurs} erreur(s).")
    print(f"Copie en clair : {dest}")


if __name__ == "__main__":
    main()
