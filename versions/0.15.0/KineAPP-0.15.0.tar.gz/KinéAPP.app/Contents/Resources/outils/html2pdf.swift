// html2pdf : convertit un fichier HTML en PDF paginé (A4), entièrement en local (WebKit).
// Usage : html2pdf entree.html sortie.pdf
import AppKit
import WebKit

let args = CommandLine.arguments
guard args.count == 3 else { FileHandle.standardError.write("usage: html2pdf entree.html sortie.pdf\n".data(using: .utf8)!); exit(2) }
let entree = URL(fileURLWithPath: args[1]), sortie = URL(fileURLWithPath: args[2])

final class Convertisseur: NSObject, WKNavigationDelegate {
    let vue: WKWebView
    init(largeur: CGFloat) {
        let conf = WKWebViewConfiguration()
        vue = WKWebView(frame: NSRect(x: 0, y: 0, width: largeur, height: 1000), configuration: conf)
        super.init()
        vue.navigationDelegate = self
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        let info = NSPrintInfo()
        info.paperSize = NSSize(width: 595.28, height: 841.89)            // A4 en points
        info.topMargin = 36; info.bottomMargin = 36; info.leftMargin = 36; info.rightMargin = 36
        info.horizontalPagination = .fit; info.verticalPagination = .automatic
        info.jobDisposition = .save
        info.dictionary()[NSPrintInfo.AttributeKey.jobSavingURL] = sortie
        let op = webView.printOperation(with: info)
        op.showsPrintPanel = false; op.showsProgressPanel = false
        op.view?.frame = NSRect(x: 0, y: 0, width: 523, height: 1000)
        op.runModal(for: NSWindow(), delegate: self, didRun: #selector(fini(_:success:contextInfo:)), contextInfo: nil)
    }
    @objc func fini(_ op: NSPrintOperation, success: Bool, contextInfo: UnsafeMutableRawPointer?) {
        exit(success ? 0 : 1)
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { exit(1) }
}

let app = NSApplication.shared
app.setActivationPolicy(.prohibited)
let c = Convertisseur(largeur: 523)
c.vue.loadFileURL(entree, allowingReadAccessTo: entree.deletingLastPathComponent())
DispatchQueue.main.asyncAfter(deadline: .now() + 30) { exit(3) }
app.run()
