# -*- coding: utf-8 -*-
"""Contrôle avant tout envoi du code vers GitHub (crochet pre-push du dépôt).

Le dépôt GitHub n'est qu'une copie de sauvegarde du CODE. Rien de nominatif ne doit y partir,
ni dans le code actuel ni dans l'historique (commits d'avant le coffre). L'envoi est refusé si :
  1. un nom de patient apparaît dans l'historique : civilité suivie d'un nom qui n'est pas un code
     du coffre, hors noms fictifs des tests ; ou nom d'un dossier patient encore en clair dans
     le dossier KinéAPP, dans Documents ou sur le Bureau (migration non faite) ;
  2. les garde-fous de confidentialité refusent le code envoyé.
Rien de nominatif n'est affiché : des nombres, des identifiants de commit, des chemins de fichiers
du code et des mots masqués (initiale et longueur), numérotés.

Tri des mots repérés (un mot qui suit « M. » n'est pas toujours un patient : « M. Lecture »…) :
    python3 -I outils/verifier_envoi.py --montrer     MONTRE les mots en clair, avec leur contexte :
                                                     dans le Terminal de macOS seulement, par
                                                     l'utilisateur, jamais par un assistant
    python3 -I outils/verifier_envoi.py --ignorer 2,5  mots qui ne sont PAS des patients : leur
                                                     empreinte (SHA-256, sans le mot) est notée dans
                                                     outils/envoi_ignores.txt

    python3 -I outils/verifier_envoi.py [--git-dir DEPOT]
"""
import argparse, hashlib, os, re, subprocess, sys, tempfile

ICI = os.path.dirname(os.path.abspath(__file__))
CODE = r"P-[23456789BCDFGHJKMNPQRSTVWXZ]{6}"
CIVILITE = re.compile(r"\b(?:Mme|Mlle|Madame|Monsieur|Mademoiselle|M\.?)\s+(?!" + CODE + r")([A-ZÀ-Ý][a-zà-ÿ'’-]{2,})")
DOSSIER = re.compile(r"^(?:Mme|Mlle|M\.?|Madame|Monsieur|Mademoiselle)\s+(?!" + CODE + r")([^_\s]+)", re.I)
GENERIQUES = {"modèle", "modele", "test", "testeur", "exemple", "fictif", "fictive", "patient", "patiente", "code",
              "nom", "prénom", "untel", "unetelle"}
DOSSIERS_PATIENTS = ("Bilans", "Suivi Kiné", "Transcriptions", "Comptes rendus", "Ordonnances")
IGNORES = os.path.join(ICI, "envoi_ignores.txt")


def empreinte(mot):
    return hashlib.sha256(("kineapp-envoi:" + mot).encode("utf-8")).hexdigest()


def ignores():
    try:
        return {l.split()[0] for l in open(IGNORES, encoding="utf-8") if l.strip() and not l.startswith("#")}
    except OSError:
        return set()


def plat(t):
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")


def git(depot, *a, entree=None):
    return subprocess.run(["git", "--git-dir", depot] + list(a), capture_output=True, input=entree, check=True).stdout


def noms_fictifs(depot):
    """Noms des tests (fictifs par règle du projet), dans le code actuel."""
    out = set(GENERIQUES)
    for chemin in git(depot, "ls-tree", "-r", "--name-only", "HEAD", "tests").decode().splitlines():
        texte = git(depot, "show", f"HEAD:{chemin}").decode("utf-8", "replace")
        out |= {plat(m.group(1)) for m in CIVILITE.finditer(texte)}
    return out


def noms_en_clair():
    """Noms des dossiers patients encore en clair (avant la migration) : cherchés tels quels."""
    out = set()
    for base, d in ((os.path.expanduser(b), d) for b in ("~/Documents/KinéAPP", "~/Desktop/KinéAPP")
                    for d in DOSSIERS_PATIENTS):        # dossier KinéAPP dans Documents ou sur le Bureau
        try:
            for n in os.listdir(os.path.join(base, d)):
                m = DOSSIER.match(n)
                if m and len(m.group(1)) >= 3:
                    out.add(plat(m.group(1)))
        except OSError:
            pass
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--git-dir", default=os.environ.get("GIT_DIR") or os.path.expanduser("~/Developer/KineAPP.git"))
    ap.add_argument("--montrer", action="store_true", help="mots en clair et contexte (Terminal de macOS seulement)")
    ap.add_argument("--ignorer", help="numéros des mots qui ne sont pas des patients, séparés par des virgules")
    a = ap.parse_args()
    depot = a.git_dir
    # Crochet pre-push : git donne sur l'entrée standard « réf_locale sha réf_distante sha » ; seul ce
    # qui part est contrôlé, avec tout son historique (l'historique local d'avant la publication,
    # gardé sous refs/archives, ne part jamais). Sans entrée : HEAD.
    a.revs = []
    if not sys.stdin.isatty():
        for l in sys.stdin.read().splitlines():
            x = l.split()
            if len(x) == 4 and x[1].strip("0"):
                a.revs.append(x[1])
    a.revs = a.revs or ["HEAD"]
    deja = ignores()
    fictifs = noms_fictifs(depot)
    clairs = noms_en_clair() - fictifs
    motif_clairs = re.compile(r"\b(" + "|".join(re.escape(n) for n in sorted(clairs)) + r")\b") if clairs else None

    # Tout l'historique : messages et contenus (hors tests), commit par commit.
    journal = git(depot, "log", *a.revs, "-p", "--no-color", "--no-ext-diff", "--format=@@COMMIT %h%n%B",
                  "--", ".", ":(exclude)tests").decode("utf-8", "replace")
    commits, fichiers, n = set(), set(), 0
    commit, fichier = "", ""
    mots = {}                                       # mot -> [(commit, fichier, ligne)]
    for ligne in journal.splitlines():
        if ligne.startswith("@@COMMIT "):
            commit, fichier = ligne.split()[1], "(message)"
            continue
        if ligne.startswith("+++ b/"):
            fichier = ligne[6:]
            continue
        if ligne.startswith(("---", "+++", "diff --git", "index ")):
            continue
        trouves = [plat(m.group(1)) for m in CIVILITE.finditer(ligne)]
        trouves = [w for w in trouves if w not in fictifs and empreinte(w) not in deja]
        for w in trouves:
            mots.setdefault(w, []).append((commit, fichier, ligne.strip()[:160]))
        trouve = bool(trouves)
        if not trouve and motif_clairs:
            trouve = bool(motif_clairs.search(plat(ligne)))
        if trouve:
            n += 1
            commits.add(commit)
            fichiers.add(fichier)
    liste = sorted(mots)

    if a.montrer:
        print("NOMS EN CLAIR — à lire vous-même, ne pas copier dans une conversation avec un assistant.\n")
        for i, w in enumerate(liste, 1):
            print(f"{i}. {w}")
            for c, f, l in mots[w][:3]:
                print(f"     {c} {f} : {l}")
        print("\nMots qui ne sont pas des patients : python3 -I outils/verifier_envoi.py --ignorer 1,3,…")
        return 0
    if a.ignorer:
        choisis = [liste[int(x) - 1] for x in a.ignorer.replace(" ", "").split(",") if x.isdigit() and 0 < int(x) <= len(liste)]
        with open(IGNORES, "a", encoding="utf-8") as f:
            if not deja:
                f.write("# Mots repérés par verifier_envoi.py qui ne sont pas des patients (empreintes, sans le mot).\n")
            for w in choisis:
                f.write(empreinte(w) + "\n")
        print(f"{len(choisis)} mot(s) noté(s) comme n'étant pas des patients.")
        return 0

    # Garde-fous de confidentialité sur le code envoyé (HEAD).
    with tempfile.TemporaryDirectory() as t:
        subprocess.run(["tar", "-x", "-C", t], input=git(depot, "archive", "--format=tar", "HEAD"), check=True)
        gf = subprocess.run([sys.executable, "-I", os.path.join(ICI, "garde_fous.py"), t], capture_output=True, text=True)

    refus = False
    if clairs:
        print(f"Migration non faite : {len(clairs)} nom(s) de patients encore en clair dans le dossier KinéAPP.")
    if n:
        refus = True
        print(f"Envoi refusé : {n} ligne(s) de l'historique contiennent un nom possible de patient, "
              f"dans {len(commits)} commit(s) et {len(fichiers)} fichier(s). Mots repérés (masqués) :")
        for i, w in enumerate(liste, 1):
            fs = sorted({f for _, f, _ in mots[w]})
            print(f"  {i}. {w[0].upper()}… ({len(w)} lettres) — {', '.join(fs)}")
        print("Tri par l'utilisateur, dans le Terminal de macOS : python3 -I outils/verifier_envoi.py --montrer")
    if gf.returncode != 0:
        refus = True
        print(gf.stdout.strip())
    if not refus:
        print("Contrôle avant envoi : aucun nom de patient dans l'historique, garde-fous conformes.")
    return 1 if refus else 0


if __name__ == "__main__":
    sys.exit(main())
