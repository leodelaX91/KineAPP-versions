# -*- coding: utf-8 -*-
"""Dictées de séance enregistrées sur l'iPhone (Raccourci) et déposées par iCloud Drive.

Lancé par la fenêtre native de KinéAPP (Python isolé, environnement propre), jamais par le
serveur : le nom du patient, tapé sur l'iPhone, est dans le NOM du fichier. Il ne transite que
par la sortie standard de ce script, lue en mémoire par la fenêtre, puis par le coffre. Ce script
n'écrit rien de nominatif et ne se connecte à rien (macOS synchronise le dossier).

    python3 -I dictees_icloud.py --lister DOSSIER [--attente 5]
        JSON : {"dictees": [{id, fichier, type, nom_saisi, date, heure, octets}], "en_attente": n, "erreur": ""}
        Seuls les fichiers COMPLETS : taille stable pendant l'attente et contenu présent sur le Mac
        (un fichier encore dans iCloud est demandé à macOS, puis repris au passage suivant).
    python3 -I dictees_icloud.py --ingerer CHEMIN --vers DOSSIER --id IDENTIFIANT
        Copie vers DOSSIER/IDENTIFIANT.<ext> (nom neutre, droits 600), relit la copie, puis met
        l'original à la Corbeille et vérifie qu'il a quitté le dossier.
        JSON : {"ok": true, "chemin": …, "corbeille": bool} ou {"ok": false, "erreur": …}.
    python3 -I dictees_icloud.py --retirer CHEMIN --vers DOSSIER --id IDENTIFIANT
        Original d'une dictée déjà reçue : Corbeille, Corbeille de la session, sinon rangé hors d'iCloud
        (DOSSIER/originaux/IDENTIFIANT.<ext>). JSON : {"ok", "comment", "erreur"}.

Nom attendu : « Nom saisi__AAAA-MM-JJ_HHMM.m4a » (deux tirets bas). Date illisible : date de
modification du fichier.

Raccourci simple (tutoriel de l'app) : « Usage__Nom saisi.m4a », l'usage choisi dans le menu en tête
(Séance, Bilan, Réévaluation, Courrier), sans date : la date et l'heure sont celles du fichier.
Note écrite (choix « Texte » du Raccourci) : « Usage__Nom saisi.txt », traitée comme une dictée déjà
transcrite. Un fichier en double reçu de l'iPhone (« … 2.m4a ») garde le même nom saisi. Un sous-dossier portant
le nom d'un usage (Séances, Bilans…) est aussi compris. Sans usage : note de séance.
"""
import argparse, datetime, hashlib, json, os, re, shutil, subprocess, sys, threading, time

EXTENSIONS = (".m4a", ".mp3", ".wav", ".aac", ".caf", ".txt")   # .txt : note écrite (choix « Texte » du Raccourci)
SF_DATALESS = 0x40000000                   # fichier iCloud dont le contenu n'est pas sur le Mac
RE_DATE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})(?:[_ T-]?(\d{2})[h:.]?(\d{2}))?$")


def _plat(t):
    import unicodedata
    t = unicodedata.normalize("NFD", t or "")
    return "".join(c for c in t if unicodedata.category(c) != "Mn").lower().strip()


TYPES_EXACTS = {"seance": "seance", "seances": "seance", "note": "seance", "notes": "seance", "note de seance": "seance",
                "bilan": "bilan", "bilans": "bilan", "bilan initial": "bilan", "reevaluation": "reevaluation",
                "reevaluations": "reevaluation", "bilan de reevaluation": "reevaluation", "courrier": "courrier",
                "courriers": "courrier", "lettre": "courrier"}


def type_en_tete(mot):
    """Usage écrit en tête du nom : mot exact seulement (un nom de patient n'est jamais pris pour un usage)."""
    return TYPES_EXACTS.get(" ".join(_plat(mot).replace("_", " ").split()))


def type_dictee(mot):
    """« Séances », « bilan initial », « Réévaluation », « courriers »… -> type, ou None."""
    m = " ".join(_plat(mot).replace("_", " ").split())
    if "reeval" in m or "re-eval" in m:               # « Réévaluations », « bilan de réévaluation »
        return "reevaluation"
    for prefixe, t in (("seance", "seance"), ("note", "seance"), ("bilan", "bilan"), ("courrier", "courrier"),
                       ("lettre", "courrier"), ("compte rendu", "courrier")):
        if m.startswith(prefixe):
            return t
    return None


def analyser_nom(fichier, mtime):
    """« Mme Dupont__2026-10-15_1432.m4a » -> (« Mme Dupont », « 15/10/2026 », « 14:32 »)."""
    base = os.path.basename(fichier)
    while os.path.splitext(base)[1].lower() in EXTENSIONS:      # « …1432.m4a.m4a » : extension en double
        base = os.path.splitext(base)[0]
    morceaux = base.split("__")
    if len(morceaux) > 1 and type_en_tete(morceaux[0]):         # « Bilan__Nom saisi » : usage en tête
        morceaux = morceaux[1:]
    date = morceaux.pop() if len(morceaux) > 1 and RE_DATE.match(morceaux[-1].strip()) else ""
    nom = " ".join("__".join(morceaux).replace("_", " ").split())
    if not date:
        nom = re.sub(r"\s\d{1,2}$", "", nom)                      # « Nom 2 » : doublon renommé par l'iPhone
    m = RE_DATE.match(date.strip())
    if m:
        try:
            d = datetime.datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                                  int(m.group(4) or 0), int(m.group(5) or 0))
            return nom, d.strftime("%d/%m/%Y"), (d.strftime("%H:%M") if m.group(4) else "")
        except ValueError:
            pass
    d = datetime.datetime.fromtimestamp(mtime)
    return nom, d.strftime("%d/%m/%Y"), d.strftime("%H:%M")


def identifiant(rel, st):
    """Stable tant que le fichier ne change pas : chemin relatif + taille + date de modification."""
    return hashlib.sha256(f"{rel}|{st.st_size}|{int(st.st_mtime)}".encode("utf-8")).hexdigest()[:24]


def demander_telechargement(chemin, delai=20):
    """Lire un octet suffit pour que macOS rapatrie un fichier iCloud ; borné dans le temps."""
    def lire():
        try:
            with open(chemin, "rb") as f:
                f.read(1)
        except OSError:
            pass
    t = threading.Thread(target=lire, daemon=True)
    t.start()
    t.join(delai)


def candidats(dossier):
    out = []
    for d, dirs, fichiers in os.walk(dossier):
        dirs[:] = [x for x in dirs if not x.startswith(".")]
        for f in fichiers:
            if f.startswith(".") or not f.lower().endswith(EXTENSIONS):
                continue                   # .DS_Store, espaces réservés « .x.m4a.icloud », temporaires
            if f.lower().endswith(".txt") and not ("__" in f and type_en_tete(f.split("__", 1)[0])):
                continue                   # texte sans usage en tête : pas une note du Raccourci
            p = os.path.join(d, f)
            try:
                st = os.stat(p)
            except OSError:
                continue
            out.append((p, st))
    return out


def type_du_fichier(chemin, dossier):
    """Sous-dossier (premier niveau) d'abord, type en tête du nom ensuite, note de séance sinon."""
    rel = os.path.relpath(chemin, dossier).split(os.sep)
    if len(rel) > 1 and type_dictee(rel[0]):
        return type_dictee(rel[0])
    base = os.path.basename(chemin)
    if "__" in base and type_en_tete(base.split("__", 1)[0]):
        return type_en_tete(base.split("__", 1)[0])
    return "seance"


def lister(dossier, attente):
    if not os.path.isdir(dossier):
        # Dossier dans iCloud Drive pas encore créé : créé ici, il apparaît sur l'iPhone (app Fichiers).
        parent = os.path.dirname(os.path.normpath(dossier))
        if os.path.isdir(parent) and os.path.basename(parent) == "com~apple~CloudDocs":
            try:
                os.mkdir(dossier, 0o700)
                return {"dictees": [], "en_attente": 0, "erreur": "", "cree": True}
            except OSError:
                pass
        return {"dictees": [], "en_attente": 0, "erreur": "Dossier des dictées introuvable."}
    try:
        os.listdir(dossier)
    except PermissionError:
        return {"dictees": [], "en_attente": 0,
                "erreur": "Accès au dossier iCloud refusé : autorisez KinéAPP (Réglages Système → Confidentialité "
                          "et sécurité → Fichiers et dossiers)."}
    premiers = candidats(dossier)
    en_attente = 0
    for p, st in premiers:
        if st.st_flags & SF_DATALESS:
            demander_telechargement(p)
    if attente:
        time.sleep(attente)
    out = []
    for p, st in premiers:
        try:
            st2 = os.stat(p)
        except OSError:
            continue
        mini = 1 if p.lower().endswith(".txt") else 1000       # une note écrite est petite, un audio non
        if (st2.st_flags & SF_DATALESS) or st2.st_size != st.st_size or st2.st_mtime != st.st_mtime \
                or st2.st_size < mini or time.time() - st2.st_mtime < attente:
            en_attente += 1                # encore dans iCloud, ou en cours d'écriture
            continue
        rel = os.path.relpath(p, dossier)
        nom, date, heure = analyser_nom(p, st2.st_mtime)
        out.append({"id": identifiant(rel, st2), "fichier": p, "type": type_du_fichier(p, dossier), "nom_saisi": nom,
                    "date": date, "heure": heure, "octets": st2.st_size})
    out.sort(key=lambda x: (x["date"][6:] + x["date"][3:5] + x["date"][:2], x["heure"]))
    return {"dictees": out, "en_attente": en_attente, "erreur": ""}


def corbeille(chemin):
    if os.environ.get("KINEAPP_TEST") == "1":          # tests : corbeille d'essai
        dest = os.path.join(os.environ["KINEAPP_CORBEILLE_ESSAI"], os.path.basename(chemin))
        try:
            shutil.move(chemin, dest)
        except OSError as e:
            return f"Corbeille refusée ({type(e).__name__})."
        return ""
    r = subprocess.run(["/usr/bin/trash", chemin], capture_output=True, text=True, timeout=120)
    return "" if r.returncode == 0 else (r.stderr or r.stdout).strip()[-200:]


def _vers_corbeille_du_mac(chemin):
    """Second essai sans l'outil « trash » : déplacement dans la Corbeille de la session (~/.Trash), sous un nom
    libre ; le fichier quitte iCloud et reste récupérable depuis le Finder."""
    corb = os.path.expanduser("~/.Trash")
    if os.environ.get("KINEAPP_TEST") == "1":
        corb = os.environ.get("KINEAPP_CORBEILLE_MAC_ESSAI", "")
    if not corb or not os.path.isdir(corb):
        return False
    base, ext = os.path.splitext(os.path.basename(chemin))
    dest, n = os.path.join(corb, base + ext), 1
    while os.path.lexists(dest):
        n += 1
        dest = os.path.join(corb, f"{base} {n}{ext}")
    try:
        os.rename(chemin, dest)
    except OSError:
        return False
    return not os.path.lexists(chemin)


def retirer(chemin, vers, ident):
    """Original d'une dictée déjà copiée : il doit quitter iCloud, sinon il reviendrait à chaque passage
    (« à attribuer » sans fin). Corbeille de macOS, puis Corbeille de la session, puis, en dernier recours, rangé
    hors d'iCloud sous un nom neutre dans le dossier de l'app (VERS/originaux, contenu intact, sans le nom tapé).
    Rien n'est effacé. Renvoie {"ok", "comment", "erreur"}."""
    if not os.path.lexists(chemin):
        return {"ok": True, "comment": "deja", "erreur": ""}
    err = corbeille(chemin)
    if not err and not os.path.lexists(chemin):
        return {"ok": True, "comment": "corbeille", "erreur": ""}
    if _vers_corbeille_du_mac(chemin):
        return {"ok": True, "comment": "corbeille_mac", "erreur": ""}
    if not re.fullmatch(r"[0-9a-f]{8,64}", ident or "") or not vers:
        return {"ok": False, "comment": "", "erreur": err or "Original toujours dans iCloud."}
    rang = os.path.join(vers, "originaux")
    os.makedirs(rang, mode=0o700, exist_ok=True)
    dest = os.path.join(rang, ident + os.path.splitext(chemin)[1].lower())
    try:
        shutil.move(chemin, dest)
        os.chmod(dest, 0o600)
    except OSError as e:
        return {"ok": False, "comment": "", "erreur": (err or "") + f" ; rangement impossible ({type(e).__name__})."}
    return {"ok": not os.path.lexists(chemin), "comment": "range", "erreur": err}


def ingerer(chemin, vers, ident):
    if not re.fullmatch(r"[0-9a-f]{8,64}", ident or ""):
        return {"ok": False, "erreur": "Identifiant invalide."}
    ext = os.path.splitext(chemin)[1].lower()
    if ext not in EXTENSIONS or not os.path.isfile(chemin):
        return {"ok": False, "erreur": "Fichier introuvable."}
    os.makedirs(vers, mode=0o700, exist_ok=True)
    dest = os.path.join(vers, ident + ext)
    tmp = dest + ".partiel"
    with open(chemin, "rb") as src, open(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "wb") as dst:
        shutil.copyfileobj(src, dst)
        dst.flush()
        os.fsync(dst.fileno())
    # Copie relue : même taille, même contenu ; sinon l'original reste dans iCloud.
    h = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
    if os.path.getsize(tmp) != os.path.getsize(chemin) or h(tmp) != h(chemin):
        os.remove(tmp)
        return {"ok": False, "erreur": "Copie incomplète : l'original reste dans iCloud."}
    os.replace(tmp, dest)
    r = retirer(chemin, vers, ident)
    return {"ok": True, "chemin": dest, "corbeille": r["ok"], "comment": r["comment"], "erreur": r["erreur"]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lister")
    ap.add_argument("--attente", type=float, default=5.0)
    ap.add_argument("--ingerer")
    ap.add_argument("--vers")
    ap.add_argument("--id")
    ap.add_argument("--retirer")
    a = ap.parse_args()
    try:
        if a.lister:
            r = lister(os.path.expanduser(a.lister), a.attente)
        elif a.ingerer and a.vers:
            r = ingerer(a.ingerer, a.vers, a.id)
        elif a.retirer:
            ext = os.path.splitext(a.retirer)[1].lower()
            r = retirer(a.retirer, a.vers, a.id) if ext in EXTENSIONS else {"ok": False, "erreur": "Fichier refusé."}
        else:
            r = {"erreur": "Usage : --lister DOSSIER ou --ingerer CHEMIN --vers DOSSIER --id ID"}
    except Exception as e:                 # jamais de trace : elle citerait le nom du fichier
        r = {"ok": False, "dictees": [], "erreur": f"Erreur ({type(e).__name__})."}
    json.dump(r, sys.stdout, ensure_ascii=False)


if __name__ == "__main__":
    main()
