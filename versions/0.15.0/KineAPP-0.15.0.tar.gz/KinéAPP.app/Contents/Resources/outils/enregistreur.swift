// enregistreur : enregistre le micro en WAV 16 kHz mono 16 bits, sans perdre de blocs.
// Usage : enregistreur [--micro N] [--duree S] sortie.wav
//
// Remplace ffmpeg (avfoundation) pour les séances et les dictées. ffmpeg ne garde qu'un
// bloc audio à la fois et le relit toutes les ~10 ms : un bloc sur six environ est écrasé
// avant d'être lu. Mesuré le 11/10/2026 sur trois séances : 17 % de l'audio manquant, par
// trous de 10,7 ms répartis dans toute la séance. Ici, chaque bloc livré par macOS est écrit.
//
// - Même liste de micros que ffmpeg (--micro N = « -i :N ») ; autorisation micro de l'app.
// - Fichier lisible pendant l'enregistrement (en-tête de 44 octets, tailles mises à jour
//   toutes les 2 s), refermé proprement sur SIGINT ou SIGTERM.
// - S'arrête seul si le processus qui l'a lancé disparaît : jamais d'enregistrement orphelin.
// - Erreurs et bilan sur la sortie d'erreur (« permission denied », « Input/output error »
//   comme ffmpeg, pour les messages de l'app).
import AVFoundation
import CoreMedia
import Foundation

let FREQ = 16000.0

func journal(_ s: String) {
    FileHandle.standardError.write((s + "\n").data(using: .utf8)!)
}

var indice = 0
var dureeMax: Double? = nil
var chemin: String? = nil
var args = Array(CommandLine.arguments.dropFirst())
while !args.isEmpty {
    let a = args.removeFirst()
    if a == "--micro", let v = args.first { indice = Int(v) ?? 0; args.removeFirst() }
    else if a == "--duree", let v = args.first { dureeMax = Double(v); args.removeFirst() }
    else { chemin = a }
}
guard let sortie = chemin else {
    journal("usage: enregistreur [--micro N] [--duree S] sortie.wav")
    exit(2)
}

// Autorisation : celle de l'application qui nous lance (processus responsable).
switch AVCaptureDevice.authorizationStatus(for: .audio) {
case .authorized:
    break
case .notDetermined:
    let attente = DispatchSemaphore(value: 0)
    var accorde = false
    AVCaptureDevice.requestAccess(for: .audio) { accorde = $0; attente.signal() }
    attente.wait()
    if !accorde { journal("Microphone : permission denied"); exit(1) }
default:
    journal("Microphone : permission denied (Réglages Système > Confidentialité et sécurité > Microphone)")
    exit(1)
}

func micros() -> [AVCaptureDevice] {
    if #available(macOS 14.0, *) {
        return AVCaptureDevice.DiscoverySession(deviceTypes: [.microphone], mediaType: .audio,
                                                position: .unspecified).devices
    }
    return AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInMicrophone, .externalUnknown],
                                            mediaType: .audio, position: .unspecified).devices
}

let liste = micros()
guard indice >= 0, indice < liste.count else {
    journal("Input/output error : micro \(indice) introuvable (\(liste.count) micro(s) disponible(s))")
    exit(1)
}

func entete(_ octets: UInt64) -> Data {
    var d = Data()
    func u32(_ v: UInt32) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 4)) }
    func u16(_ v: UInt16) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 2)) }
    let n = UInt32(min(octets, UInt64(UInt32.max - 36)))
    d.append("RIFF".data(using: .ascii)!); u32(36 + n); d.append("WAVE".data(using: .ascii)!)
    d.append("fmt ".data(using: .ascii)!); u32(16); u16(1); u16(1); u32(16000); u32(32000); u16(2); u16(16)
    d.append("data".data(using: .ascii)!); u32(n)
    return d
}

final class Ecrivain: NSObject, AVCaptureAudioDataOutputSampleBufferDelegate {
    let fichier: FileHandle
    var octets: UInt64 = 0
    var majEntete = Date()
    var finPrecedente: CMTime? = nil
    var discontinuites = 0
    var manquant = 0.0
    var formatVu = false
    var ferme = false

    init(_ chemin: String) {
        FileManager.default.createFile(atPath: chemin, contents: entete(0))
        guard let f = FileHandle(forUpdatingAtPath: chemin) else {
            journal("Input/output error : impossible d'écrire \(chemin)")
            exit(1)
        }
        f.seekToEndOfFile()
        fichier = f
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput tampon: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        if ferme { return }
        if !formatVu {
            formatVu = true
            if let fd = CMSampleBufferGetFormatDescription(tampon),
               let f = CMAudioFormatDescriptionGetStreamBasicDescription(fd)?.pointee,
               f.mSampleRate != FREQ || f.mChannelsPerFrame != 1 || f.mBitsPerChannel != 16
                || (f.mFormatFlags & kAudioFormatFlagIsFloat) != 0 {
                journal("format inattendu : \(f.mSampleRate) Hz, \(f.mChannelsPerFrame) canal(aux), \(f.mBitsPerChannel) bits")
                exit(3)
            }
        }
        // Continuité : un saut d'horodatage entre deux blocs est un vrai trou (veille du Mac,
        // micro décroché), compté et signalé dans le bilan final.
        let debut = CMSampleBufferGetPresentationTimeStamp(tampon)
        let n = CMSampleBufferGetNumSamples(tampon)
        if let fin = finPrecedente, debut.isValid, fin.isValid {
            let ecart = CMTimeGetSeconds(CMTimeSubtract(debut, fin))
            if ecart > 0.05 { discontinuites += 1; manquant += ecart }
        }
        if debut.isValid { finPrecedente = CMTimeAdd(debut, CMTime(value: CMTimeValue(n), timescale: 16000)) }
        guard let bloc = CMSampleBufferGetDataBuffer(tampon) else { return }
        let taille = CMBlockBufferGetDataLength(bloc)
        var donnees = Data(count: taille)
        let ok = donnees.withUnsafeMutableBytes { p -> Bool in
            CMBlockBufferCopyDataBytes(bloc, atOffset: 0, dataLength: taille, destination: p.baseAddress!) == noErr
        }
        if !ok { return }
        fichier.write(donnees)
        octets += UInt64(taille)
        if Date().timeIntervalSince(majEntete) >= 2 { ecrireEntete(); majEntete = Date() }
    }

    func ecrireEntete() {
        let pos = fichier.offsetInFile
        fichier.seek(toFileOffset: 0)
        fichier.write(entete(octets))
        fichier.seek(toFileOffset: pos)
    }

    func fermer() {
        if ferme { return }
        ferme = true
        ecrireEntete()
        fichier.synchronizeFile()
        fichier.closeFile()
    }
}

let micro = liste[indice]
let session = AVCaptureSession()
let ecrivain = Ecrivain(sortie)
let file = DispatchQueue(label: "enregistreur.ecriture")
do {
    let entree = try AVCaptureDeviceInput(device: micro)
    guard session.canAddInput(entree) else { journal("Input/output error : micro indisponible"); exit(1) }
    session.addInput(entree)
} catch {
    journal("Input/output error : \(error.localizedDescription)")
    exit(1)
}
let sortieAudio = AVCaptureAudioDataOutput()
sortieAudio.audioSettings = [
    AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: FREQ, AVNumberOfChannelsKey: 1,
    AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false,
    AVLinearPCMIsNonInterleaved: false,
]
sortieAudio.setSampleBufferDelegate(ecrivain, queue: file)
guard session.canAddOutput(sortieAudio) else { journal("Input/output error : sortie audio refusée"); exit(1) }
session.addOutput(sortieAudio)

let debutMur = Date()
func arreter(_ code: Int32, _ raison: String) {
    session.stopRunning()
    file.sync { ecrivain.fermer() }
    let audio = Double(ecrivain.octets) / 32000.0
    let ecoule = Date().timeIntervalSince(debutMur)
    journal(String(format: "%@ : %.1f s d'audio pour %.1f s écoulées, %d discontinuité(s), %.1f s manquantes",
                   raison, audio, ecoule, ecrivain.discontinuites, ecrivain.manquant))
    exit(code)
}

NotificationCenter.default.addObserver(forName: .AVCaptureSessionRuntimeError, object: session, queue: .main) { n in
    let e = n.userInfo?[AVCaptureSessionErrorKey] as? Error
    journal("Input/output error : \(e?.localizedDescription ?? "erreur de capture")")
    arreter(1, "Arrêt sur erreur")
}

signal(SIGINT, SIG_IGN)
signal(SIGTERM, SIG_IGN)
var sources: [DispatchSourceSignal] = []
for s in [SIGINT, SIGTERM] {
    let src = DispatchSource.makeSignalSource(signal: s, queue: .main)
    src.setEventHandler { arreter(0, "Arrêt normal (signal \(s))") }
    src.resume()
    sources.append(src)
}

// Parent disparu (serveur de l'app tué), durée atteinte, et un point d'étape toutes les 30 s.
let parent = getppid()
let minuteur = DispatchSource.makeTimerSource(queue: .main)
var tours = 0
minuteur.schedule(deadline: .now() + 1, repeating: 1)
minuteur.setEventHandler {
    tours += 1
    if getppid() != parent { arreter(0, "Arrêt : processus parent disparu") }
    if let d = dureeMax, Date().timeIntervalSince(debutMur) >= d { arreter(0, "Arrêt : durée atteinte") }
    if tours % 30 == 0 {
        let audio = file.sync { Double(ecrivain.octets) / 32000.0 }
        journal(String(format: "enregistré : %.1f s d'audio pour %.1f s écoulées", audio, Date().timeIntervalSince(debutMur)))
    }
}
minuteur.resume()

session.startRunning()
journal("Enregistrement : \(micro.localizedName) -> \(sortie)")
dispatchMain()
