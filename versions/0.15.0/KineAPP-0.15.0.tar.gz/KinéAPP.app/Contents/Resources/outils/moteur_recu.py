# -*- coding: utf-8 -*-
"""Décompresse une archive de moteur reçue par l'app, en refusant tout ce qui sortirait du dossier.

Utilisé par l'app (essai avant de proposer la version) et par l'installateur, en administrateur :
    python3 -I outils/moteur_recu.py ARCHIVE SHA256 DOSSIER_RECUS BINAIRE DESTINATION VERSION [ARCHIVE_GGML SHA256_GGML]
whisper.cpp est publié sans ses bibliothèques de calcul (ggml), qui viennent de la version de llama.cpp
avec laquelle il a été compilé : ARCHIVE_GGML est cette version, dont seules ces bibliothèques sont reprises.
L'archive est recopiée à côté de la destination avant contrôle : ce qui est vérifié est ce qui est
installé, même si le dossier d'origine change entre-temps. Les liens internes deviennent des
fichiers (l'app n'en contient aucun)."""
import hashlib, os, shutil, stat, sys, tarfile


def _dans(racine, p):
    racine, p = os.path.realpath(racine), os.path.realpath(p)
    return p == racine or p.startswith(racine + os.sep)


def extraire(archive, dest, binaire):
    """Contenu de l'archive dans dest (créé), liens résolus. Lève ValueError à la moindre anomalie."""
    tmp = dest + ".extraction"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    try:
        with tarfile.open(archive, "r:gz") as t:
            t.chown = lambda *a, **k: None                 # en administrateur : ne pas reprendre les comptes de l'archive
            membres = t.getmembers()
            for m in membres:
                cible = os.path.join(tmp, m.name)
                if m.name.startswith("/") or ".." in m.name.split("/") or not _dans(tmp, cible):
                    raise ValueError(f"Archive refusée : chemin hors du dossier ({m.name[:80]}).")
                if not (m.isfile() or m.isdir() or m.issym()):
                    raise ValueError(f"Archive refusée : élément spécial ({m.name[:80]}).")
                if m.issym() and not _dans(tmp, os.path.join(os.path.dirname(cible), m.linkname)):
                    raise ValueError(f"Archive refusée : lien vers l'extérieur ({m.name[:80]}).")
                m.mode = (m.mode & 0o755) | stat.S_IRUSR | stat.S_IWUSR
            t.extractall(tmp, members=membres)
        for base, dirs, fichiers in os.walk(tmp, topdown=False):
            for n in fichiers + dirs:
                p = os.path.join(base, n)
                if os.path.islink(p):
                    reel = os.path.realpath(p)
                    if not _dans(tmp, reel) or not os.path.exists(reel):
                        raise ValueError(f"Archive refusée : lien cassé ou extérieur ({n[:80]}).")
                    os.remove(p)
                    (shutil.copytree if os.path.isdir(reel) else shutil.copy2)(reel, p)
        racine = tmp
        entrees = [x for x in os.listdir(tmp) if not x.startswith("._")]     # fichiers d'attributs de macOS
        if len(entrees) == 1 and os.path.isdir(os.path.join(tmp, entrees[0])):
            racine = os.path.join(tmp, entrees[0])
        if not os.path.isfile(os.path.join(racine, binaire)):
            raise ValueError(f"Archive refusée : {binaire} est absent.")
        shutil.rmtree(dest, ignore_errors=True)
        shutil.move(racine, dest)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def ajouter_ggml(archive_ggml, dest):
    """Copie dans dest les bibliothèques libggml* d'une archive de llama.cpp."""
    tmp = dest + ".ggml"
    try:
        extraire(archive_ggml, tmp, "llama-server")
        trouvees = [n for n in os.listdir(tmp) if n.startswith("libggml") and n.endswith(".dylib")]
        if not trouvees:
            raise ValueError("Archive refusée : bibliothèques ggml absentes.")
        for n in trouvees:
            shutil.copy2(os.path.join(tmp, n), os.path.join(dest, n))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _copie_verifiee(archive, sha256, recus, copie):
    if not _dans(recus, archive) or os.path.islink(archive) or not os.path.isfile(archive):
        raise ValueError("Archive hors du dossier des moteurs reçus.")
    shutil.copyfile(archive, copie)
    h = hashlib.sha256()
    with open(copie, "rb") as f:
        for bloc in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloc)
    if h.hexdigest() != sha256:
        raise ValueError("Empreinte de l'archive différente de celle de la version publiée.")


def installer(archive, sha256, recus, binaire, dest, version, archive_ggml="", sha256_ggml=""):
    copie, copie_ggml = dest + ".archive", dest + ".archive-ggml"
    try:
        _copie_verifiee(archive, sha256, recus, copie)
        extraire(copie, dest, binaire)
        if archive_ggml:
            _copie_verifiee(archive_ggml, sha256_ggml, recus, copie_ggml)
            ajouter_ggml(copie_ggml, dest)
    except Exception:
        shutil.rmtree(dest, ignore_errors=True)
        raise
    finally:
        for c in (copie, copie_ggml):
            if os.path.exists(c):
                os.remove(c)
    with open(os.path.join(dest, "VERSION_KINEAPP"), "w", encoding="utf-8") as f:
        f.write(version + "\n")


if __name__ == "__main__":
    try:
        installer(*[a for a in sys.argv[1:9]])
    except (OSError, ValueError, tarfile.TarError) as e:
        print(e)
        sys.exit(1)
