# -*- coding: utf-8 -*-
"""Python embarqué dans l'app (le Python du système, 3.9, ne reçoit plus de correctifs de sécurité).

Lancé par l'installateur avec le Python du système, en administrateur. La source est un CPython
autonome (python-build-standalone, installé par `uv python install 3.13`) : un dossier de la session
de l'utilisateur, donc modifiable par ses programmes. Il n'entre dans l'app protégée qu'avec
l'EMPREINTE attendue, inscrite dans python_embarque.json (versionné, testé, jugé par les garde-fous).

    python3 -I python_embarque.py --trouver MAISON          chemin de la source (version attendue), ou rien
    python3 -I python_embarque.py --copier SOURCE DEST       copie élaguée, liens vérifiés, empreinte contrôlée
    python3 -I python_embarque.py --empreinte DOSSIER        empreinte d'un dossier déjà élagué (pour le .json)

Élagué : Tk, IDLE, pip, en-têtes C, documentation (inutiles à l'app). Les liens symboliques doivent
rester DANS le dossier ; tout autre lien, ou une empreinte différente, refuse l'installation.
"""
import glob, hashlib, json, os, shutil, stat, sys

ICI = os.path.dirname(os.path.abspath(__file__))
ATTENDU = os.environ.get("KINEAPP_PYTHON_ATTENDU") or os.path.join(ICI, "python_embarque.json")   # tests : fictif
ELAGUES = ("include", "share", "lib/pkgconfig", "lib/python3.13/idlelib", "lib/python3.13/tkinter",
           "lib/python3.13/turtledemo", "lib/python3.13/ensurepip", "lib/python3.13/site-packages",
           "lib/tcl9", "lib/tcl9.0", "lib/tk9.0", "lib/itcl4.3.5", "lib/thread3.0.4",
           "lib/libtcl9.0.dylib", "lib/libtcl9tk9.0.dylib", "lib/python3.13/lib-dynload/_tkinter.cpython-313-darwin.so")
BINAIRES = ("python3.13", "python3")          # le reste de bin/ (pip, idle, pydoc, config) est élagué


def attendu():
    return json.load(open(ATTENDU, encoding="utf-8"))


def elague(rel):
    rel = rel.replace(os.sep, "/")
    if rel.startswith("bin/"):
        return rel[4:] not in BINAIRES
    return any(rel == e or rel.startswith(e + "/") for e in ELAGUES) or "/__pycache__" in "/" + rel


def empreinte(dossier):
    """SHA-256 de la liste triée (chemin, type, contenu ou cible du lien, exécutable)."""
    h = hashlib.sha256()
    for racine, dirs, fichiers in os.walk(dossier):
        dirs.sort()
        for nom in sorted(fichiers + [d for d in dirs if os.path.islink(os.path.join(racine, d))]):
            p = os.path.join(racine, nom)
            rel = os.path.relpath(p, dossier).replace(os.sep, "/")
            if os.path.islink(p):
                h.update(f"L {rel} {os.readlink(p)}\n".encode())
            else:
                with open(p, "rb") as f:
                    c = hashlib.sha256(f.read()).hexdigest()
                x = "x" if os.stat(p).st_mode & stat.S_IXUSR else "-"
                h.update(f"F {rel} {x} {c}\n".encode())
    return h.hexdigest()


def trouver(maison):
    v = attendu()["version"]
    for d in sorted(glob.glob(os.path.join(maison, ".local/share/uv/python", f"cpython-{v}-macos-aarch64-none"))):
        if not os.path.islink(d) and os.path.isfile(os.path.join(d, "bin", "python3.13")):
            return d
    return ""


def copier(source, dest):
    copier_elague(source, dest)
    verifier(dest)


def copier_elague(source, dest):
    if os.path.lexists(dest):
        raise SystemExit("Destination déjà présente.")
    for racine, dirs, fichiers in os.walk(source):
        rel_racine = os.path.relpath(racine, source)
        dirs[:] = [d for d in dirs if not elague(os.path.normpath(os.path.join(rel_racine, d)))]
        os.makedirs(os.path.join(dest, rel_racine), exist_ok=True)
        for nom in fichiers + [d for d in list(dirs) if os.path.islink(os.path.join(racine, d))]:
            rel = os.path.normpath(os.path.join(rel_racine, nom))
            if elague(rel):
                continue
            src, dst = os.path.join(source, rel), os.path.join(dest, rel)
            if os.path.islink(src):
                cible = os.readlink(src)
                arrivee = os.path.normpath(os.path.join(os.path.dirname(rel), cible))
                if os.path.isabs(cible) or arrivee.startswith(".."):
                    raise SystemExit(f"Lien hors du Python embarqué : {rel}")
                os.symlink(cible, dst)
                if nom in dirs:
                    dirs.remove(nom)
            elif os.path.isfile(src):
                shutil.copyfile(src, dst)
                os.chmod(dst, 0o755 if os.stat(src).st_mode & stat.S_IXUSR else 0o644)


def verifier(dest):
    e, voulu = empreinte(dest), attendu()["empreinte"]
    if e != voulu:
        shutil.rmtree(dest)                     # copie refusée (dossier temporaire de l'installation)
        raise SystemExit(f"Empreinte du Python embarqué inattendue ({e[:12]}… au lieu de {voulu[:12]}…) : "
                         "la source a été modifiée. Rien n'est installé.")
    with open(os.path.join(dest, ".version-kineapp"), "w") as f:
        f.write(attendu()["version"] + "\n")


def main():
    a = sys.argv[1:]
    if a[:1] == ["--trouver"] and len(a) == 2:
        print(trouver(a[1]))
    elif a[:1] == ["--copier"] and len(a) == 3:
        copier(a[1], a[2])
        print(f"Python {attendu()['version']} embarqué, empreinte vérifiée.")
    elif a[:1] == ["--empreinte"] and len(a) == 2:
        print(empreinte(a[1]))
    elif a[:1] == ["--elaguer"] and len(a) == 3:       # préparation de l'empreinte (développement)
        copier_elague(a[1], a[2])
        print(empreinte(a[2]))
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main()
