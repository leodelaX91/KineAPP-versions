#!/bin/bash
# Construit une version de KinéAPP prête à installer sur le Mac d'un collègue (sans git, sans outils de
# développement, sans compilation) : l'app de l'étiquette signée vX.Y.Z, fenêtre compilée et Python embarqué
# compris, moteurs exclus (téléchargés depuis l'app). Lancé par outils/publier.sh.
#
#     outils/construire_version.sh vX.Y.Z DOSSIER_DE_SORTIE
#
# Produit dans DOSSIER_DE_SORTIE :
#   versions/X.Y.Z/KineAPP-X.Y.Z.tar.gz     l'archive (KinéAPP.app)
#   versions/X.Y.Z/KineAPP-X.Y.Z.json       son manifeste (version, empreinte SHA-256, changements) — À SIGNER
#   derniere.json                           copie du manifeste de la version la plus récente — À SIGNER
# La signature (ssh-keygen -Y sign -n kineapp-version) est faite par publier.sh, avec la clé de publication.
set -euo pipefail
ICI="$(cd "$(dirname "$0")/.." && pwd)"
DEPOT="${KINEAPP_DEPOT:-$HOME/Developer/KineAPP.git}"
TAG="${1:?étiquette vX.Y.Z attendue}"; SORTIE="${2:?dossier de sortie attendu}"
G() { git --git-dir="$DEPOT" --work-tree="$ICI" "$@"; }
[[ "$TAG" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "Étiquette invalide : $TAG"; exit 1; }
V="${TAG#v}"
G rev-parse -q --verify "refs/tags/$TAG" >/dev/null || { echo "Étiquette $TAG absente."; exit 1; }
[ "$(G show "$TAG:version.json" | /usr/bin/python3 -c 'import json,sys; print(json.load(sys.stdin)["version"])')" = "$V" ] \
  || { echo "version.json de $TAG différent de $V."; exit 1; }
[ -z "$(G ls-tree -r "$TAG" | awk '$1 == "120000"')" ] || { echo "Liens symboliques dans $TAG : refusé."; exit 1; }

TMP=$(mktemp -d /tmp/kineapp-construction.XXXXXX)
trap 'rm -rf "$TMP"' EXIT
B="$TMP/KinéAPP.app"; R="$B/Contents/Resources"
mkdir -p "$B/Contents/MacOS" "$R"
G archive --format=tar "$TAG" | tar -x -C "$R"
COMMIT=$(G rev-parse --short "$TAG^{commit}")
cp "$R/outils/bundle/Info.plist" "$B/Contents/Info.plist"
echo "$COMMIT $(date +%d/%m/%Y)" > "$R/VERSION"
plutil -replace CFBundleShortVersionString -string "$V" "$B/Contents/Info.plist"
plutil -replace CFBundleVersion -string "$V" "$B/Contents/Info.plist"

echo "Compilation de la fenêtre…"
xcrun swiftc -parse-as-library -O -target arm64-apple-macos12.0 -o "$B/Contents/MacOS/KineAPP" "$R/source/KineAPP.swift"

echo "Python embarqué…"
VPE=$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["version"])' "$R/outils/python_embarque.json")
PI="/Applications/KinéAPP.app/Contents/Resources/python"
if [ -x "$PI/bin/python3" ] && [ "$(cat "$PI/.version-kineapp" 2>/dev/null)" = "$VPE" ]; then
  cp -RP "$PI" "$R/python"
else
  SPY=$(/usr/bin/python3 -I "$R/outils/python_embarque.py" --trouver "$HOME")
  [ -n "$SPY" ] || { echo "Python $VPE introuvable (uv python install $VPE)."; exit 1; }
  /usr/bin/python3 -I "$R/outils/python_embarque.py" --copier "$SPY" "$R/python"
fi
"$R/python/bin/python3" -I -c 'import sqlite3, ssl, ctypes'

# Ni moteurs (téléchargés depuis l'app, vérifiés par leur empreinte), ni fichiers de développement inutiles.
rm -rf "$R/tests" "$R/.tests-reussis.json"
mkdir -p "$SORTIE/versions/$V"
ARCH="$SORTIE/versions/$V/KineAPP-$V.tar.gz"
( cd "$TMP" && COPYFILE_DISABLE=1 tar --no-mac-metadata -czf "$ARCH" "KinéAPP.app" )
SHA=$(shasum -a 256 "$ARCH" | awk '{print $1}')
OCTETS=$(stat -f %z "$ARCH")
STATUT=$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("statut",""))' "$R/version.json")
PREC=$(G tag -l 'v[0-9]*.[0-9]*.[0-9]*' --sort=-version:refname | grep -v -x "$TAG" | head -1 || true)
DEPUIS="$PREC"
G log -n 40 --format='%s' "${DEPUIS:+$DEPUIS..}$TAG" > "$TMP/changements.txt" || true
/usr/bin/python3 - "$SORTIE/versions/$V/KineAPP-$V.json" "$V" "$SHA" "$OCTETS" "$COMMIT" "$STATUT" "$TMP/changements.txt" <<'PYEOF'
import json, sys, datetime
dest, v, sha, octets, commit, statut, ch = sys.argv[1:]
m = {"version": v, "archive": f"versions/{v}/KineAPP-{v}.tar.gz", "sha256": sha, "octets": int(octets),
     "commit": commit, "statut": statut, "date": datetime.date.today().isoformat(), "macos_min": "13.0",
     "changements": [l.strip() for l in open(ch, encoding="utf-8") if l.strip()][:40]}
json.dump(m, open(dest, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
PYEOF
cp "$SORTIE/versions/$V/KineAPP-$V.json" "$SORTIE/derniere.json"
echo "Version $V construite : $ARCH ($((OCTETS / 1048576)) Mo, sha256 $SHA)"
