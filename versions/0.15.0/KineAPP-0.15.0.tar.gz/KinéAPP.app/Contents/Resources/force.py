# -*- coding: utf-8 -*-
"""Suivi de force : catalogue des tests par articulation, lecture des valeurs dictées, photos d'installation.

Le catalogue (force/tests.json) décrit, pour chaque groupe musculaire, l'installation validée dans la
littérature (position, point d'application de la sangle, stabilisation, bras de levier), son intérêt
clinique et ses références. Les mesures sont rangées dans le dossier du patient (patients.py).
"""
import base64, json, os, re, unicodedata

CODE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
PHOTOS = os.path.join(DATA, "force", "photos")
FICHIER = os.path.join(CODE, "force", "tests.json")
UNITES = {"N": 1.0, "kg": 9.80665}          # kg de force -> newtons
TYPES_IMAGE = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
TAILLE_MAX = 8 * 1024 * 1024
_CACHE = {}


def catalogue():
    if not _CACHE:
        with open(FICHIER, encoding="utf-8") as f:
            _CACHE.update(json.load(f))
        _CACHE["par_id"] = {t["id"]: t for t in _CACHE["tests"]}
    return _CACHE


def tests():
    return catalogue()["tests"]


def test(tid):
    return catalogue()["par_id"].get(tid)


def articulations():
    out = []
    for t in tests():
        if t["articulation"] not in out:
            out.append(t["articulation"])
    return out


def en_newtons(valeur, unite):
    try:
        return round(float(valeur) * UNITES.get(unite, 1.0), 1)
    except (TypeError, ValueError):
        return None


def nombre(v):
    """310.0 -> « 310 », 32.5 -> « 32,5 »."""
    if v in (None, ""):
        return "—"
    v = float(v)
    return (str(int(v)) if v.is_integer() else f"{v}").replace(".", ",")


def symetrie(g, d, cote_atteint):
    """Rapport côté atteint / côté sain en %. Sans côté atteint : le plus faible / le plus fort."""
    if g in (None, "") or d in (None, "") or not (g and d):
        return None
    g, d = float(g), float(d)
    if cote_atteint == "G":
        r = g / d
    elif cote_atteint == "D":
        r = d / g
    else:
        r = min(g, d) / max(g, d)
    return round(r * 100, 1)


# ── lecture d'une dictée : « quadriceps droite 32,5 gauche 28 » ───────────────
_MOT_NOMBRE = {"zéro": 0, "zero": 0, "un": 1, "une": 1, "deux": 2, "trois": 3, "quatre": 4, "cinq": 5, "six": 6,
               "sept": 7, "huit": 8, "neuf": 9, "dix": 10}
_COTES = [(re.compile(r"\b(?:gauche|gauches)\b", re.I), "g"),
          (re.compile(r"\b(?:droite|droit|droites)\b", re.I), "d")]


def _normaliser(texte):
    t = unicodedata.normalize("NFC", texte or "")
    t = re.sub(r"(\d)\s*(?:virgule|,)\s*(\d)", r"\1.\2", t)
    for mot, n in _MOT_NOMBRE.items():
        t = re.sub(rf"\b{mot}\b", str(n), t, flags=re.I)
    return t


def _valeurs_segment(segment):
    """Renvoie {'g': x, 'd': y} pour un morceau de phrase concernant un seul test."""
    marques = []
    for motif, cote in _COTES:
        for m in motif.finditer(segment):
            marques.append((m.start(), m.end(), cote))
    marques.sort()
    nombres = [(m.start(), float(m.group(1))) for m in re.finditer(r"(\d{1,4}(?:\.\d{1,2})?)", segment)]
    out = {}
    for i, (deb, fin, cote) in enumerate(marques):
        suite = min([p for p, _ in nombres if p >= fin] or [None], default=None)
        avant = max([p for p, _ in nombres if p < deb] or [None], default=None)
        pos = suite if suite is not None else avant
        if pos is None:
            continue
        valeur = dict(nombres)[pos]
        out.setdefault(cote, valeur)
    return out


def analyser_dictee(texte, ids):
    """Associe les valeurs dictées aux tests demandés. Renvoie ({test: {'g','d'}}, texte non compris)."""
    t = _normaliser(texte)
    reperes = []
    for tid in ids:
        fiche = test(tid)
        if not fiche:
            continue
        for alias in fiche.get("alias", []):
            for m in re.finditer(alias, t, re.I):
                reperes.append((m.start(), m.end(), tid, len(m.group(0))))
    reperes.sort(key=lambda x: (x[0], -x[3]))
    retenus, fin_precedente = [], -1
    for deb, fin, tid, _ in reperes:
        if deb >= fin_precedente and not any(r[2] == tid for r in retenus):
            retenus.append((deb, fin, tid))
            fin_precedente = fin
    mesures = {}
    for i, (deb, fin, tid) in enumerate(retenus):
        suivant = retenus[i + 1][0] if i + 1 < len(retenus) else len(t)
        vals = _valeurs_segment(t[fin:suivant])
        if vals:
            mesures[tid] = vals
    reste = t if not retenus else t[:retenus[0][0]].strip()
    return mesures, reste.strip()


# ── photos d'installation (fournies par l'utilisateur) ───────────────────────
def chemin_photo(tid):
    for ext in TYPES_IMAGE.values():
        p = os.path.join(PHOTOS, tid + ext)
        if os.path.isfile(p):
            return p
    return None


def enregistrer_photo(tid, donnees):
    """donnees : « data:image/jpeg;base64,... »."""
    if not test(tid):
        raise ValueError("Test inconnu.")
    m = re.match(r"^data:([\w/+.-]+);base64,(.+)$", donnees or "", re.S)
    if not m or m.group(1) not in TYPES_IMAGE:
        raise ValueError("Image attendue au format JPEG, PNG ou WebP.")
    brut = base64.b64decode(m.group(2), validate=True)
    if len(brut) > TAILLE_MAX:
        raise ValueError(f"Image trop lourde ({len(brut) / 1e6:.1f} Mo, maximum 8 Mo).")
    supprimer_photo(tid)
    os.makedirs(PHOTOS, exist_ok=True)
    chemin = os.path.join(PHOTOS, tid + TYPES_IMAGE[m.group(1)])
    with open(chemin, "wb") as f:
        f.write(brut)
    return chemin


def supprimer_photo(tid):
    p = chemin_photo(tid)
    if p:
        os.remove(p)
    return bool(p)


def photos_presentes():
    return {t["id"]: bool(chemin_photo(t["id"])) for t in tests()}
