# -*- coding: utf-8 -*-
"""Modèles de transcription : large-v3 et large-v3-turbo, téléchargés au choix, gardés tous deux.

Deux choix (comparatif du 17/09/2026 sur 3 h 18 de vrais bilans, méthode de l'app) :
- large-v3       : ×3,0 ; 93,0 % de la parole réelle retrouvée ; 3 passages perdus.
- large-v3-turbo : ×13,9 ; 86,6 % ; 29 passages perdus ; plus de boucles.

Télécharger = fichier public du modèle depuis Hugging Face (aucune donnée patient ne sort), avec
reprise, avancement et vérification de l'empreinte SHA-256 avant usage. Les deux modèles peuvent
être sur le disque : on choisit celui des prochaines transcriptions. Rien n'est retiré sans une
demande explicite, et un modèle retiré va à la Corbeille.
"""
import hashlib, os, shutil, subprocess, threading, time, urllib.request

DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
DOSSIER = os.path.join(DATA, "models")
BASE_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"
CATALOGUE = {
    "large-v3": {"fichier": "ggml-large-v3.bin", "taille": 3095033483,
                 "sha256": "64d182b440b98d5203c4f9bd541544d84c605196c4f7b845dfa11fb23594d1e2",
                 "vitesse": 3.0, "parole": 93.0, "perdus": 3},
    "large-v3-turbo": {"fichier": "ggml-large-v3-turbo.bin", "taille": 1624555275,
                       "sha256": "1fc70f774d38eb169993ac391eea357ef47c88757ef72ee5943879b7e8e2bc69",
                       "vitesse": 13.9, "parole": 86.6, "perdus": 29},
}
DEFAUT = "large-v3"
ETAT = {"phase": "", "modele": "", "recu": 0, "total": 0, "erreur": "", "debut": 0, "retire": ""}
_ANNULER = threading.Event()
_VERROU = threading.Lock()


def chemin(m):
    return os.path.join(DOSSIER, CATALOGUE[m]["fichier"])


def present(m):
    try:
        return os.path.getsize(chemin(m)) == CATALOGUE[m]["taille"]
    except OSError:
        return False


def retirer(m, choisi, transcription_en_cours):
    """Met un modèle à la Corbeille, à la demande : jamais celui qui est utilisé, ni pendant une
    transcription ou un téléchargement."""
    if m not in CATALOGUE:
        raise ValueError("modèle inconnu")
    if m == choisi:
        raise RuntimeError("C'est le modèle utilisé : choisissez d'abord l'autre.")
    if transcription_en_cours() or ETAT["phase"] in ("téléchargement", "vérification"):
        raise RuntimeError("Attendez la fin de la transcription ou du téléchargement en cours.")
    ok, err = corbeille([CATALOGUE[m]["fichier"]])
    if not ok:
        raise RuntimeError(f"Mise à la Corbeille impossible : {err}")


def fichiers_inutiles(choisi=None):
    """Fichiers de Whisper hors des deux modèles proposés (large-v2, filtre des silences, reste
    d'un téléchargement abandonné…)."""
    gardes = {v["fichier"] for v in CATALOGUE.values()}
    gardes |= {f + ".part" for f in gardes}         # téléchargement interrompu : il reprendra là
    out = []
    try:
        noms = sorted(os.listdir(DOSSIER))
    except OSError:
        return out
    for n in noms:
        if n.startswith("ggml-") and (n.endswith(".bin") or n.endswith(".part")) and n not in gardes:
            if ETAT["phase"] == "téléchargement" and n == CATALOGUE.get(ETAT["modele"], {}).get("fichier", "") + ".part":
                continue
            out.append({"nom": n, "octets": os.path.getsize(os.path.join(DOSSIER, n))})
    return out


def corbeille(noms):
    cibles = [os.path.join(DOSSIER, os.path.basename(n)) for n in noms]
    cibles = [c for c in cibles if os.path.isfile(c)]
    if not cibles:
        return True, ""
    r = subprocess.run(["/usr/bin/trash"] + cibles, capture_output=True, text=True)
    return r.returncode == 0, (r.stderr or r.stdout).strip()


def _sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for bloc in iter(lambda: f.read(8 * 1024 * 1024), b""):
            if _ANNULER.is_set():
                raise InterruptedError
            h.update(bloc)
    return h.hexdigest()


def telecharger(m, base_url=None):
    """Télécharge et vérifie le modèle m (reprise possible). Lève une exception en cas d'échec."""
    info = CATALOGUE[m]
    os.makedirs(DOSSIER, exist_ok=True)
    libre = shutil.disk_usage(DOSSIER).free
    part = chemin(m) + ".part"
    deja = os.path.getsize(part) if os.path.isfile(part) else 0
    if libre < info["taille"] - deja + 500 * 1024 * 1024:
        raise RuntimeError(f"Espace disque insuffisant : {info['taille'] / 1e9:.1f} Go nécessaires, "
                           f"{libre / 1e9:.1f} Go libres.")
    ETAT.update(recu=deja, total=info["taille"])
    req = urllib.request.Request((base_url or BASE_URL) + info["fichier"], headers={"User-Agent": "KineAPP"})
    if deja:
        req.add_header("Range", f"bytes={deja}-")
    with urllib.request.urlopen(req, timeout=60) as rep, open(part, "ab" if deja else "wb") as f:
        if deja and rep.status != 206:          # le serveur ne reprend pas : on recommence
            f.seek(0); f.truncate(); ETAT["recu"] = 0
        while True:
            if _ANNULER.is_set():
                raise InterruptedError
            bloc = rep.read(1024 * 1024)
            if not bloc:
                break
            f.write(bloc)
            ETAT["recu"] += len(bloc)
    if os.path.getsize(part) != info["taille"]:
        raise RuntimeError("Téléchargement incomplet : relancez pour reprendre là où il s'est arrêté.")
    ETAT["phase"] = "vérification"
    if _sha256(part) != info["sha256"]:
        os.remove(part)
        raise RuntimeError("Le fichier téléchargé ne correspond pas au modèle officiel (empreinte différente) : il a été supprimé.")
    os.replace(part, chemin(m))


def telecharger_fond(m, base_url=None):
    """Télécharge et vérifie le modèle m en arrière-plan ; le modèle utilisé ne change pas."""
    if m not in CATALOGUE:
        raise ValueError("modèle inconnu")
    with _VERROU:
        if ETAT["phase"] in ("téléchargement", "vérification"):
            raise RuntimeError("Un téléchargement est déjà en cours.")
        if present(m):
            raise RuntimeError("Ce modèle est déjà sur le disque.")
        _ANNULER.clear()
        ETAT.update(phase="téléchargement", modele=m, recu=0, total=CATALOGUE[m]["taille"], erreur="", debut=time.time(), retire="")

    def travail():
        try:
            telecharger(m, base_url)
            ETAT.update(phase="terminé", erreur="")
        except InterruptedError:
            ETAT.update(phase="annulé", erreur="")
            try:
                os.remove(chemin(m) + ".part")
            except OSError:
                pass
        except Exception as e:
            ETAT.update(phase="erreur", erreur=str(e) or type(e).__name__)
    threading.Thread(target=travail, daemon=True).start()


def annuler():
    if ETAT["phase"] in ("téléchargement", "vérification"):
        _ANNULER.set()
        return True
    return False
