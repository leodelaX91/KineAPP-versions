# -*- coding: utf-8 -*-
"""Fichiers audio de KinéAPP : conversion des dictées de l'iPhone, lecture des WAV PCM 16 bits
(format « extensible » d'afconvert compris : le module wave de Python 3.9 le refuse), assemblage des
parties d'un même enregistrement, mesure du son utile et de la durée."""
import array, os, shutil, struct, subprocess, sys, wave

import journal as JO


def en_wav(source, dest):
    """Audio de l'iPhone (m4a, AAC…) -> WAV 16 kHz mono, avec l'outil du système (afconvert)."""
    if source.lower().endswith(".wav"):
        shutil.copyfile(source, dest)
        return
    r = subprocess.run(["/usr/bin/afconvert", "-f", "WAVE", "-d", "LEI16@16000", "-c", "1", source, dest],
                       capture_output=True, text=True, timeout=600)
    if r.returncode != 0 or not os.path.isfile(dest):
        raise JO.ErreurAudio("Conversion de l'audio impossible.")


def _entete(f):
    """Lit les blocs RIFF jusqu'aux données : (fréquence, canaux, bits, taille des données), le
    fichier placé au début des données ; None si ce n'est pas un WAV lisible."""
    tete = f.read(12)
    if len(tete) < 12 or tete[:4] != b"RIFF" or tete[8:] != b"WAVE":
        return None
    canaux = freq = bits = 0
    while True:
        h = f.read(8)
        if len(h) < 8:
            return None
        bloc, taille = h[:4], struct.unpack("<I", h[4:])[0]
        if bloc == b"fmt ":
            c = f.read(taille + taille % 2)
            if len(c) < 16:
                return None
            canaux, freq, bits = struct.unpack("<H", c[2:4])[0], struct.unpack("<I", c[4:8])[0], struct.unpack("<H", c[14:16])[0]
        elif bloc == b"data":
            return freq, canaux, bits, taille
        else:
            f.seek(taille + taille % 2, 1)


def lire_pcm16(wav):
    """(fréquence, canaux, octets audio) d'un WAV PCM 16 bits ; None sinon."""
    with open(wav, "rb") as f:
        e = _entete(f)
        if e is None or e[2] != 16:
            return None
        return e[0], e[1], f.read(e[3])


def assembler_wav(sources, dest):
    """Plusieurs WAV 16 kHz mono 16 bits (après en_wav) bout à bout, dans l'ordre ; renvoie la durée
    (s) de chaque partie. Écrit à côté puis remplace : jamais un fichier à moitié écrit."""
    parties = [lire_pcm16(x) for x in sources]
    if any(p is None or p[:2] != parties[0][:2] for p in parties):
        raise JO.ErreurAudio("Parties d'enregistrement de formats différents : assemblage impossible.")
    tmp = dest + ".assemblage"
    with wave.open(tmp, "wb") as w:
        w.setnchannels(parties[0][1]); w.setsampwidth(2); w.setframerate(parties[0][0])
        for p in parties:
            w.writeframes(p[2])
    os.replace(tmp, dest)
    return [len(p[2]) / (2 * p[1] * p[0]) for p in parties]


def secondes_de_son(wav, seuil=100):
    """Durée (s) où le niveau dépasse un murmure (fenêtres de 100 ms, un échantillon sur quatre).
    None si le fichier n'est pas du PCM 16 bits (pas de jugement)."""
    with open(wav, "rb") as f:
        e = _entete(f)
        if e is None:
            return None
        freq, canaux, bits, taille = e
        if bits != 16 or not canaux or not freq:
            return None
        pas, n = max(2, freq // 10 * canaux * 2), 0
        while taille > 0:
            d = f.read(min(pas, taille))
            if len(d) < 2:
                break
            taille -= len(d)
            a = array.array("h", d[:len(d) // 2 * 2])
            if sys.byteorder == "big":
                a.byteswap()
            echantillons = a[::4]
            if echantillons and sum(x * x for x in echantillons) / len(echantillons) > seuil * seuil:
                n += 1
        return n / 10


def duree_wav(chemin):
    """Durée d'après la taille du fichier (l'en-tête d'un enregistrement en cours n'est pas à jour)."""
    try:
        with wave.open(chemin, "rb") as w:
            par_s = w.getframerate() * w.getnchannels() * w.getsampwidth()
        return max(0, (os.path.getsize(chemin) - 44)) / par_s if par_s else 0
    except (OSError, EOFError, wave.Error):
        return 0
