# -*- coding: utf-8 -*-
"""Avancement d'un bilan : pourcentage global et temps restant, estimés sur les traitements passés.

Chaque passe du modèle a deux temps : la LECTURE du texte (aucun mot ne sort, plusieurs minutes sur
une longue transcription) puis l'ÉCRITURE, mot après mot. Pour chacune, les derniers appels du même
modèle donnent la vitesse de lecture (jetons par seconde), la vitesse d'écriture et la longueur
habituelle de ce qu'il écrit ; la transcription, elle, se mesure en secondes de calcul par seconde
d'audio. Sans historique, des valeurs prudentes servent de départ.

L'avancement d'une passe en cours se lit ainsi : pendant la lecture, au temps écoulé ; pendant
l'écriture, au nombre de jetons écrits rapporté à la longueur attendue. Le temps restant est
corrigé par l'allure réelle du bilan en cours (plus lent ou plus rapide que d'habitude).
Calcul seul, sur des nombres : aucun texte de patient n'est lu ici.
"""
import statistics

CHARS_PAR_JETON = 3.5           # français, tokenizer des modèles Qwen
CHARS_PAR_S_PAROLE = 15         # environ 150 mots par minute en consultation
RATIO_TRANSCRIPTION = 0.25      # secondes de calcul par seconde d'audio, sans historique
DECODE_DEFAUT = 8.0             # jetons écrits par seconde, sans historique
SORTIE_DEFAUT = {"extraction": 2500, "mesures": 400, "redaction": 1800, "mise en forme": 450, "corrections": 1800,
                 "questions": 500}
NOMS = {"transcription": "Transcription", "extraction": "Extraction", "mesures": "Mesures",
        "redaction": "Rédaction", "questions": "Questions", "chargement": "Chargement du modèle"}


def mediane(valeurs):
    v = [x for x in valeurs if isinstance(x, (int, float)) and x > 0]
    return statistics.median(v) if v else None


class Profil:
    """Vitesses et longueurs habituelles, par passe, tirées des derniers appels (le même modèle d'abord)."""

    def __init__(self, appels=(), transcriptions=(), modele="", prefill_defaut=250.0, garder=15):
        self.prefill_defaut = prefill_defaut
        self.etapes = {}
        appels = [a for a in appels if a.get("etape")]
        for etape in {a["etape"] for a in appels}:
            l = [a for a in appels if a["etape"] == etape]
            meme = [a for a in l if a.get("modele") == modele]
            l = (meme if len(meme) >= 3 else l)[-garder:]
            prefill = mediane([a.get("prefill_tok_s") for a in l]) or mediane(
                [(a.get("prompt_tokens") or 0) / a["ttft_s"] for a in l if a.get("ttft_s")])
            self.etapes[etape] = {"prefill": prefill, "decode": mediane([a.get("decode_tok_s") for a in l]),
                                  "sortie": mediane([a.get("completion_tokens") for a in l]), "n": len(l)}
        ratios = [t["duree_s"] / t["audio_s"] for t in list(transcriptions)[-garder:]
                  if (t.get("audio_s") or 0) > 30 and (t.get("duree_s") or 0) > 0]
        self.ratio_transcription = mediane(ratios) or RATIO_TRANSCRIPTION

    def llm(self, etape, prompt_chars):
        """Prévision d'une passe : (lecture en s, jetons à écrire, écriture en s)."""
        e = self.etapes.get(etape, {})
        lecture = (prompt_chars / CHARS_PAR_JETON) / (e.get("prefill") or self.prefill_defaut)
        sortie = e.get("sortie") or SORTIE_DEFAUT.get(etape, 1500)
        return lecture, sortie, sortie / (e.get("decode") or DECODE_DEFAUT)

    def transcription(self, audio_s):
        return (audio_s or 0) * self.ratio_transcription


def fraction_llm(suivi, maintenant):
    """Part faite d'une passe en cours, d'après son suivi {t0, lecture_s, sortie, ecriture_s, jetons,
    t_premier} (jamais 100 % avant la fin : la passe peut durer plus que prévu)."""
    lecture, ecriture = suivi.get("lecture_s") or 1.0, suivi.get("ecriture_s") or 1.0
    total = lecture + ecriture
    if not suivi.get("t_premier"):                      # encore en lecture
        fait = min(maintenant - suivi.get("t0", maintenant), lecture * 0.97)
    else:
        fait = lecture + ecriture * min(1.0, (suivi.get("jetons") or 0) / (suivi.get("sortie") or 1))
    return max(0.0, min(0.97, fait / total))


def plan_bilan(job, profil, systemes, avec_mesures=False, avec_questions=False):
    """Étapes prévues d'un bilan : [(clé, nom, durée prévue en s)]. systemes : longueur (caractères)
    des consignes de chaque passe ; la transcription, si elle n'est pas encore faite, est estimée
    d'après la durée de l'audio."""
    audio = job.get("audio_s") or 0
    texte = job.get("transcription_chars") or audio * CHARS_PAR_S_PAROLE
    notes = job.get("notes_chars") or 0
    etapes = []
    if audio:
        etapes.append(("transcription", NOMS["transcription"], profil.transcription(audio)))
    lec, sortie_ext, ecr = profil.llm("extraction", systemes.get("extraction", 12000) + texte + notes)
    etapes.append(("extraction", NOMS["extraction"], lec + ecr))
    if avec_mesures:
        lec, _, ecr = profil.llm("mesures", systemes.get("mesures", 4000) + texte)
        etapes.append(("mesures", NOMS["mesures"], lec + ecr))
    lec, _, ecr = profil.llm("redaction", systemes.get("redaction", 8000) + sortie_ext * CHARS_PAR_JETON
                             + (job.get("precedent_chars") or 0))
    etapes.append(("redaction", NOMS["redaction"], lec + ecr))
    if avec_questions:                      # questions à poser au praticien : courte, sans la transcription
        lec, _, ecr = profil.llm("questions", systemes.get("questions", 2500) + 2500)
        etapes.append(("questions", NOMS["questions"], lec + ecr))
    return etapes


def avancement(job, etapes, maintenant):
    """{pct, reste_s, ecoule_s, etape, numero, nombre, etape_pct, etapes: [{nom, etat}]} pour un bilan."""
    cles = [e[0] for e in etapes]
    phase = job.get("phase")
    suivi = job.get("llm") or {}
    if phase in ("queued", None):
        courante, frac = -1, 0.0
    elif phase == "transcription":
        courante = cles.index("transcription") if "transcription" in cles else -1
        frac = min(0.99, (job.get("progress") or 0) / 100)
    else:
        etape = suivi.get("etape") if suivi.get("etape") in cles else ("redaction" if phase == "redaction" else "extraction")
        courante = cles.index(etape) if etape in cles else len(cles) - 1
        frac = fraction_llm(suivi, maintenant) if suivi.get("etape") == etape else 0.0
    total = sum(e[2] for e in etapes) or 1.0
    fait = sum(e[2] for e in etapes[:max(courante, 0)]) + (etapes[courante][2] * frac if courante >= 0 else 0.0)
    ecoule = maintenant - job["t_debut"] if job.get("t_debut") and phase not in ("queued", None) else 0.0
    # Allure réelle du bilan : appliquée au reste une fois une part utile faite.
    allure = max(0.5, min(3.0, ecoule / fait)) if fait > 0.15 * total and ecoule > 0 else 1.0
    return {"pct": int(round(100 * fait / total)), "reste_s": int(round((total - fait) * allure)),
            "ecoule_s": int(ecoule), "etape": etapes[courante][1] if courante >= 0 else "",
            "numero": courante + 1, "nombre": len(etapes), "etape_pct": int(round(100 * frac)),
            "etapes": [{"nom": n, "etat": "faite" if i < courante else ("en_cours" if i == courante else "a_venir")}
                       for i, (_, n, _) in enumerate(etapes)]}
