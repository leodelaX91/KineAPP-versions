# -*- coding: utf-8 -*-
"""Versions publiées de KinéAPP, canal « paquet » (Mac des collègues, installés par le paquet .pkg).

L'éditeur publie chaque version déjà construite (archive de l'app, sans compilation ni git sur le Mac qui la
reçoit) dans un dépôt de versions (outils/publication/canal.json) :

    derniere.json, derniere.json.sig          version la plus récente : numéro, empreinte SHA-256 de l'archive,
                                              changements ; signé par la clé de publication (ssh-keygen -Y sign,
                                              espace de noms « kineapp-version »)
    versions/X.Y.Z/KineAPP-X.Y.Z.tar.gz       l'archive (KinéAPP.app sans les moteurs, téléchargés depuis l'app)

1. Au plus une fois par jour (si autorisé : Paramètres → Mises à jour), ou sur demande, l'app lit derniere.json et
   sa signature. Rien n'est envoyé qu'une demande de fichier public.
2. La signature est vérifiée avec les clés de l'app INSTALLÉE (outils/publication/signataires_autorises) : une
   version que l'éditeur n'a pas signée n'est jamais proposée.
3. À la demande du praticien, l'archive est téléchargée et son empreinte vérifiée ; l'installateur de l'app
   installée (outils/installer.sh --paquet) refait toutes les vérifications avant d'installer.
"""
import hashlib, json, os, re, subprocess, tempfile, time, urllib.request

CODE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
PUBLIEES = os.path.join(DATA, "versions_app")           # dernière lecture (manifeste + signature)
RECUES = os.path.join(DATA, "versions_app_recues")      # archives téléchargées, une par version
INTERVALLE_S = 24 * 3600
ESPACE = "kineapp-version"
RE_VERSION = re.compile(r"^\d+\.\d+\.\d+$")
TELECHARGEMENT = {"phase": "", "recu": 0, "total": 0, "erreur": ""}


def canal(code=None):
    """Adresse du dépôt des versions (outils/publication/canal.json)."""
    try:
        d = json.load(open(os.path.join(code or CODE, "outils", "publication", "canal.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    depot = str(d.get("depot_versions") or "")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", depot):
        return {}
    branche = str(d.get("branche") or "main")
    return {"depot": depot, "branche": branche, "base": f"https://raw.githubusercontent.com/{depot}/{branche}/",
            "page": f"https://github.com/{depot}"}


def _vt(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)


def signataires(code=None):
    return os.path.join(code or CODE, "outils", "publication", "signataires_autorises")


def identite(fichier):
    """Premier signataire autorisé (« publication@kineapp »)."""
    for l in open(fichier, encoding="utf-8"):
        if l.strip() and not l.startswith("#"):
            return l.split()[0]
    return ""


def verifier_signature(donnees, signature, fichier_signataires):
    """La signature (ssh-keygen -Y sign, espace « kineapp-version ») est-elle d'une clé autorisée ?"""
    if not os.path.isfile(fichier_signataires) or not signature:
        return False
    with tempfile.TemporaryDirectory() as d:
        sig = os.path.join(d, "manifeste.sig")
        open(sig, "wb").write(signature)
        try:
            r = subprocess.run(["/usr/bin/ssh-keygen", "-Y", "verify", "-f", fichier_signataires, "-I",
                                identite(fichier_signataires), "-n", ESPACE, "-s", sig], input=donnees,
                               capture_output=True, timeout=30)
        except (OSError, subprocess.SubprocessError):
            return False
    return r.returncode == 0


def lire_manifeste(donnees):
    """Manifeste d'une version, contrôlé champ par champ (rien d'autre n'est cru)."""
    m = json.loads(donnees.decode("utf-8"))
    v, archive, sha = str(m.get("version") or ""), str(m.get("archive") or ""), str(m.get("sha256") or "")
    if not RE_VERSION.match(v) or not re.fullmatch(r"versions/\d+\.\d+\.\d+/KineAPP-\d+\.\d+\.\d+\.tar\.gz", archive) \
            or archive != f"versions/{v}/KineAPP-{v}.tar.gz" or not re.fullmatch(r"[0-9a-f]{64}", sha):
        raise ValueError("Manifeste de version invalide.")
    return {"version": v, "archive": archive, "sha256": sha, "octets": int(m.get("octets") or 0),
            "commit": str(m.get("commit") or "")[:12], "date": str(m.get("date") or "")[:10],
            "statut": str(m.get("statut") or "")[:20], "macos_min": str(m.get("macos_min") or "")[:10],
            "changements": [str(x)[:200] for x in (m.get("changements") or [])][:40]}


def _get(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": "KineAPP"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def verifier(version_installee, force=False, base=None, code=None):
    """Lit la dernière version publiée (au plus une fois par jour sauf demande) et la garde si sa signature est
    valide. Renvoie l'état (voir etat())."""
    os.makedirs(PUBLIEES, exist_ok=True)
    etat_p = os.path.join(PUBLIEES, "etat.json")
    try:
        e = json.load(open(etat_p, encoding="utf-8"))
    except (OSError, ValueError):
        e = {}
    if not force and time.time() - float(e.get("verifie") or 0) < INTERVALLE_S:
        return etat(version_installee, code)
    e.update(verifie=time.time(), erreur="")
    c = canal(code)
    base = base or c.get("base")
    try:
        if not base:
            raise RuntimeError("Dépôt des versions non configuré.")
        manifeste, sig = _get(base + "derniere.json"), _get(base + "derniere.json.sig")
        if not verifier_signature(manifeste, sig, signataires(code)):
            raise RuntimeError("Dernière version publiée non signée par l'éditeur de KinéAPP : ignorée.")
        lire_manifeste(manifeste)
        open(os.path.join(PUBLIEES, "derniere.json"), "wb").write(manifeste)
        open(os.path.join(PUBLIEES, "derniere.json.sig"), "wb").write(sig)
    except Exception as ex:
        e["erreur"] = str(ex)[:300] or type(ex).__name__
    json.dump(e, open(etat_p, "w", encoding="utf-8"))
    return etat(version_installee, code)


def etat(version_installee, code=None):
    """Dernière version publiée connue (signature revérifiée à chaque lecture), et si elle est plus récente."""
    out = {"disponible": "", "nouvelle": False, "signee": False, "changements": [], "erreur": "", "verifie": 0,
           "page": canal(code).get("page", "")}
    try:
        e = json.load(open(os.path.join(PUBLIEES, "etat.json"), encoding="utf-8"))
        out.update(erreur=e.get("erreur", ""), verifie=e.get("verifie", 0))
    except (OSError, ValueError):
        pass
    try:
        manifeste = open(os.path.join(PUBLIEES, "derniere.json"), "rb").read()
        sig = open(os.path.join(PUBLIEES, "derniere.json.sig"), "rb").read()
    except OSError:
        return out
    if not verifier_signature(manifeste, sig, signataires(code)):
        out["erreur"] = out["erreur"] or "Signature de la version publiée invalide."
        return out
    m = lire_manifeste(manifeste)
    out.update(disponible=m["version"], signee=True, changements=m["changements"], date=m["date"], statut=m["statut"],
               octets=m["octets"], nouvelle=_vt(m["version"]) > _vt(version_installee))
    return out


def preparer(version_installee, base=None, code=None):
    """Télécharge l'archive de la dernière version signée et vérifie son empreinte. Renvoie le dossier à donner à
    l'installateur (manifeste, signature, archive), ou lève une erreur."""
    manifeste = open(os.path.join(PUBLIEES, "derniere.json"), "rb").read()
    sig = open(os.path.join(PUBLIEES, "derniere.json.sig"), "rb").read()
    if not verifier_signature(manifeste, sig, signataires(code)):
        raise RuntimeError("Version publiée non signée par l'éditeur : rien n'est téléchargé.")
    m = lire_manifeste(manifeste)
    if _vt(m["version"]) <= _vt(version_installee):
        raise RuntimeError("Déjà à jour.")
    d = os.path.join(RECUES, m["version"])
    os.makedirs(d, exist_ok=True)
    archive = os.path.join(d, os.path.basename(m["archive"]))
    if not (os.path.isfile(archive) and _sha256(archive) == m["sha256"]):
        base = base or canal(code).get("base")
        part = archive + ".partiel"
        TELECHARGEMENT.update(phase="téléchargement", recu=0, total=m["octets"], erreur="")
        req = urllib.request.Request(base + m["archive"], headers={"User-Agent": "KineAPP"})
        with urllib.request.urlopen(req, timeout=60) as rep, open(part, "wb") as f:
            while True:
                bloc = rep.read(1 << 20)
                if not bloc:
                    break
                f.write(bloc)
                TELECHARGEMENT["recu"] += len(bloc)
        if _sha256(part) != m["sha256"]:
            os.remove(part)
            TELECHARGEMENT.update(phase="", erreur="Archive altérée (empreinte différente).")
            raise RuntimeError("Archive téléchargée altérée (empreinte différente) : rien n'est installé.")
        os.replace(part, archive)
        TELECHARGEMENT.update(phase="")
    open(os.path.join(d, "manifeste.json"), "wb").write(manifeste)
    open(os.path.join(d, "manifeste.json.sig"), "wb").write(sig)
    # Versions plus anciennes reçues : inutiles (l'installateur garde la version remplacée), à la Corbeille.
    import confidentialite as CF
    CF.corbeille([os.path.join(RECUES, v) for v in os.listdir(RECUES) if v != m["version"] and RE_VERSION.match(v)])
    return d


def _sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()
