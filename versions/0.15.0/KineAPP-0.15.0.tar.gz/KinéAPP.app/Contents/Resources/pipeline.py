# -*- coding: utf-8 -*-
"""Emplacements des consignes et des brouillons, et squelette JSON donné au modèle."""
import os

BASE = os.path.dirname(os.path.abspath(__file__))     # code (bundle)
DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
PROMPTS = os.path.join(BASE, "prompts")               # code : lecture seule
DRAFTS = os.path.join(DATA, "brouillons")             # données : modifiables


def read(p):
    return open(p, encoding="utf-8").read()


def json_skeleton(node):
    t = node.get("type")
    if t == "object": return {k: json_skeleton(v) for k, v in node["properties"].items()}
    if t == "array":
        # Tableau d'objets : on montre UN élément d'exemple, sinon le modèle ne voit pas les
        # clés qu'il doit produire (antecedents.medicaux et .medicaments depuis le 05/10/2026).
        it = node.get("items")
        return [json_skeleton(it)] if isinstance(it, dict) and it.get("type") == "object" else []
    if node.get("enum"): return " | ".join(node["enum"])   # valeurs admises, pas « non évalué »
    return "non évalué"
