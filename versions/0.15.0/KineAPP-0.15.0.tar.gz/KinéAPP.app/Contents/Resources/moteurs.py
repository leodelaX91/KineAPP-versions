# -*- coding: utf-8 -*-
"""Moteurs d'inférence de KinéAPP : Splash, et llama.cpp en secours.

Tous deux sont intégrés à l'app, lancés par elle et parlent l'API OpenAI
(/v1/chat/completions) sur 127.0.0.1 : mêmes consignes, températures et max_tokens. Ce qui
diffère — lancement, arrêt, mode JSON — est isolé ici ; leurs réglages sont dans moteurs.json.
Un modèle se désigne par son mode (rapide, qualite, qualite_rapide : modeles_llm.py).

Règle : un seul modèle en mémoire à la fois. Avant d'en charger un, l'app décharge
tout modèle chargé par un autre moteur (arreter_tous).
"""
import json, os, signal, subprocess, threading, time, urllib.error, urllib.request

import journal as JO
import materiel as MAT
import moteurs_integres as MI
import modeles_llm as MLL

CODE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
JOURNAUX = os.path.join(DATA, "journaux")

def http(url, charge=None, timeout=30, entetes=None, methode=None):
    """Appel JSON ; lève ErreurMoteur avec le message renvoyé par le serveur."""
    donnees = json.dumps(charge).encode() if charge is not None else None
    req = urllib.request.Request(url, data=donnees, method=methode,
                                 headers={"Content-Type": "application/json", **(entetes or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            brut = r.read().decode("utf-8", "ignore")
            return json.loads(brut) if brut.strip() else {}
    except urllib.error.HTTPError as e:
        corps = e.read().decode("utf-8", "ignore")
        try:
            motif = (json.loads(corps).get("error") or {})
            motif = motif.get("message") if isinstance(motif, dict) else motif
        except Exception:
            motif = corps[:300]
        raise ErreurMoteur(f"HTTP {e.code} : {motif or corps[:300]}") from None


class ErreurMoteur(RuntimeError):
    pass


# ── En-tête GGUF : un modèle à experts (MoE) peut être lu depuis le disque ──
_OCTETS = {0: 1, 1: 1, 2: 2, 3: 2, 4: 4, 5: 4, 6: 4, 7: 1, 10: 8, 11: 8, 12: 8}
_EXPERTS = {}


def experts_gguf(chemin):
    """Nombre d'experts d'un modèle GGUF, lu dans son en-tête (0 : modèle dense ou illisible)."""
    import struct
    try:
        reel = os.path.realpath(chemin)
        st = os.stat(reel)
    except OSError:
        return 0
    cle_cache = (reel, st.st_size, st.st_mtime)
    if cle_cache in _EXPERTS:
        return _EXPERTS[cle_cache]
    n = 0
    try:
        with open(reel, "rb") as f:
            def lire(k):
                b = f.read(k)
                if len(b) != k:
                    raise EOFError
                return b
            def u32(): return struct.unpack("<I", lire(4))[0]
            def u64(): return struct.unpack("<Q", lire(8))[0]
            def chaine(): return lire(u64()).decode("utf-8", "replace")
            def valeur(ty):
                if ty == 8:
                    return chaine()
                if ty == 9:
                    sous, nb = u32(), u64()
                    if sous == 8:
                        for _ in range(nb): f.seek(u64(), 1)
                    elif sous in _OCTETS:
                        f.seek(_OCTETS[sous] * nb, 1)
                    else:
                        for _ in range(nb): valeur(sous)
                    return None
                b = lire(_OCTETS[ty])
                return int.from_bytes(b, "little") if ty in (0, 2, 4, 10) else None
            if lire(4) != b"GGUF" or u32() < 2:
                raise ValueError("pas un GGUF")
            u64()                                   # nombre de tenseurs
            for _ in range(min(u64(), 100000)):
                cle, ty = chaine(), u32()
                v = valeur(ty)
                if cle.endswith(".expert_count") and isinstance(v, int):
                    n = v
                    break
    except Exception as e_tol:
        JO.ignoree(e_tol)
    _EXPERTS[cle_cache] = n
    return n


# ── Journal des requêtes côté client (moteurs sans journal serveur exploitable) ──
_JOURNAL, _VERROU = [], threading.Lock()


def noter_requete(mesure):
    with _VERROU:
        _JOURNAL.append(mesure)
        del _JOURNAL[:-50]


def _requetes_depuis(n):
    with _VERROU:
        return list(_JOURNAL[n:]), len(_JOURNAL)


class Moteur:
    """Interface commune. Les méthodes par défaut conviennent à un serveur
    OpenAI-compatible « simple » ; chaque moteur surcharge ce qui diffère."""
    id = ""

    def __init__(self, cle, cfg):
        self.id, self.cfg = cle, cfg
        self.nom = cfg.get("nom", cle)

    # adresse
    @property
    def port(self):     return int(self.cfg.get("port", 0))
    @property
    def base(self):     return f"http://127.0.0.1:{self.port}"
    @property
    def api(self):      return self.base + "/v1/chat/completions"
    def entetes(self):  return {}

    # présence, modèles, état
    def installe(self):              return False
    def modeles(self):               return []
    def modele_defaut(self):         m = self.modeles(); return m[0]["id"] if m else ""
    def en_marche(self):
        try: http(self.base + "/v1/models", timeout=3, entetes=self.entetes()); return True
        except Exception: return False
    def modele_charge(self):         return None
    def besoin_memoire_go(self, modele): return 0.0

    # cycle de vie
    def demarrer(self, modele):      raise NotImplementedError
    def arreter(self):               pass
    def arreter_enfant(self):        pass       # processus lancé par l'app elle-même

    # requêtes
    def adapter(self, charge, json_mode=False):
        """Adapte une requête commune aux particularités du moteur."""
        if json_mode:
            charge["response_format"] = {"type": "json_object"}
        if self.cfg.get("raisonnement") == "chat_template_kwargs":
            charge["chat_template_kwargs"] = {"enable_thinking": False}     # réflexion toujours coupée
        charge.update(self.cfg.get("par_requete") or {})
        if charge.get("stream"):
            charge["stream_options"] = {"include_usage": True}   # décompte exact des tokens
        return charge

    @property
    def delai_lecture(self):         return int(self.cfg.get("delai_lecture_s", 1800))
    @property
    def prefill_estime(self):        return float(self.cfg.get("prefill_tok_s_estime", 50))

    # métriques
    def repere(self):                return _requetes_depuis(0)[1]
    def mesures(self, repere, garder=2):
        reqs, _ = _requetes_depuis(repere)
        out = [{"prompt_tokens": r.get("prompt_tokens"), "completion_tokens": r.get("completion_tokens"),
                "ttft_s": r.get("ttft_s"), "prefill_tok_s": r.get("prefill_tok_s"),
                "decode_tok_s": r.get("decode_tok_s"), "duree_s": r.get("duree_s"),
                "pic_ram_gio": r.get("pic_ram_gio")} for r in reqs if r.get("reelle", True)]
        return out[-garder:]

    def description(self):
        return {"id": self.id, "nom": self.nom, "installe": self.installe(),
                "description": self.cfg.get("description", ""), "port": self.port}


# ═══════════════════════════════════════════════════════════════════════════
class Serveur(Moteur):
    """Un processus serveur par modèle, lancé et arrêté par l'app, écoutant sur 127.0.0.1.
    Le journal ne reçoit que les lignes techniques : aucune ligne de requête."""
    PROCESSUS = ""                             # mot attendu dans sa ligne de commande

    @property
    def _pidf(self):     return os.path.join(DATA, f"{self.id}.pid")
    @property
    def journal(self):   return os.path.join(JOURNAUX, f"{self.id}.log")

    def modeles(self):
        return [{"id": x["id"], "nom": x["titre"], "taille": f"{x['taille'] / 1e9:.1f} GB"}
                for x in MLL.modes() if x["present"] and self.accepte(x["id"])]

    def accepte(self, mode):                   return True
    def besoin_memoire_go(self, mode):         return float(self.cfg.get("memoire_min_go", 4))

    def _pid(self):
        try: return int(open(self._pidf).read().split()[0])
        except (OSError, ValueError, IndexError): return None

    def modele_charge(self):
        try: return open(self._pidf).read().split(None, 1)[1].strip() if self.en_marche() else None
        except (OSError, IndexError): return None

    def _commande(self, mode):                 raise NotImplementedError
    def _environnement(self):                  return None
    def _pret(self):                           return self.en_marche()
    def _identifiant(self, mode):              return mode

    def _lancer(self, mode):
        """Lance le serveur et attend qu'il réponde ; lève ErreurMoteur s'il s'arrête ou tarde."""
        os.makedirs(JOURNAUX, exist_ok=True)
        pr = subprocess.Popen(self._commande(mode), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              env=self._environnement(), start_new_session=True)
        threading.Thread(target=self._filtrer_journal, args=(pr,), daemon=True).start()
        with open(self._pidf, "w") as f:
            f.write(f"{pr.pid} {mode}")
        limite, t0 = int(self.cfg.get("delai_demarrage_s", 600)), time.time()
        while time.time() - t0 < limite:
            if pr.poll() is not None:
                time.sleep(0.5)                # le fil du journal finit d'écrire
                fin = ""
                try: fin = open(self.journal, encoding="utf-8", errors="ignore").read()[-600:]
                except OSError: pass
                self.arreter()
                raise ErreurMoteur(f"{self.nom} s'est arrêté au démarrage : " + fin)
            if self._pret():
                return self._identifiant(mode)
            time.sleep(2)
        self.arreter()
        raise ErreurMoteur(f"{self.nom} n'a pas répondu en {limite} s.")

    def demarrer(self, mode):
        if self.modele_charge() == mode:
            return self._identifiant(mode)
        self.arreter()
        if not MLL.present(mode):
            raise ErreurMoteur(f"Le modèle du {MLL.CATALOGUE[mode]['titre'].lower() if mode in MLL.CATALOGUE else mode} "
                               "n'est pas sur ce Mac : téléchargez-le dans Paramètres → IA.")
        return self._lancer(mode)

    def arreter(self):
        pid = self._pid()
        if pid:
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try:
                    cmd = subprocess.run(["ps", "-o", "command=", "-p", str(pid)],
                                         capture_output=True, text=True, timeout=10).stdout
                    if self.PROCESSUS not in cmd:          # pid recyclé : ne tuer personne d'autre
                        break
                    os.killpg(pid, sig)                    # ses processus enfants avec lui
                    for _ in range(40 if sig == signal.SIGTERM else 5):
                        time.sleep(0.5)
                        if not subprocess.run(["ps", "-p", str(pid)], capture_output=True).returncode == 0:
                            break
                except (ProcessLookupError, PermissionError, subprocess.SubprocessError):
                    break
        try: os.remove(self._pidf)
        except OSError: pass

    arreter_enfant = arreter

    def _filtrer_journal(self, pr):
        """Écarte toute ligne qui pourrait contenir le texte d'une requête."""
        os.makedirs(JOURNAUX, exist_ok=True)
        with open(self.journal, "w", encoding="utf-8") as fh:
            for brute in pr.stdout:
                ligne = brute.decode("utf-8", "replace")
                if '"content"' in ligne or '"messages"' in ligne or '"prompt"' in ligne:
                    continue
                fh.write(ligne); fh.flush()


# ═══════════════════════════════════════════════════════════════════════════
class Splash(Serveur):
    """Le moteur principal. Toujours hors ligne (--offline) : les modèles viennent de l'app, avec
    leur empreinte vérifiée. Le cache disque est temporaire et borné, jamais persistant."""
    PROCESSUS = "splash"
    DELAI_MEMOIRE_S = 20                       # la mémoire du modèle précédent met du temps à revenir

    @property
    def racine(self):       return MI.dossier_splash()
    def macos_ok(self):     return MAT.macos() >= tuple(self.cfg.get("macos_min") or (26, 4))
    def installe(self):     return bool(self.racine) and self.macos_ok()
    def _identifiant(self, mode):  return f"kineapp/{mode}"
    def _pret(self):
        if not self.en_marche():
            return False
        try: return "Ready ·" in open(self.journal, encoding="utf-8", errors="ignore").read()
        except OSError: return False

    def _commande(self, mode):
        c = MLL.chemins(mode)
        return [os.path.join(self.racine, "python", "bin", "python3"), "-u",
                os.path.join(self.racine, "install", "launcher.py"), "serve",
                "--model", self._identifiant(mode), "--model-dir", c["modele"], "--draft-model", c["brouillon"],
                "--host", "127.0.0.1", "--port", str(self.port)] + list(self.cfg.get("arguments") or [])

    def _environnement(self):
        env = {k: v for k, v in os.environ.items() if k != "SPLASH_HIDDEN_LOG"}
        env.update(PYTHONDONTWRITEBYTECODE="1", HF_HUB_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1")
        return env

    def _lancer(self, mode):
        # Sans assez de mémoire libre, Splash refuse de démarrer ; elle revient souvent en quelques secondes.
        for essai in range(3):
            try:
                return super()._lancer(mode)
            except ErreurMoteur as e:
                if "not enough free memory" not in str(e) or essai == 2:
                    raise
                time.sleep(self.DELAI_MEMOIRE_S)


# ═══════════════════════════════════════════════════════════════════════════
class Llama(Serveur):
    """Le moteur de secours : llama-server, pour les modes dont le modèle le permet."""
    PROCESSUS = "llama-server"

    @property
    def binaire(self):      return MI.integre("llama")
    def installe(self):     return bool(self.binaire)
    def accepte(self, mode):
        return bool((MLL.CATALOGUE.get(mode) or {}).get("llama"))

    def _besoin_en_memoire(self, modele):
        try: return os.path.getsize(os.path.realpath(modele)) / 1e9 * 1.15
        except OSError: return float(self.cfg.get("memoire_min_go", 12))

    def mode_ssd(self, modele, ram=None):
        """Un modèle à experts trop gros pour la mémoire de ce Mac est lu depuis le SSD : le cœur
        reste en mémoire, les experts sont lus sur le disque à chaque mot (bancs du 29-30/10/2026 :
        35B IQ3 sur 16 Go, ~14 min par bilan, même qualité qu'en mémoire)."""
        return experts_gguf(modele) > 0 and not MAT.tient_en_memoire(self._besoin_en_memoire(modele), ram)

    def _gguf(self, mode):
        return (MLL.chemins(mode) or {}).get("gguf", "")

    def besoin_memoire_go(self, mode):
        modele = self._gguf(mode)
        if not modele:
            return float(self.cfg.get("memoire_min_go", 12))
        if self.mode_ssd(modele):
            return float(self.cfg.get("memoire_ssd_go", 4))
        return self._besoin_en_memoire(modele)

    def arguments(self, modele, ram=None):
        """Arguments du serveur pour ce modèle sur ce Mac."""
        args = list(self.cfg.get("arguments") or [])
        if self.mode_ssd(modele, ram):
            # --no-repack est indispensable : sans lui, llama.cpp recopie les experts en mémoire
            # anonyme et tout part dans le swap (17,6 Go, 2,7 t/s, mesuré le 28/10/2026).
            args += list(self.cfg.get("arguments_ssd") or [])
        return args

    def _commande(self, mode):
        modele = self._gguf(mode)
        # Pas de décodage spéculatif : mesuré le 05/10/2026, activer le brouillon FAIT PERDRE du débit sous llama.cpp.
        return [self.binaire, "--model", modele, "--host", "127.0.0.1", "--port", str(self.port),
                "--alias", mode] + self.arguments(modele)

    def demarrer(self, mode):
        if not self.accepte(mode):
            raise ErreurMoteur(f"Le {MLL.CATALOGUE[mode]['titre'].lower()} ne fonctionne qu'avec Splash." if mode in MLL.CATALOGUE
                               else f"Mode inconnu : {mode}")
        return super().demarrer(mode)


_CLASSES = {"splash": Splash, "llama": Llama}
REGLAGES = {k: v for k, v in json.load(open(os.path.join(CODE, "moteurs.json"), encoding="utf-8")).items()
            if not k.startswith("_")}
MOTEURS = {k: _CLASSES[k](k, v) for k, v in REGLAGES.items() if k in _CLASSES}


def get(cle):
    return MOTEURS.get(cle) or MOTEURS["splash"]


def liste():
    return [m.description() for m in MOTEURS.values()]


def arreter_tous(sauf=None):
    """Décharge tout modèle chargé par un autre moteur : un seul modèle en mémoire."""
    for cle, m in MOTEURS.items():
        if cle == sauf:
            continue
        try:
            if m.installe() and m.modele_charge():
                m.arreter()
        except Exception as e_tol:
            JO.ignoree(e_tol)


def arreter_enfants():
    """À l'arrêt de l'app : les serveurs lancés comme processus enfants."""
    for m in MOTEURS.values():
        try: m.arreter_enfant()
        except Exception: pass
