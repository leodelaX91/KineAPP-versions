# -*- coding: utf-8 -*-
"""Confidentialité : traces de santé hors de l'app, droits des dossiers, secrets au Trousseau.

Données dérivées des bilans qui échappent à la politique de l'app (effacement, sauvegarde chiffrée) :
sorties brutes du modèle, fichiers d'anciennes versions, audio et transcription d'un bilan interrompu.

Rien n'est jamais supprimé : tout part à la Corbeille, que l'utilisateur vide lui-même.
Les journaux de Splash et de llama.cpp ne sont pas listés : l'app les filtre déjà à
l'écriture (moteurs.py), aucune ligne de contenu n'y arrive.
"""
import glob, os, subprocess, time

DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
TROUSSEAU_SERVICE = os.environ.get("KINEAPP_TROUSSEAU_SECRETS") or "KinéAPP secrets"
JOUR = 86400.0

EMPLACEMENTS = [
    {"cle": "brouillons_bruts", "nom": "Sorties brutes du modèle",
     "motifs": [os.path.join(DATA, "brouillons", "*.extraction-brute.txt")], "externe": False,
     "pourquoi": "Filet de sécurité gardé après chaque extraction : le texte complet produit par "
                 "le modèle, donc tout le contenu clinique du bilan. Inutile une fois le bilan relu."},
    {"cle": "anciennes_versions", "nom": "Fichiers d'anciennes versions de l'app",
     "motifs": [os.path.join(DATA, "notes_links.json"), os.path.join(DATA, "notes_sync_state.json")], "externe": False,
     "pourquoi": "Liens et état de l'ancienne synchronisation des notes (Apple Notes, dossier « Suivi Kiné ») : "
                 "ils peuvent contenir des noms de patients et ne servent plus à rien."},
    {"cle": "entrees", "nom": "Enregistrements et transcriptions non traités",
     "motifs": [os.path.join(DATA, "entrees", "*.wav"), os.path.join(DATA, "entrees", "*.txt"),
                os.path.join(DATA, "entrees", "ff_*.log")], "externe": False,
     "pourquoi": "Audio et transcription d'un bilan interrompu, gardés pour permettre une relance. "
                 "L'audio est la donnée la plus sensible : il ne doit pas rester des semaines."},
]
PAR_CLE = {e["cle"]: e for e in EMPLACEMENTS}


def _chemins(emplacement, proteges=(), age_min_s=0.0):
    """Fichiers et dossiers concernés, hors fichiers protégés (bilan en cours) et trop récents."""
    proteges = {os.path.realpath(p) for p in proteges if p}
    out, limite = [], time.time() - age_min_s
    for motif in emplacement["motifs"]:
        for p in sorted(glob.glob(os.path.expanduser(motif))):
            if os.path.realpath(p) in proteges:
                continue
            try:
                if age_min_s and os.path.getmtime(p) > limite:
                    continue
            except OSError:
                continue
            out.append(p)
    return out


def _taille(p):
    if os.path.isfile(p):
        try:
            return os.path.getsize(p)
        except OSError:
            return 0
    total = 0
    for racine, _, fichiers in os.walk(p):
        for f in fichiers:
            try:
                total += os.path.getsize(os.path.join(racine, f))
            except OSError:
                pass
    return total


def _age_jours(p):
    try:
        return (time.time() - os.path.getmtime(p)) / JOUR
    except OSError:
        return 0.0


def inventaire(proteges=(), age_min_s=0.0):
    """Ce qui traîne, emplacement par emplacement : nombre, volume, âge du plus ancien."""
    out = []
    for e in EMPLACEMENTS:
        chemins = _chemins(e, proteges, age_min_s)
        out.append({"cle": e["cle"], "nom": e["nom"], "pourquoi": e["pourquoi"],
                    "externe": e["externe"], "nombre": len(chemins),
                    "octets": sum(_taille(p) for p in chemins),
                    "plus_ancien_j": round(max((_age_jours(p) for p in chemins), default=0.0), 1),
                    "exemples": [os.path.basename(p) for p in chemins[:4]]})
    return out


def corbeille(chemins):
    """Déplace vers la Corbeille (jamais de suppression). Renvoie (nombre, octets, erreur).
    Tests automatiques : une corbeille dans leur dossier temporaire, pas celle de l'utilisateur."""
    chemins = [p for p in chemins if os.path.exists(p)]
    if not chemins:
        return 0, 0, ""
    octets = sum(_taille(p) for p in chemins)
    if os.environ.get("KINEAPP_TEST") == "1":
        import shutil, tempfile
        dest = tempfile.mkdtemp(prefix="corbeille-", dir=os.path.join(os.environ.get("KINEAPP_DATA") or tempfile.gettempdir()))
        for p in chemins:
            shutil.move(p, os.path.join(dest, os.path.basename(p)))
        return len(chemins), octets, ""
    r = subprocess.run(["/usr/bin/trash"] + chemins, capture_output=True, text=True, timeout=300)
    if r.returncode != 0:
        return 0, 0, (r.stderr or r.stdout).strip()[-300:]
    return len(chemins), octets, ""


def purger(cles, proteges=(), age_min_s=0.0):
    """Purge les emplacements demandés. Renvoie {cle: {nombre, octets, erreur}}."""
    resultat = {}
    for cle in cles or []:
        e = PAR_CLE.get(cle)
        if not e:
            continue
        n, octets, err = corbeille(_chemins(e, proteges, age_min_s))
        resultat[cle] = {"nombre": n, "octets": octets, "erreur": err}
    return resultat


def purger_audio(jours, proteges=()):
    """Automatique au démarrage : seuls les ENREGISTREMENTS au-delà du délai, jamais les
    transcriptions (elles permettent de relancer un bilan interrompu)."""
    if not jours or jours <= 0:
        return 0, 0, ""
    vieux = [p for p in _chemins({"motifs": [os.path.join(DATA, "entrees", "*.wav")]},
                                 proteges, float(jours) * JOUR)]
    return corbeille(vieux)


# ── droits du dossier de données ────────────────────────────────────────────
def durcir_droits(dossier=None):
    """Dossiers en 700, fichiers en 600 : les données de santé ne sont lisibles que par
    ce compte. Le dossier était en 755 avant l'audit du 30/09/2026."""
    racine = dossier or DATA
    change = 0
    for chemin, mode in _a_durcir(racine):
        try:
            os.chmod(chemin, mode)
            change += 1
        except OSError:
            pass
    return change


def _a_durcir(racine):
    if not os.path.isdir(racine):
        return
    if (os.stat(racine).st_mode & 0o777) != 0o700:
        yield racine, 0o700
    for base, dossiers, fichiers in os.walk(racine):
        for d in dossiers:
            p = os.path.join(base, d)
            try:
                if (os.stat(p).st_mode & 0o777) != 0o700:
                    yield p, 0o700
            except OSError:
                pass
        for f in fichiers:
            p = os.path.join(base, f)
            try:
                if os.path.islink(p) or (os.stat(p).st_mode & 0o777) == 0o600:
                    continue
                yield p, 0o600
            except OSError:
                pass


# ── secrets (Trousseau) ─────────────────────────────────────────────────────
def secret(nom):
    """Valeur enregistrée dans le Trousseau, ou chaîne vide."""
    r = subprocess.run(["security", "find-generic-password", "-a", nom, "-s", TROUSSEAU_SERVICE, "-w"],
                       input="", capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        return ""
    try:
        return bytes.fromhex(r.stdout.strip()).decode("utf-8")
    except ValueError:
        return ""


def memoriser_secret(nom, valeur):
    """Enregistre (ou efface si valeur vide). Passé par l'entrée standard : rien dans `ps`."""
    if not valeur:
        return oublier_secret(nom)
    commande = (f'add-generic-password -U -a {nom} -s "{TROUSSEAU_SERVICE}" '
                f'-w {valeur.encode("utf-8").hex()}\n')
    subprocess.run(["security", "-i"], input=commande, capture_output=True, text=True, timeout=30)
    return secret(nom) == valeur


def oublier_secret(nom):
    subprocess.run(["security", "delete-generic-password", "-a", nom, "-s", TROUSSEAU_SERVICE],
                   input="", capture_output=True, text=True, timeout=30)
    return not secret(nom)
