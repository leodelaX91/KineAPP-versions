# -*- coding: utf-8 -*-
"""Lignes rédigées PAR LE CODE à partir des champs structurés de l'extraction.

La passe de rédaction recomposait elle-même les mesures, les antécédents et le programme
à partir du JSON — et y réintroduisait des erreurs que l'extraction n'avait pas : côtés
devinés pour deux valeurs rangées ensemble, écart oublié, statut recopié tel quel
(« avril, terminé »), libellés de formulaire. Ces lignes-là n'ont rien à interpréter : un
côté, une valeur, une unité, une date. Le code les écrit sans erreur possible ; le modèle
les recopie et ne rédige que ce qui demande une formulation (motif, constats, synthèse).
"""
import re

NON = ("", "non évalué", "non evalue", "sans objet", "côté non précisé", "cote non precise")


def _v(x):
    x = " ".join(str(x or "").split())
    return "" if x.lower() in NON else x


def _cote(c):
    c = _v(c)
    return {"droit": "à droite", "gauche": "à gauche", "bilatéral": "des deux côtés"}.get(c, "")


# Mesures sans côté par nature : une EVA ou un score global ne porte pas « côté non précisé ».
SANS_COTE = re.compile(r"\beva\b|douleur|echelle|échelle|score|rachis|lombaire|cervical|dorsal|\bdos\b|"
                       r"schober|tronc|distance doigts?-sol|questionnaire|ressenti|scoliose|superman|\bplanche\b(?!\s+lat)|"
                       # La marche comme test global ; jamais « périmètre » seul (cuisse, mollet ont un côté)
                       # ni « marche » seule (une montée de marche se teste d'un côté).
                       r"(?:test|tol[ée]rance|p[ée]rim[èe]tre|distance|temps)\s+(?:(?:à|a)\s+la\s+|de\s+)?marche", re.I)
# Pour une force, la valeur retenue d'une série est le PIC : c'est la pratique standard en
# dynamométrie (meilleur de trois essais). Pour d'autres mesures on ne choisit pas.
FORCE = re.compile(r"force|dynamom|isométri|isocinét|préhension|prehension", re.I)


def _nombre(s, force=False):
    """Valeur retenue d'une série : celle marquée « meilleure / retenue / pic », sinon la
    valeur unique. Plusieurs valeurs sans marque : pas de valeur retenue (on ne choisit pas
    à la place du praticien — pour une durée, la meilleure est la plus courte)."""
    s = str(s or "")
    m = re.search(r"(?:meilleur\w*|retenu\w*|pic)\s*:?\s*(\d+(?:[.,]\d+)?)", s, re.I)
    if m:
        return float(m.group(1).replace(",", "."))
    nombres = [float(n.replace(",", ".")) for n in re.findall(r"\d+(?:[.,]\d+)?", s)]
    if len(nombres) == 1:
        return nombres[0]
    return max(nombres) if force and nombres else None


def _nb(v):
    return str(int(v)) if float(v).is_integer() else f"{v}".replace(".", ",")


def lignes_mesures(mesures):
    """Une ligne par mesure et par moment, les deux côtés ensemble, écart calculé."""
    groupes, ordre = {}, []
    for m in mesures or []:
        if not isinstance(m, dict) or not _v(m.get("valeurs")):
            continue
        cle = (_v(m.get("mesure")), _v(m.get("site")), _v(m.get("moment")) or "ce jour")
        if cle not in groupes:
            groupes[cle] = []; ordre.append(cle)
        groupes[cle].append(m)
    lignes = []
    for cle in ordre:
        mesure, site, moment = cle
        titre = mesure + (f" ({site})" if site and site.lower() not in mesure.lower() else "")
        parts, retenues, unites = [], {}, set()
        for m in groupes[cle]:
            unite = _v(m.get("unite"))
            unites.add(unite)
            valeurs = _v(m.get("valeurs"))
            plusieurs = len(re.findall(r"\d+(?:[.,]\d+)?", valeurs)) > 1
            cote = _v(m.get("cote"))
            # Unité déjà écrite dans la valeur (« 10 degrés d'hyperextension ») : la répéter
            # donnait « 10 degrés d'hyperextension degrés à droite » (bilan du 08/10/2026).
            if unite and re.search(r"(?<!\w)" + re.escape(unite.lower()) + r"(?!\w)", valeurs.lower()):
                unite = ""
            if cote in ("droit", "gauche"):
                r = _nombre(valeurs, force=bool(FORCE.search(mesure)))
                texte = (f"{_nb(r)} {unite} {_cote(cote)} (pic, essais {valeurs})"
                         if plusieurs and r is not None and FORCE.search(mesure)
                         else f"{_nb(r)} {unite} {_cote(cote)} (essais {valeurs})" if plusieurs and r is not None
                         else f"{valeurs} {unite} {_cote(cote)}")
                if r is not None:
                    retenues[cote] = r
            # Mesure sans côté par nature (rachis, échelle, test global) : jamais « des deux côtés »
            # ni « côté non précisé » (« Angle de scoliose : 9 degrés des deux côtés », 12/10/2026).
            elif SANS_COTE.search(titre) or cote == "sans objet":
                texte = f"{valeurs} {unite}"
            elif cote == "bilatéral" and not plusieurs:
                texte = f"{valeurs} {unite} des deux côtés"
            else:
                # Sans côté unique : les valeurs SANS attribution — on ne sait pas laquelle est où.
                texte = f"{valeurs} {unite} (côté non précisé)"
            parts.append(" ".join(texte.split()))
        ligne = f"{titre} : " + ", ".join(parts)
        if "droit" in retenues and "gauche" in retenues and len(unites) == 1:
            ecart = abs(retenues["droit"] - retenues["gauche"])
            if ecart > 0:
                ligne += f", écart de {_nb(round(ecart, 1))} {next(iter(unites))}".rstrip()
        if moment != "ce jour":
            ligne += f" — {moment}"
        lignes.append(re.sub(r"(\d)\s+(/\s*\d)", r"\1\2", " ".join(ligne.split())))   # « 7 /10 » → « 7/10 »
    return lignes


def lignes_antecedents(medicaux):
    out = []
    for it in medicaux or []:
        if not isinstance(it, dict) or not _v(it.get("libelle")):
            continue
        libelle, cote, date = _v(it["libelle"]), _v(it.get("cote")), _v(it.get("date"))
        ligne = libelle
        if cote in ("droit", "gauche") and cote not in libelle.lower():
            ligne += f" ({cote})"
        if date:
            ligne += f", {date}"
        statut = it.get("statut")
        if statut == "en cours":
            ligne += " — actuel"
        elif statut == "incertain":
            ligne += " — statut à confirmer"
        out.append(ligne)
    return out


def lignes_medicaments(medicaments):
    out = []
    for it in medicaments or []:
        if not isinstance(it, dict) or not _v(it.get("libelle")):
            continue
        libelle, poso, date, statut = (_v(it["libelle"]), _v(it.get("posologie")),
                                       _v(it.get("date")), it.get("statut"))
        if statut == "terminé":
            # « — arrêt … » plutôt que « arrêté » : un gabarit fixe ne peut pas accorder
            # (« Perfusion arrêtée », « Ibuprofène arrêté »), et la date commence souvent
            # elle-même par « arrêt » (« arrêt il y a 2-3 mois »).
            quand = re.sub(r"^arr[êe]t(é|ée|és|ées)?\b\s*", "", date, flags=re.I)
            out.append(f"{libelle} — arrêt" + (f" {quand}" if quand else ""))
        elif statut == "incertain":
            out.append(f"{libelle}" + (f", {poso}" if poso else "") + (f", {date}" if date else "")
                       + " — statut à confirmer")
        else:
            # La date d'un traitement en cours (« depuis 2003 ») dit sa durée : la perdre
            # appauvrissait le compte rendu (constaté au banc clinique du 07/10/2026).
            out.append(f"Traitement en cours : {libelle}" + (f", {poso}" if poso else "")
                       + (f", {date}" if date else ""))
    return out


def ligne_programme(programme):
    items = [f"{_v(x.get('exercice'))} ({_v(x.get('dosage'))})" if _v(x.get("dosage")) else _v(x.get("exercice"))
             for x in programme or [] if isinstance(x, dict) and _v(x.get("exercice"))]
    return "Programme d'exercices à domicile : " + " ; ".join(items) if items else ""


EVA = (("eva", "EVA"), ("eva_repos", "EVA au repos"), ("eva_effort", "EVA à l'effort"))


def preparer(extraction):
    """L'extraction telle que la rédaction la reçoit : les champs structurés remplacés par
    leurs lignes déjà rédigées, à recopier telles quelles."""
    import copy
    e = copy.deepcopy(extraction or {})
    ant = e.get("antecedents") or {}
    if isinstance(ant.get("medicaux"), list):
        ant["medicaux"] = {"LIGNES_REDIGEES": lignes_antecedents(ant["medicaux"])}
    if isinstance(ant.get("medicaments"), list):
        ant["medicaments"] = {"LIGNES_REDIGEES": lignes_medicaments(ant["medicaments"])}
    ex = e.get("examen_clinique") or {}
    if isinstance(ex.get("mesures"), list):
        ex["mesures"] = {"LIGNES_REDIGEES": lignes_mesures(ex["mesures"])}
    # Cotations de douleur : sur le banc du 07/11/2026, une fois l'EVA rangée dans un seul champ « eva » (et non plus
    # dans « mesures »), la rédaction l'a omise dans 6 bilans sur 9 où elle avait été dite. Rédigées par le code, elles
    # ne peuvent plus se perdre.
    dl = ex.get("douleur")
    if isinstance(dl, dict):
        # Seule une cotation chiffrée devient une ligne « EVA : … » : une description de la douleur rangée là par le
        # modèle (« gêne lors des squats », banc du 07/11/2026) reste telle quelle pour la rédaction.
        evas = [(cle, f"{lib} : {_v(dl.get(cle))}") for cle, lib in EVA if re.search(r"\d", _v(dl.get(cle)))]
        for cle, _ in EVA:
            if cle in dl and not _v(dl.get(cle)):
                dl.pop(cle)
        if evas:
            for cle, _ in evas:
                dl.pop(cle)
            dl["cotations_eva"] = {"LIGNES_REDIGEES": [l for _, l in evas]}
    pc = e.get("prise_en_charge") or {}
    if "programme_hep" in pc and "exercices_a_domicile" not in pc:      # nom d'avant le 07/11/2026
        pc["exercices_a_domicile"] = pc.pop("programme_hep")
    if isinstance(pc.get("exercices_a_domicile"), list):
        pc["exercices_a_domicile"] = {"LIGNES_REDIGEES": [l for l in [ligne_programme(pc["exercices_a_domicile"])] if l]}
    rdv = _v(pc.get("prochain_rendez_vous"))
    if rdv:
        pc["prochain_rendez_vous"] = {"LIGNES_REDIGEES": [f"Prochaine consultation : {rdv}"]}
    docs = _v(pc.get("documents_demandes"))
    if docs:
        pc["documents_demandes"] = {"LIGNES_REDIGEES": [f"Documents à apporter : {docs}"]}
    return e
