# -*- coding: utf-8 -*-
"""Amplitudes articulaires relevées dans le texte des bilans d'un patient (initial, réévaluations),
pour en tracer l'évolution. Calcul seul, sur le bilan tel qu'il a été relu et enregistré.

Une ligne « Flexion du genou : 110° à droite, 140° à gauche » donne deux relevés (genou, flexion,
D 110 et G 140). L'articulation peut venir d'un titre (« ### Genou droit ») ou d'une ligne
précédente ; le côté, de la proposition (« à droite », « D : »), sinon de la ligne. Une valeur hors
de [-90°, 200°] est ignorée (ce n'est pas une amplitude), comme une ligne d'objectif ou de norme.
"""
import re

import verification as VE

MOUVEMENTS = (("flexion dorsale", "Flexion dorsale"), ("flexion plantaire", "Flexion plantaire"),
              ("rotation interne", "Rotation interne"), ("rotation externe", "Rotation externe"),
              ("inclinaison", "Inclinaison"), ("antepulsion", "Antépulsion"), ("retropulsion", "Rétropulsion"),
              ("abduction", "Abduction"), ("adduction", "Adduction"), ("pronation", "Pronation"),
              ("supination", "Supination"), ("eversion", "Éversion"), ("inversion", "Inversion"),
              ("elevation", "Élévation"), ("flexion", "Flexion"), ("extension", "Extension"))
ABREGES = {"RI": "Rotation interne", "RE": "Rotation externe", "ABD": "Abduction", "ADD": "Adduction"}
ARTICULATIONS = ("epaule", "coude", "poignet", "hanche", "genou", "cheville", "cervical", "lombaire", "dorsal")
NOMS = {"epaule": "épaule", "cervical": "rachis cervical", "lombaire": "rachis lombaire", "dorsal": "rachis dorsal"}
DEGRES = re.compile(r"(-\s?)?(\d+(?:[.,]\d+)?)\s*(?:°|degr[ée]s?\b)")
OBJECTIF = re.compile(r"\b(objectifs?|cibles?|a atteindre|attendue?s?|normes?|normales?|visee?s?)\b")
COTE_MOT = re.compile(r"\b(droite?s?|gauches?)\b", re.I)
COTE_ABREGE = re.compile(r"(?<![\w'])([DG])(?=\s*[:=)]|\s+\d|\s*$)")


def _plat(t):
    return VE._sans_accent(t).lower()


def _articulation(t):
    p = _plat(t)
    return next((a for a in ARTICULATIONS if re.search(rf"\b{a}s?\b", p)), None)


def _mouvement(t):
    p = _plat(t)
    for cle, nom in MOUVEMENTS:
        if re.search(rf"\b{cle}\b", p):
            return nom
    return next((nom for ab, nom in ABREGES.items() if re.search(rf"\b{ab}\b", t)), None)


def _cotes(t):
    out = {("D" if m.group(1).lower().startswith("droit") else "G") for m in COTE_MOT.finditer(VE._sans_accent(t))}
    return out | {m.group(1) for m in COTE_ABREGE.finditer(t)}


def releves(texte):
    """[{"articulation", "mouvement", "cote" (D, G ou ""), "valeur"}] dans l'ordre du texte."""
    out = []
    contexte, cote_contexte = None, set()      # annoncés par un titre ou une ligne « Genou droit : »
    for ligne in (texte or "").splitlines():
        if ligne.lstrip().startswith("#"):
            sous_titre = ligne.lstrip().startswith("###")
            contexte = _articulation(ligne) if sous_titre else None
            cote_contexte = _cotes(ligne) if sous_titre and contexte else set()
            continue
        # Une cible ou une norme n'est pas une mesure : ligne d'objectif écartée, « (norme 140°) » retiré.
        ligne = re.sub(r"\([^)]*\)", lambda m: "" if OBJECTIF.search(_plat(m.group(0))) else m.group(0), ligne)
        if OBJECTIF.match(_plat(ligne).lstrip(" -*•")):
            continue
        if not DEGRES.search(ligne):
            if _articulation(ligne) and not _mouvement(ligne):
                contexte, cote_contexte = _articulation(ligne), _cotes(ligne)
            continue
        art = _articulation(ligne) or contexte
        contexte = art                              # « Extension : -3° » suit « Flexion du genou : … »
        if _articulation(ligne):
            cote_contexte = set()
        cotes_ligne = _cotes(ligne) or cote_contexte
        mouvement = None
        for prop in re.split(r"[,;]|\s/\s|\bet\b", ligne):
            if OBJECTIF.search(_plat(prop)):
                continue
            mouvement = _mouvement(prop) or mouvement
            cotes = _cotes(prop) or (cotes_ligne if len(cotes_ligne) == 1 else set())
            for m in DEGRES.finditer(prop):
                v = float(m.group(2).replace(",", ".")) * (-1 if m.group(1) else 1)
                if mouvement and -90 <= v <= 200:
                    out.append({"articulation": NOMS.get(art, art) or "", "mouvement": mouvement,
                                "cote": next(iter(cotes)) if len(cotes) == 1 else "", "valeur": v})
    return out


def series(bilans):
    """bilans : [(date jj/mm/aaaa, texte)] du plus ancien au plus récent ->
    [{"cle", "libelle", "points": [{"date", "g", "d", "x"}]}] (x : sans côté), seulement les mesures
    relevées dans au moins deux bilans (une évolution)."""
    par_cle = {}
    for date, texte in bilans:
        vus = set()
        for r in releves(texte):
            cle = (r["articulation"], r["mouvement"])
            k = {"G": "g", "D": "d"}.get(r["cote"], "x")
            if (cle, k) in vus:
                continue                                  # première valeur du bilan (active avant passive)
            vus.add((cle, k))
            s = par_cle.setdefault(cle, {})
            s.setdefault(date, {"date": date, "g": None, "d": None, "x": None})[k] = r["valeur"]
    out = []
    for (art, mvt), pts in par_cle.items():
        if len(pts) >= 2:
            out.append({"cle": f"{art}|{mvt}", "libelle": f"{art.capitalize()} — {mvt.lower()}" if art else mvt,
                        "points": list(pts.values())})
    return sorted(out, key=lambda s: s["libelle"])
