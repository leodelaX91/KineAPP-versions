//  KinéAPP — fenêtre native autour de l'interface servie en local.
//  Conservé DANS le bundle (ce fichier a déjà été perdu deux fois en vivant dans un dossier
//  temporaire). Compilé (swiftc -parse-as-library), assemblé et signé par outils/installer.sh,
//  qui installe l'app comme code du système (root) : personne ne peut la modifier sans mot de
//  passe administrateur.
//
//  Sécurité (refonte du 13/10/2026, coffre d'identité) :
//  - le serveur Python est lancé avec l'interpréteur du système en mode isolé (-I) et un
//    environnement propre ; son port est lu sur SA sortie, jamais cru d'un fichier modifiable ;
//  - la fenêtre ne charge que ce serveur et, en cadres, les pages du coffre ; tout autre lien
//    s'ouvre dans le navigateur, et seulement sur un clic ;
//  - le jeton du coffre (obtenu par son mot de passe, tapé ici) ne vit qu'en mémoire et n'est
//    remis qu'aux cadres du coffre (origine vérifiée), jamais à la page clinique ;
//  - aucune donnée web n'est écrite sur le disque (ni cache, ni stockage local) : rien à y piéger ;
//  - Touch ID (facultatif) : une clé de la puce de sécurité du Mac, utilisable seulement avec
//    l'empreinte, signe un défi à usage unique du coffre ; l'empreinte n'est demandée qu'après un
//    clic dans KinéAPP ; le mot de passe n'est stocké nulle part.

import AppKit
import CryptoKit
import Security
import LocalAuthentication
import WebKit

let RESSOURCES = Bundle.main.resourcePath ?? ""
/// Python embarqué dans l'app (3.13, maintenu) ; celui du système seulement s'il manque (essais).
let PYTHON: String = {
    let p = (Bundle.main.resourcePath ?? "") + "/python/bin/python3"
    return FileManager.default.isExecutableFile(atPath: p) ? p : "/usr/bin/python3"
}()
let SCRIPT = RESSOURCES + "/ui/server.py"
/// Publié par le serveur pour une fenêtre relancée pendant une séance ; jamais cru sur parole :
/// le processus qui écoute sur ce port est vérifié (serveurLegitime).
let FICHIER_PORT = NSHomeDirectory() + "/Library/Application Support/BilanKine/port.txt"
let DOSSIER_COFFRE = "/Library/Application Support/KineAPP"
/// Sortie du serveur, gardée pour « Signaler un problème » (l'app ne manipule que des codes).
let JOURNAL = NSHomeDirectory() + "/Library/Logs/KinéAPP/serveur.log"
/// Dossier KinéAPP : dans Documents ou sur le Bureau, selon le réglage « emplacement » de l'app.
func dossierKineAPP() -> String {
    let reglages = NSHomeDirectory() + "/Library/Application Support/BilanKine/ui_config.json"
    if let d = FileManager.default.contents(atPath: reglages),
       let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
       j["emplacement"] as? String == "bureau" {
        return NSHomeDirectory() + "/Desktop/KinéAPP"
    }
    return NSHomeDirectory() + "/Documents/KinéAPP"
}
/// Clé Touch ID du coffre : enveloppe chiffrée par la puce de sécurité de CE Mac, inutilisable
/// sans l'empreinte (et invalidée si les empreintes changent).
let FICHIER_TOUCHID = NSHomeDirectory() + "/Library/Application Support/BilanKine/coffre-touchid.cle"
let PREFIXE_TOUCHID = "kineapp-coffre-touchid:"

enum IssueTouchID {
    case signature(Data), annule, motDePasse, cleInvalide, echec(String)
}

/// Journal technique du serveur, tourné à 2 Mo (le précédent devient serveur.log.1).
final class Journal {
    private var h: FileHandle?
    private let file = DispatchQueue(label: "journal")
    init() {
        let fm = FileManager.default
        try? fm.createDirectory(atPath: (JOURNAL as NSString).deletingLastPathComponent, withIntermediateDirectories: true)
        if let a = try? fm.attributesOfItem(atPath: JOURNAL), ((a[.size] as? NSNumber)?.intValue ?? 0) > 2_000_000 {
            try? fm.removeItem(atPath: JOURNAL + ".1")
            try? fm.moveItem(atPath: JOURNAL, toPath: JOURNAL + ".1")
        }
        if !fm.fileExists(atPath: JOURNAL) {
            fm.createFile(atPath: JOURNAL, contents: nil, attributes: [.posixPermissions: 0o600])
        }
        h = FileHandle(forWritingAtPath: JOURNAL)
        h?.seekToEndOfFile()
    }
    func ecrire(_ d: Data) { file.async { self.h?.write(d) } }
}
let COFFRE_PUBLIC = DOSSIER_COFFRE + "/coffre-public.json"

func adresse(_ port: Int, _ chemin: String = "") -> String {
    "http://127.0.0.1:\(port)/" + chemin
}

func adresseURL(_ port: Int, _ chemin: String) -> URL {
    URL(string: adresse(port, chemin))!
}

/// Fichier ou dossier du système : propriétaire root, modifiable par lui seul.
func appartientAuSysteme(_ chemin: String) -> Bool {
    guard let a = try? FileManager.default.attributesOfItem(atPath: chemin),
          (a[.ownerAccountID] as? NSNumber)?.intValue == 0,
          let droits = (a[.posixPermissions] as? NSNumber)?.intValue
    else { return false }
    return droits & 0o022 == 0
}

/// Port du coffre d'identité, d'après sa configuration publique — seulement si elle appartient au
/// système : une configuration modifiable par la session pourrait désigner un faux coffre.
func portCoffre() -> Int? {
    guard appartientAuSysteme(DOSSIER_COFFRE), appartientAuSysteme(COFFRE_PUBLIC),
          let donnees = FileManager.default.contents(atPath: COFFRE_PUBLIC),
          let json = try? JSONSerialization.jsonObject(with: donnees) as? [String: Any],
          let port = json["port"] as? Int, port > 1024, port < 65536
    else { return nil }
    return port
}

/// Sortie d'une commande du système (lsof, ps), sans shell.
func executer(_ outil: String, _ args: [String]) -> String {
    let p = Process()
    p.executableURL = URL(fileURLWithPath: outil)
    p.arguments = args
    let tube = Pipe()
    p.standardOutput = tube
    p.standardError = FileHandle.nullDevice
    do { try p.run() } catch { return "" }
    let d = tube.fileHandleForReading.readDataToEndOfFile()
    p.waitUntilExit()
    return String(data: d, encoding: .utf8) ?? ""
}

/// Secret du serveur, au Trousseau et non dans un fichier lisible par la session : une fenêtre
/// relancée pendant une séance (plantage) retrouve le canal du serveur resté en vie.
let SERVICE_SECRET = "KinéAPP serveur"
func memoriserSecretServeur(_ secret: String, port: Int) {
    let cle: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: SERVICE_SECRET]
    SecItemDelete(cle as CFDictionary)
    var ajout = cle
    ajout[kSecAttrAccount as String] = String(port)
    ajout[kSecValueData as String] = Data(secret.utf8)
    ajout[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
    SecItemAdd(ajout as CFDictionary, nil)
}
func secretServeurMemorise(port: Int) -> String? {
    let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: SERVICE_SECRET,
                            kSecAttrAccount as String: String(port), kSecReturnData as String: true]
    var r: CFTypeRef?
    guard SecItemCopyMatching(q as CFDictionary, &r) == errSecSuccess, let d = r as? Data else { return nil }
    return String(data: d, encoding: .utf8)
}
func oublierSecretServeur() {
    SecItemDelete([kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: SERVICE_SECRET] as CFDictionary)
}

/// Le serveur qui écoute sur ce port est-il bien celui de l'app : l'interpréteur du système en mode
/// isolé, le script du bundle, et aucune variable qui le détournerait (données, coffre, bibliothèques) ?
func serveurLegitime(port: Int) -> Bool {
    let pids = executer("/usr/sbin/lsof", ["-nP", "-iTCP:\(port)", "-sTCP:LISTEN", "-t"])
        .split(whereSeparator: \.isNewline).map(String.init)
    guard pids.count == 1 else { return false }
    let commande = executer("/bin/ps", ["-E", "-ww", "-o", "command=", "-p", pids[0]])
        .trimmingCharacters(in: .whitespacesAndNewlines)
    guard let r = commande.range(of: " -I " + SCRIPT) else { return false }
    let interpreteur = String(commande[..<r.lowerBound])
    // Python embarqué : ce chemin exactement. Python du système (essais) : son relais xcrun.
    guard interpreteur == PYTHON || (PYTHON == "/usr/bin/python3"
            && (interpreteur.hasPrefix("/Library/Developer/CommandLineTools/") || interpreteur.hasPrefix("/Applications/Xcode")))
    else { return false }
    let suite = commande[r.upperBound...]
    for motif in ["KINEAPP_", "DYLD_", "PYTHONPATH=", "PYTHONHOME=", "PYTHONSTARTUP=", "PYTHONINSPECT="]
    where suite.contains(motif) { return false }
    return true
}

/// Le vrai coffre tourne sous son compte système : `lsof`, lancé par la session, ne voit pas son
/// écoute. S'il en voit une sur le port du coffre, c'est un programme de la session qui s'y est mis.
func coffreUsurpe(port: Int) -> Bool {
    !executer("/usr/sbin/lsof", ["-nP", "-iTCP:\(port)", "-sTCP:LISTEN", "-t"])
        .trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
}

/// Environnement minimal du serveur : rien de ce que la session aurait pu glisser (DYLD_*, PYTHON*,
/// KINEAPP_*) ; les sites Python de l'utilisateur sont ignorés, y compris par ses sous-processus.
func environnementPropre() -> [String: String] {
    let e = ProcessInfo.processInfo.environment
    var r = ["PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1"]
    for k in ["HOME", "USER", "LOGNAME", "TMPDIR", "LANG", "LC_ALL", "LC_CTYPE", "__CF_USER_TEXT_ENCODING", "SHELL"] {
        if let v = e[k] { r[k] = v }
    }
    return r
}

/// Bande transparente posée sur la WebView, à l'emplacement du titlebar.
/// L'interface réserve déjà 46 px en haut : la poignée ne masque donc rien,
/// elle rend seulement cette zone vide déplaçable, ce que la WebView empêchait.
final class PoigneeFenetre: NSView {
    override func mouseDown(with event: NSEvent) {
        window?.performDrag(with: event)
    }
    override func mouseUp(with event: NSEvent) {
        if event.clickCount == 2 { window?.zoom(nil) }   // double-clic : agrandir
    }
    override var mouseDownCanMoveWindow: Bool { true }
}

final class Delegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate,
                      WKScriptMessageHandlerWithReply, WKDownloadDelegate {
    var fenetre: NSWindow!
    var vue: WKWebView!
    var serveur: Process?
    /// Port du serveur affiché : celui que NOTRE serveur a annoncé, ou un serveur vérifié.
    var portServeur: Int?
    var demarrageEnCours = false
    /// Jeton de session du coffre : en mémoire seulement, remis aux seuls cadres du coffre.
    var jeton: String? { didSet { if jeton != nil { sansCoffre = false }; majVoile() } }
    /// Écran de verrouillage : l'interface reste cachée tant que le coffre n'est pas déverrouillé.
    var voile: NSView?
    var voileTexte: NSTextField?
    var voileBoutons: (deverrouiller: NSButton, reessayer: NSButton, sans: NSButton)?
    var poignee: NSView?
    /// Coffre injoignable : l'app s'ouvre sans les noms, sur demande (jusqu'au prochain verrouillage).
    var sansCoffre = false
    var feuilleOuverte = false
    var refusDeverrouillage = Date.distantPast
    /// Dernière vérification que le port du coffre n'est pas tenu par un programme de la session.
    var verifCoffre: (quand: Date, usurpe: Bool)?
    let journal = Journal()
    var miseAJourEnCours = false
    var feuilleProgression: NSWindow?
    var touchIDEnCours = false
    /// L'app se ferme : plus rien ne se pose sur la fenêtre (17/10/2026 : l'écran de verrouillage
    /// visait une fenêtre déjà fermée, l'app plantait et le coffre ne recevait pas le verrouillage).
    var fermeture = false
    /// Secret remis au serveur par son entrée standard : lui seul ouvre le canal réservé à la fenêtre
    /// (transcriptions brutes des dictées, à faire pseudonymiser par le coffre).
    var secretServeur = ""
    var dicteesEnCours = false
    var minuteurDictees: Timer?
    /// Dictées de l'iPhone sans patient trouvé : le nom tapé ne vit qu'ici, en mémoire.
    var dicteesAAttribuer: [[String: Any]] = []
    let session = URLSession(configuration: .ephemeral)

    // MARK: serveur Python

    private func repond(_ port: Int) -> Bool {
        guard let url = URL(string: adresse(port, "api/ping")) else { return false }
        var requete = URLRequest(url: url)
        requete.timeoutInterval = 1.5
        var vivant = false
        let attente = DispatchSemaphore(value: 0)
        session.dataTask(with: requete) { _, reponse, _ in
            vivant = (reponse as? HTTPURLResponse)?.statusCode == 200
            attente.signal()
        }.resume()
        _ = attente.wait(timeout: .now() + 2)
        return vivant
    }

    /// Serveur d'une fenêtre précédente encore en vie (séance en cours lors d'un plantage) :
    /// repris seulement s'il est bien celui de l'app.
    private func serveurExistant() -> Int? {
        guard let t = try? String(contentsOfFile: FICHIER_PORT, encoding: .utf8),
              let p = Int(t.trimmingCharacters(in: .whitespacesAndNewlines)), p > 0,
              repond(p), serveurLegitime(port: p), let secret = secretServeurMemorise(port: p) else { return nil }
        secretServeur = secret
        return p
    }

    private func demarrerServeur() {
        if demarrageEnCours || miseAJourEnCours { return }
        if let t = serveur, t.isRunning { return }
        if let p = serveurExistant() { serveurPret(p); return }
        guard FileManager.default.isExecutableFile(atPath: PYTHON) else {
            alerte("Python 3 est introuvable.", "Installez les outils en ligne de commande avec :\nxcode-select --install")
            return
        }
        guard FileManager.default.fileExists(atPath: SCRIPT) else {
            alerte("Fichier manquant.", "Le serveur est introuvable dans l'application :\n\(SCRIPT)")
            return
        }
        demarrageEnCours = true
        let tache = Process()
        tache.executableURL = URL(fileURLWithPath: PYTHON)
        tache.arguments = ["-I", SCRIPT]
        tache.arguments?.append("--canal-fenetre")
        tache.currentDirectoryURL = URL(fileURLWithPath: RESSOURCES)
        tache.environment = environnementPropre()
        let entree = Pipe()
        tache.standardInput = entree
        var octets = [UInt8](repeating: 0, count: 32)
        _ = SecRandomCopyBytes(kSecRandomDefault, octets.count, &octets)
        let secret = octets.map { String(format: "%02x", $0) }.joined()
        let sortie = Pipe()
        tache.standardOutput = sortie
        tache.standardError = sortie
        var tampon = Data()
        var trouve = false
        // La sortie est lue sans fin (un tube plein bloquerait le serveur) et gardée dans le journal
        // (~/Library/Logs/KinéAPP/serveur.log) ; le port est pris dans la ligne
        // « interface sur http://127.0.0.1:PORT ».
        sortie.fileHandleForReading.readabilityHandler = { [weak self] h in
            let d = h.availableData
            if d.isEmpty { h.readabilityHandler = nil; return }
            self?.journal.ecrire(d)
            guard !trouve, tampon.count < 65_536 else { return }
            tampon.append(d)
            guard let texte = String(data: tampon, encoding: .utf8),
                  let r = texte.range(of: #"interface sur http://127\.0\.0\.1:\d+"#, options: .regularExpression),
                  let port = Int(texte[r].split(separator: ":").last ?? "") else { return }
            trouve = true
            DispatchQueue.main.async { if self?.serveur === tache { self?.serveurPret(port) } }
        }
        tache.terminationHandler = { [weak self] fini in
            DispatchQueue.main.async { self?.serveurArrete(fini) }
        }
        do { try tache.run() } catch {
            demarrageEnCours = false
            alerte("Le serveur n'a pas démarré.", error.localizedDescription)
            return
        }
        entree.fileHandleForWriting.write(Data((secret + "\n").utf8))
        try? entree.fileHandleForWriting.close()
        secretServeur = secret
        serveur = tache
    }

    private func serveurPret(_ port: Int) {
        demarrageEnCours = false
        portServeur = port
        if !secretServeur.isEmpty { memoriserSecretServeur(secretServeur, port: port) }
        DispatchQueue.global(qos: .userInitiated).async {
            for _ in 0..<60 {
                if self.repond(port) { break }
                Thread.sleep(forTimeInterval: 0.25)
            }
            DispatchQueue.main.async { self.charger() }
        }
    }

    /// Serveur arrêté (bouton « Arrêter le serveur », plantage, ou processus tué) : la page est
    /// vidée aussitôt — un autre programme pourrait reprendre ce port — et rien n'est rechargé
    /// d'ici tant qu'un nouveau serveur n'a pas annoncé le sien.
    private func serveurArrete(_ fini: Process) {
        guard serveur === fini else { return }
        serveur = nil
        portServeur = nil
        demarrageEnCours = false
        let message = miseAJourEnCours ? "Mise à jour en cours…"
            : "Serveur arrêté. Choisissez Fenêtre → Actualiser pour le relancer."
        vue?.loadHTMLString("<html><body style='font:14px -apple-system;color:#888;padding:60px'>"
                            + message + "</body></html>", baseURL: nil)
    }

    /// La page s'ouvre avec un code d'entrée à usage unique, demandé par le canal de la fenêtre ; le
    /// serveur l'échange contre le cookie de session (seule la fenêtre peut ainsi lire les bilans).
    private func charger() {
        guard let port = portServeur else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            let code = self.requeteJSON(adresseURL(port, "api/fenetre/entree"), [String: Any](), delai: 5, fenetre: true)?["code"] as? String
            DispatchQueue.main.async {
                guard self.portServeur == port, let code,
                      let url = URL(string: adresse(port) + "?entree=" + code) else { return }
                self.vue.load(URLRequest(url: url))
            }
        }
    }

    private func alerte(_ titre: String, _ detail: String) {
        let a = NSAlert()
        a.messageText = titre
        a.informativeText = detail
        a.alertStyle = .warning
        a.runModal()
    }

    // MARK: cycle de vie

    func applicationDidFinishLaunching(_ notification: Notification) {
        construireMenu()

        fenetre = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 1180, height: 780),
            styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView],
            backing: .buffered, defer: false)
        fenetre.title = "KinéAPP"
        fenetre.isReleasedWhenClosed = false          // l'objet reste valide après la fermeture
        fenetre.titleVisibility = .hidden
        fenetre.titlebarAppearsTransparent = true
        fenetre.minSize = NSSize(width: 900, height: 600)
        fenetre.setFrameAutosaveName("BilanKineFenetre")
        fenetre.center()

        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()            // ni cache ni stockage sur le disque
        config.userContentController.addScriptMessageHandler(self, contentWorld: .page, name: "coffre")
        vue = WKWebView(frame: .zero, configuration: config)
        vue.navigationDelegate = self
        vue.uiDelegate = self
        if #available(macOS 13.3, *) { vue.isInspectable = false }
        vue.autoresizingMask = [.width, .height]
        vue.setValue(false, forKey: "drawsBackground")

        let racine = NSView(frame: fenetre.contentLayoutRect)
        racine.autoresizingMask = [.width, .height]
        vue.frame = racine.bounds
        racine.addSubview(vue)

        // poignée de déplacement : bande haute de 46 px, ancrée en haut
        let hauteurBarre: CGFloat = 46
        let poignee = PoigneeFenetre(frame: NSRect(x: 0, y: racine.bounds.height - hauteurBarre,
                                                   width: racine.bounds.width, height: hauteurBarre))
        poignee.autoresizingMask = [.width, .minYMargin]
        racine.addSubview(poignee, positioned: .above, relativeTo: vue)
        self.poignee = poignee

        fenetre.contentView = racine
        majVoile()                                    // coffre installé : rien n'est visible avant le déverrouillage
        fenetre.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)

        demarrerServeur()
        if portCoffre() != nil {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { self.deverrouiller(demande: true) }
            // Touch ID activé : coffre verrouillé à la mise en veille et au verrouillage de l'écran.
            let ws = NSWorkspace.shared.notificationCenter
            let dn = DistributedNotificationCenter.default()
            ws.addObserver(self, selector: #selector(miseEnVeille(_:)), name: NSWorkspace.willSleepNotification, object: nil)
            dn.addObserver(self, selector: #selector(miseEnVeille(_:)), name: Notification.Name("com.apple.screenIsLocked"), object: nil)
        }
    }

    /// Au retour dans l'application, on relance le serveur s'il s'est arrêté.
    func applicationDidBecomeActive(_ notification: Notification) {
        guard vue != nil, serveur == nil, !demarrageEnCours, !miseAJourEnCours, portServeur == nil else { return }
        demarrerServeur()
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    /// Le coffre est verrouillé, puis le serveur doit mourir avec l'application. `terminate()`
    /// (SIGTERM) ne suffit pas toujours : on laisse un court instant, puis on insiste.
    func applicationWillTerminate(_ notification: Notification) {
        fermeture = true
        oublierSecretServeur()
        minuteurDictees?.invalidate()
        verrouillerCoffre(attendre: true)
        guard let tache = serveur, tache.isRunning else { return }
        tache.terminate()
        let echeance = Date().addingTimeInterval(1.5)
        while tache.isRunning && Date() < echeance { usleep(50_000) }
        if tache.isRunning { kill(tache.processIdentifier, SIGKILL) }
    }

    // MARK: navigation bornée

    private func estServeur(_ url: URL) -> Bool {
        url.scheme == "http" && url.host == "127.0.0.1" && portServeur != nil && url.port == portServeur
    }

    private func estCoffre(_ url: URL) -> Bool {
        guard let p = portCoffre() else { return false }
        return url.scheme == "http" && url.host == "127.0.0.1" && url.port == p
            && (url.path.hasPrefix("/ui/") || url.path.hasPrefix("/telechargement/"))
    }

    /// Port du coffre tenu par un programme de la session ? (vérifié au plus toutes les 30 s : un
    /// cadre par nom affiché, on ne relance pas lsof pour chacun)
    private func coffreDouteux() -> Bool {
        guard let p = portCoffre() else { return true }
        if let v = verifCoffre, Date().timeIntervalSince(v.quand) < 30 { return v.usurpe }
        let u = coffreUsurpe(port: p)
        verifCoffre = (Date(), u)
        return u
    }

    private func estLocal(_ url: URL) -> Bool {
        ["127.0.0.1", "localhost", "::1", "[::1]"].contains(url.host ?? "")
    }

    /// Lien externe : ouvert dans le navigateur, et seulement s'il vient d'un clic.
    private func ouvrirAuDehors(_ action: WKNavigationAction) {
        guard action.navigationType == .linkActivated, let url = action.request.url,
              ["http", "https"].contains(url.scheme ?? ""), !estLocal(url) else { return }
        NSWorkspace.shared.open(url)
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        let principal = action.targetFrame?.isMainFrame ?? true
        if url.scheme == "about" { decisionHandler(.allow); return }
        if estServeur(url) { decisionHandler(.allow); return }
        if estCoffre(url) && !principal { decisionHandler(coffreDouteux() ? .cancel : .allow); return }
        ouvrirAuDehors(action)
        decisionHandler(.cancel)
    }

    func webView(_ webView: WKWebView, decidePolicyFor reponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let url = reponse.response.url, estCoffre(url), url.path.hasPrefix("/telechargement/") {
            decisionHandler(.download)                    // document exporté par le coffre
            return
        }
        decisionHandler(reponse.canShowMIMEType ? .allow : .cancel)
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        reessayer()
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) {
        reessayer()
    }
    private func reessayer() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            guard let self, let p = self.portServeur, self.repond(p) else { return }
            self.charger()
        }
    }

    /// Processus d'affichage de WebKit tombé : la page est rechargée.
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { charger() }

    // MARK: export d'un document nominatif (coffre)

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let panneau = NSSavePanel()
        panneau.nameFieldStringValue = suggestedFilename
        panneau.canCreateDirectories = true
        panneau.message = "Document avec le nom du patient : enregistrez-le là où il doit aller, puis mettez-le à la Corbeille."
        panneau.beginSheetModal(for: fenetre) { r in
            guard r == .OK, let url = panneau.url else { completionHandler(nil); return }
            // Remplacement confirmé dans le panneau : l'ancien fichier part à la Corbeille (jamais effacé).
            if FileManager.default.fileExists(atPath: url.path) {
                try? FileManager.default.trashItem(at: url, resultingItemURL: nil)
            }
            completionHandler(url)
        }
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        alerte("Export impossible.", error.localizedDescription)
    }

    // MARK: dialogues de la page (sans eux, alert() ne montrait rien et confirm() répondait non)

    private func feuille(_ message: String, boutons: [String], accessoire: NSView? = nil,
                         fin: @escaping (NSApplication.ModalResponse) -> Void) {
        let a = NSAlert()
        let lignes = message.components(separatedBy: "\n")
        a.messageText = lignes.first ?? ""
        a.informativeText = lignes.dropFirst().joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
        for b in boutons { a.addButton(withTitle: b) }
        if let accessoire { a.accessoryView = accessoire; a.window.initialFirstResponder = accessoire }
        a.beginSheetModal(for: fenetre, completionHandler: fin)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        feuille(message, boutons: ["OK"]) { _ in completionHandler() }
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        feuille(message, boutons: ["OK", "Annuler"]) { r in completionHandler(r == .alertFirstButtonReturn) }
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        let champ = NSTextField(frame: NSRect(x: 0, y: 0, width: 280, height: 24))
        champ.stringValue = defaultText ?? ""
        feuille(prompt, boutons: ["OK", "Annuler"], accessoire: champ) { r in
            completionHandler(r == .alertFirstButtonReturn ? champ.stringValue : nil)
        }
    }

    /// Champ « fichier » de la page (photos des tests de force).
    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let panneau = NSOpenPanel()
        panneau.canChooseFiles = true
        panneau.canChooseDirectories = false
        panneau.allowsMultipleSelection = parameters.allowsMultipleSelection
        panneau.beginSheetModal(for: fenetre) { r in completionHandler(r == .OK ? panneau.urls : nil) }
    }

    /// target="_blank" : lien externe ouvert dans le navigateur, jamais de nouvelle fenêtre ici.
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        ouvrirAuDehors(action)
        return nil
    }

    // MARK: coffre d'identité

    /// Messages des pages : le jeton n'est remis qu'aux cadres du coffre (origine 127.0.0.1:port du
    /// coffre, jamais la page principale) ; la page clinique peut seulement demander d'ouvrir la
    /// fenêtre de déverrouillage ou de verrouiller.
    func userContentController(_ controleur: WKUserContentController, didReceive message: WKScriptMessage,
                               replyHandler: @escaping (Any?, String?) -> Void) {
        guard let corps = message.body as? [String: Any], let demande = corps["demande"] as? String else {
            replyHandler(nil, "demande invalide"); return
        }
        let o = message.frameInfo.securityOrigin
        let local = o.protocol == "http" && o.host == "127.0.0.1"
        let vport = portCoffre()
        let duCoffre = local && !message.frameInfo.isMainFrame && vport != nil && o.port == vport!
        let dePage = local && message.frameInfo.isMainFrame && portServeur != nil && o.port == portServeur!
        switch demande {
        case "jeton" where duCoffre:
            replyHandler(coffreDouteux() ? nil : jeton, nil)
            if jeton == nil { proposerDeverrouillage() }
        case "jeton-invalide" where duCoffre:            // session expirée côté coffre
            jeton = nil
            replyHandler(nil, nil)
            proposerDeverrouillage()
        case "deverrouiller" where duCoffre || dePage:
            replyHandler(nil, nil)
            deverrouiller(demande: true)
        case "verrouiller" where duCoffre || dePage:
            replyHandler(nil, nil)
            refusDeverrouillage = Date()             // verrouillé exprès : pas de fenêtre aussitôt
            sansCoffre = false
            verrouillerCoffre(attendre: false)
            majVoile()
        case "chiffrement-activer" where dePage:
            replyHandler(nil, nil)
            activerChiffrement()
        case "chiffrement-code" where dePage:
            replyHandler(nil, nil)
            montrerCodeDeSecours()
        case "dictees-verifier" where dePage:
            synchroniserDictees(manuel: true) { replyHandler($0, nil) }
        case "dictees-attribuer" where dePage:
            replyHandler(nil, nil)
            attribuerDictees()
        case "dictees-dossier" where dePage:
            replyHandler(nil, nil)
            ouvrirDossierDictees()
        case "touchid-etat" where dePage:
            etatTouchID { replyHandler($0, nil) }
        case "touchid-activer" where dePage:
            replyHandler(nil, nil)
            activerTouchID()
        case "touchid-desactiver" where dePage:
            replyHandler(nil, nil)
            desactiverTouchID()
        case "mettre-a-jour" where dePage, "revenir" where dePage:
            replyHandler(nil, nil)
            proposerMiseAJour(revenir: demande == "revenir")
        case "installer-moteurs" where dePage:
            replyHandler(nil, nil)
            proposerMoteurs()
        default:
            replyHandler(nil, "refusé")
        }
    }

    /// Demandes répétées des cadres (un par nom affiché) : une seule fenêtre, et pas de nouvelle
    /// insistance pendant une minute après « Annuler ».
    private func proposerDeverrouillage() {
        guard !feuilleOuverte, voile == nil, !sansCoffre, Date().timeIntervalSince(refusDeverrouillage) > 60 else { return }
        deverrouiller(demande: false)
    }

    @objc func deverrouillerMenu() { deverrouiller(demande: true) }
    @objc func verrouillerMenu() {
        refusDeverrouillage = Date()
        sansCoffre = false
        verrouillerCoffre(attendre: false)
        majVoile()
    }

    @objc func ouvrirSansCoffre() {
        sansCoffre = true
        majVoile()
    }

    @objc func revenirMenu() { proposerMiseAJour(revenir: true) }

    /// Version (version.json du code installé) et mention « bêta expérimentale ».
    @objc func aPropos() {
        var mention = "Version bêta expérimentale."
        if let d = FileManager.default.contents(atPath: RESSOURCES + "/version.json"),
           let v = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let m = v["mention"] as? String {
            mention = m
        }
        NSApp.orderFrontStandardAboutPanel(options: [.credits: NSAttributedString(string: mention,
            attributes: [.font: NSFont.systemFont(ofSize: 11), .foregroundColor: NSColor.secondaryLabelColor])])
    }

    /// Écran de verrouillage posé sur l'interface (cachée, pas déchargée : une séance en cours continue
    /// côté serveur). Coffre installé et non déverrouillé = rien de visible, sauf « sans coffre »
    /// choisi quand le coffre ne répond pas.
    func majVoile() {
        guard Thread.isMainThread else { DispatchQueue.main.async { self.majVoile() }; return }
        guard !fermeture, fenetre != nil, vue != nil else { return }
        if portCoffre() != nil && jeton == nil && !sansCoffre { montrerVoile(nil, secours: false) } else { retirerVoile() }
    }

    private func montrerVoile(_ message: String?, secours: Bool) {
        guard let racine = fenetre.contentView else { return }
        if voile == nil {
            let v = NSVisualEffectView(frame: racine.bounds)
            v.autoresizingMask = [.width, .height]
            v.material = .windowBackground
            v.blendingMode = .withinWindow
            v.state = .active
            let titre = NSTextField(labelWithString: "KinéAPP")
            titre.font = .systemFont(ofSize: 28, weight: .semibold)
            let texte = NSTextField(wrappingLabelWithString: "")
            texte.alignment = .center
            texte.textColor = .secondaryLabelColor
            let ouvrir = NSButton(title: "Déverrouiller", target: self, action: #selector(deverrouillerMenu))
            ouvrir.bezelStyle = .rounded
            ouvrir.keyEquivalent = "\r"
            let reessayer = NSButton(title: "Réessayer", target: self, action: #selector(deverrouillerMenu))
            reessayer.bezelStyle = .rounded
            let sans = NSButton(title: "Ouvrir sans le coffre", target: self, action: #selector(ouvrirSansCoffre))
            sans.bezelStyle = .rounded
            let pile = NSStackView(views: [titre, texte, ouvrir, reessayer, sans])
            pile.orientation = .vertical
            pile.alignment = .centerX
            pile.spacing = 14
            pile.translatesAutoresizingMaskIntoConstraints = false
            v.addSubview(pile)
            NSLayoutConstraint.activate([pile.centerXAnchor.constraint(equalTo: v.centerXAnchor),
                                         pile.centerYAnchor.constraint(equalTo: v.centerYAnchor),
                                         texte.widthAnchor.constraint(lessThanOrEqualToConstant: 440)])
            if let p = poignee { racine.addSubview(v, positioned: .below, relativeTo: p) } else { racine.addSubview(v) }
            voile = v
            voileTexte = texte
            voileBoutons = (ouvrir, reessayer, sans)
        }
        voileTexte?.stringValue = message ?? "Le coffre d'identité est verrouillé : l'app s'ouvre avec son mot de passe"
            + (cleTouchID() != nil ? " ou Touch ID." : ".")
        voileBoutons?.deverrouiller.title = cleTouchID() != nil ? "Déverrouiller avec Touch ID" : "Déverrouiller…"
        voileBoutons?.deverrouiller.isHidden = secours
        voileBoutons?.reessayer.isHidden = !secours
        voileBoutons?.sans.isHidden = !secours
        vue.isHidden = true
        fenetre.makeFirstResponder(nil)
    }

    private func retirerVoile() {
        voile?.removeFromSuperview()
        voile = nil
        voileTexte = nil
        voileBoutons = nil
        vue?.isHidden = false
    }

    private func demanderMotDePasse(_ erreur: String?) {
        guard let port = portCoffre() else {
            alerte("Coffre d'identité absent.", "Le coffre n'est pas installé sur ce Mac (outils/installer.sh).")
            return
        }
        guard !feuilleOuverte, fenetre != nil else { return }
        feuilleOuverte = true
        let a = NSAlert()
        a.messageText = "Déverrouiller le coffre d'identité"
        a.informativeText = erreur ?? "Le mot de passe du coffre affiche les noms des patients dans KinéAPP. "
            + "Il n'est enregistré nulle part ; le coffre se verrouille quand vous quittez l'app."
        if erreur != nil { a.alertStyle = .warning }
        let champ = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 260, height: 24))
        a.accessoryView = champ
        a.addButton(withTitle: "Déverrouiller")
        a.addButton(withTitle: "Annuler")
        a.window.initialFirstResponder = champ
        a.beginSheetModal(for: fenetre) { r in
            self.feuilleOuverte = false
            let mdp = champ.stringValue
            champ.stringValue = ""
            guard r == .alertFirstButtonReturn, !mdp.isEmpty else { self.refusDeverrouillage = Date(); return }
            self.ouvrirSession(port, mdp)
        }
    }

    /// Premier lancement après le paquet d'installation (pas de Terminal) : le praticien choisit ici le mot de
    /// passe du coffre. Le coffre ne l'accepte que s'il n'en a aucun et que l'installateur l'a permis.
    private func creerMotDePasseCoffre(_ port: Int, _ erreur: String?) {
        guard !feuilleOuverte, fenetre != nil else { return }
        feuilleOuverte = true
        let a = NSAlert()
        a.messageText = "Choisir le mot de passe du coffre d'identité"
        a.informativeText = erreur ?? ("Le coffre garde les noms de vos patients, séparés de leurs bilans. Choisissez un mot de "
            + "passe d'au moins 10 caractères et notez-le hors de ce Mac : sans lui, les noms des sauvegardes du coffre "
            + "sont irrécupérables. Il vous sera demandé à chaque ouverture de KinéAPP (Touch ID ensuite, si vous le voulez).")
        if erreur != nil { a.alertStyle = .warning }
        let un = NSSecureTextField(frame: NSRect(x: 0, y: 30, width: 280, height: 24))
        un.placeholderString = "Mot de passe"
        let deux = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 280, height: 24))
        deux.placeholderString = "Confirmez le mot de passe"
        let boite = NSView(frame: NSRect(x: 0, y: 0, width: 280, height: 54))
        boite.addSubview(un)
        boite.addSubview(deux)
        a.accessoryView = boite
        a.addButton(withTitle: "Créer")
        a.addButton(withTitle: "Plus tard")
        a.window.initialFirstResponder = un
        a.beginSheetModal(for: fenetre) { r in
            self.feuilleOuverte = false
            let m1 = un.stringValue, m2 = deux.stringValue
            un.stringValue = ""; deux.stringValue = ""
            guard r == .alertFirstButtonReturn else { self.refusDeverrouillage = Date(); return }
            if m1 != m2 { self.creerMotDePasseCoffre(port, "Les deux saisies sont différentes : recommencez."); return }
            if m1.count < 10 { self.creerMotDePasseCoffre(port, "Trop court : 10 caractères au moins."); return }
            guard !coffreUsurpe(port: port), let url = URL(string: adresse(port, "api/initialiser")) else {
                self.alerte("Mot de passe non envoyé.", "Le coffre ne répond pas normalement : redémarrez le Mac, puis rouvrez KinéAPP.")
                return
            }
            var requete = URLRequest(url: url)
            requete.httpMethod = "POST"
            requete.setValue("application/json", forHTTPHeaderField: "Content-Type")
            requete.httpBody = try? JSONSerialization.data(withJSONObject: ["mot_de_passe": m1])
            requete.timeoutInterval = 30
            self.session.dataTask(with: requete) { donnees, reponse, _ in
                let code = (reponse as? HTTPURLResponse)?.statusCode ?? 0
                let json = donnees.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
                DispatchQueue.main.async {
                    if code == 200, let j = json?["jeton"] as? String {
                        self.jeton = j
                        self.coffreChange()
                        self.apresDeverrouillage()
                    } else {
                        self.creerMotDePasseCoffre(port, (json?["erreur"] as? String) ?? "Le coffre ne répond pas.")
                    }
                }
            }.resume()
        }
    }

    private func ouvrirSession(_ port: Int, _ motDePasse: String) {
        guard !coffreUsurpe(port: port) else {
            alerte("Mot de passe non envoyé.", "Un programme de votre session écoute sur le port du coffre "
                   + "(\(port)) à la place du vrai coffre. Redémarrez le Mac ; si cela se reproduit, ne "
                   + "déverrouillez pas et relancez l'installation.")
            return
        }
        guard let url = URL(string: adresse(port, "api/session")) else { return }
        var requete = URLRequest(url: url)
        requete.httpMethod = "POST"
        requete.setValue("application/json", forHTTPHeaderField: "Content-Type")
        requete.httpBody = try? JSONSerialization.data(withJSONObject: ["mot_de_passe": motDePasse])
        requete.timeoutInterval = 30
        session.dataTask(with: requete) { donnees, reponse, _ in
            let code = (reponse as? HTTPURLResponse)?.statusCode ?? 0
            let json = donnees.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
            DispatchQueue.main.async {
                if code == 200, let j = json?["jeton"] as? String {
                    self.jeton = j
                    self.coffreChange()
                    self.apresDeverrouillage()
                } else {
                    self.demanderMotDePasse((json?["erreur"] as? String) ?? "Le coffre ne répond pas.")
                }
            }
        }.resume()
    }

    private func verrouillerCoffre(attendre: Bool) {
        dicteesAAttribuer = []                       // noms tapés sur l'iPhone : oubliés au verrouillage
        guard let j = jeton, let port = portCoffre(), let url = URL(string: adresse(port, "api/verrouiller")) else { return }
        jeton = nil
        var requete = URLRequest(url: url)
        requete.httpMethod = "POST"
        requete.setValue("application/json", forHTTPHeaderField: "Content-Type")
        requete.setValue(j, forHTTPHeaderField: "X-Jeton")
        requete.httpBody = Data("{}".utf8)
        requete.timeoutInterval = 2
        let fini = DispatchSemaphore(value: 0)
        session.dataTask(with: requete) { _, _, _ in fini.signal() }.resume()
        if attendre { _ = fini.wait(timeout: .now() + 1.5) }
        coffreChange()
    }

    // MARK: Touch ID

    func touchIDDisponible() -> Bool {
        var e: NSError?
        return SecureEnclave.isAvailable && LAContext().canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &e)
    }

    private func controleTouchID() -> SecAccessControl? {
        SecAccessControlCreateWithFlags(nil, kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
                                        [.privateKeyUsage, .biometryCurrentSet], nil)
    }

    private func cleTouchID() -> Data? { FileManager.default.contents(atPath: FICHIER_TOUCHID) }

    private func oublierTouchID() { try? FileManager.default.removeItem(atPath: FICHIER_TOUCHID) }

    private func touchIDChange() {
        vue?.evaluateJavaScript("window.touchIdChange && window.touchIdChange()", completionHandler: nil)
    }

    /// L'empreinte autorise la puce à signer `message` ; réponse sur un fil quelconque.
    private func signerTouchID(_ blob: Data, _ message: Data, raison: String, fin: @escaping (IssueTouchID) -> Void) {
        guard let ac = controleTouchID() else { fin(.echec("contrôle d'accès indisponible")); return }
        let ctx = LAContext()
        ctx.localizedFallbackTitle = "Mot de passe"
        ctx.localizedCancelTitle = "Annuler"
        ctx.evaluateAccessControl(ac, operation: .useKeySign, localizedReason: raison) { ok, erreur in
            guard ok else {
                switch (erreur as? LAError)?.code {
                case .userFallback?: fin(.motDePasse)
                case .userCancel?, .appCancel?, .systemCancel?: fin(.annule)
                case .biometryLockout?: fin(.echec("Touch ID est bloqué après trop d'essais."))
                default: fin(.echec(erreur?.localizedDescription ?? "échec"))
                }
                return
            }
            do {
                let cle = try SecureEnclave.P256.Signing.PrivateKey(dataRepresentation: blob, authenticationContext: ctx)
                fin(.signature(try cle.signature(for: message).derRepresentation))
            } catch {
                fin(.cleInvalide)                     // empreintes changées : la puce a invalidé la clé
            }
        }
    }

    /// Déverrouillage : Touch ID s'il est activé et prêt, sinon le mot de passe. `demande` : on vient
    /// de cliquer dans KinéAPP (lancement, menu, bouton) ; sinon (un cadre réclame un nom, retour de
    /// veille), une fenêtre de KinéAPP s'affiche d'abord : l'empreinte n'est jamais demandée sans clic.
    func deverrouiller(demande: Bool) {
        guard let port = portCoffre() else { demanderMotDePasse(nil); return }      // « coffre absent »
        guard !feuilleOuverte, !touchIDEnCours, fenetre != nil, jeton == nil else { return }
        touchIDEnCours = true
        DispatchQueue.global(qos: .userInitiated).async {
            let reponse = self.requeteJSON(adresseURL(port, "api/sante"), nil, delai: 3)
            DispatchQueue.main.async {
                self.touchIDEnCours = false
                guard let sante = reponse, sante["ok"] as? Bool == true else {
                    // Coffre injoignable (un programme de la session ne peut pas provoquer cela : le port
                    // est tenu par le système). L'app peut s'ouvrir sans les noms, pour ne pas bloquer
                    // une séance.
                    if self.voile != nil {
                        self.montrerVoile("Le coffre d'identité ne répond pas. Réessayez dans un instant. S'il ne "
                                          + "répond toujours pas, ouvrez l'app sans le coffre (les noms resteront masqués), "
                                          + "puis Paramètres → Signaler un problème.", secours: true)
                    } else {
                        self.alerte("Le coffre d'identité ne répond pas.", "Réessayez dans un instant.")
                    }
                    return
                }
                if self.voile != nil { self.montrerVoile(nil, secours: false) }
                if sante["mot_de_passe_defini"] as? Bool == false && sante["initialisation_ouverte"] as? Bool == true {
                    self.creerMotDePasseCoffre(port, nil); return         // installé par le paquet : premier lancement
                }
                if sante["touchid"] as? Bool == false { self.oublierTouchID() }     // désactivé (mot de passe changé)
                guard self.cleTouchID() != nil, self.touchIDDisponible(), sante["touchid"] as? Bool == true else {
                    self.demanderMotDePasse(nil); return
                }
                guard sante["touchid_pret"] as? Bool == true else {
                    self.demanderMotDePasse("Mot de passe requis : le Mac a redémarré, l'app a été mise à jour, ou la "
                                            + "dernière saisie date de plus de 7 jours. Touch ID reprendra ensuite.")
                    return
                }
                if demande { self.ouvrirSessionTouchID(port) } else { self.proposerTouchID(port) }
            }
        }
    }

    private func proposerTouchID(_ port: Int) {
        guard !feuilleOuverte else { return }
        feuilleOuverte = true
        let a = NSAlert()
        a.messageText = "Déverrouiller le coffre d'identité"
        a.informativeText = "Par Touch ID, ou par le mot de passe du coffre."
        a.addButton(withTitle: "Touch ID")
        a.addButton(withTitle: "Mot de passe…")
        a.addButton(withTitle: "Annuler").keyEquivalent = "\u{1b}"
        a.beginSheetModal(for: fenetre) { r in
            self.feuilleOuverte = false
            switch r {
            case .alertFirstButtonReturn: self.ouvrirSessionTouchID(port)
            case .alertSecondButtonReturn: self.demanderMotDePasse(nil)
            default: self.refusDeverrouillage = Date()
            }
        }
    }

    private func ouvrirSessionTouchID(_ port: Int) {
        guard let blob = cleTouchID(), !touchIDEnCours else { return }
        touchIDEnCours = true
        func fin(_ action: @escaping () -> Void) {
            DispatchQueue.main.async { self.touchIDEnCours = false; action() }
        }
        DispatchQueue.global(qos: .userInitiated).async {
            guard !coffreUsurpe(port: port) else {
                fin { self.alerte("Touch ID non utilisé.", "Un programme de votre session écoute sur le port du coffre "
                                  + "(\(port)) à la place du vrai coffre. Redémarrez le Mac.") }
                return
            }
            let r = self.requeteJSON(adresseURL(port, "api/touchid/defi"), [String: Any](), delai: 10) ?? [:]
            guard let defi = r["defi"] as? String else {
                fin { self.demanderMotDePasse((r["erreur"] as? String) ?? "Le coffre ne répond pas.") }
                return
            }
            self.signerTouchID(blob, Data((PREFIXE_TOUCHID + defi).utf8), raison: "déverrouiller le coffre d'identité") { issue in
                switch issue {
                case .signature(let sig):
                    DispatchQueue.global(qos: .userInitiated).async {
                        let o = self.requeteJSON(adresseURL(port, "api/touchid/ouvrir"),
                                                 ["defi": defi, "signature": sig.base64EncodedString()], delai: 30) ?? [:]
                        fin {
                            if let j = o["jeton"] as? String {
                                self.jeton = j
                                self.coffreChange()
                                self.apresDeverrouillage()
                            } else {
                                self.demanderMotDePasse((o["erreur"] as? String) ?? "Le coffre ne répond pas.")
                            }
                        }
                    }
                case .annule: fin { self.refusDeverrouillage = Date() }
                case .motDePasse: fin { self.demanderMotDePasse(nil) }
                case .cleInvalide:
                    fin {
                        self.oublierTouchID()
                        self.demanderMotDePasse("Touch ID est désactivé pour le coffre : les empreintes du Mac ont changé. "
                                                + "Tapez le mot de passe, puis réactivez Touch ID dans Paramètres → Coffre d'identité.")
                    }
                case .echec(let m): fin { self.demanderMotDePasse("Touch ID : \(m) Tapez le mot de passe du coffre.") }
                }
            }
        }
    }

    /// Activation : mot de passe du coffre, puis empreinte (la clé créée dans la puce signe une preuve,
    /// vérifiée par le coffre avant d'enregistrer sa clé publique).
    func activerTouchID() {
        guard let port = portCoffre() else {
            alerte("Coffre d'identité absent.", "Le coffre n'est pas installé sur ce Mac (outils/installer.sh).")
            return
        }
        guard touchIDDisponible() else {
            alerte("Touch ID indisponible.", "Aucune empreinte n'est enregistrée sur ce Mac (Réglages Système → "
                   + "Touch ID et mot de passe), ou ce Mac n'a pas de capteur.")
            return
        }
        guard !feuilleOuverte, !touchIDEnCours, fenetre != nil else { return }
        feuilleOuverte = true
        let a = NSAlert()
        a.messageText = "Activer Touch ID pour le coffre"
        a.informativeText = "Tapez le mot de passe du coffre, puis posez le doigt sur le capteur.\n\nLe mot de passe "
            + "restera demandé après un redémarrage du Mac ou une mise à jour de l'app, et tous les 7 jours. Le coffre "
            + "se verrouillera à la mise en veille et au verrouillage de l'écran."
        let champ = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 260, height: 24))
        a.accessoryView = champ
        a.addButton(withTitle: "Continuer")
        a.addButton(withTitle: "Annuler")
        a.window.initialFirstResponder = champ
        a.beginSheetModal(for: fenetre) { r in
            self.feuilleOuverte = false
            let mdp = champ.stringValue
            champ.stringValue = ""
            guard r == .alertFirstButtonReturn, !mdp.isEmpty else { return }
            self.touchIDEnCours = true
            func fin(_ titre: String, _ detail: String) {
                DispatchQueue.main.async {
                    self.touchIDEnCours = false
                    if !titre.isEmpty { self.alerte(titre, detail) }
                    self.touchIDChange()
                }
            }
            DispatchQueue.global(qos: .userInitiated).async {
                guard !coffreUsurpe(port: port) else {
                    fin("Mot de passe non envoyé.", "Un programme de votre session écoute sur le port du coffre à la place "
                        + "du vrai coffre. Redémarrez le Mac.")
                    return
                }
                guard let ac = self.controleTouchID(),
                      let cle = try? SecureEnclave.P256.Signing.PrivateKey(accessControl: ac) else {
                    fin("Touch ID n'a pas été activé.", "La clé n'a pas pu être créée dans la puce de sécurité du Mac.")
                    return
                }
                self.signerTouchID(cle.dataRepresentation, Data((PREFIXE_TOUCHID + "activation").utf8),
                                   raison: "activer Touch ID pour le coffre d'identité") { issue in
                    guard case .signature(let preuve) = issue else {
                        if case .annule = issue { fin("", "") } else { fin("Touch ID n'a pas été activé.", "L'empreinte n'a pas été reconnue.") }
                        return
                    }
                    DispatchQueue.global(qos: .userInitiated).async {
                        let o = self.requeteJSON(adresseURL(port, "api/touchid/activer"),
                                                 ["mot_de_passe": mdp, "cle": cle.publicKey.derRepresentation.base64EncodedString(),
                                                  "preuve": preuve.base64EncodedString()], delai: 30) ?? [:]
                        guard o["ok"] as? Bool == true else {
                            fin("Touch ID n'a pas été activé.", (o["erreur"] as? String) ?? "Le coffre ne répond pas.")
                            return
                        }
                        let fm = FileManager.default
                        try? fm.createDirectory(atPath: (FICHIER_TOUCHID as NSString).deletingLastPathComponent,
                                                withIntermediateDirectories: true)
                        try? fm.removeItem(atPath: FICHIER_TOUCHID)
                        guard fm.createFile(atPath: FICHIER_TOUCHID, contents: cle.dataRepresentation,
                                            attributes: [.posixPermissions: 0o600]) else {
                            fin("Touch ID n'a pas été activé.", "La clé n'a pas pu être enregistrée.")
                            return
                        }
                        fin("Touch ID activé.", "Le coffre se déverrouille maintenant par votre empreinte. N'appuyez sur "
                            + "le capteur que juste après avoir cliqué dans KinéAPP, et si la demande vient de KinéAPP.")
                    }
                }
            }
        }
    }

    func desactiverTouchID() {
        guard let j = jeton, let port = portCoffre() else {
            alerte("Coffre verrouillé.", "Déverrouillez le coffre, puis désactivez Touch ID.")
            return
        }
        DispatchQueue.global(qos: .userInitiated).async {
            let o = self.requeteJSON(adresseURL(port, "api/touchid/desactiver"), [String: Any](), jeton: j, delai: 10) ?? [:]
            DispatchQueue.main.async {
                if o["ok"] as? Bool == true {
                    self.oublierTouchID()
                    self.alerte("Touch ID désactivé.", "Le coffre se déverrouille de nouveau par son mot de passe.")
                } else {
                    self.alerte("Touch ID n'a pas été désactivé.", (o["erreur"] as? String) ?? "Le coffre ne répond pas.")
                }
                self.touchIDChange()
            }
        }
    }

    private func etatTouchID(_ fin: @escaping ([String: Any]) -> Void) {
        let disponible = touchIDDisponible()
        guard let port = portCoffre() else { fin(["disponible": disponible, "active": false, "pret": false]); return }
        DispatchQueue.global(qos: .userInitiated).async {
            let s = self.requeteJSON(adresseURL(port, "api/sante"), nil, delai: 3) ?? [:]
            DispatchQueue.main.async {
                if s["touchid"] as? Bool == false { self.oublierTouchID() }
                let active = self.cleTouchID() != nil && s["touchid"] as? Bool == true
                fin(["disponible": disponible, "active": active, "pret": active && s["touchid_pret"] as? Bool == true])
            }
        }
    }

    /// Touch ID activé : le coffre (donc l'app) se verrouille à la mise en veille et au verrouillage
    /// de l'écran ; au retour, l'écran de verrouillage attend un clic (jamais l'empreinte d'office).
    @objc func miseEnVeille(_ n: Notification) {
        guard jeton != nil, cleTouchID() != nil else { return }
        refusDeverrouillage = Date()
        verrouillerCoffre(attendre: true)
    }

    // MARK: mises à jour

    /// Bouton de l'app : rien pendant une séance ou un traitement ; ce qui change est montré ; le
    /// mot de passe administrateur est demandé par macOS ; c'est la copie INSTALLÉE de
    /// l'installateur (code du système) qui prend le commit validé, le fait juger par ses
    /// garde-fous, l'installe et garde la version remplacée.
    func proposerMiseAJour(revenir: Bool) {
        guard !miseAJourEnCours, revenir || portServeur != nil else { return }
        let cport = portServeur ?? 0
        DispatchQueue.global(qos: .userInitiated).async {
            // Sans serveur (interface en panne), aucune séance ne peut être en cours : retour permis.
            let etat = cport == 0 ? [:] : (self.requeteJSON(adresseURL(cport, "api/state"), nil, delai: 5) ?? [:])
            let actifs: Set<String> = ["queued", "transcription", "extraction", "verification", "redaction"]
            let occupe = ((etat["recording"] as? [String: Any])?["active"] as? Bool) == true
                || (etat["jobs"] as? [[String: Any]] ?? []).contains { actifs.contains($0["phase"] as? String ?? "") }
            let maj = revenir ? [:] : (self.requeteJSON(adresseURL(cport, "api/mise-a-jour"), nil, delai: 30) ?? [:])
            DispatchQueue.main.async {
                if occupe {
                    self.alerte("Pas maintenant.", "Une séance ou un traitement de bilan est en cours : réessayez quand il sera terminé.")
                    return
                }
                if !revenir {
                    // Les mêmes conditions sont contrôlées par l'installateur ; ici, pour ne pas demander
                    // le mot de passe administrateur en vain.
                    if let e = maj["erreur"] as? String, !e.isEmpty {
                        self.alerte("Mise à jour impossible.", e); return
                    }
                    if (maj["en_attente"] as? [Any] ?? []).isEmpty {
                        self.alerte("Déjà à jour.", "La version installée est la plus récente."); return
                    }
                    if maj["canal"] as? String == "github" && maj["signee"] as? Bool != true {
                        self.alerte("Mise à jour refusée.", "La dernière version publiée n'est pas signée par l'éditeur de KinéAPP.")
                        return
                    }
                    if maj["propre"] as? Bool != true {
                        self.alerte("Pas encore prête.", "La nouvelle version a des modifications non enregistrées : "
                                    + "demandez à Claude de terminer son travail (commit)."); return
                    }
                    if maj["tests"] as? Bool != true {
                        self.alerte("Pas encore prête.", "Les tests automatiques n'ont pas été passés sur cette version : "
                                    + "demandez à Claude de les lancer."); return
                    }
                }
                let a = NSAlert()
                if revenir {
                    a.messageText = "Revenir à la version précédente ?"
                    a.informativeText = "La version actuelle est gardée de côté. Vos données ne changent pas. "
                        + "Le mot de passe administrateur du Mac vous sera demandé ; l'app redémarrera."
                    a.addButton(withTitle: "Revenir")
                } else {
                    let changements = (maj["en_attente"] as? [[String: Any]] ?? []).compactMap { $0["sujet"] as? String }
                    let sensibles = maj["sensibles"] as? [String] ?? []
                    a.messageText = "Installer la mise à jour \((maj["disponible"] as? String) ?? "") ?"
                    a.informativeText = changements.prefix(8).map { "• " + $0 }.joined(separator: "\n")
                        + (changements.count > 8 ? "\n…" : "")
                        + (sensibles.isEmpty ? "" : "\n\nTouche à : " + sensibles.joined(separator: ", ")
                           + " (vérifié par les garde-fous de confidentialité).")
                        + "\n\nLe mot de passe administrateur du Mac vous sera demandé. L'app redémarrera ensuite "
                        + "et le coffre se reverrouillera. La version actuelle est gardée."
                    a.addButton(withTitle: "Installer")
                }
                a.addButton(withTitle: "Annuler")
                a.beginSheetModal(for: self.fenetre) { r in
                    guard r == .alertFirstButtonReturn else { return }
                    if !revenir && maj["paquet"] as? Bool == true { self.telechargerPuisInstaller(cport) }
                    else { self.executerMiseAJour(revenir: revenir) }
                }
            }
        }
    }

    /// Version de moteur reçue par l'app (Paramètres → IA) : installée sans toucher au code de l'app.
    func proposerMoteurs() {
        guard !miseAJourEnCours, let cport = portServeur else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            let etat = self.requeteJSON(adresseURL(cport, "api/state"), nil, delai: 5) ?? [:]
            let actifs: Set<String> = ["queued", "transcription", "extraction", "verification", "redaction"]
            let occupe = ((etat["recording"] as? [String: Any])?["active"] as? Bool) == true
                || (etat["jobs"] as? [[String: Any]] ?? []).contains { actifs.contains($0["phase"] as? String ?? "") }
            DispatchQueue.main.async {
                if occupe {
                    self.alerte("Pas maintenant.", "Une séance ou un traitement de bilan est en cours : réessayez quand il sera terminé.")
                    return
                }
                let a = NSAlert()
                a.messageText = "Installer le moteur ?"
                a.informativeText = "La version choisie dans Paramètres → IA remplace l'actuelle, qui reste gardée pour y revenir. "
                    + "Le mot de passe administrateur du Mac vous sera demandé ; l'app redémarrera."
                a.addButton(withTitle: "Installer")
                a.addButton(withTitle: "Annuler")
                a.beginSheetModal(for: self.fenetre) { r in
                    if r == .alertFirstButtonReturn { self.executerMiseAJour(revenir: false, moteurs: true) }
                }
            }
        }
    }

    private func montrerProgression(_ texte: String) {
        let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 400, height: 100), styleMask: [.titled],
                         backing: .buffered, defer: false)
        let v = NSView(frame: NSRect(x: 0, y: 0, width: 400, height: 100))
        let roue = NSProgressIndicator(frame: NSRect(x: 22, y: 34, width: 32, height: 32))
        roue.style = .spinning
        roue.startAnimation(nil)
        let t = NSTextField(wrappingLabelWithString: texte)
        t.frame = NSRect(x: 70, y: 20, width: 310, height: 60)
        v.addSubview(roue)
        v.addSubview(t)
        w.contentView = v
        fenetre.beginSheet(w, completionHandler: nil)
        feuilleProgression = w
    }

    /// Mac installé par le paquet : la version publiée et signée est d'abord téléchargée (archive vérifiée par le
    /// serveur), puis l'installateur de l'app installée la vérifie de nouveau et l'installe.
    private func telechargerPuisInstaller(_ cport: Int) {
        montrerProgression("Téléchargement de la nouvelle version…")
        DispatchQueue.global(qos: .userInitiated).async {
            let r = self.requeteJSON(adresseURL(cport, "api/mise-a-jour/preparer"), [:], delai: 900) ?? [:]
            DispatchQueue.main.async {
                if let w = self.feuilleProgression { self.fenetre.endSheet(w); self.feuilleProgression = nil }
                guard r["ok"] as? Bool == true, let d = r["dossier"] as? String, !d.contains("'"),
                      FileManager.default.fileExists(atPath: d + "/manifeste.json") else {
                    self.alerte("Téléchargement impossible.", ((r["error"] as? String) ?? "Vérifiez la connexion à Internet.")
                                + "\n\nVotre version actuelle est intacte.")
                    return
                }
                self.executerMiseAJour(revenir: false, paquet: d)
            }
        }
    }

    private func executerMiseAJour(revenir: Bool, moteurs: Bool = false, paquet: String? = nil) {
        miseAJourEnCours = true
        verrouillerCoffre(attendre: true)
        montrerProgression(moteurs ? "Installation du moteur…" : revenir ? "Retour à la version précédente…"
                                   : "Mise à jour : vérifications, compilation, signature, installation (1 à 2 min)…")
        let tache = serveur
        DispatchQueue.global(qos: .userInitiated).async {
            // Le serveur s'arrête proprement (il ferme ses moteurs) avant que son code soit remplacé.
            if let t = tache, t.isRunning {
                t.terminate()
                let fin = Date().addingTimeInterval(5)
                while t.isRunning && Date() < fin { usleep(100_000) }
                if t.isRunning { kill(t.processIdentifier, SIGKILL) }
            }
            // Forme composée (é en un caractère), comme dans l'installateur (dossier comparé, de toute façon).
            let script = RESSOURCES.precomposedStringWithCanonicalMapping + "/outils/installer.sh"
            let commande = "'" + script + "' " + (moteurs ? "--moteurs-seuls" : revenir ? "--revenir" : "--mise-a-jour")
                + (paquet.map { " --paquet '" + $0 + "'" } ?? "")
                + " --depuis-app --utilisateur '" + NSUserName() + "' 2>&1"
            let echappe = commande.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"")
            let p = Process()
            p.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
            p.arguments = ["-e", "do shell script \"" + echappe + "\" with prompt \"KinéAPP installe sa mise à jour.\" "
                           + "with administrator privileges"]
            let tube = Pipe()
            p.standardOutput = tube
            p.standardError = tube
            var sortie = ""
            var code: Int32 = -1
            do {
                try p.run()
                let d = tube.fileHandleForReading.readDataToEndOfFile()
                p.waitUntilExit()
                sortie = String(data: d, encoding: .utf8) ?? ""
                code = p.terminationStatus
            } catch {
                sortie = error.localizedDescription
            }
            // osascript sépare les lignes par des retours chariot et préfixe l'erreur de sa position.
            sortie = sortie.replacingOccurrences(of: "\r", with: "\n")
                .replacingOccurrences(of: #"^\d+:\d+: execution error: "#, with: "", options: .regularExpression)
            // Compte rendu gardé pour Claude en cas d'échec (aucune donnée patient : sortie de l'installateur).
            try? FileManager.default.createDirectory(atPath: dossierKineAPP() + "/Diagnostics", withIntermediateDirectories: true)
            let horodatage = DateFormatter()
            horodatage.dateFormat = "yyyy-MM-dd_HH'h'mm"
            try? sortie.write(toFile: dossierKineAPP() + "/Diagnostics/mise-a-jour_\(horodatage.string(from: Date())).log",
                              atomically: true, encoding: .utf8)
            DispatchQueue.main.async {
                if let w = self.feuilleProgression { self.fenetre.endSheet(w); self.feuilleProgression = nil }
                let annule = sortie.contains("(-128)")
                if code == 0 && sortie.contains("== Terminé") {
                    self.relancer(moteurs ? "Moteur installé." : revenir ? "Version précédente remise en place." : "Mise à jour installée.")
                    return
                }
                self.miseAJourEnCours = false
                if code == 0 && sortie.contains("Déjà à jour") {
                    self.alerte("Déjà à jour.", "La version installée est la plus récente.")
                } else if !annule {
                    let fin = sortie.split(separator: "\n").suffix(12).joined(separator: "\n")
                    self.alerte("Rien n'a été installé.", "Votre version actuelle est intacte.\n\n" + fin
                                + "\n\nCompte rendu complet : dossier KinéAPP, sous-dossier Diagnostics.")
                }
                self.demarrerServeur()
            }
        }
    }

    /// Nouvelle version : l'app se relance (son code vient d'être remplacé).
    private func relancer(_ message: String) {
        let a = NSAlert()
        a.messageText = message
        a.informativeText = "KinéAPP redémarre."
        a.runModal()
        let cfg = NSWorkspace.OpenConfiguration()
        cfg.createsNewApplicationInstance = true
        NSWorkspace.shared.openApplication(at: Bundle.main.bundleURL, configuration: cfg) { _, _ in
            DispatchQueue.main.async { NSApp.terminate(nil) }
        }
    }

    // MARK: échanges avec le serveur et le coffre

    /// Coffre déverrouillé : travaux qui ont besoin du jeton.
    func apresDeverrouillage() {
        remettreCleDonnees()
        synchroniserDictees(manuel: false) { _ in }
        minuteurDictees?.invalidate()
        minuteurDictees = Timer.scheduledTimer(withTimeInterval: 120, repeats: true) { [weak self] _ in
            guard let self, self.jeton != nil else { return }
            self.synchroniserDictees(manuel: false) { _ in }
        }
    }

    /// Requête JSON synchrone (fil de travail, jamais le fil principal).
    private func requeteJSON(_ url: URL, _ corps: Any?, jeton: String? = nil, delai: TimeInterval = 60,
                             fenetre: Bool = false) -> [String: Any]? {
        var r = URLRequest(url: url)
        r.timeoutInterval = delai
        if fenetre || (url.port != nil && url.port == portServeur) { r.setValue(secretServeur, forHTTPHeaderField: "X-Fenetre") }
        if let corps {
            r.httpMethod = "POST"
            r.setValue("application/json", forHTTPHeaderField: "Content-Type")
            r.httpBody = try? JSONSerialization.data(withJSONObject: corps)
        }
        if let jeton { r.setValue(jeton, forHTTPHeaderField: "X-Jeton") }
        var resultat: [String: Any]?
        let fini = DispatchSemaphore(value: 0)
        session.dataTask(with: r) { d, _, _ in
            resultat = d.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
            fini.signal()
        }.resume()
        _ = fini.wait(timeout: .now() + delai + 5)
        return resultat
    }

    // MARK: chiffrement des données (clé gardée par le coffre)

    /// Clé des données : demandée au coffre (jeton) et remise au serveur par le canal réservé, en
    /// mémoire seulement. Sans chiffrement activé, le coffre n'en a pas : rien n'est remis.
    func remettreCleDonnees() {
        guard let j = jeton, let vport = portCoffre(), let cport = portServeur else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            guard let cle = self.requeteJSON(adresseURL(vport, "api/cle-donnees"), [String: Any](), jeton: j, delai: 10)?["cle"] as? String
            else { return }
            let r = self.requeteJSON(adresseURL(cport, "api/fenetre/cle"), ["cle": cle], delai: 30, fenetre: true) ?? [:]
            if r["nouvelle"] as? Bool == true {
                // Données illisibles jusqu'ici (lancement) : la page est relue avec la clé.
                DispatchQueue.main.async { self.vue?.reload() }
            }
        }
    }

    /// Code de secours : la clé en base 32, par groupes de 4 (comme outils/dechiffrer_secours.py).
    func codeDeSecours(_ cle: Data) -> String {
        let alphabet = Array("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567")
        var bits = 0, valeur = 0, sortie = ""
        for octet in cle {
            valeur = (valeur << 8) | Int(octet); bits += 8
            while bits >= 5 { sortie.append(alphabet[(valeur >> (bits - 5)) & 31]); bits -= 5 }
        }
        if bits > 0 { sortie.append(alphabet[(valeur << (5 - bits)) & 31]) }
        return stride(from: 0, to: sortie.count, by: 4).map { i in
            String(sortie[sortie.index(sortie.startIndex, offsetBy: i)..<sortie.index(sortie.startIndex, offsetBy: min(i + 4, sortie.count))])
        }.joined(separator: "-")
    }

    private func alerteCode(_ titre: String, _ texte: String, _ code: String) {
        let a = NSAlert()
        a.messageText = titre
        a.informativeText = texte
        let champ = NSTextField(frame: NSRect(x: 0, y: 0, width: 420, height: 46))
        champ.stringValue = code
        champ.isEditable = false
        champ.isSelectable = true
        champ.font = NSFont.monospacedSystemFont(ofSize: 13, weight: .medium)
        a.accessoryView = champ
        a.addButton(withTitle: "Je l'ai noté")
        a.runModal()
    }

    func activerChiffrement() {
        guard let j = jeton, let vport = portCoffre(), let cport = portServeur else {
            alerte("Coffre verrouillé.", "Déverrouillez KinéAPP pour chiffrer les données."); return
        }
        let q = NSAlert()
        q.messageText = "Chiffrer toutes les données de KinéAPP ?"
        q.informativeText = "Bilans, transcriptions, comptes rendus, ordonnances, brouillons et fiches seront chiffrés sur le disque, "
            + "lisibles seulement dans KinéAPP déverrouillée. Un code de secours va s'afficher : notez-le hors de ce Mac. "
            + "Sans lui ni le coffre, les données seraient perdues."
        q.addButton(withTitle: "Chiffrer")
        q.addButton(withTitle: "Annuler")
        guard q.runModal() == .alertFirstButtonReturn else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            let c = self.requeteJSON(adresseURL(vport, "api/cle-donnees"), ["creer": true], jeton: j, delai: 10)?["cle"] as? String
            let r = c.flatMap { self.requeteJSON(adresseURL(cport, "api/fenetre/chiffrement/activer"), ["cle": $0], delai: 600, fenetre: true) } ?? [:]
            DispatchQueue.main.async {
                guard let c, let cle = Data(base64Encoded: c), r["ok"] as? Bool == true else {
                    self.alerte("Chiffrement non activé.", (r["error"] as? String) ?? "Le coffre ou le serveur n'a pas répondu."); return
                }
                self.alerteCode("Données chiffrées.",
                                "\(r["fichiers"] as? Int ?? 0) fichier(s) et \(r["documents"] as? Int ?? 0) fiche(s) chiffrés. "
                                + "Code de secours, à noter maintenant (papier ou gestionnaire de mots de passe) : il permet de tout "
                                + "déchiffrer sans l'app (dossier KinéAPP › Secours).", self.codeDeSecours(cle))
                self.vue?.reload()
            }
        }
    }

    func montrerCodeDeSecours() {
        guard let j = jeton, let vport = portCoffre() else {
            alerte("Coffre verrouillé.", "Déverrouillez KinéAPP pour afficher le code de secours."); return
        }
        let q = NSAlert()
        q.messageText = "Afficher le code de secours ?"
        q.informativeText = "Il permet de déchiffrer toutes les données. Vérifiez que personne ne regarde l'écran."
        q.addButton(withTitle: "Afficher")
        q.addButton(withTitle: "Annuler")
        guard q.runModal() == .alertFirstButtonReturn else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            let c = self.requeteJSON(adresseURL(vport, "api/cle-donnees"), [String: Any](), jeton: j, delai: 10)?["cle"] as? String
            DispatchQueue.main.async {
                guard let c, let cle = Data(base64Encoded: c) else {
                    self.alerte("Aucun code de secours.", "Le chiffrement n'est pas activé."); return
                }
                self.alerteCode("Code de secours", "À garder hors de ce Mac.", self.codeDeSecours(cle))
            }
        }
    }

    // MARK: dictées de l'iPhone (Raccourci → iCloud Drive)

    /// Lancement d'outils/dictees_icloud.py (Python isolé) ; sa sortie JSON est lue en mémoire.
    private func scriptDictees(_ args: [String], delai: TimeInterval = 120) -> [String: Any]? {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: PYTHON)
        p.arguments = ["-I", RESSOURCES + "/outils/dictees_icloud.py"] + args
        p.environment = environnementPropre()
        let tube = Pipe()
        p.standardOutput = tube
        p.standardError = FileHandle.nullDevice
        do { try p.run() } catch { return nil }
        let minuteur = DispatchWorkItem { if p.isRunning { p.terminate() } }
        DispatchQueue.global().asyncAfter(deadline: .now() + delai, execute: minuteur)
        let d = tube.fileHandleForReading.readDataToEndOfFile()
        p.waitUntilExit()
        minuteur.cancel()
        return try? JSONSerialization.jsonObject(with: d) as? [String: Any]
    }

    private func codeSeul(_ patient: String) -> String {
        guard let r = patient.range(of: #"P-[23456789BCDFGHJKMNPQRSTVWXZ]{6}"#, options: .regularExpression) else { return "" }
        return String(patient[r])
    }

    /// Une dictée attribuée : copie sous un nom neutre, original à la Corbeille, remise au serveur (code seul).
    /// originalReste : la copie est faite mais l'original n'a pas quitté iCloud (repris au passage suivant).
    private func remettreDictee(_ x: [String: Any], patient: String, audio: String, cport: Int) -> (remise: Bool, originalReste: Bool) {
        guard let fichier = x["fichier"] as? String, let id = x["id"] as? String,
              let r = scriptDictees(["--ingerer", fichier, "--vers", audio, "--id", id]), r["ok"] as? Bool == true else { return (false, false) }
        let reste = r["corbeille"] as? Bool != true && !recyclerOriginal(fichier)
        let o = requeteJSON(adresseURL(cport, "api/fenetre/dictees/recevoir"),
                            ["id": id, "patient": patient, "date": x["date"] ?? "", "heure": x["heure"] ?? "",
                             "type": x["type"] ?? "seance"],
                            delai: 15, fenetre: true) ?? [:]
        return (o["ok"] as? Bool == true, reste)
    }

    /// Original d'une dictée déjà reçue (ou écartée) : il doit quitter iCloud, sinon il revient à chaque passage.
    /// Outil de l'app (Corbeille, Corbeille de la session, sinon rangé hors d'iCloud sous un nom neutre), puis
    /// Corbeille du Finder. Vrai si l'original a quitté le dossier. Appelé hors du fil principal.
    private func retirerOriginal(_ x: [String: Any], audio: String) -> Bool {
        guard let fichier = x["fichier"] as? String else { return false }
        var args = ["--retirer", fichier]
        if let id = x["id"] as? String, !audio.isEmpty { args += ["--vers", audio, "--id", id] }
        if scriptDictees(args)?["ok"] as? Bool == true, !FileManager.default.fileExists(atPath: fichier) { return true }
        return recyclerOriginal(fichier)
    }

    /// Second essai par la Corbeille de macOS (celle du Finder) quand l'outil « trash » a échoué ;
    /// vrai si l'original a quitté le dossier. Appelé hors du fil principal.
    private func recyclerOriginal(_ fichier: String) -> Bool {
        let fin = DispatchSemaphore(value: 0)
        NSWorkspace.shared.recycle([URL(fileURLWithPath: fichier)]) { _, _ in fin.signal() }
        _ = fin.wait(timeout: .now() + 60)
        return !FileManager.default.fileExists(atPath: fichier)
    }

    /// Coffre déverrouillé, toutes les 2 minutes et sur demande : (1) transcriptions brutes du serveur
    /// pseudonymisées par le coffre, (2) dossier iCloud lu, chaque nom tapé confié au coffre (lecture
    /// seule), les dictées attribuées remises au serveur, les autres gardées « à attribuer ».
    func synchroniserDictees(manuel: Bool, fin: @escaping ([String: Any]) -> Void) {
        guard let j = jeton, let vport = portCoffre(), let cport = portServeur, !dicteesEnCours, !coffreDouteux() else {
            fin(["erreur": jeton == nil ? "Coffre verrouillé : déverrouillez-le d'abord." : "Vérification impossible pour l'instant."])
            return
        }
        dicteesEnCours = true
        let enAttente = dicteesAAttribuer
        DispatchQueue.global(qos: .utility).async {
            var resultat: [String: Any] = [:]
            var restantes: [[String: Any]] = []
            defer {
                DispatchQueue.main.async {
                    self.dicteesEnCours = false
                    self.dicteesAAttribuer = restantes
                    self.vue?.evaluateJavaScript("window.dicteesChange && window.dicteesChange()", completionHandler: nil)
                    fin(resultat)
                    if manuel && !restantes.isEmpty { self.attribuerDictees() }
                }
            }
            // 1. Noms prononcés : remplacés par les codes avant toute écriture par le serveur.
            if let t = self.requeteJSON(adresseURL(cport, "api/fenetre/dictees"), nil, delai: 15, fenetre: true),
               let textes = t["textes"] as? [[String: Any]], !textes.isEmpty {
                var pseudo: [String: String] = [:]
                for x in textes {
                    guard let id = x["id"] as? String, let texte = x["texte"] as? String else { continue }
                    let r = self.requeteJSON(adresseURL(vport, "api/pseudonymiser"),
                                             ["texte": texte, "soi": self.codeSeul(x["patient"] as? String ?? "")], jeton: j, delai: 60)
                    if let p = r?["texte"] as? String { pseudo[id] = p }
                }
                if !pseudo.isEmpty {
                    _ = self.requeteJSON(adresseURL(cport, "api/fenetre/dictees"), ["textes": pseudo], delai: 30, fenetre: true)
                }
            }
            // 2. Dossier iCloud.
            guard let e = self.requeteJSON(adresseURL(cport, "api/dictees"), nil, delai: 10),
                  e["actif"] as? Bool == true, let dossier = e["dossier"] as? String, let audio = e["audio"] as? String else {
                resultat = ["erreur": "Dictées de l'iPhone désactivées."]
                restantes = enAttente
                return
            }
            guard let l = self.scriptDictees(["--lister", dossier]) else {
                resultat = ["erreur": "Lecture du dossier des dictées impossible."]
                restantes = enAttente
                return
            }
            var recues = 0, originaux = 0
            let liste = l["dictees"] as? [[String: Any]] ?? []
            // Déjà reçues (original resté dans iCloud) : jamais reprises ni proposées « à attribuer » ; l'original
            // est retiré d'iCloud (banc du 11/11/2026 : dictées « à attribuer » sans fin, originaux jamais effacés).
            let connues = Set((self.requeteJSON(adresseURL(cport, "api/fenetre/dictees/connues"),
                                                ["ids": liste.compactMap { $0["id"] as? String }], delai: 10,
                                                fenetre: true)?["connues"] as? [String]) ?? [])
            for x in liste {
                if let id = x["id"] as? String, connues.contains(id) {
                    if !self.retirerOriginal(x, audio: audio) { originaux += 1 }
                    continue
                }
                let r = self.requeteJSON(adresseURL(vport, "api/dictees/resoudre"), ["nom_saisi": x["nom_saisi"] ?? ""], jeton: j, delai: 20) ?? [:]
                if r["statut"] as? String == "trouve", let patient = r["patient"] as? String {
                    let m = self.remettreDictee(x, patient: patient, audio: audio, cport: cport)
                    if m.remise { recues += 1 }
                    if m.originalReste { originaux += 1 }
                } else if r["statut"] != nil {
                    var y = x
                    y["statut"] = r["statut"]
                    y["candidats"] = r["candidats"] ?? []
                    restantes.append(y)
                } else {
                    restantes.append(x)                      // coffre muet : on réessaiera
                }
            }
            let erreur = l["erreur"] as? String ?? ""
            _ = self.requeteJSON(adresseURL(cport, "api/fenetre/dictees/etat"),
                                 ["a_attribuer": restantes.count, "en_attente_icloud": l["en_attente"] ?? 0,
                                  "originaux_restants": originaux, "erreur": erreur],
                                 delai: 10, fenetre: true)
            resultat = ["recues": recues, "a_attribuer": restantes.count, "en_attente_icloud": l["en_attente"] ?? 0,
                        "originaux_restants": originaux, "erreur": erreur]
        }
    }

    /// Dictées sans patient trouvé : le nom tapé est montré ICI seulement (fenêtre de l'app), avec les
    /// patients possibles du coffre ; créer une fiche demande une confirmation explicite.
    func attribuerDictees() {
        // Liste vide (fenêtre rouverte, coffre reverrouillé) alors que la page en annonce : on relit d'abord le
        // dossier ; coffre verrouillé : on le dit au lieu de ne rien faire.
        if jeton == nil {
            alerte("Coffre verrouillé.", "Déverrouillez le coffre d'identité, puis recommencez : il faut le nom des patients pour attribuer les dictées.")
            return
        }
        if dicteesAAttribuer.isEmpty {
            if !dicteesEnCours { synchroniserDictees(manuel: true) { _ in } }
            return
        }
        guard let x = dicteesAAttribuer.first, let j = jeton, let vport = portCoffre(), let cport = portServeur,
              !feuilleOuverte, fenetre != nil else { return }
        let nomSaisi = x["nom_saisi"] as? String ?? ""
        DispatchQueue.global(qos: .userInitiated).async {
            // Patients proposés : les homonymes, sinon ceux dont le nom contient un mot tapé.
            var options: [(code: String, patient: String, nom: String)] = []
            let candidats = (x["candidats"] as? [[String: Any]] ?? []).compactMap { c -> (String, String)? in
                guard let code = c["code"] as? String, let p = c["patient"] as? String else { return nil }
                return (code, p)
            }
            var liste = candidats
            if liste.isEmpty {
                let mot = nomSaisi.split(separator: " ").map(String.init).filter { $0.count >= 3 && !["mme", "mlle", "madame", "monsieur"].contains($0.lowercased()) }.first ?? ""
                if !mot.isEmpty, let q = mot.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                   let r = self.requeteJSON(adresseURL(vport, "api/recherche?q=" + q), nil, jeton: j, delai: 10) {
                    liste = (r["resultats"] as? [[String: Any]] ?? []).prefix(15).compactMap {
                        guard let c = $0["code"] as? String, let p = $0["patient"] as? String else { return nil }
                        return (c, p)
                    }
                }
            }
            if !liste.isEmpty, let q = liste.map({ $0.0 }).joined(separator: ",").addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
               let r = self.requeteJSON(adresseURL(vport, "api/noms?codes=" + q), nil, jeton: j, delai: 10),
               let noms = r["noms"] as? [String: String] {
                options = liste.map { ($0.0, $0.1, ($0.1.components(separatedBy: " ").first ?? "") + " " + (noms[$0.0] ?? "")) }
            }
            DispatchQueue.main.async {
                guard !self.feuilleOuverte else { return }
                self.feuilleOuverte = true
                let a = NSAlert()
                a.messageText = "Dictée de l'iPhone à attribuer"
                let statut = (x["statut"] as? String) == "ambigu" ? "plusieurs patients possibles" : "patient introuvable"
                let quoi = ["bilan": "Bilan initial", "reevaluation": "Réévaluation", "courrier": "Courrier"][x["type"] as? String ?? ""] ?? "Note de séance"
                a.informativeText = "\(quoi) du \(x["date"] as? String ?? "") \(x["heure"] as? String ?? "")\nNom tapé : « \(nomSaisi) » (\(statut)).\n\n"
                    + "Choisissez le patient, ou créez sa fiche s'il est nouveau."
                let choix = NSPopUpButton(frame: NSRect(x: 0, y: 0, width: 320, height: 26), pullsDown: false)
                for o in options { choix.addItem(withTitle: o.nom.trimmingCharacters(in: .whitespaces)) }
                choix.addItem(withTitle: "Créer la fiche « \(nomSaisi) »")
                a.accessoryView = choix
                a.addButton(withTitle: "Attribuer")
                a.addButton(withTitle: "Plus tard")
                a.addButton(withTitle: "Mettre à la Corbeille")
                a.beginSheetModal(for: self.fenetre) { r in
                    self.feuilleOuverte = false
                    let i = choix.indexOfSelectedItem
                    switch r {
                    case .alertFirstButtonReturn:
                        DispatchQueue.global(qos: .userInitiated).async {
                            var patient = ""
                            if i >= 0 && i < options.count {
                                patient = options[i].patient
                            } else if let c = self.requeteJSON(adresseURL(vport, "api/patients"), ["nom_saisi": nomSaisi], jeton: j, delai: 20),
                                      let p = c["patient"] as? String {
                                patient = p
                            }
                            let audio = (self.requeteJSON(adresseURL(cport, "api/dictees"), nil, delai: 10)?["audio"] as? String) ?? ""
                            let ok = !patient.isEmpty && !audio.isEmpty && self.remettreDictee(x, patient: patient, audio: audio, cport: cport).remise
                            DispatchQueue.main.async {
                                if ok {
                                    self.dicteesAAttribuer.removeAll { ($0["id"] as? String) == (x["id"] as? String) }
                                    self.vue?.evaluateJavaScript("window.dicteesChange && window.dicteesChange()", completionHandler: nil)
                                    if !self.dicteesAAttribuer.isEmpty { self.attribuerDictees() }
                                } else {
                                    self.alerte("Dictée non attribuée.", "La copie ou la remise de l'audio a échoué ; la dictée reste dans iCloud.")
                                }
                            }
                        }
                    case .alertThirdButtonReturn:
                        DispatchQueue.global(qos: .userInitiated).async {
                            let audio = (self.requeteJSON(adresseURL(cport, "api/dictees"), nil, delai: 10)?["audio"] as? String) ?? ""
                            let parti = self.retirerOriginal(x, audio: audio)
                            DispatchQueue.main.async {
                                self.dicteesAAttribuer.removeAll { ($0["id"] as? String) == (x["id"] as? String) }
                                self.vue?.evaluateJavaScript("window.dicteesChange && window.dicteesChange()", completionHandler: nil)
                                if !parti {
                                    self.alerte("Fichier resté dans iCloud.", "macOS a refusé de le déplacer. Ouvrez le dossier KinéAPP-Dictées dans le Finder et mettez-le à la Corbeille vous-même.")
                                } else if !self.dicteesAAttribuer.isEmpty {
                                    self.attribuerDictees()
                                }
                            }
                        }
                    default:
                        break
                    }
                }
            }
        }
    }

    /// Dossier iCloud des dictées ouvert dans le Finder (originaux que macOS refuse de déplacer).
    func ouvrirDossierDictees() {
        guard let cport = portServeur else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            let d = (self.requeteJSON(adresseURL(cport, "api/dictees"), nil, delai: 10)?["dossier"] as? String) ?? ""
            DispatchQueue.main.async {
                if !d.isEmpty, FileManager.default.fileExists(atPath: d) { NSWorkspace.shared.open(URL(fileURLWithPath: d)) }
                else { self.alerte("Dossier introuvable.", "Le dossier KinéAPP-Dictées n'existe pas dans iCloud Drive.") }
            }
        }
    }

    /// Les cadres du coffre se rechargent : déverrouillés, ils redemandent le jeton ; verrouillés,
    /// ils n'affichent plus que les codes.
    private func coffreChange() {
        vue?.evaluateJavaScript("window.coffreChange && window.coffreChange()", completionHandler: nil)
    }

    // MARK: menu

    private func construireMenu() {
        let barre = NSMenu()

        let appItem = NSMenuItem()
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "À propos de KinéAPP", action: #selector(aPropos), keyEquivalent: "")
        appMenu.addItem(.separator())
        // Recours si une mise à jour empêche d'ouvrir l'interface (mot de passe administrateur demandé).
        appMenu.addItem(withTitle: "Revenir à la version précédente…", action: #selector(revenirMenu), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Masquer KinéAPP",
                        action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(withTitle: "Quitter KinéAPP",
                        action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu
        barre.addItem(appItem)

        let editItem = NSMenuItem()
        let editMenu = NSMenu(title: "Édition")
        editMenu.addItem(withTitle: "Annuler", action: Selector(("undo:")), keyEquivalent: "z")
        editMenu.addItem(withTitle: "Rétablir", action: Selector(("redo:")), keyEquivalent: "Z")
        editMenu.addItem(.separator())
        editMenu.addItem(withTitle: "Couper", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "Copier", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "Coller", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "Tout sélectionner",
                         action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        editItem.submenu = editMenu
        barre.addItem(editItem)

        let coffreItem = NSMenuItem()
        let coffreMenu = NSMenu(title: "Coffre")
        coffreMenu.addItem(withTitle: "Déverrouiller le coffre…", action: #selector(deverrouillerMenu), keyEquivalent: "u")
        coffreMenu.addItem(withTitle: "Verrouiller le coffre", action: #selector(verrouillerMenu), keyEquivalent: "l")
        coffreItem.submenu = coffreMenu
        barre.addItem(coffreItem)

        let vueItem = NSMenuItem()
        let vueMenu = NSMenu(title: "Fenêtre")
        vueMenu.addItem(withTitle: "Actualiser", action: #selector(actualiser), keyEquivalent: "r")
        vueMenu.addItem(.separator())
        vueMenu.addItem(withTitle: "Réduire",
                        action: #selector(NSWindow.miniaturize(_:)), keyEquivalent: "m")
        vueMenu.addItem(withTitle: "Plein écran",
                        action: #selector(NSWindow.toggleFullScreen(_:)), keyEquivalent: "f")
        vueItem.submenu = vueMenu
        barre.addItem(vueItem)

        NSApp.mainMenu = barre
    }

    @objc private func actualiser() {
        if let p = portServeur, repond(p) { vue.reload() }
        else { portServeur = nil; demarrerServeur() }
    }
}

#if !ESSAI_UNITAIRE                    // tests/essai_fenetre.swift compile ce fichier sans lancer l'app
@main
enum Lanceur {
    static let delegue = Delegate()
    static func main() {
        let app = NSApplication.shared
        app.delegate = delegue
        app.setActivationPolicy(.regular)
        app.run()
    }
}
#endif
