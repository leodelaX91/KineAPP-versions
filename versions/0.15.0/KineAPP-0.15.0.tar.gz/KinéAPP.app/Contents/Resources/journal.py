# -*- coding: utf-8 -*-
"""Journal structuré et erreurs typées de KinéAPP.

Journal : une ligne JSON par événement dans ~/Library/Logs/KinéAPP/evenements.jsonl (600) :
date, niveau (info, attention, erreur), code (« modele_indisponible », « transcription_vide »…),
où (fonction et ligne), type d'erreur. Jamais de texte clinique ni de nom : les messages passent par
un filtre (un nom après une civilité est retiré, les codes « P-XXXXXX » restent). Gardé à 2 000
lignes. « Signaler un problème » en reprend les dernières.

Erreurs typées : chacune porte un code stable (pour le journal et les tests) et un message destiné
au praticien. Elles héritent des exceptions d'avant (RuntimeError, ValueError) : le code qui les
attrapait les attrape toujours.

Erreur tolérée : une opération accessoire (ménage d'un fichier temporaire, réglage d'un droit…)
peut échouer sans arrêter l'app ; `ignoree(e)` la note dans le journal au lieu de l'avaler sans
trace (140 « except Exception: pass » rendaient les vrais problèmes invisibles).
"""
import datetime, json, os, re, threading, time, traceback

CHEMIN = os.environ.get("KINEAPP_EVENEMENTS") or os.path.expanduser("~/Library/Logs/KinéAPP/evenements.jsonl")
MAX_LIGNES = 2000
_VERROU = threading.Lock()
NOM_APRES_CIVILITE = re.compile(r"\b(Mme|Mlle|Madame|Monsieur|Mademoiselle|M\.?)\s+(?!P-[23456789BCDFGHJKMNPQRSTVWXZ]{6})"
                                r"[A-ZÀ-Ý][\w'’-]+(?:\s+[A-ZÀ-Ý][\w'’-]+)?")


class ErreurKineAPP(Exception):
    code = "erreur"


class ErreurModele(ErreurKineAPP, RuntimeError):
    code = "modele_indisponible"


class ErreurTranscription(ErreurKineAPP, RuntimeError):
    code = "transcription"


class TranscriptionVide(ErreurTranscription):
    code = "transcription_vide"


class ReponseVide(ErreurModele):
    code = "reponse_vide"


class ErreurAudio(ErreurKineAPP, RuntimeError):
    code = "audio"


class ErreurExtraction(ErreurKineAPP, RuntimeError):
    code = "extraction"


class ExtractionIllisible(ErreurExtraction, ValueError):
    code = "extraction_illisible"


class Occupe(ErreurKineAPP, ValueError):
    code = "occupe"


class DonneeInvalide(ErreurKineAPP, ValueError):
    code = "donnee_invalide"


def filtrer(texte):
    """Rien de nominatif dans le journal : un nom après une civilité est retiré."""
    return NOM_APRES_CIVILITE.sub(lambda m: m.group(1) + " (nom retiré)", str(texte or ""))[:300]


def _ou(exc=None):
    pile = traceback.extract_tb(exc.__traceback__) if exc is not None and exc.__traceback__ else traceback.extract_stack()[:-2]
    for cadre in reversed(pile):
        if "journal.py" not in cadre.filename:
            return f"{os.path.basename(cadre.filename)}:{cadre.lineno} {cadre.name}"
    return ""


_DEJA = {}                                  # (niveau, code, où, type) -> dernière écriture
REPIT_S = {"attention": 600, "erreur": 60, "info": 0}


def evenement(niveau, code, message="", exc=None, **contexte):
    ligne = {"date": datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"), "niveau": niveau, "code": code,
             "ou": _ou(exc)}
    # Une boucle de surveillance qui échoue à chaque tour ne noie pas le journal : la même erreur,
    # au même endroit, n'est notée qu'une fois par répit (10 min pour une erreur tolérée).
    cle, t = (niveau, code, ligne["ou"], type(exc).__name__ if exc is not None else ""), time.monotonic()
    with _VERROU:
        if t - _DEJA.get(cle, -1e9) < REPIT_S.get(niveau, 0):
            return None
        _DEJA[cle] = t
    if message:
        ligne["message"] = filtrer(message)
    if exc is not None:
        ligne["type"] = type(exc).__name__
        ligne["detail"] = filtrer(exc)
    for k, v in contexte.items():
        ligne[k] = filtrer(v) if isinstance(v, str) else v
    try:
        os.makedirs(os.path.dirname(CHEMIN), exist_ok=True)
        with _VERROU:
            with open(os.open(CHEMIN, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600), "a", encoding="utf-8") as f:
                f.write(json.dumps(ligne, ensure_ascii=False) + "\n")
            if os.path.getsize(CHEMIN) > MAX_LIGNES * 400:
                lignes = open(CHEMIN, encoding="utf-8").read().splitlines()[-MAX_LIGNES:]
                with open(CHEMIN, "w", encoding="utf-8") as f:
                    f.write("\n".join(lignes) + "\n")
    except OSError:
        pass                                    # le journal ne doit jamais faire tomber l'app
    if niveau == "erreur":                      # aussi dans le journal du serveur (code et type seulement)
        print(f"[erreur] {code} · {ligne['ou']} · {ligne.get('type', '')}", flush=True)
    return ligne


def erreur(contexte, exc, code=None):
    """Erreur d'une tâche : code de l'erreur typée, sinon celui donné, sinon « erreur »."""
    return evenement("erreur", code or getattr(exc, "code", "erreur"), contexte, exc)


def ignoree(exc, contexte=""):
    """Erreur d'une opération accessoire, tolérée mais notée."""
    return evenement("attention", "erreur_toleree", contexte, exc)


def derniers(n=50):
    try:
        return [json.loads(l) for l in open(CHEMIN, encoding="utf-8").read().splitlines()[-n:] if l.strip()]
    except (OSError, ValueError):
        return []
