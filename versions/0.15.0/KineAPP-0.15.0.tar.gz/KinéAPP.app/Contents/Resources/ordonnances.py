# -*- coding: utf-8 -*-
"""Ordonnances de masseur-kinésithérapeute.

Références (vérifiées au Journal officiel le 16/09/2026)
  - Arrêté du 14 septembre 2026 fixant la liste des produits de santé que les
    masseurs-kinésithérapeutes sont autorisés à prescrire (JO du 16/09/2026), qui abroge
    l'arrêté du 9 janvier 2006. Prescription « dans le cadre de leurs compétences et sauf
    indication contraire du médecin », à l'exclusion des produits et matériels utilisés
    pendant la séance.
  - Code de la santé publique, art. R. 5132-3 : mentions de l'ordonnance (prescripteur,
    produit ou principe actif, posologie et mode d'emploi, durée ou nombre d'unités,
    renouvellements, identité du patient, signature sous la dernière ligne, date).
  - ameli.fr (masseur-kinésithérapeute) : mention « NR » devant un produit non remboursable,
    numéro d'identification du prescripteur.

La liste est reprise mot pour mot ; le numéro de chaque catégorie est celui de l'arrêté.
Aucun modèle de langage n'intervient : l'ordonnance est ce que le kinésithérapeute saisit.
"""
import datetime, html, json, os, re, uuid, zipfile

import base
DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
FICHES = os.path.join(DATA, "ordonnances")

REFERENCE = ("Arrêté du 14 septembre 2026 fixant la liste des produits de santé que les "
             "masseurs-kinésithérapeutes sont autorisés à prescrire (JO du 16 septembre 2026)")

# (numéro, libellé exact de l'arrêté, groupe, nature, contrainte)
#   nature : "dm" dispositif ou produit, "med" médicament
#   contrainte : None | "location" | "location_3_mois" | "location_ou_achat" | "renouvellement"
_LISTE = [
    (1, "Appareils destinés au soulèvement du malade : potences, soulève-malades, harnais (souple ou rigide)", "Aides techniques et maintien à domicile", "dm", None),
    (2, "Matelas d'aide à la prévention d'escarres en mousse de haute résilience type gaufrier", "Aides techniques et maintien à domicile", "dm", None),
    (3, "Matelas à air à la location", "Aides techniques et maintien à domicile", "dm", "location"),
    (4, "Coussin d'aide à la prévention des escarres en fibres siliconées ou en mousse monobloc", "Aides techniques et maintien à domicile", "dm", None),
    (5, "Barrières de lits et cerceaux", "Aides techniques et maintien à domicile", "dm", None),
    (6, "Aide à la déambulation : cannes, béquilles, déambulateur", "Aides techniques et maintien à domicile", "dm", None),
    (7, "Véhicules pour personnes handicapées (fauteuils roulants non-modulaires à propulsion manuelle ou à pousser, fauteuils roulants non-modulaires à assise rigide à propulsion manuelle ou à pousser, fauteuils roulants modulaires à propulsion manuelle ou à pousser, poussettes simples, fauteuils roulants électriques) pour une location pour des durées inférieures à 3 mois", "Aides techniques et maintien à domicile", "dm", "location_3_mois"),
    (8, "Lit médicalisé à la location", "Aides techniques et maintien à domicile", "dm", "location"),
    (9, "Barre latérale de redressement, verticalisateur, draps de glisse, planche de transfert, guidon de transfert (roulant et fixe), couverts adaptés, barres de douche, rehausseur de WC, barres de maintien, fauteuil de repos", "Aides techniques et maintien à domicile", "dm", None),
    (10, "Attelles souples, rigides et articulées de correction orthopédique de série", "Orthèses, attelles et contention", "dm", None),
    (11, "Attelles souples, rigides et articulées de posture et ou de repos de série", "Orthèses, attelles et contention", "dm", None),
    (12, "Sangles thoraciques ou abdominales", "Orthèses, attelles et contention", "dm", None),
    (13, "Ceintures de soutien lombaire de série et bandes ceintures de série", "Orthèses, attelles et contention", "dm", None),
    (14, "Collier cervical de repos de série", "Orthèses, attelles et contention", "dm", None),
    (15, "Outils de réhabilitation des mouvements mandibulaires", "Rééducation maxillo-faciale et ORL", "dm", None),
    (16, "Dispositifs de lavage de nez", "Rééducation maxillo-faciale et ORL", "dm", None),
    (17, "Outils de rééducation de la posture linguale et respiration nasale", "Rééducation maxillo-faciale et ORL", "dm", None),
    (18, "Orthèses moulées, rigides ou articulées, sur mesure ou non, de posture ou de fonction", "Orthèses, attelles et contention", "dm", None),
    (19, "Orthèses de correction progressive", "Orthèses, attelles et contention", "dm", None),
    (20, "Orthèses thermoformables de série ou sur mesure", "Orthèses, attelles et contention", "dm", None),
    (21, "Talonnettes avec évidement et amortissantes", "Orthèses, attelles et contention", "dm", None),
    (22, "Attelles souples sur mesure", "Orthèses, attelles et contention", "dm", None),
    (23, "Chaussures thérapeutiques de série à usage temporaire ou à usage prolongé", "Orthèses, attelles et contention", "dm", None),
    (24, "Manchons, bandes et orthèses bas, chaussettes, bas-cuisse et collants de contention souple élastique des membres de série", "Orthèses, attelles et contention", "dm", None),
    (25, "Bandes adhésives de contention souple et rigide de série", "Orthèses, attelles et contention", "dm", None),
    (26, "Sparadrap", "Pansements et soins de la peau", "dm", None),
    (27, "Boitier de neurostimulation électrique transcutanée (TENS) à la location", "Électrothérapie et rééducation périnéale", "dm", "location"),
    (28, "Appareil d'électrostimulation musculaire de type excitomoteur à la location", "Électrothérapie et rééducation périnéale", "dm", "location"),
    (29, "Boitier de stimulation pour électrostimulation dans le cadre de la rééducation périnéo-sphinctérienne pour incontinence à la location ou l'achat", "Électrothérapie et rééducation périnéale", "dm", "location_ou_achat"),
    (30, "Sonde périnéale, anorectale ou, électrode cutanée périnéale pour électrostimulation neuromusculaire pour le traitement de l'incontinence urinaire", "Électrothérapie et rééducation périnéale", "dm", None),
    (31, "Collecteurs d'urines, étuis péniens, pessaires, urinal", "Électrothérapie et rééducation périnéale", "dm", None),
    (32, "Pansements secs ou étanches pour immersion en balnéothérapie", "Pansements et soins de la peau", "dm", None),
    (33, "Pansements étanches", "Pansements et soins de la peau", "dm", None),
    (34, "Pansements hydrocolloïdes", "Pansements et soins de la peau", "dm", None),
    (35, "Arthromoteur à la location", "Physiothérapie", "dm", "location"),
    (36, "Cryothérapie gazeuse ou compresses cryothérapiques", "Physiothérapie", "dm", None),
    (37, "Compresses thermothérapiques et patchs chauffants", "Physiothérapie", "dm", None),
    (38, "Appareil de cryocompression à la location", "Physiothérapie", "dm", "location"),
    (39, "Matériel pour l'aide à l'auto-drainage, à l'auto-surveillance ou à l'auto-rééducation : débitmètre de pointe, dispositif mécanique de nettoyage et de restauration des voies respiratoires, spiromètre débitmétrique, relaxateur de pression", "Respiratoire et surveillance", "dm", None),
    (40, "Aérosols à visée d'humidification", "Respiratoire et surveillance", "dm", None),
    (41, "Chambre d'inhalation", "Respiratoire et surveillance", "dm", None),
    (42, "Aspirateur trachéal et sondes d'aspiration", "Respiratoire et surveillance", "dm", None),
    (43, "Oxymètre de pouls pour rééducation à l'effort", "Respiratoire et surveillance", "dm", None),
    (44, "Saturomètre", "Respiratoire et surveillance", "dm", None),
    (45, "Tensiomètre", "Respiratoire et surveillance", "dm", None),
    (46, "Préservatifs", "Divers", "dm", None),
    (47, "Embouts de cannes", "Aides techniques et maintien à domicile", "dm", None),
    (48, "Crèmes et pansements cicatrisantes", "Pansements et soins de la peau", "dm", None),
    (49, "Sérum physiologique isotonique en unidose", "Médicaments et produits", "med", None),
    (50, "Sérum salé hypertonique pour nébulisation dans le cadre d'un renouvellement de prescription", "Médicaments et produits", "med", "renouvellement"),
    (51, "Crème émolliente et hydratante à base de glycérine, paraffine et vaseline", "Pansements et soins de la peau", "dm", None),
    (52, "Crème ou gel hydratant et cicatrisant vaginaux", "Pansements et soins de la peau", "dm", None),
    (53, "Crème anesthésiante", "Médicaments et produits", "med", None),
    (54, "Substituts nicotiniques", "Médicaments et produits", "med", None),
    (55, "Mucolytiques", "Médicaments et produits", "med", None),
    (56, "Antiseptiques locaux hors produits à composés iodés", "Médicaments et produits", "med", None),
    (57, "Myorelaxants à l'exclusion des formes injectables", "Médicaments et produits", "med", None),
    (58, "Antalgiques de palier 1 selon la classification de l'OMS, à l'exclusion des formes injectables", "Médicaments et produits", "med", None),
]
CATALOGUE = [{"num": n, "libelle": l, "groupe": g, "nature": t, "contrainte": c} for n, l, g, t, c in _LISTE]
# Aide-mémoire clinique (indications, contre-indications, précautions) : fichier séparé, jamais imprimé
# sur l'ordonnance. Il ne remplace ni la notice ni le résumé des caractéristiques du produit.
try:
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "ordonnances_infos.json"), encoding="utf-8") as _f:
        _INFOS = json.load(_f)
except Exception:
    _INFOS = {"avertissement": "", "fiches": {}}
INFOS, AVERTISSEMENT_INFOS = _INFOS["fiches"], _INFOS["avertissement"]
PAR_NUM = {c["num"]: c for c in CATALOGUE}
GROUPES = ["Aides techniques et maintien à domicile", "Orthèses, attelles et contention",
           "Pansements et soins de la peau", "Physiothérapie", "Électrothérapie et rééducation périnéale",
           "Respiratoire et surveillance", "Rééducation maxillo-faciale et ORL", "Médicaments et produits", "Divers"]
DE_SERIE = {10, 11, 13, 14, 23, 24, 25}          # « de série » : pas de sur-mesure

OPIOIDES = r"cod[ée]ine|tramadol|opium|morphin|oxycod|tapentadol|bupr[ée]norphin|fentanyl|nalbuphin|hydromorphon|m[ée]thadon|p[ée]thidin|dihydrocod"
INJECTABLE = r"inject|\bIM\b|\bIV\b|\bSC\b|intramusc|intraveine|sous[- ]cutan|seringue|perfusion"
IODES = r"iod|povidone|b[ée]tadine"


# ── utilitaires ──────────────────────────────────────────────────────────────
def _v(x):
    return " ".join(str(x or "").split())


CODE_SEUL = re.compile(r"^P-[23456789BCDFGHJKMNPQRSTVWXZ]{6}$")


def code_patient(pat):
    """Mode coffre : le « nom » est le code du patient ; nom, prénom et date de naissance vivent
    dans le coffre, qui les écrit dans le document seulement à l'export."""
    n = _v((pat or {}).get("nom"))
    return n if CODE_SEUL.match(n) else None


def telephone_international(t):
    """R. 5132-3 : coordonnées téléphoniques précédées de l'indicatif +33."""
    chiffres = re.sub(r"\D", "", t or "")
    if chiffres.startswith("33"):
        chiffres = chiffres[2:]
    chiffres = chiffres.lstrip("0")
    if len(chiffres) != 9:
        return _v(t)
    return "+33 " + chiffres[0] + " " + " ".join(chiffres[i:i + 2] for i in range(1, 9, 2))


def ville(adresse):
    m = re.search(r"\b\d{5}\s+(.+)$", adresse or "")
    return m.group(1).strip(" ,.") if m else ""


def _date(s):
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.datetime.strptime(_v(s), fmt).date()
        except ValueError:
            pass
    return None


def age(naissance, le=None):
    d = _date(naissance)
    if not d:
        return None
    le = le or datetime.date.today()
    return le.year - d.year - ((le.month, le.day) < (d.month, d.day))


def duree_jours(texte):
    """« 4 semaines » -> 28 ; « 2 mois » -> 60 ; « 45 jours » -> 45 ; None si illisible."""
    m = re.search(r"(\d+(?:[.,]\d+)?)\s*(j|jour|jours|sem|semaine|semaines|mois)\b", (texte or "").lower())
    if not m:
        return None
    n = float(m.group(1).replace(",", "."))
    unite = m.group(2)
    return n * (1 if unite.startswith("j") else 7 if unite.startswith("sem") else 30)


# ── prescripteur ─────────────────────────────────────────────────────────────
def lignes_prescripteur(p):
    p = {k: _v(v) for k, v in (p or {}).items()}
    out = []
    if p.get("nom"):
        out.append(" ".join(filter(None, (p.get("nom"), p.get("titre")))))
    if p.get("profession"):
        out.append(p["profession"])
    ids = [x for x in (p.get("rpps") and f"RPPS : {p['rpps']}",
                       p.get("numero_am") and f"N° Assurance Maladie : {p['numero_am']}") if x]
    if ids:
        out.append(" — ".join(ids))
    if p.get("cabinet"):
        out.append(p["cabinet"])
    if p.get("adresse"):
        out.append(p["adresse"] + ("" if p["adresse"].lower().endswith("france") else ", France"))
    contact = [x for x in (p.get("telephone") and "Tél. " + telephone_international(p["telephone"]),
                           p.get("email")) if x]
    if contact:
        out.append(" — ".join(contact))
    return out


# ── lignes ───────────────────────────────────────────────────────────────────
def texte_ligne(l):
    """Rédaction d'une ligne telle qu'imprimée."""
    c = PAR_NUM.get(int(l.get("num") or 0), {})
    tete = ("NR " if l.get("nr") else "")
    if c.get("nature") == "med":
        tete += " ".join(filter(None, (_v(l.get("dci")), _v(l.get("dosage")))))
        if _v(l.get("marque")):
            tete += f" ({_v(l['marque'])})"
    else:
        tete += _v(l.get("designation"))
    details = []
    if c.get("contrainte") in ("location", "location_3_mois"):
        details.append(f"En location, durée : {_v(l.get('duree_location'))}")
    elif c.get("contrainte") == "location_ou_achat":
        details.append("À l'achat" if l.get("mode") == "achat"
                       else f"En location, durée : {_v(l.get('duree_location'))}")
    if _v(l.get("quantite")):
        details.append(f"Quantité : {_v(l['quantite'])}")
    if _v(l.get("posologie")):
        details.append(f"Posologie : {_v(l['posologie'])}")
    if _v(l.get("duree")):
        details.append(f"Durée du traitement : {_v(l['duree'])}")
    if c.get("nature") == "med" or _v(l.get("renouvellements")) not in ("", "0"):
        r = _v(l.get("renouvellements")) or "0"
        details.append("Non renouvelable" if r == "0" else f"À renouveler {r} fois")
    if c.get("contrainte") == "renouvellement":
        details.append("Dans le cadre d'un renouvellement de prescription")
    if _v(l.get("precision")):
        details.append(_v(l["precision"]))
    return tete, details


def verifier(fiche, prescripteur):
    """Contrôles réglementaires. niveau « erreur » : bloque la génération ; « alerte » : à vérifier."""
    out = []
    def ajoute(niveau, libelle, detail=""):
        out.append({"niveau": niveau, "libelle": libelle, "detail": detail})

    p = {k: _v(v) for k, v in (prescripteur or {}).items()}
    manquants = [lib for k, lib in (("nom", "nom et prénom"), ("profession", "qualité"), ("rpps", "RPPS"),
                                    ("adresse", "adresse professionnelle"), ("telephone", "téléphone"),
                                    ("email", "adresse électronique")) if not p.get(k)]
    if manquants:
        ajoute("erreur", "Prescripteur incomplet (R. 5132-3)",
               "À renseigner dans Paramètres → En-tête des courriers : " + ", ".join(manquants))
    elif re.sub(r"\D", "", p.get("rpps", "")).__len__() != 11:
        ajoute("alerte", "RPPS", "Le numéro RPPS compte normalement 11 chiffres.")
    if not p.get("numero_am"):
        ajoute("alerte", "Numéro Assurance Maladie absent",
               "Nécessaire au remboursement des produits prescrits (Paramètres → En-tête).")

    pat = fiche.get("patient") or {}
    code = code_patient(pat)
    if code:
        idc = fiche.get("identite_coffre") or {}
        manquants = ([] if idc.get("complet") else ["nom, prénom et date de naissance (cadre du coffre)"]) \
            + (["sexe"] if not _v(pat.get("sexe")) else [])
        if manquants:
            ajoute("erreur", "Patient incomplet (R. 5132-3)", "Manque : " + ", ".join(manquants))
    else:
        manquants = [lib for k, lib in (("nom", "nom"), ("prenom", "prénom"), ("sexe", "sexe"),
                                        ("naissance", "date de naissance")) if not _v(pat.get(k))]
        if manquants:
            ajoute("erreur", "Patient incomplet (R. 5132-3)", "Manque : " + ", ".join(manquants))
        elif not _date(pat.get("naissance")) or _date(pat["naissance"]) > datetime.date.today():
            ajoute("erreur", "Date de naissance invalide", "Format attendu : JJ/MM/AAAA.")
    if not _date(fiche.get("date")):
        ajoute("erreur", "Date de l'ordonnance invalide")

    lignes = fiche.get("lignes") or []
    if not lignes:
        ajoute("erreur", "Aucun produit prescrit")
    if not fiche.get("confirme_competence"):
        ajoute("erreur", "Conditions de prescription non confirmées",
               "Cochez : dans le cadre de vos compétences, sans indication contraire du médecin, "
               "hors produits et matériels utilisés pendant la séance.")

    a = (fiche.get("identite_coffre") or {}).get("age") if code else age(pat.get("naissance"))
    for i, l in enumerate(lignes, 1):
        c = PAR_NUM.get(int(l.get("num") or 0) if str(l.get("num") or "").isdigit() else 0)
        nom = f"Ligne {i}"
        if not c:
            ajoute("erreur", f"{nom} : catégorie hors liste", "Seuls les produits de l'arrêté du 14/09/2026 sont prescriptibles.")
            continue
        tout = " ".join(_v(l.get(k)) for k in ("designation", "dci", "dosage", "marque", "posologie", "precision"))
        if c["nature"] == "med":
            if not _v(l.get("dci")):
                ajoute("erreur", f"{nom} : principe actif manquant", "Indiquer la dénomination commune (DCI).")
            if not _v(l.get("posologie")):
                ajoute("erreur", f"{nom} : posologie et mode d'emploi manquants (R. 5132-3)")
            if not (_v(l.get("duree")) or _v(l.get("quantite"))):
                ajoute("erreur", f"{nom} : durée du traitement ou nombre de boîtes manquant (R. 5132-3)")
            if re.search(INJECTABLE, tout, re.I):
                ajoute("erreur", f"{nom} : forme injectable", "Les formes injectables sont exclues.")
            if a is not None and a < 15 and not _v(pat.get("poids")):
                ajoute("alerte", f"{nom} : poids du patient", "Patient de moins de 15 ans : indiquer le poids pour la posologie.")
        else:
            if not _v(l.get("designation")):
                ajoute("erreur", f"{nom} : désignation manquante", "Préciser le produit : type, taille, côté…")
            if not _v(l.get("quantite")) and c["contrainte"] not in ("location", "location_3_mois") \
                    and not (c["contrainte"] == "location_ou_achat" and l.get("mode") != "achat"):
                ajoute("erreur", f"{nom} : quantité manquante")
        if c["num"] == 58 and re.search(OPIOIDES, tout, re.I):
            ajoute("erreur", f"{nom} : antalgique de palier 2 ou 3", "Seuls les antalgiques de palier 1 (OMS) sont autorisés.")
        if c["num"] == 56 and re.search(IODES, tout, re.I):
            ajoute("erreur", f"{nom} : antiseptique iodé", "Les produits à composés iodés sont exclus.")
        if c["num"] == 57 and re.search(r"t[ée]traz[ée]pam", tout, re.I):
            ajoute("erreur", f"{nom} : tétrazépam", "Spécialité retirée du marché.")
        if c["num"] == 57 and re.search(r"thiocolchicoside", tout, re.I):
            ajoute("alerte", f"{nom} : thiocolchicoside",
                   "À vérifier dans le RCP : durée limitée, contre-indications (grossesse, allaitement, "
                   "contraception, âge).")
        loc = c["contrainte"] in ("location", "location_3_mois") or \
            (c["contrainte"] == "location_ou_achat" and l.get("mode") != "achat")
        if loc:
            j = duree_jours(l.get("duree_location"))
            if not _v(l.get("duree_location")):
                ajoute("erreur", f"{nom} : durée de location manquante")
            elif j is None:
                ajoute("alerte", f"{nom} : durée de location", "Écrire par exemple « 4 semaines » ou « 2 mois ».")
            elif c["contrainte"] == "location_3_mois" and j >= 90:
                ajoute("erreur", f"{nom} : location de 3 mois ou plus",
                       "Fauteuils roulants : location pour des durées inférieures à 3 mois.")
        if c["contrainte"] == "renouvellement" and not l.get("renouvellement_confirme"):
            ajoute("erreur", f"{nom} : sérum hypertonique",
                   "Prescriptible uniquement dans le cadre d'un renouvellement de prescription : à confirmer.")
        if c["num"] in DE_SERIE and re.search(r"sur[- ]mesure", tout, re.I):
            ajoute("erreur", f"{nom} : sur mesure", "Cette catégorie n'autorise que les produits de série.")
        if c["num"] == 24 and not re.search(r"classe|\b(I{1,3}|IV)\b|mmhg", tout, re.I):
            ajoute("alerte", f"{nom} : contention", "Préciser la classe de compression et la taille.")
        if c["num"] in (10, 11, 18, 20, 22) and not re.search(r"droit|gauche|bilat", tout, re.I):
            ajoute("alerte", f"{nom} : côté", "Préciser le côté (droit, gauche, bilatéral).")
    return out


# ── fiches ───────────────────────────────────────────────────────────────────
def nouvelle(bilan=None):
    patient = {"civilite": "", "nom": "", "prenom": "", "sexe": "", "naissance": "", "poids": "", "taille": ""}
    if bilan:
        m = re.match(r"^(M\.?|Mme|Mlle)\s+(.*?)_\d{2}-\d{2}-\d{4}", bilan)
        if m:
            homme = m.group(1).startswith("M") and not m.group(1).startswith("Mme") and m.group(1) != "Mlle"
            patient.update(civilite="M." if homme else "Mme", nom=m.group(2), sexe="M" if homme else "F")
    return {"id": uuid.uuid4().hex[:12], "cree": datetime.datetime.now().strftime("%d-%m-%Y %H:%M"),
            "bilan": bilan or None, "patient": patient, "lignes": [], "precisions": "",
            "date": datetime.date.today().strftime("%d/%m/%Y"), "lieu": "", "duplicata": True,
            "confirme_competence": False, "statut": "brouillon", "fichier": ""}


def purger_vides():
    """Brouillons ouverts puis abandonnés sans aucune ligne ni patient."""
    for _, f in base.tous("ordonnance"):
        if f and f["statut"] == "brouillon" and not f.get("lignes") and not _v((f.get("patient") or {}).get("naissance")) \
                and not _v(f.get("precisions")):
            base.retirer("ordonnance", f["id"])          # brouillon vide : rien à garder


def charger(oid):
    return base.lire("ordonnance", os.path.basename(str(oid or ""))) if oid else None


def sauver(fiche):
    base.ecrire("ordonnance", fiche["id"], fiche)


def mettre_a_la_corbeille(oid):
    """Brouillon retiré de la liste, gardé dans la base (récupérable), jamais effacé."""
    f = charger(oid)
    if f:
        with base.transaction():
            base.ecrire("ordonnance_corbeille", f["id"], dict(f, retire=datetime.datetime.now().strftime("%d/%m/%Y %H:%M")))
            base.retirer("ordonnance", f["id"])
    return bool(f)


CHAMPS_LIGNE = ("num", "designation", "dci", "dosage", "marque", "posologie", "duree", "quantite",
                "renouvellements", "duree_location", "mode", "nr", "renouvellement_confirme", "precision")


def fusionner(fiche, donnees):
    """Applique les champs saisis dans l'interface, sans jamais toucher id, cree, statut, fichier."""
    pat = donnees.get("patient") or {}
    fiche["patient"] = {k: _v(pat.get(k))[:120] for k in fiche["patient"]}
    fiche["lignes"] = [{k: (bool(l.get(k)) if k in ("nr", "renouvellement_confirme") else _v(l.get(k))[:400])
                        for k in CHAMPS_LIGNE} for l in (donnees.get("lignes") or [])[:30]]
    idc = donnees.get("identite_coffre")
    if isinstance(idc, dict):                 # ce que le cadre du coffre dit de l'identité, sans la donner
        a = idc.get("age")
        fiche["identite_coffre"] = {"complet": bool(idc.get("complet")),
                                    "age": a if isinstance(a, int) and not isinstance(a, bool) and 0 <= a <= 130 else None}
    fiche["precisions"] = str(donnees.get("precisions") or "")[:2000]
    for k in ("date", "lieu"):
        fiche[k] = _v(donnees.get(k))[:80]
    fiche["duplicata"] = bool(donnees.get("duplicata"))
    fiche["confirme_competence"] = bool(donnees.get("confirme_competence"))
    return fiche


def liste(bilan=None, non_lies=False):
    out = []
    for _, f in base.tous("ordonnance"):
        if not f or (bilan is not None and f.get("bilan") != bilan) or (non_lies and f.get("bilan")):
            continue
        pat = f.get("patient") or {}
        out.append({"id": f["id"], "cree": f["cree"], "date": f.get("date"), "statut": f["statut"],
                    "patient": " ".join(filter(None, (pat.get("civilite"), pat.get("nom"), pat.get("prenom")))),
                    "lignes": len(f.get("lignes") or []),
                    "fichier_existe": bool(f.get("fichier")) and os.path.isfile(f["fichier"])})
    out.sort(key=lambda r: datetime.datetime.strptime(r["cree"], "%d-%m-%Y %H:%M"), reverse=True)
    return out


def dupliquer(fiche):
    copie = nouvelle(fiche.get("bilan"))
    if fiche.get("identite_coffre"):
        copie["identite_coffre"] = dict(fiche["identite_coffre"])
    copie.update(patient=dict(fiche.get("patient") or {}), lignes=[dict(l) for l in fiche.get("lignes") or []],
                 precisions=fiche.get("precisions", ""), duplicata=fiche.get("duplicata", True))
    sauver(copie)
    return copie


# ── document .docx (sans dépendance) ─────────────────────────────────────────
def _run(texte, gras=False, taille=None, italique=False):
    rpr = ("<w:b/>" if gras else "") + ("<w:i/>" if italique else "") + (f'<w:sz w:val="{taille}"/>' if taille else "")
    return (f'<w:r>{"<w:rPr>" + rpr + "</w:rPr>" if rpr else ""}'
            f'<w:t xml:space="preserve">{html.escape(texte, quote=False)}</w:t></w:r>')


def _p(runs, align=None, avant=0, apres=0, retrait=0, garder=False, bordure_bas=False):
    ppr = ""
    if garder:
        ppr += "<w:keepNext/>"
    if bordure_bas:
        ppr += '<w:pBdr><w:bottom w:val="single" w:sz="4" w:space="4" w:color="999999"/></w:pBdr>'
    ppr += f'<w:spacing w:before="{avant}" w:after="{apres}"/>'
    if retrait:
        ppr += f'<w:ind w:left="{retrait}"/>'
    if align:
        ppr += f'<w:jc w:val="{align}"/>'
    return f"<w:p><w:pPr>{ppr}</w:pPr>{''.join(runs) if isinstance(runs, list) else runs}</w:p>"


def _page(fiche, prescripteur, duplicata=False):
    pat = fiche.get("patient") or {}
    corps = []
    ent = lignes_prescripteur(prescripteur)
    for i, l in enumerate(ent):
        corps.append(_p(_run(l, gras=(i == 0), taille=24 if i == 0 else 19), apres=0,
                        bordure_bas=(i == len(ent) - 1)))
    lieu = _v(fiche.get("lieu")) or ville((prescripteur or {}).get("adresse"))
    corps.append(_p(_run(f"{lieu + ', le ' if lieu else 'Le '}{_v(fiche.get('date'))}", taille=21),
                    align="right", avant=240))
    corps.append(_p(_run("ORDONNANCE" + (" — DUPLICATA" if duplicata else ""), gras=True, taille=30),
                    align="center", avant=240, apres=240))
    code = code_patient(pat)
    if code:                                   # jetons remplis par le coffre à l'export, jamais ici
        ident = " ".join(filter(None, (pat.get("civilite"), f"[[NOM:{code}]]", f"[[prenom:{code}]]")))
        naissance, ans = f"[[naissance:{code}]]", f" ([[age:{code}]] ans)"
    else:
        ident = " ".join(filter(None, (pat.get("civilite"), _v(pat.get("nom")).upper(), pat.get("prenom"))))
        a = age(pat.get("naissance"))
        naissance, ans = _v(pat.get("naissance")), (f" ({a} ans)" if a is not None else "")
    corps.append(_p(_run(ident, gras=True, taille=23)))
    infos = [f"Né{'e' if pat.get('sexe') == 'F' else ''} le {naissance}{ans}",
             "Sexe : " + {"F": "féminin", "M": "masculin"}.get(pat.get("sexe"), _v(pat.get("sexe")))]
    if _v(pat.get("poids")):
        infos.append(f"Poids : {_v(pat['poids'])} kg")
    if _v(pat.get("taille")):
        infos.append(f"Taille : {_v(pat['taille'])} cm")
    corps.append(_p(_run(" — ".join(infos), taille=20), apres=280))

    lignes = fiche.get("lignes") or []
    for n, l in enumerate(lignes, 1):
        tete, details = texte_ligne(l)
        corps.append(_p([_run(f"{n}. ", gras=True, taille=22), _run(tete, gras=True, taille=22)], avant=120, garder=True))
        for j, d in enumerate(details):
            corps.append(_p(_run(d, taille=21), retrait=360, garder=(j < len(details) - 1)))
    if _v(fiche.get("precisions")):
        corps.append(_p(_run("Précisions", gras=True, taille=21), avant=200, garder=True))
        for ligne in str(fiche["precisions"]).splitlines():
            if ligne.strip():
                corps.append(_p(_run(ligne.strip(), taille=21), garder=True))
    # R. 5132-3 : signature immédiatement sous la dernière ligne ; l'espace blanc est neutralisé
    corps.append(_p(_run(f"— {len(lignes)} ligne{'s' if len(lignes) > 1 else ''} prescrite{'s' if len(lignes) > 1 else ''} — fin de l’ordonnance —",
                         italique=True, taille=18), align="center", avant=160, garder=True))
    corps.append(_p(_run("Signature du prescripteur", taille=20), align="right", avant=120, garder=True))
    corps.append(_p(_run(_v((prescripteur or {}).get("nom")), gras=True, taille=21), align="right", avant=900))
    return corps


def ecrire_docx(fiche, prescripteur, chemin):
    corps = _page(fiche, prescripteur)
    if fiche.get("duplicata"):
        corps.append('<w:p><w:r><w:br w:type="page"/></w:r></w:p>')
        corps += _page(fiche, prescripteur, duplicata=True)
    section = ('<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
               '<w:pgMar w:top="1000" w:right="1100" w:bottom="1000" w:left="1100" w:header="500" w:footer="500" w:gutter="0"/></w:sectPr>')
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'
           + "".join(corps) + section + "</w:body></w:document>")
    styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults>'
              '<w:rPrDefault><w:rPr><w:rFonts w:ascii="Helvetica" w:hAnsi="Helvetica" w:cs="Arial"/>'
              '<w:sz w:val="21"/><w:lang w:val="fr-FR"/></w:rPr></w:rPrDefault>'
              '<w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="264" w:lineRule="auto"/></w:pPr></w:pPrDefault>'
              '</w:docDefaults></w:styles>')
    types = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
             '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
             '<Default Extension="xml" ContentType="application/xml"/>'
             '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
             '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
             '</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '</Relationships>')
    doc_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                '</Relationships>')
    import io, chiffrement
    tampon = io.BytesIO()
    with zipfile.ZipFile(tampon, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", types)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", doc)
        z.writestr("word/styles.xml", styles)
        z.writestr("word/_rels/document.xml.rels", doc_rels)
    chiffrement.ecrire_octets(chemin, tampon.getvalue())        # chiffré si le dossier l'est


def generer(fiche, prescripteur, dossier):
    os.makedirs(dossier, exist_ok=True)
    pat = fiche.get("patient") or {}
    base = re.sub(r'[/\\:]', "-", " ".join(filter(None, (pat.get("civilite"), pat.get("nom"), pat.get("prenom"))))
                  + "_Ordonnance_" + (_v(fiche.get("date")).replace("/", "-") or datetime.date.today().strftime("%d-%m-%Y")))
    if fiche.get("fichier") and os.path.dirname(fiche["fichier"]) == dossier:
        chemin = fiche["fichier"]
    else:
        chemin, i = os.path.join(dossier, base + ".docx"), 2
        while os.path.exists(chemin):
            chemin = os.path.join(dossier, f"{base} ({i}).docx"); i += 1
    ecrire_docx(fiche, prescripteur, chemin)
    fiche.update(fichier=chemin, statut="générée", genere_le=datetime.datetime.now().strftime("%d-%m-%Y %H:%M"))
    sauver(fiche)
    return chemin


def apercu(fiche, prescripteur):
    """Texte brut de l'ordonnance, pour l'aperçu dans l'interface."""
    pat = fiche.get("patient") or {}
    t = lignes_prescripteur(prescripteur)
    lieu = _v(fiche.get("lieu")) or ville((prescripteur or {}).get("adresse"))
    t += ["", f"{lieu + ', le ' if lieu else 'Le '}{_v(fiche.get('date'))}", "", "ORDONNANCE", ""]
    code = code_patient(pat)
    if code:
        t.append(" ".join(filter(None, (pat.get("civilite"), code))))
        a = (fiche.get("identite_coffre") or {}).get("age")
        naissance = "date de naissance gardée dans le coffre"
    else:
        t.append(" ".join(filter(None, (pat.get("civilite"), _v(pat.get("nom")).upper(), pat.get("prenom")))))
        a = age(pat.get("naissance"))
        naissance = "Né(e) le " + _v(pat.get("naissance"))
    t.append(naissance + (f" ({a} ans)" if a is not None else "")
             + (f" — sexe {pat.get('sexe')}" if pat.get("sexe") else "")
             + (f" — {pat['poids']} kg" if _v(pat.get("poids")) else "") + (f" — {pat['taille']} cm" if _v(pat.get("taille")) else ""))
    t.append("")
    for n, l in enumerate(fiche.get("lignes") or [], 1):
        tete, details = texte_ligne(l)
        t.append(f"{n}. {tete}")
        t += ["   " + d for d in details]
    if _v(fiche.get("precisions")):
        t += ["", "Précisions"] + [x for x in str(fiche["precisions"]).splitlines() if x.strip()]
    t += ["", f"— {len(fiche.get('lignes') or [])} ligne(s) prescrite(s) — fin de l’ordonnance —", "",
          "Signature du prescripteur", _v((prescripteur or {}).get("nom"))]
    return "\n".join(t)
