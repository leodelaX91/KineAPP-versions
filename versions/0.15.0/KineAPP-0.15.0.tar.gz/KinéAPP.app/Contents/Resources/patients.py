# -*- coding: utf-8 -*-
"""Dossier patient : ce qui dépasse un seul bilan.

- Plan en cours : objectifs et exercices à domicile, modifiables à chaque séance, avec
  l'historique de leurs versions.
- Séances : notes de suivi dictées (sur le Mac ou l'iPhone, transcrites puis mises en forme) ou
  écrites dans l'app, avec leur charge structurée (exercices, séries, charges : charge.py). Une
  dictée de l'iPhone arrive « à relire » : hors des comptes rendus tant qu'elle n'est pas validée.
- Programme de charge : protocole par phases, date de début, phase retenue, critères validés.
- Bilans d'un même patient (bilan initial, réévaluations) retrouvés par le nom.

Stockage : un fichier JSON par patient dans les données de l'app (patients/<clé>.json).
"""
import datetime, functools, json, os, re, threading, unicodedata, uuid

import base

# Une fiche patient est lue, modifiée puis réécrite par plusieurs chemins à la fois (dictées de
# l'iPhone en arrière-plan, plan repris d'un bilan à l'ouverture, saisies de la page) : sans
# verrou, deux écritures simultanées en perdraient une.
_VERROU = threading.RLock()


def _exclusif(f):
    @functools.wraps(f)
    def g(*a, **k):
        with _VERROU:
            return f(*a, **k)
    return g

DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
DOSSIER = os.path.join(DATA, "patients")        # anciennes fiches JSON, versées dans la base au lancement
META_BILAN = ".bilan.json"          # type de bilan (initial / réévaluation) et bilan précédent


def nom_patient(nom_bilan):
    """« Mme Exemplaire_03-09-2026_2 » -> « Mme Exemplaire »."""
    m = re.match(r"^(.*)_\d{2}-\d{2}-\d{4}(?:_\d+)?$", nom_bilan or "")
    return (m.group(1) if m else (nom_bilan or "")).strip()


def date_bilan(nom_bilan):
    m = re.search(r"_(\d{2})-(\d{2})-(\d{4})(?:_\d+)?$", nom_bilan or "")
    return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1))) if m else None


def cle(nom):
    s = unicodedata.normalize("NFD", nom_patient(nom) if "_" in (nom or "") else (nom or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn").lower()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-") or "sans-nom"


def charger(nom):
    """Fiche du patient (base de l'app). Une fiche illisible (base chiffrée verrouillée) lève une
    erreur au lieu de passer pour vide : elle ne serait jamais écrasée par une fiche vide."""
    d = base.lire("patient", cle(nom)) or {}
    d.setdefault("nom", nom_patient(nom) if "_" in (nom or "") else nom)
    d.setdefault("plan", {"objectifs": "", "exercices": "", "maj": ""})
    d.setdefault("historique_plan", [])
    d.setdefault("seances", [])
    d.setdefault("questionnaires", [])
    d.setdefault("force", [])
    d.setdefault("preventions", [])
    d.setdefault("programme", {})
    return d


def sauver(d):
    base.ecrire("patient", cle(d["nom"]), d)


def maintenant():
    return datetime.datetime.now().strftime("%d/%m/%Y %H:%M")


# ── plan en cours ────────────────────────────────────────────────────────────
def section(md, titre_regex):
    """Contenu d'une section « ## Titre » d'un bilan rédigé."""
    m = re.search(r"^##\s*(?:" + titre_regex + r")[^\n]*\n(.*?)(?=^##\s|\Z)", md or "", re.M | re.S | re.I)
    return m.group(1).strip() if m else ""


def plan_depuis_bilan(md):
    """Propose objectifs et exercices à domicile à partir d'un bilan rédigé.

    Deux gabarits coexistent : l'ancien (« Objectifs de rééducation », « Plan de
    traitement ») et celui du 06/10/2026, calqué sur le bilan type du praticien
    (« Évaluation », « Prise en charge »), où les objectifs sont des lignes de la synthèse.
    Les bilans déjà rédigés gardent l'ancien : les deux doivent rester lisibles."""
    objectifs = section(md, r"Objectifs de rééducation")
    if not objectifs:
        # « - Objectif : extension complète en 3 semaines » -> « - Extension complète en 3 semaines »
        lignes = [re.sub(r"^\s*[-•*]?\s*objectifs?\s*(?:de rééducation)?\s*:\s*", "", l, flags=re.I).strip()
                  for l in section(md, r"[ÉE]valuation").splitlines() if re.search(r"objectif", l, re.I)]
        objectifs = "\n".join("- " + l[:1].upper() + l[1:] for l in lignes if l)
    plan = section(md, r"Plan de traitement") or section(md, r"Prise en charge")
    exos = []
    for l in plan.splitlines():
        if not re.search(r"domicile|HEP|auto-?rééducation|exercices? à la maison", l, re.I):
            continue
        # « Programme d'exercices à domicile : a ; b ; c » : un exercice par ligne.
        m = re.match(r"^\s*[-•*]?\s*programme d'exercices à domicile\s*:\s*(.+)$", l, re.I)
        if m:
            exos += ["- " + x.strip()[:1].upper() + x.strip()[1:] for x in re.split(r"\s*;\s*", m.group(1).rstrip(" .")) if x.strip()]
        else:
            exos.append(l.strip())
    return {"objectifs": objectifs.strip(), "exercices": "\n".join(exos).strip()}


def a_relire(nom):
    """Ce qui attend le praticien pour ce patient : notes dictées et changements du plan à relire."""
    d = charger(nom)
    return sum(1 for s in d["seances"] if s.get("etat") == "a_relire") + (1 if d["plan"].get("a_relire") else 0)


def resume_liste(nom):
    """Pour la colonne des patients : ce qui attend une relecture, date de la dernière séance, nombre de
    séances et programme en cours (une seule lecture de la fiche)."""
    d = charger(nom)
    dates = [x for x in (_tri_date(s.get("date")) for s in d["seances"]) if x != datetime.datetime.min]
    return {"a_relire": sum(1 for s in d["seances"] if s.get("etat") == "a_relire") + (1 if d["plan"].get("a_relire") else 0),
            "derniere_seance": max(dates).strftime("%d/%m/%Y") if dates else "", "seances": len(d["seances"]),
            "programme": d.get("programme") or {}}


# ── consentement à l'enregistrement : recueilli une fois, retirable ─────────
def consentement(nom):
    """Date du consentement du patient à l'enregistrement de ses séances, s'il est en vigueur, sinon ""."""
    c = charger(nom).get("consentement") or {}
    return "" if c.get("retire") else c.get("date", "")


@_exclusif
def noter_consentement(nom, date):
    """Consentement confirmé par le praticien (patient informé et d'accord) : gardé dans la fiche, avec
    ses dates, pour les enregistrements suivants. Un consentement retiré puis redonné repart de zéro."""
    d = charger(nom)
    c = d.get("consentement") or {}
    if c.get("date") and not c.get("retire"):
        return c
    d["consentement"] = {"date": date}
    if c.get("retire"):
        d["consentement"]["precedent"] = {k: v for k, v in c.items() if k != "precedent"}
    sauver(d)
    return d["consentement"]


@_exclusif
def retirer_consentement(nom):
    d = charger(nom)
    c = d.get("consentement") or {}
    if not c.get("date") or c.get("retire"):
        return False
    c["retire"] = maintenant()
    d["consentement"] = c
    sauver(d)
    return True


@_exclusif
def plan_apres_bilan(nom_bilan, md, seulement_si_vide=False):
    """Objectifs et programme à domicile repris d'un bilan rédigé (initial ou réévaluation), dès son
    enregistrement : le plus récent bilan fait foi ; ce qu'il ne dit pas reste tel quel. Rien si le
    plan vient déjà de ce bilan, ou (seulement_si_vide) si un plan existe."""
    prop = plan_depuis_bilan(md)
    if not (prop["objectifs"] or prop["exercices"]):
        return None
    d = charger(nom_bilan)
    ancien = d["plan"]
    if ancien.get("bilan") == nom_bilan or (seulement_si_vide and (ancien.get("objectifs") or ancien.get("exercices"))):
        return None
    jour = date_bilan(nom_bilan)
    return mettre_a_jour_plan(nom_bilan, prop["objectifs"] or ancien.get("objectifs") or "",
                              prop["exercices"] or ancien.get("exercices") or "",
                              source="bilan du " + (jour.strftime("%d/%m/%Y") if jour else "?"), bilan=nom_bilan)


REGROUPER_MIN = 30          # saisies d'un même plan à moins de 30 min d'écart : une seule version


@_exclusif
def mettre_a_jour_plan(nom, objectifs, exercices, source="saisie", a_relire=False, bilan=None, resume="", regrouper=False):
    """Nouvelle version du plan ; l'ancienne va dans l'historique (jamais perdue). source : « saisie »,
    « bilan du jj/mm/aaaa », « dictée iPhone du jj/mm/aaaa » ; a_relire : changement automatique
    à valider par le praticien (ou à annuler). regrouper : enregistrement automatique pendant la
    frappe ; une saisie qui suit de peu une autre saisie la remplace au lieu de créer une version."""
    d = charger(nom)
    ancien = d["plan"]
    if (ancien.get("objectifs") or "") == objectifs and (ancien.get("exercices") or "") == exercices:
        if source == "saisie" and ancien.get("a_relire"):        # enregistré tel quel : relu
            ancien.pop("a_relire", None)
            ancien.pop("resume", None)
            sauver(d)
        return d
    recente = False
    if regrouper and source == "saisie" and ancien.get("source") == "saisie" and not ancien.get("a_relire"):
        try:
            age = datetime.datetime.now() - datetime.datetime.strptime(ancien.get("maj") or "", "%d/%m/%Y %H:%M")
            recente = age < datetime.timedelta(minutes=REGROUPER_MIN)
        except ValueError:
            pass
    if ancien.get("maj") and not recente:
        d["historique_plan"].insert(0, dict(ancien))
        d["historique_plan"] = d["historique_plan"][:50]
    d["plan"] = {"objectifs": objectifs, "exercices": exercices, "maj": maintenant(), "source": source}
    if a_relire:
        d["plan"]["a_relire"] = True
        if resume:
            d["plan"]["resume"] = resume[:300]
    if bilan:
        d["plan"]["bilan"] = bilan
    sauver(d)
    return d


@_exclusif
def valider_plan(nom):
    d = charger(nom)
    if not d["plan"].get("a_relire"):
        return False
    d["plan"].pop("a_relire", None)
    d["plan"].pop("resume", None)
    sauver(d)
    return True


@_exclusif
def annuler_plan(nom):
    """Changement automatique refusé : la version d'avant revient ; celle refusée reste dans
    l'historique, marquée."""
    d = charger(nom)
    if not d["plan"].get("a_relire"):
        return False
    # Pas d'historique : le plan était vide avant ce changement.
    precedent = d["historique_plan"].pop(0) if d["historique_plan"] else {"objectifs": "", "exercices": "", "maj": ""}
    refusee = {k: v for k, v in d["plan"].items() if k not in ("a_relire", "resume")}
    d["historique_plan"].insert(0, dict(refusee, refusee=maintenant()))
    # La version rétablie peut être une proposition d'une dictée plus ancienne, jamais relue : elle
    # revient comme version en place, plus « à relire » (sinon le compteur ne disparaissait jamais).
    d["plan"] = {k: v for k, v in precedent.items() if k not in ("a_relire", "resume", "refusee")}
    sauver(d)
    return True


# ── séances ──────────────────────────────────────────────────────────────────
# Échelles 0-10. Douleur au réveil : celle du matin qui suit la séance précédente, notée à la séance
# suivante (modèle de surveillance de la douleur de Silbernagel : elle ne doit pas augmenter).
MESURES = {"rpe": "RPE", "eva_max": "EVA max", "eva_moy": "EVA moyenne", "eva_reveil": "Douleur au réveil"}


def mesures_valides(brutes):
    """RPE (effort perçu), EVA max / moyenne de la séance et douleur au réveil, de 0 à 10 par pas de 0,5 ;
    vide = non mesuré."""
    out = {}
    for k in MESURES:
        v = (brutes or {}).get(k)
        if v in (None, ""):
            continue
        try:
            v = round(float(str(v).replace(",", ".")) * 2) / 2
        except ValueError:
            raise ValueError(f"{MESURES[k]} : nombre attendu.")
        if not 0 <= v <= 10:
            raise ValueError(f"{MESURES[k]} : valeur entre 0 et 10.")
        out[k] = int(v) if v.is_integer() else v
    return out


_NB = r"(\d{1,2}(?:[.,]5)?)(?:\s*(?:/|sur)\s*10)?"
_MOTIFS = {"rpe": r"\b(?:rpe|borg)\b[^\d\n]{0,20}?" + _NB,
           "eva_max": r"\b(?:eva|evn)\b\s*(?:max(?:imale|imum)?|pic|la plus (?:haute|forte|élevée))[^\d\n]{0,15}?" + _NB,
           "eva_moy": r"\b(?:eva|evn)\b\s*moy(?:enne)?[^\d\n]{0,15}?" + _NB,
           # « douleur au réveil 3 », « ce matin, EVA 2 sur 10 » : un mot de douleur ET un moment du matin,
           # sinon « ce matin 3 séries » deviendrait une douleur.
           "eva_reveil": r"(?:\b(?:douleur|eva|evn|mal)\b[^\d\n]{0,30}?(?:\bau r[ée]veil\b|\bce matin\b|\ble lendemain\b)"
                         r"|(?:\bau r[ée]veil\b|\bce matin\b|\ble lendemain\b)[^\d\n]{0,30}?\b(?:douleur|eva|evn|mal)\b)"
                         r"[^\d\n]{0,15}?" + _NB}


def mesures_dictees(texte):
    """Repère « RPE 6 », « EVA max 7 sur 10 », « EVA moyenne 4 », « douleur au réveil 2 » dans une dictée :
    proposition à vérifier."""
    out = {}
    for k, motif in _MOTIFS.items():
        m = re.search(motif, texte or "", re.I)
        if m:
            try:
                out.update(mesures_valides({k: m.group(1)}))
            except ValueError:
                pass
    return out


def texte_mesures(s):
    parts = [f"{lib} {str(s[k]).replace('.', ',')}/10" for k, lib in MESURES.items() if s.get(k) is not None]
    return " ; ".join(parts)


@_exclusif
def enregistrer_seance(nom, texte, date=None, source="écrite", transcription="", sid=None, mesures=None,
                       charge=None, a_relire=False, heure="", garder_etat=False):
    """Une séance enregistrée (ou modifiée) ; modifier une séance « à relire » la valide, sauf
    garder_etat (enregistrement automatique pendant la relecture : la note reste à relire jusqu'au
    « Relu » du praticien)."""
    d = charger(nom)
    s = next((x for x in d["seances"] if x["id"] == sid), None) if sid else None
    if s is None:
        s = {"id": uuid.uuid4().hex[:10], "cree": maintenant()}
        d["seances"].insert(0, s)
    s.update(date=(date or datetime.date.today().strftime("%d/%m/%Y")), texte=texte.strip(), source=source,
             modifie=maintenant())
    if a_relire:
        s["etat"] = "a_relire"
    elif not (garder_etat and sid):
        s.pop("etat", None)
    if heure:
        s["heure"] = heure
    if charge is not None:
        if charge.get("exercices") or charge.get("duree_min"):
            s["charge"] = {k: v for k, v in charge.items() if k in ("duree_min", "exercices")}
        else:
            s.pop("charge", None)
    if mesures is not None:
        for k in MESURES:
            s.pop(k, None)
        s.update(mesures)
    if transcription:
        s["transcription"] = transcription
    d["seances"].sort(key=lambda x: _tri_date(x.get("date")), reverse=True)
    sauver(d)
    return s


def seance_a_completer(nom, date, source):
    """Note du même jour, de la même source, encore « à relire » (donc jamais retouchée ni validée) :
    une nouvelle dictée de la même séance la complète au lieu d'en créer une autre."""
    return next((s for s in charger(nom)["seances"]
                 if s.get("date") == date and s.get("source") == source and s.get("etat") == "a_relire"), None)


@_exclusif
def valider_seance(nom, sid):
    d = charger(nom)
    s = next((x for x in d["seances"] if x["id"] == sid), None)
    if not s:
        return False
    s.pop("etat", None)
    s["valide"] = maintenant()
    sauver(d)
    return True


@_exclusif
def rattacher(source, cible):
    """Notes d'un patient sans dossier (nom tapé sur l'iPhone) rattachées au dossier d'un patient
    existant : toutes ses séances passent chez lui, avec leur état (« à relire » reste à relire).
    Les objectifs proposés par une dictée ne sont repris que si le patient n'en a pas encore : sinon
    ils remplaceraient les siens ; la note, elle, garde tout ce qui a été dit. Renvoie
    (nombre de séances, objectifs repris)."""
    a, b = charger(source), charger(cible)
    if cle(a["nom"]) == cle(b["nom"]):
        return 0, False
    n = len(a["seances"])
    b["seances"].extend(a["seances"])
    b["seances"].sort(key=lambda x: _tri_date(x.get("date")), reverse=True)
    a["seances"] = []
    prop = a["plan"] if a["plan"].get("a_relire") else None
    repris = bool(prop and not (b["plan"].get("objectifs") or b["plan"].get("exercices")))
    if prop:
        a["plan"] = {k: v for k, v in prop.items() if k not in ("a_relire", "resume")}
    sauver(a)
    sauver(b)
    if repris:
        mettre_a_jour_plan(cible, prop.get("objectifs") or "", prop.get("exercices") or "",
                           source=prop.get("source") or "dictée iPhone", a_relire=True, resume=prop.get("resume", ""))
    return n, repris


@_exclusif
def mettre_a_jour_programme(nom, programme):
    d = charger(nom)
    d["programme"] = dict(programme, maj=maintenant())
    sauver(d)
    return d["programme"]


@_exclusif
@_exclusif
def transcriptions_seances():
    """[(nom, id, date de création, transcription)] des séances dictées : pour repasser leurs noms
    prononcés au coffre (Paramètres, « anciennes transcriptions »)."""
    return [(d.get("nom") or "", s["id"], s.get("cree") or "", s["transcription"])
            for _, d in base.tous("patient") for s in d.get("seances") or [] if s.get("id") and s.get("transcription")]


@_exclusif
def remplacer_transcription(nom, sid, avant, apres):
    """Transcription d'une séance remplacée, seulement si elle n'a pas changé entre-temps. True si fait."""
    d = charger(nom)
    s = next((x for x in d["seances"] if x.get("id") == sid), None)
    if not s or s.get("transcription") != avant:
        return False
    s["transcription"] = apres
    sauver(d)
    return True


def supprimer_seance(nom, sid):
    d = charger(nom)
    avant = len(d["seances"])
    d["seances"] = [s for s in d["seances"] if s["id"] != sid]
    sauver(d)
    return len(d["seances"]) < avant


def _tri_date(txt):
    try:
        return datetime.datetime.strptime(txt or "", "%d/%m/%Y")
    except ValueError:
        return datetime.datetime.min


def seances_comme_notes(nom):
    """Séances au format des notes de suivi (pour le contexte des comptes rendus). Une dictée encore
    « à relire » n'y figure pas : le praticien ne l'a pas validée."""
    import charge as CH
    out = []
    for s in charger(nom)["seances"]:
        if s.get("etat") == "a_relire":
            continue
        ts = _tri_date(s.get("date"))
        m = texte_mesures(s)
        c = CH.texte_charge(s)
        out.append({"nom": f"Séance du {s.get('date')}", "texte": (f"Mesures de séance : {m}\n\n" if m else "") + s.get("texte", "")
                    + (f"\n\nExercices et charges :\n{c}" if c else ""),
                    "mtime": ts.timestamp() if ts != datetime.datetime.min else 0})
    return out


def programme_comme_notes(nom):
    """Programme de rééducation par phases (protocole, délai, phase, critères validés), pour les
    comptes rendus et le chat."""
    import charge as CH
    e = CH.etat_programme(charger(nom).get("programme") or {})
    if not e:
        return []
    p = e["protocole"]
    ph = next((x for x in p["phases"] if x["id"] == e["phase"]), p["phases"][0])
    valides = set((e["criteres"] or {}).get(ph["id"], []))
    l = [f"- Protocole : {p['nom']} (trame indicative)"]
    if e["semaines"] is not None:
        l.append(f"- Délai depuis le début : {str(e['semaines']).replace('.', ',')} semaines")
    l.append(f"- Phase actuelle : {ph['nom']}")
    l += [f"- Critère {'validé' if c['id'] in valides else 'non encore validé'} : {c['texte']}" for c in ph["criteres"]]
    return [{"nom": "Programme de rééducation", "texte": "\n".join(l), "mtime": datetime.datetime.now().timestamp()}]


# ── prévention : repérage de la fragilité (ICOPE) et Mon Bilan Prévention ────
@_exclusif
def enregistrer_prevention(nom, seance, uid=None):
    d = charger(nom)
    ancienne = next((x for x in d["preventions"] if x.get("uid") == uid), None) if uid else None
    s = dict(seance, uid=ancienne["uid"] if ancienne else uuid.uuid4().hex[:10], enregistre=maintenant())
    if ancienne:
        d["preventions"][d["preventions"].index(ancienne)] = s
    else:
        d["preventions"].insert(0, s)
    d["preventions"].sort(key=lambda x: (_tri_date(x.get("date")), x.get("enregistre", "")), reverse=True)
    sauver(d)
    return s


@_exclusif
def supprimer_prevention(nom, uid):
    d = charger(nom)
    avant = len(d["preventions"])
    d["preventions"] = [x for x in d["preventions"] if x.get("uid") != uid]
    sauver(d)
    return len(d["preventions"]) < avant


def preventions_comme_notes(nom):
    """Bilans de prévention résumés, pour les comptes rendus et le chat."""
    import prevention as PV
    lignes = []
    for s in charger(nom)["preventions"][:3]:
        if s.get("type") == "mbp" and s.get("opposition_transmission"):
            continue                      # la personne s'oppose à la transmission
        try:
            lignes.append("- " + PV.resume(s))
        except Exception:
            continue
    if not lignes:
        return []
    return [{"nom": "Bilans de prévention", "texte": "\n".join(lignes), "mtime": datetime.datetime.now().timestamp()}]


# ── mesures de force ─────────────────────────────────────────────────────────
@_exclusif
def enregistrer_force(nom, seance, uid=None):
    """seance : {date, articulation, unite, cote_atteint, poids_kg, mesures: {test: {g, d, bras_cm}}, commentaire}."""
    d = charger(nom)
    ancienne = next((x for x in d["force"] if x.get("uid") == uid), None) if uid else None
    s = dict(seance, uid=ancienne["uid"] if ancienne else uuid.uuid4().hex[:10], enregistre=maintenant())
    if ancienne:
        d["force"][d["force"].index(ancienne)] = s
    else:
        d["force"].insert(0, s)
    d["force"].sort(key=lambda x: (_tri_date(x.get("date")), x.get("enregistre", "")), reverse=True)
    sauver(d)
    return s


@_exclusif
def supprimer_force(nom, uid):
    d = charger(nom)
    avant = len(d["force"])
    d["force"] = [x for x in d["force"] if x.get("uid") != uid]
    sauver(d)
    return len(d["force"]) < avant


def force_comme_notes(nom):
    """Dernière séance de force (et évolution depuis la précédente) pour les comptes rendus et le chat."""
    import force as FO
    seances = charger(nom)["force"]
    if not seances:
        return []
    lignes = []
    for s in seances[:2]:
        for tid, m in (s.get("mesures") or {}).items():
            fiche = FO.test(tid)
            if not fiche or (m.get("g") in (None, "") and m.get("d") in (None, "")):
                continue
            sym = FO.symetrie(m.get("g"), m.get("d"), s.get("cote_atteint"))
            u = s.get("unite", "N")
            lignes.append(f"- {s.get('date')} — {fiche['articulation']}, {fiche['groupe']} : "
                          f"G {FO.nombre(m.get('g'))} {u} / D {FO.nombre(m.get('d'))} {u}"
                          + (f" (symétrie {FO.nombre(sym)} %)" if sym is not None else ""))
    if not lignes:
        return []
    return [{"nom": "Mesures de force (deux dernières séances)", "texte": "\n".join(lignes),
             "mtime": datetime.datetime.now().timestamp()}]


# ── questionnaires et échelles ───────────────────────────────────────────────
@_exclusif
def enregistrer_questionnaire(nom, res, uid=None):
    """res : résultat de questionnaires.resultat() (id = identifiant de l'instrument)."""
    d = charger(nom)
    ancien = next((x for x in d["questionnaires"] if x.get("uid") == uid), None) if uid else None
    r = dict(res, uid=uid if ancien else uuid.uuid4().hex[:10])
    if ancien:
        d["questionnaires"][d["questionnaires"].index(ancien)] = r
    else:
        d["questionnaires"].insert(0, r)
    d["questionnaires"].sort(key=lambda x: (_tri_date(x.get("date")), x.get("enregistre", "")), reverse=True)
    sauver(d)
    return r


@_exclusif
def supprimer_questionnaire(nom, uid):
    d = charger(nom)
    avant = len(d["questionnaires"])
    d["questionnaires"] = [x for x in d["questionnaires"] if x.get("uid") != uid]
    sauver(d)
    return len(d["questionnaires"]) < avant


def questionnaires_comme_notes(nom):
    """Résultats regroupés en une note (contexte des comptes rendus et du chat)."""
    import questionnaires as QU
    lignes = []
    for r in charger(nom)["questionnaires"]:
        try:
            lignes.append("- " + QU.texte_resultat(r))
        except Exception:
            continue
    if not lignes:
        return []
    return [{"nom": "Questionnaires et échelles (du plus récent au plus ancien)", "texte": "\n".join(lignes),
             "mtime": datetime.datetime.now().timestamp()}]


# ── bilans d'un patient ──────────────────────────────────────────────────────
def meta_bilan(dossier_bilan):
    try:
        with open(os.path.join(dossier_bilan, META_BILAN), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"type": "initial"}


def bilans_du_patient(nom, tous_les_bilans, racine):
    """[(nom du bilan, date, type)] du plus ancien au plus récent."""
    k = cle(nom)
    out = []
    for b in tous_les_bilans:
        if cle(b) == k:
            meta = meta_bilan(os.path.join(racine, b))
            out.append({"nom": b, "date": (date_bilan(b) or datetime.date.min).strftime("%d/%m/%Y"),
                        "type": meta.get("type", "initial"), "precedent": meta.get("precedent")})
    out.sort(key=lambda x: (_tri_date(x["date"]), x["nom"]))
    return out
