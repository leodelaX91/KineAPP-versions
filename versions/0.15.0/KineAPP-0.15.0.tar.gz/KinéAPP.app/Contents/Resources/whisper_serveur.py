# -*- coding: utf-8 -*-
"""Transcription par le serveur Whisper (whisper.cpp intégré à l'app, Paramètres → IA).

L'app le lance pour un bilan, lui envoie l'audio, puis l'arrête : le modèle de 3,1 Go ne reste
donc jamais en mémoire. Le serveur imprime sa progression sur sa sortie standard ; on la lit au
vol pour garder l'avancement en pourcentage dans l'interface.

Repli : sans whisper.cpp dans l'app, whisper-cli s'il est installé (Homebrew).
"""
import json, os, re, signal, socket, subprocess, threading, time, urllib.error, urllib.request

DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
JOURNAUX = os.path.join(DATA, "journaux")
# Dans l'app : code du système, personne ne peut le remplacer sans mot de passe administrateur.
BINAIRE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outils", "whisper-cpp", "whisper-server")
PIDF = os.path.join(DATA, "whisper_serveur.pid")
JOURNAL = os.path.join(JOURNAUX, "whisper_serveur.log")
PROGRES = re.compile(r"progress\s*=\s*(\d+)\s*%")
DELAI_DEMARRAGE_S = 300
_ETAT = {"progres": 0, "processus": None}


class ErreurWhisper(RuntimeError):
    pass


def installe():
    return os.path.isfile(BINAIRE)


def _port_libre():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _en_marche(port):
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2)
        return True
    except urllib.error.HTTPError:
        return True                    # répond, même par une erreur : le serveur est debout
    except Exception:
        return False


def _lire_sortie(pr):
    """Progression du serveur, lue au vol. Aucune ligne de texte transcrit n'est écrite."""
    os.makedirs(JOURNAUX, exist_ok=True)
    with open(JOURNAL, "w", encoding="utf-8") as fh:
        for brute in pr.stdout:
            ligne = brute.decode("utf-8", "replace")
            m = PROGRES.search(ligne)
            if m:
                # whisper-server recompte à partir de zéro à chaque segment : on garde le
                # maximum vu, borné à 100 (il a déjà annoncé « 495 % » sur un long audio).
                _ETAT["progres"] = max(_ETAT["progres"], min(100, int(m.group(1))))
                continue
            if ligne.startswith("[") or "whisper_print" in ligne:
                continue               # segments transcrits : jamais dans un journal
            fh.write(ligne); fh.flush()


def demarrer(args_modele):
    """args_modele : les arguments de modèle et de langue de l'app (-m … -l fr)."""
    if not installe():
        raise ErreurWhisper("whisper.cpp n'est pas dans l'app : téléchargez-le dans Paramètres → IA.")
    arreter()
    port = _port_libre()
    cmd = [BINAIRE, *args_modele, "-nt", "-pp", "--host", "127.0.0.1", "--port", str(port)]
    os.makedirs(JOURNAUX, exist_ok=True)
    pr = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    threading.Thread(target=_lire_sortie, args=(pr,), daemon=True).start()
    _ETAT.update(progres=0, processus=pr)
    with open(PIDF, "w") as f:
        f.write(f"{pr.pid} {port}")
    t0 = time.time()
    while time.time() - t0 < DELAI_DEMARRAGE_S:
        if pr.poll() is not None:
            fin = ""
            try: fin = open(JOURNAL, encoding="utf-8", errors="ignore").read()[-400:]
            except OSError: pass
            arreter()
            raise ErreurWhisper("whisper-server s'est arrêté au démarrage : " + fin)
        if _en_marche(port):
            return port
        time.sleep(1)
    arreter()
    raise ErreurWhisper(f"whisper-server n'a pas répondu en {DELAI_DEMARRAGE_S} s.")


def arreter():
    pid = port = None
    try:
        pid, port = open(PIDF).read().split()[:2]
        pid = int(pid)
    except Exception:
        pid = None
    if pid:
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                cmd = subprocess.run(["ps", "-o", "command=", "-p", str(pid)],
                                     capture_output=True, text=True, timeout=10).stdout
                if "whisper-server" not in cmd:
                    break
                os.kill(pid, sig)
                time.sleep(1 if sig == signal.SIGTERM else 0.3)
            except (ProcessLookupError, subprocess.SubprocessError):
                break
    _ETAT["processus"] = None
    try: os.remove(PIDF)
    except OSError: pass


def progres():
    return _ETAT["progres"]


def _multipart(wav, champs):
    """Corps multipart construit à la main : l'app n'a aucune dépendance externe."""
    limite = "----KineAPP" + os.urandom(8).hex()
    morceaux = []
    for cle, valeur in champs.items():
        morceaux.append(f"--{limite}\r\nContent-Disposition: form-data; name=\"{cle}\"\r\n\r\n{valeur}\r\n".encode())
    morceaux.append(f"--{limite}\r\nContent-Disposition: form-data; name=\"file\"; "
                    f"filename=\"{os.path.basename(wav)}\"\r\nContent-Type: audio/wav\r\n\r\n".encode())
    with open(wav, "rb") as f:
        morceaux.append(f.read())
    morceaux.append(f"\r\n--{limite}--\r\n".encode())
    return b"".join(morceaux), f"multipart/form-data; boundary={limite}"


def transcrire(port, wav, timeout=7200, options=None):
    """Texte de la transcription. Le fichier audio ne quitte pas la machine (127.0.0.1).
    `options` : réglages de whisper-server pour CETTE requête (ex. {"beam_size": "5"})."""
    _ETAT["progres"] = 0
    corps, type_contenu = _multipart(wav, {"response_format": "json", "temperature": "0.0", **(options or {})})
    req = urllib.request.Request(f"http://127.0.0.1:{port}/inference", data=corps,
                                 headers={"Content-Type": type_contenu})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        brut = r.read().decode("utf-8", "replace")
    try:
        d = json.loads(brut)
    except Exception:
        return brut.strip()
    texte = d.get("text") if isinstance(d, dict) else None
    if texte is None and isinstance(d, dict):          # autre forme : liste de segments
        texte = " ".join(s.get("text", "") for s in (d.get("segments") or []))
    if not (texte or "").strip():
        raise ErreurWhisper("whisper-server n'a renvoyé aucun texte.")
    return texte.strip()
