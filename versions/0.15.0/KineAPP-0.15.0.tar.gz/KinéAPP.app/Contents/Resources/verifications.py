# -*- coding: utf-8 -*-
"""Points à vérifier d'un bilan, posés au praticien comme des questions (et non plus laissés en fin
de bilan, où ils restaient non lus).

À la fin du traitement, les contrôles de verification.py (valeurs introuvables, médicaments
inconnus, doses, côtés, mesures perdues, sections vides, incertitudes du modèle, passages ratés de
la transcription…) deviennent une liste de POINTS : une question, un extrait de la transcription,
des choix en un clic, une saisie si besoin. À l'ouverture du bilan, une fenêtre les pose ; le bilan
ne peut pas être enregistré tant qu'ils ne sont pas tranchés.

Ordre des questions (07/11/2026) : le côté atteint d'abord (les consignes nettoyées le perdent parfois en
entier, banc du 07/11/2026), puis les points, du plus grave au moins grave, puis une question ouverte
facultative. Les doutes du modèle et les mesures perdues, longs et peu clairs tels quels, sont reformulés
par une courte passe du modèle (prompts/13_questions_system.md) en questions à réponses à cliquer.

Application des réponses :
  - « garder », « ignorer », « j'ai compris » : rien ne change ;
  - une correction dont la valeur figure UNE seule fois dans le bilan : remplacée telle quelle ;
  - le reste (retirer, ajouter, côté, préciser…) : une passe du modèle qui n'applique QUE ces
    corrections (prompts/10_corrections_system.md), contrôlée ensuite : si le texte a changé
    au-delà des corrections, la version d'avant est gardée et les corrections sont listées à
    reporter à la main. Rien n'est jamais perdu.
Les réponses sont gardées avec le bilan (traçabilité des vérifications du praticien).
"""
import difflib, re, unicodedata

SEPARATEUR = "\n\n---\n\n## À vérifier\n\n"

CHOIX = {
    "medicament": [("garder", "Garder tel quel"), ("corriger", "Corriger le nom"), ("retirer", "Retirer du bilan")],
    "dose": [("garder", "Dose exacte"), ("corriger", "Corriger la dose"), ("retirer", "Retirer du bilan")],
    "valeur": [("garder", "Exact (dit pendant la séance)"), ("corriger", "Corriger"), ("retirer", "Retirer du bilan")],
    "mesure_perdue": [("ajouter", "Ajouter au bilan"), ("ignorer", "Ne pas ajouter"), ("corriger", "Ajouter en corrigeant")],
    "cote": [("garder", "Côté exact"), ("inverser", "Inverser le côté"), ("corriger", "Corriger")],
    "cote_retire": [("garder", "Laisser sans côté"), ("droit", "Côté droit"), ("gauche", "Côté gauche")],
    "mesure": [("garder", "Valeur exacte"), ("corriger", "Corriger")],
    "section": [("garder", "Laisser vide"), ("completer", "Compléter")],
    "signe": [("garder", "D'accord (non abordé)"), ("aborde", "Abordé et absent : l'ajouter")],
    "incertitude": [("garder", "Exact tel quel"), ("corriger", "Préciser ou corriger"), ("retirer", "Retirer du bilan")],
    "info": [("vu", "J'ai compris")],
    "cote_atteint": [("droit", "Droit"), ("gauche", "Gauche"), ("deux", "Les deux côtés"), ("sans", "Sans objet")],
    "libre": [("rien", "Rien à ajouter"), ("completer", "Ajouter ou corriger…")],
}
# Section vide : des réponses qui disent quelque chose au bilan, selon la section.
CHOIX_SECTION = {
    "examen_clinique.mesures": [("garder", "Aucune mesure prise"), ("completer", "Ajouter les mesures…")],
    "diagnostic.signes_alerte": [("garder", "Non recherchés"), ("normal", "Recherchés : aucun"), ("completer", "Préciser…")],
    "antecedents.medicaments": [("garder", "Aucun traitement"), ("completer", "Préciser…")],
    "examen_clinique": [("garder", "Non examiné"), ("normal", "Normal, sans particularité"), ("completer", "Préciser…")],
}
CHOIX_SECTION_DEFAUT = [("garder", "Rien à noter"), ("completer", "Préciser…")]
FACULTATIFS = {"libre"}             # sans réponse : « rien à ajouter »
SAISIE = {"corriger", "completer"}
NEUTRES = {"garder", "ignorer", "vu", "rien", "sans"}
TITRES = {"medicament": "Médicament", "dose": "Dose", "valeur": "Valeur introuvable dans la transcription",
          "mesure_perdue": "Mesure dite mais absente du bilan", "cote": "Côté", "cote_retire": "Côté retiré",
          "mesure": "Mesure", "section": "Section vide", "signe": "Signe d'alerte", "incertitude": "Incertitude",
          "info": "Enregistrement et transcription", "cote_atteint": "Côté atteint", "libre": "Pour finir"}

# Libellés lisibles des champs de l'extraction (« examen_clinique.palpation » → « Examen clinique › palpation »).
SECTIONS = {"identite_patient": "Identité", "contexte_pro_activite": "Travail et sport", "antecedents": "Antécédents",
            "antecedents_sociaux": "Mode de vie", "motif_consultation": "Motif", "objectifs_attentes_patient": "Attentes du patient",
            "imagerie_examens": "Imagerie et examens", "examen_clinique": "Examen clinique", "diagnostic": "Évaluation",
            "objectifs_reeducation": "Objectifs", "prise_en_charge": "Prise en charge",
            "elements_incertains_a_verifier": "Incertitudes"}
CHAMPS = {"age": "âge", "statut_professionnel": "profession", "exigences_physiques_travail": "exigences du travail",
          "activite_sportive_niveau": "sport", "medicaux": "médicaux", "chirurgicaux": "chirurgicaux", "allergies": "allergies",
          "medicaments": "traitements", "familiaux": "familiaux", "kine_reeducation": "rééducation antérieure",
          "plainte_principale": "plainte", "prescription_medicale": "prescription", "date_debut_ou_chirurgie": "début",
          "mecanisme_apparition": "mécanisme", "therapies_anterieures": "traitements antérieurs",
          "evolution_symptomes": "évolution", "intervention": "intervention", "cote": "côté", "chirurgien": "chirurgien",
          "etablissement": "établissement", "deroulement": "déroulement", "douleur": "douleur", "eva": "EVA",
          "eva_repos": "EVA au repos", "eva_effort": "EVA à l'effort", "localisation": "localisation",
          "horaire_rythme": "horaire", "facteurs_aggravants": "facteurs aggravants", "facteurs_soulageants": "facteurs soulageants",
          "inspection_morphostatique": "inspection", "palpation": "palpation", "bilan_articulaire": "bilan articulaire",
          "bilan_musculaire": "bilan musculaire", "bilan_neuro_sensitif": "bilan neurologique", "tests_specifiques_orthopediques":
          "tests spécifiques", "bilan_fonctionnel_avq": "bilan fonctionnel", "bilan_sportif_geste": "geste sportif",
          "scores_echelles": "scores", "mesures": "mesures", "diagnostic_kinesitherapique": "diagnostic kinésithérapique",
          "problemes_prioritaires": "problèmes prioritaires", "facteurs_pronostiques_drapeaux": "facteurs pronostiques",
          "signes_alerte": "signes d'alerte", "evolution": "évolution", "court_terme": "court terme", "moyen_terme": "moyen terme",
          "long_terme": "long terme", "plan_interventions_frequence_duree": "plan et fréquence",
          "moyens_techniques": "moyens techniques", "exercices_a_domicile": "exercices à domicile",
          "programme_hep": "exercices à domicile", "education_patient": "éducation", "equipement_materiel": "matériel",
          "references_autres_pros": "autres professionnels", "realise_ce_jour": "réalisé ce jour",
          "prochain_rendez_vous": "rendez-vous", "documents_demandes": "documents demandés"}


def lieu(champ):
    """Champ de l'extraction en clair ; un libellé déjà lisible (« compte rendu ») reste tel quel."""
    champ = str(champ or "")
    if not re.fullmatch(r"[a-z_]+(\[\d+\])?(\.[a-z_]+(\[\d+\])?)*", champ):
        return champ
    morceaux = []
    for i, m in enumerate(champ.split(".")):
        cle, rang = re.fullmatch(r"([a-z_]+)(?:\[(\d+)\])?", m).groups()
        nom = (SECTIONS if i == 0 else CHAMPS).get(cle) or CHAMPS.get(cle) or cle.replace("_", " ")
        morceaux.append(nom + (f" n° {rang}" if rang else ""))
    return " › ".join(morceaux)


def choix_section(champ):
    for prefixe in (champ, champ.split(".")[0]):
        if prefixe in CHOIX_SECTION:
            return CHOIX_SECTION[prefixe]
    return CHOIX_SECTION_DEFAUT


def _plat(t):
    t = unicodedata.normalize("NFD", t or "")
    return "".join(c for c in t if unicodedata.category(c) != "Mn").lower()


# Mots trop courants pour situer un passage : ils tirent l'extrait n'importe où (banc du 07/11/2026 : extraits
# « hors sujet » relevés dans 15 bilans sur 20).
COURANTS = set("""douleur douleurs patient patiente seance genou epaule cheville droite droit gauche depuis quand comme alors
apres avant encore toujours pendant niveau faire avoir etait cette votre notre quelque chose choses exercice exercices
bilan modele incertain incertaine precise preciser mentionne mentionnee transcription enregistrement valeur mesure
mesures exactement clairement probablement semble quelle quelles lequel laquelle entre autre autres plusieurs jambe
jambes cotes parce vraiment juste petit petite peu beaucoup aussi maintenant ensuite fois sont etre dans pour avec
sans plus moins tres bien rien tout tous toute toutes faut fallait dire disait parle parler indique indiquee non
precisee precises valeurs donnee donnees""".split())


def extrait(transcription, valeur, largeur=220):
    """Passage de la transcription qui réunit le plus de mots distinctifs de la valeur (nombres, mots de 5 lettres
    et plus hors mots courants), pour trancher sans tout relire. Si la valeur en a plusieurs, le passage doit en
    réunir au moins deux : rien plutôt qu'un passage hors sujet."""
    if not transcription or not valeur:
        return ""
    v = _plat(str(valeur)).replace("…", " ")
    nombres = list(dict.fromkeys(re.findall(r"\d+(?:[.,]\d+)?", v)))
    mots = [m for m in dict.fromkeys(re.findall(r"[a-z]{5,}", v)) if m not in COURANTS]
    candidats = nombres + mots
    if not candidats:
        return ""
    t = _plat(transcription)
    motif = lambda c: re.compile((r"(?<![\d.,])" + re.escape(c) + r"(?![\d])") if c[0].isdigit() else (r"\b" + re.escape(c)))
    positions = {c: [m.start() for m in motif(c).finditer(t)] for c in candidats}
    meilleur, score = None, 0
    for c, ps in positions.items():
        for i in ps:
            a, b = i - largeur // 2, i + largeur // 2
            s_ = sum(1 for c2, ps2 in positions.items() if any(a <= j <= b for j in ps2))
            if s_ > score:
                meilleur, score = i, s_
    if meilleur is None or score < min(2, len(candidats)):
        return ""
    a, b = max(0, meilleur - largeur // 2), min(len(transcription), meilleur + largeur // 2)
    return ("…" if a else "") + transcription[a:b].strip() + ("…" if b < len(transcription) else "")


def points(controle, incertitudes=(), trous=(), coupures=(), transcription=""):
    """Contrôle d'un bilan (job["controle"]) -> points à vérifier, du plus grave au moins grave."""
    c = controle or {}
    out = []

    vus = set()

    def ajouter(categorie, question, champ="", valeur="", probleme="", choix=None):
        question = question[:1].upper() + question[1:]
        cle = (categorie, _plat(str(valeur or "")).strip(" .…"))
        if cle[1] and cle in vus:           # même valeur signalée deux fois (banc du 07/11/2026 : jusqu'à six fois)
            return
        vus.add(cle)
        choix = choix or CHOIX[categorie]
        out.append({"id": f"v{len(out) + 1}", "categorie": categorie, "titre": TITRES[categorie], "question": question,
                    "champ": champ, "lieu": lieu(champ), "valeur": str(valeur or "")[:300], "probleme": probleme,
                    "extrait": extrait(transcription, valeur) if categorie not in ("info", "section", "cote_atteint", "libre") else "",
                    "choix": [{"id": i, "libelle": l} for i, l in choix],
                    "saisie": any(i in SAISIE for i, _ in choix)})

    mm = lambda s: f"{int(s) // 60} min {int(s) % 60:02d}"
    ca = c.get("cote_atteint")
    if ca:
        ajouter("cote_atteint", "Quel est le côté atteint ?", "", "", constat_cote(ca))
    for x in coupures or []:
        ajouter("info", f"Un moment de la séance n'a pas été enregistré ({x.get('raison', 'coupure')}, vers "
                        f"{mm(x.get('a_s', 0))}) : ce qui a été dit alors manque au bilan.")
    for x in trous or []:
        if not x.get("repare"):
            ajouter("info", f"Passage de {mm(x['debut_s'])} à {mm(x['fin_s'])} toujours incomplet dans la transcription : "
                            "il peut manquer au bilan.")
    if c.get("boucle_extraction"):
        ajouter("info", "L'extraction s'est répétée jusqu'à épuiser son budget : la fin du bilan peut manquer. "
                        "Relancez le bilan si c'est le cas.")
    for t in c.get("tronque") or []:
        ajouter("info", f"Réponse du modèle coupée ({t}) : la fin peut manquer.")
    for d in c.get("noms_inconnus") or []:
        ajouter("medicament", f"Médicament inconnu de la base publique : « {d.get('valeur')} » ?", d.get("champ"),
                d.get("valeur"), d.get("probleme"))
    for d in c.get("doses") or []:
        ajouter("dose", f"Dose inhabituelle : « {d.get('valeur')} » ?", d.get("champ"), d.get("valeur"), d.get("probleme"))
    for d in c.get("discordances_mesures") or []:
        if ca and "aucun côté écrit" in (d.get("probleme") or ""):
            continue                        # la question du côté atteint le demande déjà
        pb = d.get("probleme") or ""
        if "jamais prononcé près" in pb:      # côté déduit par le modèle : la question le dit en clair
            ajouter("cote", f"« {d.get('valeur')} » : le côté n'a pas été dit près de ces valeurs, le modèle l'a déduit. "
                            "Est-ce le bon côté ?", d.get("champ"), d.get("valeur"), pb)
        else:
            ajouter("cote" if "côté" in pb else "mesure", f"{pb} : « {d.get('valeur')} »", d.get("champ"), d.get("valeur"), pb)
    for d in c.get("appariements") or []:
        ajouter("cote", f"Côté à confirmer : « {d.get('valeur')} » ({d.get('probleme')})", d.get("champ"), d.get("valeur"),
                d.get("probleme"))
    for d in c.get("cotes_sans_ancrage") or []:
        retire = "retir" in (d.get("probleme") or "")
        if retire and ca:                   # côté retiré faute d'ancrage : la question du côté atteint le tranche
            continue
        ajouter("cote_retire" if retire else "cote", f"{d.get('probleme')} : « {d.get('valeur')} »", d.get("champ"),
                d.get("valeur"), d.get("probleme"))
    for d in c.get("ecarts") or []:
        ajouter("mesure", f"Écart incohérent : « {d.get('valeur')} » ({d.get('probleme')})", d.get("champ"),
                d.get("valeur"), d.get("probleme"))
    for d in c.get("mesures_manquantes") or []:
        ajouter("mesure_perdue", f"Dit pendant la séance mais absent du bilan : « {d.get('valeur')} »", d.get("champ"),
                d.get("valeur"), d.get("probleme"))
    for d in c.get("signes_alerte_retires") or []:
        ajouter("signe", f"Signe d'alerte jamais abordé, retiré du bilan : « {d.get('valeur')} »", d.get("champ"),
                d.get("valeur"), d.get("probleme"))
    for d in c.get("anomalies") or []:
        pb = d.get("probleme") or ""
        if ca and re.match(r"le côté « \w+ » n'est jamais prononcé", pb):
            continue                        # la question du côté atteint le tranche (banc du 08/11/2026 : 8 fois le même côté)
        ajouter("valeur", f"{d.get('probleme', 'Introuvable dans la transcription').capitalize()} : « {d.get('valeur')} »",
                d.get("champ"), d.get("valeur"), d.get("probleme"))
    for d in c.get("manquantes") or []:
        ajouter("section", f"Rien n'est noté pour « {lieu(d.get('champ'))} » : qu'en dire ?", d.get("champ"), "",
                d.get("probleme"), choix_section(d.get("champ") or ""))
    for x in incertitudes or []:
        ajouter("incertitude", f"Le modèle n'est pas sûr de ce point : « {x} »", "", x, "incertitude déclarée")
    if out:                                 # seule, la question ouverte ne bloquerait le bilan que pour elle
        ajouter("libre", "Autre chose à corriger ou à ajouter au bilan ? (facultatif)")
    return out


def cotes_nommes(texte):
    """(droite, gauche) : nombre de fois où chaque côté est nommé (« le droit de », « tout droit » exclus)."""
    plat = re.sub(r"\btout droit\b|\bdroits? (de|d'|a |au |aux )|\b(le|du|au|pas|aucun) droits?\b", " ", _plat(texte))
    dits = re.findall(r"\b(droite?s?|gauches?)\b", plat)
    gauche = sum(d.startswith("gauche") for d in dits)
    return len(dits) - gauche, gauche


def releve_cote(cr, transcription, notes=""):
    """Ce que la séance et le compte rendu disent des côtés : la question du côté atteint est posée dès que
    l'un des deux en nomme un. None sinon (rachis, bilan sans côté)."""
    seance, compte = cotes_nommes(f"{transcription or ''}\n{notes or ''}"), cotes_nommes(cr or "")
    if not any(seance) and not any(compte):
        return None
    return {"seance": list(seance), "cr": list(compte)}


def constat_cote(ca):
    (sd, sg), (cd, cg) = ca.get("seance") or (0, 0), ca.get("cr") or (0, 0)
    fois = lambda n: f"{n} fois" if n > 1 else "1 fois"
    seance = " et ".join(x for x in (f"« droite » {fois(sd)}" if sd else "", f"« gauche » {fois(sg)}" if sg else "") if x)
    cr = ("ne nomme aucun côté" if not (cd or cg) else
          " et ".join(x for x in (f"dit « droite » {fois(cd)}" if cd else "", f"« gauche » {fois(cg)}" if cg else "") if x))
    return f"Le compte rendu {cr}" + (f" ; la séance dit {seance}." if seance else ".")


SECTIONS_ATTEINTE = re.compile(r"motif|evaluation|diagnostic|synthese|objectif")


def _parties_atteinte(texte):
    """Texte des sections qui nomment la région atteinte (motif, évaluation) : là doit figurer le côté."""
    parts = re.split(r"(?m)^(#{1,4} .+)$", texte or "")
    return "\n".join(parts[i + 1] for i in range(1, len(parts) - 1, 2) if SECTIONS_ATTEINTE.search(_plat(parts[i])))


def consigne_cote(texte, choix):
    """Réponse à « côté atteint » → consigne pour la passe de corrections, seulement si le bilan ne le dit pas déjà."""
    if choix not in ("droit", "gauche", "deux"):
        return ""
    if choix == "deux":
        if re.search(r"bilateral|deux cotes|des deux|aux deux", _plat(texte)):
            return ""
        return ("Côté atteint : les deux côtés (confirmé par le praticien). Indique-le dans le motif et l'évaluation, là où "
                "la région atteinte est nommée.")
    d, g = cotes_nommes(_parties_atteinte(texte))
    bon, autre = (d, g) if choix == "droit" else (g, d)
    mot, contraire = ("droit", "gauche") if choix == "droit" else ("gauche", "droit")
    if bon and not autre:
        return ""
    # Motif et évaluation muets ou partagés : le bilan entier tranche. Un bilan qui nomme surtout l'autre côté est
    # écrit du mauvais côté (banc du 07/11/2026 : huit questions pour corriger le côté ligne par ligne).
    td, tg = cotes_nommes(texte)
    tbon, tautre = (td, tg) if choix == "droit" else (tg, td)
    if tautre >= 2 * tbon + 2 and (autre or not bon):
        return (f"Côté atteint : {mot} (confirmé par le praticien). Le bilan est écrit du côté {contraire} presque partout : "
                f"place l'atteinte du côté {mot} dans tout le bilan (motif, douleur, examen, tests, évaluation). Là où le bilan "
                f"compare au côté {mot} présenté comme sain, ce côté sain est en réalité le côté {contraire}. N'invente aucune "
                f"mesure et ne change aucune valeur.")
    if autre and not bon:
        return (f"Côté atteint : {mot} (confirmé par le praticien). Le bilan place l'atteinte du côté {contraire} dans le "
                f"motif ou l'évaluation : corrige ces mentions de l'atteinte. Ne touche pas aux mesures qui comparent les deux "
                f"côtés ni à ce qui concerne explicitement le côté sain.")
    if bon and autre:
        return ""
    return (f"Côté atteint : {mot} (confirmé par le praticien). Le bilan ne le dit pas : précise « {mot} » ou « {mot}e » là "
            f"où il nomme la région atteinte (motif, douleur, évaluation), sans toucher aux mesures qui comparent les deux côtés.")


def reponses_valides(liste, reponses):
    """{id: {"choix": …, "texte": …}} contrôlé contre la liste ; renvoie (réponses, manquants)."""
    out, manquants = {}, []
    for p in liste:
        r = (reponses or {}).get(p["id"]) or {}
        choix = str(r.get("choix") or "")
        if not choix and p["categorie"] in FACULTATIFS:
            choix = p["choix"][0]["id"]
        if choix not in {c["id"] for c in p["choix"]}:
            manquants.append(p["id"])
            continue
        texte = " ".join(str(r.get("texte") or "").split())[:500]
        if choix in SAISIE and not texte:
            manquants.append(p["id"])
            continue
        out[p["id"]] = {"choix": choix, "texte": texte}
    return out, manquants


def sans_bloc(texte):
    """Bilan sans sa section « À vérifier » (ajoutée à la fin par le traitement)."""
    i = texte.find(SEPARATEUR)
    return texte[:i].rstrip() + "\n" if i >= 0 else texte


def corrections(liste, reponses, texte=""):
    """Réponses -> (remplacements directs [(avant, après)], consignes pour le modèle [texte]). texte : le bilan,
    pour ne demander le côté atteint que s'il y manque."""
    directs, consignes = [], []
    for p in liste:
        r = reponses.get(p["id"])
        if not r or r["choix"] in NEUTRES:
            continue
        v, t, champ = p["valeur"].rstrip("…").strip(), r["texte"], p.get("lieu") or p["champ"] or p["titre"]
        ch = r["choix"]
        libelles = {c["id"]: c["libelle"] for c in p["choix"]}
        if p["categorie"] == "cote_atteint":
            c_ = consigne_cote(texte, ch)
            if c_:
                consignes.append(c_)
        elif p["categorie"] == "libre":
            consignes.append(f"Précision du praticien, à intégrer au bilan à la place qui convient : « {t} ».")
        elif p.get("reformulee") and (re.fullmatch(r"r\d", ch) or ch == "corriger"):
            reponse = libelles.get(ch) if ch != "corriger" else t
            consignes.append(f"{champ + ' : ' if p.get('lieu') else ''}à la question « {p['question']} », le praticien répond : "
                             f"« {reponse} ». Corrige ou complète le bilan en conséquence ; si la réponse confirme ce qui "
                             f"est écrit, ne change rien.")
        elif ch == "nondit":
            consignes.append(f"{champ + ' : ' if p.get('lieu') else ''}à la question « {p['question']} », le praticien répond que "
                             f"ce n'a pas été dit pendant la séance : retire du bilan ce détail s'il y figure (ou écris « non "
                             f"précisé » s'il est nécessaire à la phrase), sans rien inventer à la place.")
        elif ch == "normal":
            consignes.append(f"{champ} : " + ("signes d'alerte recherchés, aucun présent" if "signes_alerte" in p["champ"]
                                              else "examiné, normal, sans particularité") + " ; l'indiquer en une ligne.")
        elif ch == "corriger" and p["categorie"] in ("medicament", "dose", "valeur", "mesure", "cote") and v:
            directs.append((v, t, f"{champ} : « {v} » doit devenir « {t} »"))
        elif ch == "corriger":
            consignes.append(f"{champ} : « {v} » — le praticien précise : « {t} »." if v else f"{champ} : {t}")
        elif ch == "retirer":
            consignes.append(f"{champ} : retirer « {v} » du bilan (non confirmé par le praticien).")
        elif ch == "ajouter":
            consignes.append(f"{champ} : ajouter « {v} », dit pendant la séance, à la place qui convient.")
        elif ch == "inverser":
            consignes.append(f"{champ} : « {v} » — inverser le côté (droite ↔ gauche) pour cette donnée seulement.")
        elif ch in ("droit", "gauche"):
            consignes.append(f"{champ} : « {v} » — préciser le côté {ch}.")
        elif ch == "completer":
            consignes.append(f"Section {champ} : la compléter avec : « {t} ».")
        elif ch == "aborde":
            consignes.append(f"Signes d'alerte : « {v} » a été recherché et est absent ; l'indiquer.")
    return directs, consignes


def appliquer_directs(texte, directs):
    """Remplacement d'une valeur qui figure UNE seule fois dans le bilan ; sinon, au modèle."""
    restants = []
    for avant, apres, consigne in directs:
        if avant and texte.count(avant) == 1:
            texte = texte.replace(avant, apres)
        else:
            restants.append(consigne)
    return texte, restants


def sortie_corrections(sortie):
    """Réponse de la passe de corrections ramenée au seul bilan : le modèle recopie souvent l'intitulé
    « ### BILAN » de sa consigne en tête (et parfois la liste des corrections à la fin). Constaté le
    27/10/2026 : ce titre en trop faisait refuser 4 passes sur 4 dont les corrections étaient justes."""
    t = re.sub(r"^```(?:markdown)?\s*|\s*```$", "", (sortie or "").strip()).strip()
    t = re.sub(r"^#{1,4}\s*BILAN\s*\n+", "", t)
    t = re.split(r"\n#{1,4}\s*CORRECTIONS DU PRATICIEN\b", t)[0]
    return t.strip() + "\n"


def controle_passe(avant, apres, consignes):
    """La passe du modèle n'a-t-elle changé que ce qui était demandé ? Même structure de titres, et
    un volume de texte retiré ou ajouté à la mesure du nombre de corrections (une correction retire
    ou ajoute au plus une phrase ou deux)."""
    if not apres or len(apres) < 0.7 * len(avant):
        return False
    titres = lambda t: re.findall(r"(?m)^#{1,4} .+$", t)
    if titres(avant) != titres(apres):
        return False
    retire = ajoute = 0
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, avant, apres, autojunk=False).get_opcodes():
        if tag in ("replace", "delete"):
            retire += i2 - i1
        if tag in ("replace", "insert"):
            ajoute += j2 - j1
    n = max(1, len(consignes))
    return retire <= 150 * n + 0.02 * len(avant) and ajoute <= 400 * n + 0.02 * len(avant)


def bloc_a_reporter(consignes):
    if not consignes:
        return ""
    return ("\n\n---\n\n## Corrections à reporter\n\nLa correction automatique n'a pas pu les appliquer sans "
            "toucher au reste du bilan : à reporter à la main, puis retirer cette section.\n\n"
            + "\n".join(f"- {c}" for c in consignes) + "\n")


# ---------- Questions reformulées par le modèle (prompts/13_questions_system.md) ----------
# Les doutes du modèle (« Latéralité du genou atteint : le praticien mentionne… ») et les mesures perdues (un bout
# brut de la transcription) faisaient 70 % des questions du banc du 07/11/2026, sans réponse possible en un clic.
REFORMULABLES = ("valeur", "incertitude", "mesure_perdue")
MAX_REFORMULEES = 14
# Banc du 07/11/2026 (praticien simulé, 35B) : 10,7 questions par bilan (jusqu'à 18), les doutes du modèle utiles
# 4 fois sur 10 ; ceux que le modèle juge sans enjeu sont retirés, les autres limités à 6.
MAX_INCERTITUDES = 6
# Réponses que l'application ajoute elle-même : le modèle les recopie parfois (« Exact tel quel » deux fois).
FIXES = re.compile(r"(exact|correct|confirme)s?( tel quel)?\W*$|retirer( du bilan)?\W*$|non dit|autre reponse|preciser ou corriger")
NEGATIVE = re.compile(r"(ne (pas|rien)|ignorer|aucun changement|laisser tel|garder tel|je ne sais|autre\b)")
QUOI = {"valeur": "Valeur écrite dans le bilan mais introuvable dans l'enregistrement",
        "incertitude": "Doute du modèle de rédaction",
        "mesure_perdue": "Mesure dite pendant la séance, absente du bilan"}


def a_reformuler(liste):
    return [p for p in liste if p["categorie"] in REFORMULABLES][:MAX_REFORMULEES]


def entree_questions(liste):
    """Entrée de la passe : les points à reformuler, chacun avec le passage de la transcription qui le concerne."""
    lignes = []
    for p in a_reformuler(liste):
        quoi = QUOI[p["categorie"]]
        lignes.append(f"[{p['id']}] {quoi} : {p['valeur']}" + (f"\nPassage de l'enregistrement : {p['extrait']}" if p.get("extrait") else ""))
    return "\n\n".join(lignes)


def schema_questions(liste):
    ids = [p["id"] for p in a_reformuler(liste)]
    return {"type": "object", "additionalProperties": False, "required": ["questions"], "properties": {"questions": {
        "type": "array", "maxItems": len(ids), "items": {
            "type": "object", "additionalProperties": False,
            "required": ["id", "question", "reponses", "seulement_le_cote", "important"],
            "properties": {"id": {"type": "string", "enum": ids}, "question": {"type": "string", "maxLength": 220},
                           "reponses": {"type": "array", "maxItems": 3, "items": {"type": "string", "maxLength": 90}},
                           "seulement_le_cote": {"type": "boolean"}, "important": {"type": "boolean"}}}}}}


# Premiers mots courants d'une réponse (la majuscule n'en fait pas un nom propre).
DEBUTS = set("""ajouter retirer garder oui non droit droite gauche deux aucun aucune normal normale exact exacte
corriger avant apres sans avec pour dans entre plus moins environ depuis une les des seulement uniquement pas
inverser preciser confirme confirmee newton newtons kilogrammes degres centimetres""".split())


def reponse_fondee(reponse, sources):
    """Une réponse proposée ne doit apporter ni nombre ni nom propre absents de la séance, du bilan et du point
    (banc du 07/11/2026 : médicament jamais prononcé, doses « en milliers de mg », années fausses)."""
    if not sources:
        return True
    plat = _plat(sources)
    nombres = set(re.findall(r"\d+(?:[.,]\d+)?", plat))
    for n in re.findall(r"\d+(?:[.,]\d+)?", _plat(reponse)):
        if n not in nombres and n.replace(",", ".") not in nombres and n.replace(".", ",") not in nombres:
            return False
    for k, m in enumerate(str(reponse).split()):
        m = m.strip(".,;:!?()«»\"'")
        if k == 0 and _plat(m) in DEBUTS:
            continue
        if len(m) >= 4 and m[:1].isupper() and not m.isupper() and _plat(m) not in plat:
            return False
    return True


def appliquer_questions(liste, donnees, sources=""):
    """Questions du modèle → points : question claire, ses réponses à cliquer, plus « Ne rien changer » et « Autre
    réponse… ». Un point mal reformulé (question vide, moins d'une réponse fondée) garde sa forme d'origine ; un doute
    qui ne porte que sur le côté atteint disparaît quand la question du côté est posée ; un doute sans enjeu aussi,
    et il en reste MAX_INCERTITUDES au plus. sources : transcription + bilan, pour écarter les réponses inventées."""
    par_id = {}
    for q in (donnees or {}).get("questions") or []:
        if isinstance(q, dict) and q.get("id") not in par_id:
            par_id[q.get("id")] = q
    cote_pose = any(p["categorie"] == "cote_atteint" for p in liste)
    out, n_incert = [], 0
    for p in liste:
        q = par_id.get(p["id"]) if p["categorie"] in REFORMULABLES else None
        if p["categorie"] == "incertitude":
            if q and ((q.get("seulement_le_cote") and cote_pose) or q.get("important") is False):
                continue
            n_incert += 1
            if n_incert > MAX_INCERTITUDES:
                continue
        reponses = [" ".join(str(r).split()) for r in (q or {}).get("reponses") or [] if str(r).strip()]
        # « Ne pas ajouter », « Ne rien changer » : l'application les propose déjà.
        reponses = [r for r in dict.fromkeys(reponses) if not NEGATIVE.match(_plat(r)) and not FIXES.match(_plat(r))
                    and (not sources or reponse_fondee(r, f"{sources}\n{p.get('valeur', '')}"))][:3]
        question = " ".join(str((q or {}).get("question") or "").split())
        # Une valeur introuvable se tranche sans réponse du modèle : « Exact tel quel », « Retirer », « Autre réponse ».
        if q and question and (reponses or p["categorie"] == "valeur"):
            garder = "Exact tel quel" if p["categorie"] == "valeur" else "Ne rien changer"
            p = dict(p, question=question[:1].upper() + question[1:], reformulee=True, question_origine=p["question"],
                     choix=[{"id": f"r{i}", "libelle": r} for i, r in enumerate(reponses, 1)]
                     + [{"id": "garder", "libelle": garder}]
                     + ([{"id": "retirer", "libelle": "Retirer du bilan"}] if p["categorie"] == "valeur" else [])
                     # Date, nom, détail jamais précisés en séance (banc du 08/11/2026 : « pas de réponse « inconnue » »).
                     + ([{"id": "nondit", "libelle": "Non dit pendant la séance"}] if p["categorie"] == "incertitude" else [])
                     + [{"id": "corriger", "libelle": "Autre réponse…"}],
                     saisie=True)
        out.append(p)
    for i, p in enumerate(out, 1):
        p["id"] = f"v{i}"
    return out
