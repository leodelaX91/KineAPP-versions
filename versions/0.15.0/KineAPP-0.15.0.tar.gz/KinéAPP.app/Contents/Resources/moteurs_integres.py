# -*- coding: utf-8 -*-
"""Moteurs intégrés à l'app : Splash (principal), llama.cpp (secours), whisper.cpp (transcription).

Ils vivent DANS l'app (dossier protégé : personne ne peut les remplacer sans mot de passe
administrateur). Ils s'installent et se mettent à jour depuis l'app, sans autre logiciel :

1. Au plus une fois par jour, l'app lit sur GitHub la dernière version publiée (rien n'est envoyé
   qu'une demande de page publique) et prévient s'il y en a une nouvelle.
2. À la demande du praticien, elle télécharge l'archive, vérifie son empreinte SHA-256 publiée avec
   la version, et essaie le programme (« --version ») avant de le proposer.
3. Le mot de passe administrateur installe la version reçue (outils/installer.sh --moteurs-seuls,
   outils/moteur_recu.py). L'ancienne est gardée à côté : on peut y revenir.

whisper.cpp est publié sans ses bibliothèques ggml : elles viennent de la version de llama.cpp
indiquée dans son archive, téléchargée et vérifiée de la même façon.
"""
import json, os, re, shutil, subprocess, tarfile, threading, time, urllib.request

import journal as JO
import materiel as MAT

CODE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
DEMANDE = os.path.join(DATA, "moteurs_a_reprendre.json")      # lu par outils/installer.sh
VERSIONS = os.path.join(DATA, "moteurs_versions.json")        # dernière lecture des versions publiées
RECUS = os.path.join(DATA, "moteurs_recus")
HOMEBREW_SPLASH = os.environ.get("KINEAPP_SPLASH") or "/opt/homebrew/opt/splash/libexec"
API = "https://api.github.com/repos/"
FICHIER_VERSION = "VERSION_KINEAPP"                           # écrit à l'installation d'une version reçue
INTERVALLE_S = 24 * 3600
MOTEURS = {
    "splash": {"nom": "Splash", "binaire": "install/launcher.py", "dossier": "splash",
               "depot": "incoai/splash", "archive": r"^splash-.*-arm64-macos(\d+)\.tar\.gz$"},
    "llama": {"nom": "llama.cpp", "binaire": "llama-server", "dossier": "llama-cpp",
              "depot": "unslothai/llama.cpp", "archive": r"^llama-.*-bin-macos-arm64\.tar\.gz$"},
    "whisper": {"nom": "whisper.cpp", "binaire": "whisper-server", "dossier": "whisper-cpp", "essai": "--help",
                "depot": "unslothai/whisper.cpp", "archive": r"^whisper-.*-macos-arm64-slim\.tar\.gz$"},
}
TELECHARGEMENT = {"phase": "", "moteur": "", "recu": 0, "total": 0, "erreur": ""}
_ANNULER = threading.Event()
_VERROU = threading.Lock()


def integre(cle, code=None):
    """Chemin du moteur intégré à l'app (vide s'il n'y est pas)."""
    p = os.path.join(code or CODE, "outils", MOTEURS[cle]["dossier"], MOTEURS[cle]["binaire"])
    return p if os.path.isfile(p) else ""


def dossier_splash(code=None):
    """Dossier de Splash : celui de l'app ; avant sa première installation, celui de Homebrew."""
    d = os.path.join(code or CODE, "outils", "splash")
    if os.path.isfile(os.path.join(d, MOTEURS["splash"]["binaire"])):
        return d
    return HOMEBREW_SPLASH if os.path.isfile(os.path.join(HOMEBREW_SPLASH, MOTEURS["splash"]["binaire"])) else ""


def _version_info(chemin):
    """Étiquette de version d'un fichier d'information livré avec le moteur (JSON ou BUILD_INFO.txt)."""
    try:
        if chemin.endswith(".json"):
            d = json.load(open(chemin, encoding="utf-8"))
            return str(d.get("release_tag") or d.get("packaging_tag") or d.get("tag") or d.get("version") or "")
        for ligne in open(chemin, encoding="utf-8", errors="ignore"):
            if ligne.lower().startswith(("packaging tag:", "release tag:")):
                return ligne.split(":", 1)[1].strip()
    except (OSError, ValueError) as e_tol:
        JO.ignoree(e_tol)
    return ""


INFOS = ("release.json", "UNSLOTH_PREBUILT_INFO.json", "UNSLOTH_WHISPER_PREBUILT_INFO.json", "BUILD_INFO.txt")


def version_dossier(d):
    """Version d'une copie de moteur, d'après ce que l'installateur ou l'éditeur a écrit à côté."""
    try:
        return open(os.path.join(d, FICHIER_VERSION), encoding="utf-8").read().strip()
    except OSError:
        pass
    for f in INFOS:
        v = _version_info(os.path.join(d, f)) if os.path.isfile(os.path.join(d, f)) else ""
        if v:
            return v
    return ""


def version_integree(cle, code=None):
    return version_dossier(os.path.join(code or CODE, "outils", MOTEURS[cle]["dossier"]))


def precedente(cle, code=None):
    """Version gardée à côté de la version intégrée, après une mise à jour du moteur."""
    return version_dossier(os.path.join(code or CODE, "outils", MOTEURS[cle]["dossier"] + "-precedent"))


def essayer(commande, option="--version"):
    """Le programme se lance-t-il ? (60 s au plus). Renvoie (ok, dernière ligne)."""
    try:
        r = subprocess.run(list(commande) + [option], capture_output=True, text=True, timeout=60)
        sortie = ((r.stdout or "") + (r.stderr or "")).strip().splitlines()
        return r.returncode == 0, (sortie[-1] if sortie else "")[:160]
    except Exception as e:
        return False, str(e)[:160]


# ── versions publiées ────────────────────────────────────────────────────────────────────────
def _lire_json(p):
    try:
        return json.load(open(p, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ecrire_json(p, d):
    os.makedirs(DATA, exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def _publication(cle, base=None, etiquette=None):
    """Version publiée d'un moteur (la dernière, ou celle de l'étiquette) : {version, url, sha256, taille, date, macos_min}."""
    m = MOTEURS[cle]
    fin = f"releases/tags/{etiquette}" if etiquette else "releases/latest"
    req = urllib.request.Request(f"{base or API}{m['depot']}/{fin}",
                                 headers={"User-Agent": "KineAPP", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        d = json.load(r)
    for a in d.get("assets") or []:
        trouve = re.match(m["archive"], a.get("name") or "")
        empreinte = str(a.get("digest") or "")
        if trouve and empreinte.startswith("sha256:"):
            return {"version": str(d.get("tag_name") or ""), "url": a["browser_download_url"], "archive": a["name"],
                    "sha256": empreinte.split(":", 1)[1], "taille": int(a.get("size") or 0),
                    "date": str(d.get("published_at") or "")[:10],
                    "macos_min": int(trouve.group(1)) if trouve.groups() else 0}
    raise RuntimeError(f"Aucune archive vérifiable pour Mac dans la dernière version de {m['nom']}.")


def verifier(force=False, base=None):
    """Lit les dernières versions publiées, au plus une fois par jour sauf demande. Renvoie les
    versions connues. Un refus du réseau ou une panne n'empêche rien : l'erreur est gardée."""
    d = _lire_json(VERSIONS)
    if not force and time.time() - float(d.get("verifie") or 0) < INTERVALLE_S:
        return d
    d["verifie"], d["erreur"] = time.time(), ""
    for cle in MOTEURS:
        try:
            d[cle] = _publication(cle, base)
        except Exception as e:
            d["erreur"] = str(e)[:300] or type(e).__name__
            JO.ignoree(e)
    _ecrire_json(VERSIONS, d)
    return d


def _plus_recente(cle, connues):
    """La version publiée, si elle diffère de celle de l'app et convient à ce macOS."""
    p = connues.get(cle) or {}
    if not p.get("version") or p["version"].lstrip("v") == version_integree(cle).lstrip("v"):
        return None
    return p


# ── téléchargement ───────────────────────────────────────────────────────────────────────────
def archive_recue(cle, version):
    return os.path.join(RECUS, f"{cle}-{re.sub(r'[^A-Za-z0-9._-]', '_', version)}.tar.gz")


def _telecharger(cle, p, nom=None):
    import hashlib
    os.makedirs(RECUS, exist_ok=True)
    dest = archive_recue(nom or cle, p["version"])
    part = dest + ".part"
    deja = os.path.getsize(part) if os.path.isfile(part) else 0
    if shutil.disk_usage(RECUS).free < p["taille"] * 4 + 2 * 1024**3:      # l'archive et son contenu décompressé
        raise RuntimeError("Espace disque insuffisant pour cette version.")
    TELECHARGEMENT.update(recu=deja, total=p["taille"])
    req = urllib.request.Request(p["url"], headers={"User-Agent": "KineAPP"})
    if deja:
        req.add_header("Range", f"bytes={deja}-")
    with urllib.request.urlopen(req, timeout=60) as rep, open(part, "ab" if deja else "wb") as f:
        if deja and rep.status != 206:
            f.seek(0); f.truncate(); TELECHARGEMENT["recu"] = 0
        while True:
            if _ANNULER.is_set():
                raise InterruptedError
            bloc = rep.read(1024 * 256)
            if not bloc:
                break
            f.write(bloc)
            TELECHARGEMENT["recu"] += len(bloc)
    TELECHARGEMENT["phase"] = "vérification"
    h = hashlib.sha256()
    with open(part, "rb") as f:
        for bloc in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloc)
    if h.hexdigest() != p["sha256"]:
        os.remove(part)
        raise RuntimeError("L'archive reçue ne correspond pas à l'empreinte publiée : elle a été supprimée.")
    os.replace(part, dest)
    return dest


def _ggml_requis(archive):
    """whisper.cpp : l'étiquette de la version de llama.cpp qui fournit ses bibliothèques ggml."""
    with tarfile.open(archive, "r:gz") as t:
        for m in t.getmembers():
            if os.path.basename(m.name) == "UNSLOTH_WHISPER_PREBUILT_INFO.json":
                etiquette = str(json.load(t.extractfile(m)).get("requires_llama_tag") or "")
                if re.fullmatch(r"[A-Za-z0-9._-]+", etiquette):
                    return etiquette
    raise RuntimeError("Archive de whisper.cpp sans indication de ses bibliothèques.")


def essayer_archive(cle, archive, ggml=""):
    """Décompresse dans un dossier temporaire avec le même code que l'installateur, puis lance le programme."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("moteur_recu", os.path.join(CODE, "outils", "moteur_recu.py"))
    MR = importlib.util.module_from_spec(spec); spec.loader.exec_module(MR)
    essai = os.path.join(RECUS, f"essai-{cle}")
    shutil.rmtree(essai, ignore_errors=True)
    try:
        MR.extraire(archive, essai, MOTEURS[cle]["binaire"])
        if ggml:
            MR.ajouter_ggml(ggml, essai)
        if cle == "splash":
            cmd = [os.path.join(essai, "python", "bin", "python3"), "-u", os.path.join(essai, "install", "launcher.py")]
        else:
            cmd = [os.path.join(essai, MOTEURS[cle]["binaire"])]
        return essayer(cmd, MOTEURS[cle].get("essai", "--version"))
    finally:
        shutil.rmtree(essai, ignore_errors=True)


def telecharger_fond(cle):
    """Télécharge, vérifie et essaie la dernière version de ce moteur, puis note la demande."""
    p = _plus_recente(cle, _lire_json(VERSIONS))
    if cle not in MOTEURS or not p:
        raise RuntimeError("Aucune nouvelle version à télécharger.")
    if p.get("macos_min") and MAT.macos()[0] < p["macos_min"]:
        raise RuntimeError(f"Cette version demande macOS {p['macos_min']} ou plus récent.")
    with _VERROU:
        if TELECHARGEMENT["phase"] in ("téléchargement", "vérification", "essai"):
            raise RuntimeError("Un téléchargement est déjà en cours.")
        _ANNULER.clear()
        TELECHARGEMENT.update(phase="téléchargement", moteur=cle, recu=0, total=p["taille"], erreur="")

    def travail():
        try:
            archive = _telecharger(cle, p)
            supplement = {}
            if cle == "whisper":
                g = _publication("llama", etiquette=_ggml_requis(archive))
                TELECHARGEMENT["phase"] = "téléchargement"
                supplement = {"archive_ggml": _telecharger("llama", g, nom="ggml"), "sha256_ggml": g["sha256"]}
            TELECHARGEMENT["phase"] = "essai"
            ok, ligne = essayer_archive(cle, archive, supplement.get("archive_ggml", ""))
            if not ok:
                raise RuntimeError(f"Cette version ne se lance pas sur ce Mac : {ligne}")
            d = demandes()
            d[cle] = dict(quoi="telecharge", version=p["version"], archive=archive, sha256=p["sha256"], **supplement)
            _ecrire_json(DEMANDE, d)
            TELECHARGEMENT.update(phase="prêt", erreur="")
        except InterruptedError:
            TELECHARGEMENT.update(phase="annulé", erreur="")
        except Exception as e:
            TELECHARGEMENT.update(phase="erreur", erreur=str(e) or type(e).__name__)
    threading.Thread(target=travail, daemon=True).start()


def annuler():
    if TELECHARGEMENT["phase"] == "téléchargement":
        _ANNULER.set()
        return True
    return False


# ── demandes prises en compte par l'installateur ─────────────────────────────────────────────
def demandes():
    """{moteur: {"quoi": "telecharge" | "precedent", "version": version attendue, …}}"""
    d = _lire_json(DEMANDE)
    return {k: v for k, v in d.items() if k in MOTEURS and isinstance(v, dict)
            and v.get("quoi") in ("telecharge", "precedent")}


def demander(cle, quoi):
    """quoi : « precedent » (revenir à la version d'avant) ou « annuler »."""
    if cle not in MOTEURS or quoi not in ("precedent", "annuler"):
        raise ValueError("demande inconnue")
    d = demandes()
    if quoi == "precedent":
        if not precedente(cle):
            raise RuntimeError("Aucune version précédente n'est gardée dans l'app.")
        d[cle] = {"quoi": quoi, "version": precedente(cle)}
    else:
        d.pop(cle, None)
    _ecrire_json(DEMANDE, d)
    return d


def solder():
    """Au démarrage : une demande dont la version est maintenant celle de l'app est faite (son archive part)."""
    d = demandes()
    restes = {k: v for k, v in d.items() if not (v.get("version") and v["version"] == version_integree(k))}
    if restes != d:
        for v in d.values():
            if v not in restes.values():
                for a in (v.get("archive"), v.get("archive_ggml")):
                    if a and os.path.dirname(a) == RECUS:
                        try: os.remove(a)
                        except OSError as e_tol: JO.ignoree(e_tol)
        _ecrire_json(DEMANDE, restes)
    return restes


def nouvelles():
    """Moteurs dont une nouvelle version est publiée : [(nom, version)]."""
    connues = _lire_json(VERSIONS)
    return [(MOTEURS[c]["nom"], _plus_recente(c, connues)["version"]) for c in MOTEURS if _plus_recente(c, connues)]


def etat():
    d, connues = demandes(), _lire_json(VERSIONS)
    out = {}
    for cle, m in MOTEURS.items():
        p = _plus_recente(cle, connues)
        trop_ancien = bool(p and p.get("macos_min") and MAT.macos()[0] < p["macos_min"])
        out[cle] = {"nom": m["nom"], "integre": bool(integre(cle)), "version": version_integree(cle),
                    "publiee": (p or {}).get("version", ""), "date": (p or {}).get("date", ""),
                    "taille": (p or {}).get("taille", 0), "macos_trop_ancien": trop_ancien,
                    "precedente": precedente(cle), "demande": (d.get(cle) or {}).get("quoi", ""),
                    "demande_version": (d.get(cle) or {}).get("version", "")}
    return {"moteurs": out, "telechargement": TELECHARGEMENT, "verifie": connues.get("verifie") or 0,
            "erreur": connues.get("erreur") or ""}
