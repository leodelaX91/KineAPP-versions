# -*- coding: utf-8 -*-
"""Questionnaires et échelles cliniques : définitions, calcul des scores, historique patient.

Chaque instrument est un fichier JSON dans questionnaires/ :
  id, nom, nom_court, domaines[], licence ("libre" | "licence"), reference, consigne,
  diffusion : "libre" | "permission" | "licence" — statut si l'app est diffusée à d'autres (revue du
              17/10/2026, docs/LICENCES_QUESTIONNAIRES.md),
  mode : "items" (formulaire complet) ou "score" (instrument sous licence : seul le score
         obtenu sur le formulaire officiel est saisi, ses questions ne sont pas reproduites),
  items : [{id, texte, type: "choix" | "nombre" | "texte", options: [{texte, valeur, code?}], bornes, min, max,
            unite, section, facultatif, aide}]
            (« code » distingue deux options de même valeur ; valeur "na" = option non comptée)
  calcul : {"total": {methode, items, ...}, "sous_scores": [{nom, methode, items, ...}]}
  interpretation : {"<nom du score ou total>": [{"min", "max", "texte"}]}
  interpretation_globale : [{"si": [[score, "<=" | ">=" | "<" | ">", seuil], ...], "texte"}] (première règle vraie)
  alertes : [{"item", "min", "texte"}] (ex. PHQ-9 item 9)
  exclusifs : [[ids…]] (une seule réponse possible dans le groupe, géré par l'interface)

Méthodes de calcul (une seule implémentation, côté serveur) :
  somme, moyenne, pourcentage (somme / maximum des items répondus × 100),
  koos (100 − moyenne × 100 / 4, KOOS/HOOS/FAOS/HAGOS), dash ((moyenne − 1) × 25, QuickDASH),
  moyenne_x10, nombre (valeur saisie), ponderee (options déjà pondérées : somme), vitesse
  (distance / temps), sppb, ikdc.
Batteries de tests (Ankle-GO, K-STARTS…), sous-scores calculés dans l'ordre et réutilisables par leur nom :
  rapport_pct (items [a, b] -> a / b × 100 : symétrie, distance normalisée), moyenne_de (sources : noms
  de sous-scores), paliers (source -> points selon des seuils {"lt"|"le"|"gt"|"ge"|"eq": x, "points": p},
  premier seuil vrai ; "si" : points imposés quand un item a une valeur, ex. test impossible par douleur ;
  "bonus" : points ajoutés quand un item a une valeur, ex. pas de sentiment d'instabilité),
  somme_points (total = somme des sous-scores marqués "points": true), expression ("expr" : formule
  arithmétique sur les identifiants d'items et les « cle » des sous-scores déjà calculés) ;
  paliers « selon » un item (ex. normes différentes si le côté opéré est dominant).
Sous-scores : « nom_depuis » (nom pris dans une réponse texte, ex. nom d'un test libre), « masquer_si_vide »,
  « detail » (texte avec {id d'item}, ex. "G {g} / D {d}", repris dans les comptes rendus).
Items : « ligne » regroupe des champs côte à côte dans l'interface (ex. côté gauche | côté droit).
Un score n'est calculé que si le nombre minimal d'items répondus est atteint (« min_repondus »).
"""
import ast, datetime, glob, json, operator, os

CODE = os.path.dirname(os.path.abspath(__file__))
DOSSIER = os.path.join(CODE, "questionnaires")
_CACHE = {}


def catalogue():
    if not _CACHE:
        for f in sorted(glob.glob(os.path.join(DOSSIER, "*.json"))):
            with open(f, encoding="utf-8") as fh:
                d = json.load(fh)
            _CACHE[d["id"]] = d
    return _CACHE


def resume_catalogue():
    return [{"id": q["id"], "nom": q["nom"], "nom_court": q.get("nom_court", q["nom"]), "domaines": q.get("domaines", []),
             "licence": q.get("licence", "libre"), "mode": q.get("mode", "items"), "diffusion": q.get("diffusion", "libre"), "nb_items": len(q.get("items", [])),
             "duree_min": q.get("duree_min")} for q in catalogue().values()]


def _option(item, v):
    for o in item.get("options") or []:
        if str(o.get("code", o["valeur"])) == str(v):
            return o
    return None


def _num(item, v):
    """Réponse -> valeur numérique (None si absente, non applicable ou invalide)."""
    if v is None or v == "" or v == "na":
        return None
    if item.get("options"):
        o = _option(item, v)
        v = o["valeur"] if o else None
        if v in (None, "na"):
            return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _valeurs(q, reponses, ids):
    items = {i["id"]: i for i in q.get("items", [])}
    out = []
    for i in ids:
        n = _num(items.get(i, {}), reponses.get(i))
        if n is not None:
            out.append((items.get(i, {}), n))
    return out


def _max_item(item):
    if item.get("options"):
        return max(float(o["valeur"]) for o in item["options"] if o.get("valeur") not in (None, "na"))
    return float(item.get("max", 0))


def _min_item(item):
    if item.get("options"):
        return min(float(o["valeur"]) for o in item["options"] if o.get("valeur") not in (None, "na"))
    return float(item.get("min", 0))


_SEUILS = {"lt": lambda v, x: v < x, "le": lambda v, x: v <= x, "gt": lambda v, x: v > x,
           "ge": lambda v, x: v >= x, "eq": lambda v, x: v == x}


def _valeur_item(q, reponses, iid):
    it = next((i for i in q.get("items", []) if i["id"] == iid), {})
    return _num(it, reponses.get(iid))


_OPERATIONS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
               ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos}


def _expression(expr, variables):
    """Formule arithmétique simple (+ - * / ** et parenthèses) ; None si une valeur manque."""
    def calc(n):
        if isinstance(n, ast.Expression):
            return calc(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.Name):
            v = variables.get(n.id)
            if v is None:
                raise LookupError(n.id)
            return v
        if isinstance(n, ast.BinOp) and type(n.op) in _OPERATIONS:
            return _OPERATIONS[type(n.op)](calc(n.left), calc(n.right))
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPERATIONS:
            return _OPERATIONS[type(n.op)](calc(n.operand))
        raise ValueError("formule non autorisée")
    try:
        return calc(ast.parse(expr, mode="eval"))
    except (LookupError, ZeroDivisionError):
        return None


def _paliers(q, regle, reponses, calcules):
    items = {i["id"]: i for i in q.get("items", [])}
    for cond in regle.get("si") or []:
        if str(reponses.get(cond["item"])) == str(cond["valeur"]):
            return cond["points"]
    src = regle["source"]
    v = calcules.get(src) if src in calcules else _valeur_item(q, reponses, src)
    if v is None:
        return None
    paliers = regle.get("paliers")
    if "selon" in regle:
        choix = reponses.get(regle["selon"]["item"])
        paliers = regle["selon"]["paliers"].get(str(choix)) if choix not in (None, "") else None
        if paliers is None:
            return None
    points = None
    for p in paliers:
        if all(_SEUILS[k](v, x) for k, x in p.items() if k in _SEUILS):
            points = p["points"]
            break
    if points is None:
        return None
    for b in regle.get("bonus") or []:
        if "item" in b and str(reponses.get(b["item"])) == str(b["valeur"]):
            points += b["points"]
        elif "source" in b and calcules.get(b["source"]) is not None and all(
                _SEUILS[k](calcules[b["source"]], x) for k, x in b.items() if k in _SEUILS):
            points += b["points"]
    return points


def calculer_un(q, regle, reponses, calcules=None):
    calcules = calcules if calcules is not None else {}
    methode = regle.get("methode", "somme")
    if methode == "paliers":
        return _paliers(q, regle, reponses, calcules)
    if methode == "moyenne_de":
        vals = [calcules.get(n) for n in regle["sources"]]
        return None if any(v is None for v in vals) else round(sum(vals) / len(vals), regle.get("decimales", 1))
    if methode == "somme_points":
        pts = [calcules.get(n) for n in regle["sources"]]
        return None if any(v is None for v in pts) else round(sum(pts), 1)
    if methode == "expression":
        variables = {i["id"]: _num(i, reponses.get(i["id"])) for i in q.get("items", []) if i.get("type") != "texte"}
        variables.update(calcules)
        v = _expression(regle["expr"], variables)
        return round(v, regle.get("decimales", 2)) if v is not None else None
    if methode == "rapport_pct":
        a, b = (_valeur_item(q, reponses, i) for i in regle["items"])
        return round(a / b * 100, regle.get("decimales", 1)) if a is not None and b else None
    ids = regle.get("items") or [i["id"] for i in q.get("items", []) if i.get("type") != "texte"]
    vals = _valeurs(q, reponses, ids)
    n = len(vals)
    minimum = regle.get("min_repondus", len(ids))
    if methode == "nombre":
        return round(vals[0][1], 2) if vals else None
    if n < minimum or n == 0:
        return None
    s = sum(v for _, v in vals)
    if methode in ("somme", "ponderee"):
        r = s
    elif methode == "moyenne":
        r = s / n
    elif methode == "moyenne_x10":
        r = s / n * 10
    elif methode == "pourcentage":
        maxi = sum(_max_item(it) for it, _ in vals)
        r = s / maxi * 100 if maxi else None
    elif methode == "koos":
        r = 100 - (s / n) * 100 / 4
    elif methode == "dash":
        r = (s / n - 1) * 25
    elif methode == "ikdc":
        mini = sum(_min_item(it) for it, _ in vals)
        maxi = sum(_max_item(it) for it, _ in vals)
        r = (s - mini) / (maxi - mini) * 100 if maxi > mini else None
    elif methode == "vitesse":
        d = dict((it.get("id"), v) for it, v in vals)
        temps, distance = d.get(regle["temps"]), regle.get("distance_m") or d.get(regle.get("distance"))
        r = distance / temps if temps and distance else None
    elif methode == "sppb":
        d = dict((it.get("id"), v) for it, v in vals)
        r = _sppb(d, regle)
    else:
        raise ValueError(f"méthode inconnue : {methode}")
    if r is None:
        return None
    if "multiplier" in regle:
        r *= regle["multiplier"]
    return round(r, regle.get("decimales", 1))


def _sppb(d, regle):
    """Short Physical Performance Battery (Guralnik 1994) : équilibre + vitesse de marche 4 m + 5 levers."""
    eq = d.get(regle["equilibre"])
    marche, levers = d.get(regle["marche_4m_s"]), d.get(regle["levers_5_s"])
    if eq is None or marche is None or levers is None:
        return None
    if marche <= 0:
        pm = 0
    elif marche < 4.82:
        pm = 4
    elif marche <= 6.20:
        pm = 3
    elif marche <= 8.70:
        pm = 2
    else:
        pm = 1
    if levers <= 0 or levers > 60:
        pl = 0
    elif levers <= 11.19:
        pl = 4
    elif levers <= 13.69:
        pl = 3
    elif levers <= 16.69:
        pl = 2
    else:
        pl = 1
    return eq + pm + pl


def interpreter(q, nom, valeur):
    for seuil in (q.get("interpretation") or {}).get(nom, []):
        if valeur is not None and seuil.get("min", float("-inf")) <= valeur <= seuil.get("max", float("inf")):
            return seuil["texte"]
    return ""


_OPS = {"<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b, "<": lambda a, b: a < b, ">": lambda a, b: a > b}


def _globale(q, res):
    scores = {"total": res["total"], **{s["nom"]: s["valeur"] for s in res["sous_scores"]}}
    for regle in q.get("interpretation_globale") or []:
        if all(scores.get(nom) is not None and _OPS[op](scores[nom], seuil) for nom, op, seuil in regle["si"]):
            return regle["texte"]
    return ""


def _detail(q, modele, reponses):
    items = {i["id"]: i for i in q.get("items", [])}

    def remplace(m):
        iid = m.group(1)
        v = reponses.get(iid)
        it = items.get(iid, {})
        if v in (None, ""):
            return "" if it.get("type") == "texte" else "—"
        if it.get("options"):
            return _libelle(it, v)
        if it.get("type") == "texte":
            return str(v)
        n = _num(it, v)
        return nombre(n) if n is not None else str(v)
    import re
    return re.sub(r"\{([\w]+)\}", remplace, modele).replace("  ", " ").strip()


def evaluer(qid, reponses):
    q = catalogue().get(qid)
    if not q:
        raise KeyError(qid)
    calc = q.get("calcul") or {}
    res = {"total": None, "total_texte": "", "sous_scores": [], "repondus": 0, "alertes": [],
           "items": len([i for i in q.get("items", []) if not i.get("facultatif")])}
    res["repondus"] = len([i for i in q.get("items", []) if not i.get("facultatif") and reponses.get(i["id"]) not in (None, "")])
    calcules = {}
    for sous in calc.get("sous_scores", []):
        v = calculer_un(q, sous, reponses, calcules)
        calcules[sous["nom"]] = v
        if sous.get("cle"):
            calcules[sous["cle"]] = v
        if v is None and sous.get("masquer_si_vide"):
            continue
        nom = sous["nom"]
        if sous.get("nom_depuis") and str(reponses.get(sous["nom_depuis"]) or "").strip():
            nom = str(reponses[sous["nom_depuis"]]).strip()
        entree = {"nom": nom, "valeur": v, "unite": sous.get("unite", ""), "texte": interpreter(q, sous["nom"], v)}
        if sous.get("detail") and v is not None:
            entree["detail"] = _detail(q, sous["detail"], reponses)
        res["sous_scores"].append(entree)
    if calc.get("total"):
        total = dict(calc["total"])
        if total.get("methode") == "somme_points" and "sources" not in total:
            total["sources"] = [x["nom"] for x in calc.get("sous_scores", []) if x.get("points")]
        res["total"] = calculer_un(q, total, reponses, calcules)
        res["total_texte"] = interpreter(q, "total", res["total"])
    if q.get("interpretation_globale"):
        res["total_texte"] = _globale(q, res)
    items = {i["id"]: i for i in q.get("items", [])}
    for a in q.get("alertes") or []:
        n = _num(items.get(a["item"], {}), reponses.get(a["item"]))
        if n is not None and n >= a["min"]:
            res["alertes"].append(a["texte"])
    res["unite"] = calc.get("total", {}).get("unite", "")
    return res


def _libelle(item, v):
    o = _option(item, v) if item.get("options") else None
    return o["texte"] if o else f"{nombre(v) if isinstance(v, (int, float)) else v}{(' ' + item['unite']) if item.get('unite') else ''}"


def nombre(v):
    """12.0 -> « 12 », 2.27 -> « 2,27 »."""
    if v is None:
        return ""
    return str(int(v)) if float(v).is_integer() else f"{v}".replace(".", ",")


def _unite(u):
    return "" if not u else (u if u[0] in "/%" else " " + u)


def texte_resultat(r):
    """Une ligne lisible, pour l'historique, les comptes rendus et le chat."""
    q = catalogue().get(r["id"], {})
    parties = []
    if r.get("total") is not None:
        parties.append(f"{nombre(r['total'])}{_unite(r.get('unite'))}"
                       + (f" ({r['total_texte']})" if r.get("total_texte") else ""))
    for s in r.get("sous_scores") or []:
        if s.get("valeur") is not None:
            parties.append(f"{s['nom']} : {nombre(s['valeur'])}{_unite(s.get('unite'))}"
                           + (f" ({s['texte']})" if s.get("texte") else "")
                           + (f" [{s['detail']}]" if s.get("detail") else ""))
    if not parties:        # échelles sans score global (Ashworth…) : cotations saisies
        for it in q.get("items", []):
            v = (r.get("reponses") or {}).get(it["id"])
            if v not in (None, ""):
                parties.append(f"{(it.get('section') + ' ') if it.get('section') else ''}{it['texte']} : {_libelle(it, v)}")
    for a in r.get("alertes") or []:
        parties.append("ALERTE : " + a)
    ligne = f"{q.get('nom_court', r['id'])} du {r.get('date')} : " + " ; ".join(parties or ["incomplet"])
    return ligne + (f" — {r['commentaire']}" if r.get("commentaire") else "")


def resultat(qid, reponses, date=None, rempli_par="kiné", commentaire=""):
    q = catalogue()[qid]
    propres = {}
    for it in q.get("items", []):
        v = reponses.get(it["id"])
        if v in (None, ""):
            continue
        if it.get("type") == "texte":
            v = str(v).strip()[:500]
            if not v:
                continue
        elif it.get("type") in ("nombre", "echelle"):
            try:
                v = float(v)
            except (TypeError, ValueError):
                continue
            if "min" in it and v < it["min"] or "max" in it and v > it["max"]:
                continue
        elif it.get("options") and _option(it, v) is None:
            continue
        propres[it["id"]] = v
    # Groupe exclusif (VISA-A, question 8 : une seule des trois lignes) rempli plusieurs fois : l'interface
    # l'empêche, mais un score faux (jusqu'à 130/100) ne doit jamais sortir d'ici. Le groupe est écarté :
    # le score reste incomplet et la réponse est à reprendre.
    for groupe in q.get("exclusifs") or []:
        remplis = [i for i in groupe if i in propres]
        if len(remplis) > 1:
            for i in remplis:
                propres.pop(i)
    ev = evaluer(qid, propres)
    return dict(ev, id=qid, date=date or datetime.date.today().strftime("%d/%m/%Y"),
                reponses=propres, rempli_par=rempli_par, commentaire=(commentaire or "").strip()[:2000],
                enregistre=datetime.datetime.now().strftime("%d/%m/%Y %H:%M"))
