# -*- coding: utf-8 -*-
"""Contrôle des sorties réseau de l'app : aucune connexion vers Internet sans autorisation.

Toute requête faite par l'app (urllib) passe par un garde installé une fois pour toutes au
démarrage (`installer`) : la boucle locale (127.0.0.1, localhost) est toujours permise — c'est
là que tournent Whisper et les modèles — ; tout autre domaine doit avoir été autorisé dans
Paramètres → Réseau. Une redirection vers un autre domaine est contrôlée elle aussi.

Une requête refusée lève `SortieRefusee` et laisse une trace (domaine, date, nombre de
tentatives), que les Paramètres affichent avec un bouton « Autoriser ». Seuls le domaine et
le chemin sont gardés, jamais les paramètres de la requête (ils portent les mots-clés).

Une autorisation peut couvrir les sous-domaines (« hf.co et ses sous-domaines ») : les
fichiers des modèles sont servis par des serveurs dont le nom change (us.aws.cdn.hf.co…).

Les moteurs (Splash, llama-server, whisper-server) sont des programmes à part : le garde ne
peut pas les bloquer, mais `connexions_moteurs` relève toute connexion qu'ils ouvriraient
vers l'extérieur, pour l'afficher."""
import datetime, json, os, re, subprocess, threading, urllib.error, urllib.parse, urllib.request

DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
FICHIER = os.path.join(DATA, "reseau.json")
LOCAUX = {"127.0.0.1", "localhost", "::1", "[::1]"}
# Ce à quoi sert chaque domaine, pour décider en connaissance de cause.
USAGES = (("ncbi.nlm.nih.gov", "PubMed : articles scientifiques (mots-clés cliniques anonymes)"),
          ("duckduckgo.com", "Recherche des recommandations HAS (mots-clés cliniques anonymes)"),
          ("huggingface.co", "Téléchargement des modèles de transcription et de rédaction"),
          ("hf.co", "Téléchargement des modèles de transcription et de rédaction (serveur de fichiers)"),
          ("github.com", "Nouvelles versions des moteurs Splash et llama.cpp (rien n'est envoyé)"),
          ("githubusercontent.com", "Nouvelles versions de KinéAPP et des moteurs Splash et llama.cpp (serveur de fichiers)"))
MOTEURS = {"Splash": "engine/splash", "llama-server (secours, embeddings)": "llama-server",
           "whisper-server (transcription)": "whisper-server"}
_VERROU = threading.Lock()


class SortieRefusee(urllib.error.URLError):
    def __init__(self, domaine):
        self.domaine = domaine
        super().__init__(f"Connexion vers {domaine} non autorisée : autorisez-la dans Paramètres → Réseau.")

    def __str__(self):                       # affiché tel quel (téléchargement d'un modèle, chat)
        return self.reason


def _maintenant():
    return datetime.datetime.now().strftime("%d/%m/%Y %H:%M")


def _lire():
    try:
        d = json.load(open(FICHIER, encoding="utf-8"))
    except Exception:
        d = {}
    d.setdefault("autorisations", {})
    d.setdefault("refus", {})
    d.setdefault("observees", {})
    return d


def _ecrire(d):
    os.makedirs(DATA, exist_ok=True)
    tmp = FICHIER + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.chmod(tmp, 0o600)
    os.replace(tmp, FICHIER)


def usage(domaine):
    return next((u for suffixe, u in USAGES if domaine == suffixe or domaine.endswith("." + suffixe)), "usage inconnu")


def domaine_de(url):
    return (urllib.parse.urlsplit(url).hostname or "").lower()


def _regle(d, domaine):
    """L'autorisation qui couvre ce domaine : la sienne, ou celle d'un domaine parent accordée avec
    ses sous-domaines (jamais un simple suffixe de pays : « co », « fr »)."""
    a = d["autorisations"].get(domaine)
    if a is not None:
        return a
    morceaux = domaine.split(".")
    for i in range(1, len(morceaux) - 1):
        a = d["autorisations"].get(".".join(morceaux[i:]))
        if a is not None and a.get("sous_domaines"):
            return a
    return None


def verifier(url):
    """Laisse passer la boucle locale et les domaines autorisés ; sinon trace le refus et lève."""
    domaine = domaine_de(url)
    if not domaine or domaine in LOCAUX:
        return
    with _VERROU:
        d = _lire()
        a = _regle(d, domaine)
        if a is not None:
            a["derniere"] = _maintenant()
            a["requetes"] = a.get("requetes", 0) + 1
            _ecrire(d)
            return
        p = urllib.parse.urlsplit(url)
        r = d["refus"].setdefault(domaine, {"premiere": _maintenant(), "tentatives": 0})
        r.update(derniere=_maintenant(), tentatives=r["tentatives"] + 1, exemple=f"{p.scheme}://{domaine}{p.path}"[:200])
        _ecrire(d)
    raise SortieRefusee(domaine)


def autoriser(domaine, sous_domaines=False):
    domaine = (domaine or "").strip().lower()
    if not re.fullmatch(r"[a-z0-9.-]+\.[a-z]{2,}", domaine):
        raise ValueError(f"Domaine invalide : {domaine!r}")
    with _VERROU:
        d = _lire()
        d["refus"].pop(domaine, None)
        a = d["autorisations"].setdefault(domaine, {"accordee": _maintenant(), "derniere": None, "requetes": 0})
        if sous_domaines:
            a["sous_domaines"] = True
            for r in [r for r in d["refus"] if r.endswith("." + domaine)]:
                d["refus"].pop(r, None)         # refus désormais couverts
        _ecrire(d)


def autorise(domaine):
    """Ce domaine passerait-il le garde ? (sans rien tracer)"""
    with _VERROU:
        return _regle(_lire(), (domaine or "").strip().lower()) is not None


def retirer(domaine):
    with _VERROU:
        d = _lire()
        ok = d["autorisations"].pop((domaine or "").strip().lower(), None) is not None
        _ecrire(d)
    return ok


def oublier_refus(domaine):
    with _VERROU:
        d = _lire()
        d["refus"].pop((domaine or "").strip().lower(), None)
        _ecrire(d)


def etat():
    with _VERROU:
        d = _lire()
    return {"autorisations": [dict(domaine=k, usage=usage(k), **v) for k, v in sorted(d["autorisations"].items())],
            "refus": [dict(domaine=k, usage=usage(k), **v) for k, v in sorted(d["refus"].items())],
            "observees": [dict(cle=k, **v) for k, v in sorted(d["observees"].items())]}


class _Garde(urllib.request.BaseHandler):
    handler_order = 100                       # avant tout envoi, et à chaque redirection

    def http_request(self, req):
        verifier(req.full_url)
        return req

    https_request = http_request


def installer():
    """À appeler une fois au démarrage : toute requête urllib de l'app passe par le garde."""
    urllib.request.install_opener(urllib.request.build_opener(_Garde()))


def connexions_moteurs():
    """Connexions TCP établies vers l'extérieur par les moteurs lancés pour l'app (relevé, pas blocage).
    Chaque nouvelle connexion est gardée dans « observees » (moteur, adresse, première et dernière fois)."""
    pids = {}
    for nom, motif in MOTEURS.items():
        try:
            out = subprocess.run(["pgrep", "-f", motif], capture_output=True, text=True, timeout=5).stdout
        except Exception:
            continue
        for p in out.split():
            pids[p] = nom
    if not pids:
        return []
    try:
        out = subprocess.run(["lsof", "-nP", "-a", "-iTCP", "-sTCP:ESTABLISHED", "-p", ",".join(pids)],
                             capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return []
    vues = []
    for ligne in out.splitlines()[1:]:
        champs = ligne.split()
        m = re.search(r"->(\S+):(\d+)", ligne)
        if len(champs) < 2 or not m:
            continue
        distant = m.group(1).strip("[]")
        if distant in LOCAUX or distant.startswith("127."):
            continue
        vues.append({"moteur": pids.get(champs[1], champs[0]), "distant": f"{distant}:{m.group(2)}"})
    if vues:
        with _VERROU:
            d = _lire()
            for v in vues:
                o = d["observees"].setdefault(f"{v['moteur']} → {v['distant']}",
                                              {"moteur": v["moteur"], "distant": v["distant"], "premiere": _maintenant()})
                o["derniere"] = _maintenant()
            _ecrire(d)
    return vues
