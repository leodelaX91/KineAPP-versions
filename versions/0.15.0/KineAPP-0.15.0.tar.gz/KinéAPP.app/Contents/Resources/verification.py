# -*- coding: utf-8 -*-
"""Contrôle mécanique de l'extraction contre la transcription — sans modèle d'IA.

Depuis que la passe de vérification par un second modèle a été retirée, rien ne confrontait
plus l'extraction à ce qui a réellement été dit : la section « À vérifier » ne contenait que
les doutes que le modèle déclarait lui-même, ce qu'un modèle qui invente ne fait pas.

Ce module ne juge pas le sens, il vérifie des faits vérifiables, donc sans jamais se tromper
sur une question d'interprétation :

  - tout NOMBRE écrit dans l'extraction (amplitude, kilos, EVA, durée, année) doit se
    retrouver dans la transcription, en chiffres ou en mots ;
  - tout CÔTÉ mentionné doit avoir été prononcé au moins une fois ;
  - toute section exigée par le schéma doit être présente et non vide.

Un contrôle qui échoue n'est pas une erreur prouvée : c'est une ligne à relire, ajoutée à la
section « À vérifier » du compte rendu. La règle est la précision : mieux vaut laisser passer
un doute que crier au loup, sinon la section devient illisible et on ne la lit plus.
"""
import json, re, unicodedata

# Nombres écrits en mots, tels que Whisper les transcrit en consultation.
MOTS_NOMBRES = {
    "zero": 0, "un": 1, "une": 1, "deux": 2, "trois": 3, "quatre": 4, "cinq": 5, "six": 6,
    "sept": 7, "huit": 8, "neuf": 9, "dix": 10, "onze": 11, "douze": 12, "treize": 13,
    "quatorze": 14, "quinze": 15, "seize": 16, "vingt": 20, "trente": 30, "quarante": 40,
    "cinquante": 50, "soixante": 60, "cent": 100, "mille": 1000, "demi": 0.5,
}
# Nombres présents dans presque toute phrase ou déduits d'une échelle : les signaler
# produirait du bruit sans valeur clinique.
TOLERES = {0, 1, 2, 3, 10, 100}
# Les formes d'un mot entier, et SURTOUT PAS la lettre seule. « d » figure dans les sept
# transcriptions réelles (« d'abord », « d'accord ») et « g » dans celles qui parlent de
# grammes : en les acceptant comme forme du côté, le contrôle était toujours satisfait, et le
# côté droit n'a jamais pu être signalé jusqu'au 05/10/2026 — y compris sur un bilan dont la
# transcription ne prononce pas une seule fois « droite ».
COTES = {"droit": ("droit", "droite", "droites", "droits"),
         "gauche": ("gauche", "gauches")}
# Les abréviations ne se cherchent qu'en MAJUSCULE et dans des tournures où elles ne peuvent
# pas être autre chose. Le modèle écrit « 2/5 (G), 4/5 (D) » et le kiné note « D : 20 kg » :
# sans cela ces côtés n'étaient ni comptés ni vérifiés (constaté à la validation du schéma).
ABREGE = {
    "droit": re.compile(r"\(\s*D\s*\)|\bcote\s+D\b|\bD\s*/\s*G\b|\bG\s*/\s*D\b|\bD\s*:"),
    "gauche": re.compile(r"\(\s*G\s*\)|\bcote\s+G\b|\bD\s*/\s*G\b|\bG\s*/\s*D\b|\bG\s*:"),
}
CHAMPS_IGNORES = {"elements_incertains_a_verifier"}
NOMBRE = re.compile(r"\d+(?:[.,]\d+)?")


def _sans_accent(t):
    return "".join(c for c in unicodedata.normalize("NFD", t or "") if not unicodedata.combining(c))


def _mots(t):
    return set(re.findall(r"[a-z]+", _sans_accent(t).lower()))


# « 20 000 grammes » est UN nombre, pas deux : sans cela le contrôle signalait à tort
# une valeur pourtant dictée (constaté au banc du 01/10/2026).
MILLIERS = re.compile(r"(?<=\d)[\u00a0\u202f ](?=\d{3}(?!\d))")


# Durées et nombres composés dits en mots : « trois quarts d'heure » devient « 45 min » dans le
# compte rendu, « dix-huit » devient « 18 » — signalés introuvables à tort (banc du 12/10/2026).
DUREES_MOTS = ((re.compile(r"\btrois quarts d.heure|\bheures? moins (le )?quart"), 45),
               (re.compile(r"\bquart d.heure|\bheures? et quart"), 15),
               (re.compile(r"\bdemi.?heure|\bheures? et demie?"), 30))
COMPOSES = re.compile(r"\b(dix|vingt|trente|quarante|cinquante|soixante)(?:-et)?-(une?|deux|trois|quatre|cinq|six|sept|huit|neuf)\b")


# Audit des contrôles du 07/11/2026 : « 29, 7 » et « 38, 3 » (Whisper met une espace après la virgule d'une décimale
# dictée) et « un mois et demi » étaient lus 29, 7, 38, 3 et 1 : les valeurs 29,7, 38,3 et 1,5 du compte rendu
# étaient signalées introuvables à tort. Ces lectures s'AJOUTENT aux autres (« 29, 7 jours » reste aussi 29 et 7).
DECIMALE_ESPACEE = re.compile(r"(?<![\d,.])(\d{1,3}), (\d{1,2})(?![\d,])")
ET_DEMI = re.compile(r"\b(\d+|" + "|".join(k for k in MOTS_NOMBRES if k not in ("demi", "zero")) + r")\s+(?:[a-z]+\s+){0,2}et demie?\b")


def _nombres_du_texte(t):
    """Tous les nombres d'un texte : chiffres (espaces de milliers comprises) et mots."""
    t = MILLIERS.sub("", t or "")
    out = {float(m.group(0).replace(",", ".")) for m in NOMBRE.finditer(t)}
    out |= {float(f"{a}.{b}") for a, b in DECIMALE_ESPACEE.findall(t)}
    for mot in _mots(t):
        if mot in MOTS_NOMBRES:
            out.add(float(MOTS_NOMBRES[mot]))
    plat = _sans_accent(t).lower()
    out |= {float(v) for motif, v in DUREES_MOTS if motif.search(plat)}
    out |= {float(MOTS_NOMBRES[d] + MOTS_NOMBRES[u]) for d, u in COMPOSES.findall(plat)}
    out |= {(float(n) if n.isdigit() else float(MOTS_NOMBRES[n])) + 0.5 for n in ET_DEMI.findall(plat)}
    return out


def _cotes_presentes(texte):
    """Côtés mentionnés dans un texte : en mot entier, ou en abrégé majuscule."""
    plat = _sans_accent(texte)                     # accents retirés, casse CONSERVÉE
    mots = set(re.findall(r"[a-z]+", plat.lower()))
    return {cote for cote, formes in COTES.items()
            if (set(formes) & mots) or ABREGE[cote].search(plat)}


def _parcourir(noeud, chemin=""):
    """Chaque feuille de l'extraction avec son chemin lisible (« examen_clinique.force »)."""
    if isinstance(noeud, dict):
        for cle, valeur in noeud.items():
            if cle in CHAMPS_IGNORES:
                continue
            yield from _parcourir(valeur, f"{chemin}.{cle}" if chemin else cle)
    elif isinstance(noeud, list):
        for i, valeur in enumerate(noeud):
            yield from _parcourir(valeur, f"{chemin}[{i + 1}]")
    elif noeud not in (None, "", []):
        yield chemin, noeud


def anomalies(extraction, transcription, notes=""):
    """Points à relire. Renvoie (liste de {champ, valeur, probleme}, compte des contrôles).

    Les notes écrites par le kinésithérapeute pendant le bilan comptent comme source : une
    valeur qu'il a notée n'est pas une invention du modèle."""
    source = (transcription or "") + "\n" + (notes or "")
    nombres_source = _nombres_du_texte(source)
    cotes_source = _cotes_presentes(source)
    trouves = []
    n_nombres = n_cotes = 0
    for champ, valeur in _parcourir(extraction):
        texte = str(valeur)
        for nombre in sorted(_nombres_du_texte(texte)):
            if nombre in TOLERES:
                continue
            n_nombres += 1
            if nombre in nombres_source:
                continue
            # 32,5 peut avoir été dit « 32 et demi », et un entier peut venir d'un décimal.
            if any(abs(nombre - n) < 0.01 for n in nombres_source):
                continue
            trouves.append({"champ": champ, "valeur": _court(texte),
                            "probleme": f"le nombre {_nb(nombre)} n'est pas dans la transcription"})
        for cote in _cotes_presentes(texte):
            n_cotes += 1
            if cote not in cotes_source:
                trouves.append({"champ": champ, "valeur": _court(texte),
                                "probleme": f"le côté « {cote} » n'est jamais prononcé dans la transcription"})
    return trouves, {"nombres": n_nombres, "cotes": n_cotes}


def _nb(v):
    return str(int(v)) if float(v).is_integer() else f"{v}".replace(".", ",")


def _court(t, n=120):
    t = " ".join(str(t).split())
    return t if len(t) <= n else t[:n - 1] + "…"


# ── doses : unités impossibles et posologies hors plage ─────────────────────
# « j'ai fait 7000 grammes, il me remonte le cortensil jusqu'à 20 000 grammes » (bilan réel du
# 10/09/2026) : la patiente dit des milligrammes, Whisper entend « sept mille grammes ». Aucun
# modèle n'a signalé l'absurdité, et le contrôle des nombres ne pouvait rien voir — la valeur
# est bien dans la transcription. C'est l'UNITÉ qui est fausse, pas le chiffre.
#
# On ne convertit JAMAIS : écrire « 7 mg » serait inventer une dose. On signale et on cite.
UNITES = {"g": 1000.0, "gr": 1000.0, "gramme": 1000.0, "grammes": 1000.0,
          "mg": 1.0, "milligramme": 1.0, "milligrammes": 1.0,
          "ug": 0.001, "mcg": 0.001, "microgramme": 0.001, "microgrammes": 0.001,
          "ui": None, "u.i": None, "unite": None, "unites": None}      # None = pas une masse
DOSE = re.compile(r"(\d+(?:[.,]\d+)?)\s*("
                  r"grammes?|gr|g|milligrammes?|mg|microgrammes?|mcg|ug|u\.i|ui|unites?)\b")

# (nom de la classe, marqueurs cherchés dans le même champ, unités admises, plafond usuel)
CLASSES = (
    ("un corticoïde",
     ("cortancyl", "prednison", "prednisol", "solupred", "cortisone", "corticoid", "corticoide",
      "betametha", "dexametha", "medrol", "celestene", "hydrocortison", "dectancyl"),
     {"mg", "ug", "mcg"}, 1000.0),
    ("une insuline",
     ("insuline", "lantus", "novorapid", "humalog", "levemir", "tresiba", "abasaglar", "apidra"),
     {"ui"}, 300.0),
    ("un antalgique ou un anti-inflammatoire",
     ("paracetamol", "doliprane", "dafalgan", "efferalgan", "tramadol", "ibuprofen", "advil",
      "nurofen", "ketoprofen", "profenid", "naproxen", "diclofenac", "voltarene", "aspirine",
      "codeine", "morphine", "lamaline", "ixprim"),
     {"mg", "g"}, 4000.0),
)
# Au-delà de ce seuil, une dose en grammes n'existe pour aucun médicament : la plus forte
# posologie orale courante est de quelques grammes par jour (paracétamol, 4 g).
GRAMMES_IMPOSSIBLE = 10.0


def _unite(u):
    u = u.replace(".", "").rstrip("s")
    return {"gramme": "g", "gr": "g", "milligramme": "mg", "microgramme": "ug",
            "mcg": "ug", "unite": "ui", "ui": "ui"}.get(u, u)


def _feuilles_avec_contexte(noeud, chemin="", contexte=""):
    """Comme _parcourir, mais chaque feuille arrive avec les champs FRÈRES de son objet.

    « Cortancyl » est dans "libelle" et « 20 mg » dans "posologie" : séparés, on ne peut
    pas savoir de quelle classe est la dose."""
    if isinstance(noeud, dict):
        propre = " ".join(str(v) for v in noeud.values() if isinstance(v, (str, int, float)))
        for cle, valeur in noeud.items():
            if cle in CHAMPS_IGNORES:
                continue
            yield from _feuilles_avec_contexte(valeur, f"{chemin}.{cle}" if chemin else cle,
                                               propre or contexte)
    elif isinstance(noeud, list):
        for i, valeur in enumerate(noeud):
            yield from _feuilles_avec_contexte(valeur, f"{chemin}[{i + 1}]", contexte)
    elif noeud not in (None, "", []):
        yield chemin, noeud, contexte


def doses_suspectes(extraction):
    """Doses suspectes, une ligne par dose : la même dose recopiée dans deux champs (le
    libellé et la posologie, par exemple) n'est signalée qu'une fois."""
    vus, out = set(), []
    for x in _doses_suspectes(extraction):
        if x["probleme"] not in vus:
            vus.add(x["probleme"])
            out.append(x)
    return out


def note_doses_a_verifier(note):
    """Note de séance : chaque ligne qui porte une dose suspecte (« kétoprofène 100 000 grammes »,
    signature de Whisper pour « 100 milligrammes ») est suivie de « (dose à vérifier) ». La valeur
    entendue reste telle quelle, rien n'est converti."""
    out = []
    for ligne in (note or "").split("\n"):
        if doses_suspectes({"note": ligne}) and "vérifier" not in ligne:
            ligne = ligne.rstrip(" .") + " (dose à vérifier)"
        out.append(ligne)
    return "\n".join(out)


def _doses_suspectes(extraction):
    """Doses dont l'unité est impossible ou la valeur hors plage. Ne convertit rien.

    Les classes sont reconnues par un marqueur présent dans le MÊME ÉLÉMENT : sans cet
    ancrage, « un bébé de 3500 grammes » serait signalé comme une posologie."""
    trouves = []
    for champ, valeur, contexte in _feuilles_avec_contexte(extraction):
        texte = str(valeur)
        plat = MILLIERS.sub("", _sans_accent(texte).lower())
        autour = MILLIERS.sub("", _sans_accent(contexte).lower())
        classe = next((c for c in CLASSES if any(m in autour for m in c[1])), None)
        medicament = classe is not None or "medicament" in _sans_accent(champ).lower()
        for m in DOSE.finditer(plat):
            brut = m.group(0)
            try: n = float(m.group(1).replace(",", "."))
            except ValueError: continue
            u = _unite(m.group(2))
            if classe:
                nom, _, admises, plafond = classe
                if u not in admises:
                    trouves.append({"champ": champ, "valeur": _court(texte),
                                    "probleme": f"« {brut} » : {nom} ne se dose pas en "
                                                f"{_mot_unite(u)}{_hypothese(n, u)} — unité à "
                                                f"confirmer, valeur laissée telle quelle"})
                    continue
                masse = UNITES.get(u)
                en_base = n * masse if masse else n
                if en_base > plafond:
                    trouves.append({"champ": champ, "valeur": _court(texte),
                                    "probleme": f"« {brut} » : au-delà de la posologie usuelle "
                                                f"pour {nom} — à confirmer"})
                    continue
            if medicament and u == "g" and n >= GRAMMES_IMPOSSIBLE:
                trouves.append({"champ": champ, "valeur": _court(texte),
                                "probleme": f"« {brut} » : aucun médicament ne se dose en grammes "
                                            f"à cette hauteur{_hypothese(n, u)} — à confirmer"})
    return trouves


def _hypothese(n, u):
    """« sept milligrammes » entendu « sept mille grammes » : la signature est N 000 grammes.

    On propose la lecture, on ne l'applique pas — le compte rendu garde la forme entendue."""
    if u == "g" and n >= 1000 and n % 1000 == 0:
        return f" (dit pour « {_nb(n / 1000)} milligrammes » ?)"
    return ""


def _mot_unite(u):
    return {"g": "grammes", "mg": "milligrammes", "ug": "microgrammes",
            "ui": "unités internationales"}.get(u, u)


# ── R2 : conformité au schéma ───────────────────────────────────────────────
def sections_manquantes(extraction, schema, transcript="", notes=""):
    """Sections exigées par le schéma, absentes ou vides. Une section vide passait
    inaperçue et le compte rendu perdait un paragraphe sans le dire."""
    manquantes = []
    admises = set(LISTES_VIDES_ADMISES)
    if MEDICAMENT_EVOQUE.search(_sans_accent(f"{transcript or ''} {notes or ''}").lower()):
        admises.discard("antecedents.medicaments")
    _verifier_objet(extraction, (schema or {}).get("json_schema", {}).get("schema", schema) or {},
                    "", manquantes, admises)
    return manquantes


# Listes qu'un bilan laisse vides le plus souvent à juste titre (aucun traitement, aucun antécédent, aucun exercice à
# domicile) : « section vide » y était inutile 14 fois sur 15 (audit des contrôles du 07/11/2026). Les mesures, elles,
# restent signalées : un bilan sans aucune mesure est suspect (3 justes sur 5).
LISTES_VIDES_ADMISES = {"antecedents.medicaux", "antecedents.medicaments", "prise_en_charge.exercices_a_domicile"}
# Sauf les médicaments quand la séance en parle : la seule « section vide » juste perdue par cette règle était un essai
# d'anti-inflammatoires évoqué puis oublié par l'extraction (même bilan, deux modèles).
MEDICAMENT_EVOQUE = re.compile(
    r"medicament|medoc|cachet|\bcomprimes?\b|gelule|anti-? ?inflammatoire|\bains\b|antalgique|anti-? ?douleur|doliprane|"
    r"paracetamol|dafalgan|efferalgan|ibuprofen|advil|nurofen|voltaren|ketoprofen|profenid|tramadol|codeine|lamaline|"
    r"izalgi|cortison|corticoide|anticoagul|kardegic|aspirine|myorelaxant|decontractant|thiocolchicoside|morphin")


def _verifier_objet(valeur, regle, chemin, manquantes, admises=LISTES_VIDES_ADMISES):
    if not isinstance(regle, dict) or regle.get("type") != "object":
        return
    proprietes = regle.get("properties") or {}
    for cle in regle.get("required") or list(proprietes):
        sous_chemin = f"{chemin}.{cle}" if chemin else cle
        if not isinstance(valeur, dict) or cle not in valeur:
            manquantes.append({"champ": sous_chemin, "probleme": "section absente"})
            continue
        contenu = valeur[cle]
        if contenu == [] and sous_chemin in admises:
            continue
        if contenu in (None, "", [], {}):
            manquantes.append({"champ": sous_chemin, "probleme": "section vide"})
            continue
        _verifier_objet(contenu, proprietes.get(cle) or {}, sous_chemin, manquantes, admises)


# ── R1 : mesures dictées absentes de l'extraction ───────────────────────────
# Le contrôle des nombres vérifie que ce qui est ÉCRIT a été dit. Celui-ci vérifie l'inverse,
# que ce qui a été DIT a été écrit — et c'est le seul qui voie une mesure perdue. Sur le bilan
# instrumenté du 05/10/2026, quatre modèles sur six affichaient « 0 à relire » après avoir
# laissé tomber huit des dix valeurs dictées pendant l'examen (périmètres de cuisse,
# dynamométrie), dont les quatre périmètres qui sont LE marqueur de suivi d'un post-opératoire.
UNITES_MESURE = r"cm|mm|centimetres?|millimetres?|kg|kilos?|degres|°|sur\s*10|sur\s*5|/\s*10|/\s*5"
MESURE_DICTEE = re.compile(r"(\d+(?:[.,]\d+)?)\s*(" + UNITES_MESURE + r")(?!\w)", re.I)


def _unite_lisible(u):
    u = " ".join(u.lower().split())
    return {"kilos": "kg", "kilo": "kg", "centimetres": "cm", "centimetre": "cm",
            "millimetres": "mm", "millimetre": "mm", "degres": "°",
            "/ 5": "sur 5", "/5": "sur 5", "/ 10": "sur 10", "/10": "sur 10"}.get(u, u)


# Lectures d'appareil SANS UNITÉ : pendant un test de force, le praticien encourage puis lit
# le chiffre seul (« … encore, encore. 47. On relâche »), ou rappelle le résultat (« t'avais
# fait 51 », « 44 à droite »). Le contrôle par unité ne les voyait pas : deux séries de force
# perdues sans aucun signalement (banc du 07/10/2026). Un nombre nu n'est retenu que dans ces
# tournures, et à partir de 5 : un décompte « 3, 2, 1 » n'est pas une mesure.
EFFORT = re.compile(r"\b(a fond|vas[- ]y|allez|encore|plus fort|pousse[sz]?|pousser|serre[sz]?|tiens|tenez|relache)\b", re.I)
EFFORT_FENETRE = 160
_FIN_NOMBRE = r"(?=\s*[.!?]|\s*,\s*(?!\d)|\s*$)"
LECTURE_NUE = re.compile(r"(?:(?<=[.,!?] )|(?<=\ba ))(\d{1,3}(?:[.,]\d)?)" + _FIN_NOMBRE)
# « si tu avais 25 [ans] » est une hypothèse, pas une lecture (banc du 12/10/2026).
LECTURE_RESULTAT = re.compile(r"(?<!\bsi )\b(?:tu es|t['’]es|t['’]etais|tu etais|t['’]avais|tu avais|t['’]as fait|tu as fait|avais fait|avait fait)"
                              r"\s+(?:a\s+)?(\d{1,3}(?:[.,]\d)?)" + _FIN_NOMBRE, re.I)
LECTURE_COTE = re.compile(r"(?<![\d,.])(\d{1,3}(?:[.,]\d)?)\s+(?:a|du cote|cote)\s+(?:droite?|gauche)\b", re.I)
# Whisper coupe une décimale dictée : « trente-trois virgule cinq » devient « 33, 5 ».
DECIMALE_COUPEE = re.compile(r"(?<![\d,.])(\d{1,3}), (\d)" + _FIN_NOMBRE)
LECTURE_MIN = 5.0


def _decompte(plat, debut, fin):
    """Vrai si le nombre APPARTIENT à un décompte : « 1, 2, 3, 4… », que Whisper écrit parfois
    « 1,2, 3,4, 5,6, 7,8 » — deux faux « 5,6 » et « 7,8 » signalés le 09/10/2026. Un vrai
    « 47 » lu juste après le décompte reste une lecture."""
    a0 = max(0, debut - 40)
    jetons = [(int(m.group()), a0 + m.start(), a0 + m.end()) for m in re.finditer(r"\d+", plat[a0:fin + 40])]
    serie = [jetons[0]] if jetons else []
    for j in jetons[1:]:
        if j[0] == serie[-1][0] + 1:
            serie.append(j)
            continue
        if len(serie) >= 4 and any(d < fin and f > debut for _, d, f in serie):
            return True
        serie = [j]
    return len(serie) >= 4 and any(d < fin and f > debut for _, d, f in serie)


def _lectures_sans_unite(plat):
    """Nombres lus à voix haute pendant un test, sans unité : (valeur, début, fin)."""
    plat = DECIMALE_COUPEE.sub(r"\1,\2", plat)
    trouves = [m for m in LECTURE_NUE.finditer(plat)
               if EFFORT.search(plat[max(0, m.start() - EFFORT_FENETRE):m.start()])]
    trouves += list(LECTURE_RESULTAT.finditer(plat)) + list(LECTURE_COTE.finditer(plat))
    sortie = []
    for m in sorted(trouves, key=lambda m: m.start(1)):
        try: valeur = float(m.group(1).replace(",", "."))
        except ValueError: continue
        if valeur >= LECTURE_MIN and not _decompte(plat, m.start(1), m.end(1)):
            sortie.append((valeur, m.start(1), m.end(1), plat))
    return sortie


# Nombres avec unité qui ne sont pas des mesures de l'examen (audit des contrôles du 07/11/2026, 11 fausses alertes
# sur 14) : eau à 30 degrés, « à peu près à 90 degrés » (la position du test), charges d'exercice conseillées ou
# racontées, « 100 kg ? » (une question), « capable de pousser quasiment 90 kg » (une estimation), « 10/5 » de la
# prise en charge par la sécurité sociale, et une cotation impossible (10 sur 5).
CONTEXTE_HORS_EXAMEN = {
    "°": re.compile(r"\beau\b|piscine|bain|temperature|il fait|dehors|position|a peu pres|environ"),
    "kg": re.compile(r"charges?\b|haltere|\blest|kettle|disque|monter les|repetitif|capable de|quasiment|pourrai|des gens"),
}
FACTURATION = re.compile(r"securite sociale|mutuelle|rembours|euros?\b")
# Lecture sans unité qui n'est qu'une supposition : « À ton avis ? 72. — T'as fait 92. », « idéalement, allez, 20 ».
SUPPOSITION = re.compile(r"a ton avis|a votre avis|devine|idealement|on vise|objectif")


def _hors_examen(bas, debut, fin, unite, valeur):
    if re.match(r"\s*\?", bas[fin:fin + 3]):
        return True
    if (unite == "sur 5" and valeur > 5) or (unite == "sur 10" and valeur > 10):
        return True
    # Facturation : dans la même phrase seulement (« On fait 10/5 sur la partie sécurité sociale. »).
    deb_phrase = max(bas.rfind(c, 0, debut) for c in ".?!\n") + 1
    fins = [i for i in (bas.find(c, fin) for c in ".?!\n") if i >= 0]
    if FACTURATION.search(bas[deb_phrase:min(fins) if fins else len(bas)]):
        return True
    motif = CONTEXTE_HORS_EXAMEN.get(unite)
    return bool(motif and motif.search(bas[max(0, debut - 80):debut]))


def mesures_manquantes(extraction, transcription, notes="", maxi=12):
    """Valeurs mesurées à voix haute pendant l'examen et absentes de l'extraction.

    On retient les nombres SUIVIS D'UNE UNITÉ clinique (cm, mm, kg, degrés, cotation sur 5 ou
    sur 10), et les lectures sans unité dans les seules tournures d'un test (_lectures_sans_unite) :
    un nombre nu quelconque est trop souvent un âge, une durée ou un décompte, et le signaler
    noierait la section. Une mesure notée par le kiné compte aussi comme dictée."""
    source = (transcription or "") + "\n" + (notes or "")
    plat = MILLIERS.sub("", _sans_accent(source))
    bas = plat.lower()
    presents = _nombres_du_texte(json.dumps(extraction, ensure_ascii=False))
    vus, trouves = set(), []
    for m in MESURE_DICTEE.finditer(plat):
        try: valeur = float(m.group(1).replace(",", "."))
        except ValueError: continue
        unite = _unite_lisible(m.group(2))
        if (valeur, unite) in vus or _hors_examen(bas, m.start(), m.end(), unite, valeur):
            continue
        vus.add((valeur, unite))
        if valeur in presents or any(abs(valeur - n) < 0.01 for n in presents):
            continue
        a, b = max(0, m.start() - 70), m.end() + 50
        trouves.append({"champ": "— mesure dictée", "valeur": _court(" ".join(plat[a:b].split()), 150),
                        "probleme": f"« {_nb(valeur)} {unite} » a été mesuré pendant le bilan "
                                    f"mais ne figure nulle part dans l'extraction"})
    for valeur, debut, fin, texte in _lectures_sans_unite(plat):
        if any(abs(valeur - v) < 0.01 for v, _ in vus) or SUPPOSITION.search(texte[max(0, debut - 40):debut].lower()):
            continue
        vus.add((valeur, ""))
        if any(abs(valeur - n) < 0.01 for n in presents):
            continue
        a, b = max(0, debut - 70), fin + 50
        trouves.append({"champ": "— mesure dictée", "valeur": _court(" ".join(texte[a:b].split()), 150),
                        "probleme": f"« {_nb(valeur)} » a été lu à voix haute pendant un test (sans unité "
                                    f"dictée) mais ne figure nulle part dans l'extraction"})
    reste = len(trouves) - maxi
    trouves = trouves[:maxi]
    if reste > 0:
        trouves.append({"champ": "— mesures dictées", "valeur": f"{reste} autre(s)",
                        "probleme": f"{reste} autre(s) mesure(s) dictée(s) manquent également "
                                    f"— l'extraction a perdu une grande partie du bilan chiffré"})
    return trouves


# Unité de force jamais prononcée : « 67 N » quand la séance ne parle que de kilos. Un facteur
# 10 sépare deux unités également plausibles, et aucun autre contrôle ne le voit (banc du
# 07/10/2026). Le kilo n'est pas contrôlé : c'est l'unité par défaut des dynamomètres, souvent
# sous-entendue, et la signaler à chaque bilan noierait la section.
UNITES_FORCE = {"n": r"newton", "dan": r"decanewton|\bdan\b", "lb": r"livres?\b|\blbs?\b"}
UNITES_DITES = dict(UNITES_FORCE, kg=r"\bkg\b|kilo")


def unites_non_dites(extraction, transcription, notes=""):
    """Mesures dont l'unité de force (N, daN, lb) n'est jamais prononcée."""
    source = _sans_accent((transcription or "") + "\n" + (notes or "")).lower()
    mesures = ((extraction or {}).get("examen_clinique") or {}).get("mesures") or []
    trouves, vues = [], set()
    for m in mesures:
        if not isinstance(m, dict):
            continue
        u = _sans_accent(str(m.get("unite") or "")).lower().strip().rstrip(".")
        u = {"newton": "n", "newtons": "n", "decanewton": "dan", "decanewtons": "dan", "lbs": "lb"}.get(u, u)
        if u not in UNITES_FORCE or u in vues or re.search(UNITES_FORCE[u], source):
            continue
        vues.add(u)
        dites = [k for k, motif in UNITES_DITES.items() if re.search(motif, source)]
        trouves.append({"champ": "examen_clinique.mesures",
                        "valeur": _court(f"{m.get('mesure')} : {m.get('valeurs')} {m.get('unite')}"),
                        "probleme": f"unité « {m.get('unite')} » jamais prononcée dans la transcription"
                                    + (f" (on y entend : {', '.join(dites)})" if dites else "") + " — à vérifier"})
    return trouves


# R5 : côté d'une mesure du jour qu'aucun mot de la transcription n'énonce près de la lecture.
# « Encore, encore. Parfait. 67. » : ni droite ni gauche pendant toute la série. Le côté de
# l'extraction est alors DÉDUIT du contexte — et sur le banc du 07/10/2026, deux lectures
# indépendantes l'ont déduit à l'envers, d'accord entre elles, donc sans aucune discordance.
# Le contrôle ne dit pas que le côté est faux : qu'il n'a pas été dit, et doit être confirmé.
COTE_ENONCE = re.compile(r"\b(droite?s?|gauches?)\b|\bautre (cote|jambe|bras|pied|main|genou|epaule|hanche|cheville)"
                         r"|\bl['’]autre\b", re.I)
AVANT_LECTURE, APRES_LECTURE = 400, 60


SERIE_MAX = 2000        # caractères : une série de force, encouragements compris, tient dans cette distance


def _dernier_cote(bas, p):
    """Dernier côté nommé avant la lecture ; « l'autre (côté, jambe…) » annonce un changement sans le nommer : None."""
    ms = list(re.finditer(r"\b(droite?s?|gauches?)\b|\bautre (?:cote|jambe|bras|pied|main|genou|epaule|hanche|cheville)\b"
                          r"|\bl'autre\b|\bon change\b", bas[max(0, p - SERIE_MAX):p]))
    if not ms or not ms[-1].group(1):
        return None
    return "gauche" if ms[-1].group(1).startswith("g") else "droit"


def _cotes_attendus(bas, p):
    """Côtés compatibles avec l'ordre du test à cette lecture : le dernier côté annoncé (basculé par « l'autre côté »),
    et l'autre côté si une série a déjà été lue depuis cette annonce (seconde série d'un test bilatéral, que le praticien
    ne renomme pas : « déduit sans ambiguïté de l'ordre du test » pour les relecteurs de l'audit du 07/11/2026)."""
    fen = bas[max(0, p - SERIE_MAX):p]
    cote, depuis = None, 0
    for mk in re.finditer(r"\b(droite?s?|gauches?)\b|\bautre (?:cote|jambe|bras|pied|main|genou|epaule|hanche|cheville)\b"
                          r"|\bl'autre\b|\bon change\b", fen):
        if mk.group(1):
            cote = "gauche" if mk.group(1).startswith("g") else "droit"
        elif cote:
            cote = "gauche" if cote == "droit" else "droit"
        depuis = mk.end()
    if cote is None:
        return set()
    oppose = "gauche" if cote == "droit" else "droit"
    return {cote, oppose} if re.search(r"(?<![\d,.])\d{2,3}(?:[.,]\d)?(?!\d)", fen[depuis:]) else {cote}


def cotes_non_enonces(extraction, transcription, notes=""):
    """Mesures du jour dotées d'un côté qu'aucun mot n'énonce près des lectures."""
    plat = DECIMALE_COUPEE.sub(r"\1,\2", MILLIERS.sub("", _sans_accent((transcription or "") + "\n" + (notes or ""))))
    bas = plat.lower()
    mesures = ((extraction or {}).get("examen_clinique") or {}).get("mesures") or []
    trouves = []
    for m in mesures:
        if not isinstance(m, dict) or m.get("moment") != "ce jour" or m.get("cote") not in ("droit", "gauche"):
            continue
        texte = re.sub(r"\([^)]*\)", " ", str(m.get("valeurs") or ""))
        texte = re.sub(r"(sur|/)\s*(5|10|20|100)\b", " ", texte)
        deduits = []
        # Un ordinal n'est pas une lecture : « arrêtée à la 2e répétition » donnait « 2 (gauche) » (M S, 12/10/2026).
        for v in re.findall(r"(?<![\d,.])\d+(?:[.,]\d+)?(?![\d,.]|(?:e|er|re|ère|ere|ème|eme)\b)", texte):
            motif = r"(?<![\d,.])" + re.sub(r"[.,]", "[.,]", v) + r"(?![\d]|[.,]\d)"
            lieux = [x.start() for x in re.finditer(motif, plat)]
            # Valeur absente de la transcription : d'autres contrôles s'en chargent.
            # Le côté annoncé en tête de série (« on commence à droite », puis encouragements et plusieurs essais) vaut
            # pour les lectures qui suivent, et la série suivante sans annonce porte sur l'autre côté (_cotes_attendus).
            # Audit du 07/11/2026 : 12 des 16 fausses alertes retrouvées retirées, 1 juste perdue sur 4.
            if lieux and not any(COTE_ENONCE.search(plat[max(0, p - AVANT_LECTURE):p + APRES_LECTURE])
                                 or m.get("cote") in _cotes_attendus(bas, p) for p in lieux):
                deduits.append(v)
        if deduits:
            trouves.append({"champ": "examen_clinique.mesures",
                            "valeur": _court(f"{m.get('mesure')} : {' ; '.join(deduits)} ({m.get('cote')})"),
                            "probleme": "côté jamais prononcé près de ces lectures : déduit, à confirmer"})
    return trouves


# Lésion jamais prononcée : « fracture de la clavicule » écrite deux fois par le 27B chez un
# patient qui parle d'un choc sur la clavicule sans jamais dire « fracture » (banc du
# 07/10/2026). Un diagnostic lésionnel inventé se lit comme une donnée plausible et aucun
# contrôle de chiffre ou de côté ne le voit. On signale tout terme de lésion de l'extraction
# dont la racine n'apparaît nulle part dans la transcription ni dans les notes.
LESIONS = {"fracture": r"fractur", "rupture": r"ruptur", "luxation": r"luxa|luxe", "déchirure": r"dechir",
           "arrachement": r"arrach", "entorse": r"entors", "hernie": r"herni", "fissure": r"fissur",
           "tassement": r"tassement", "lésion méniscale": r"menisc|menisq"}
# Formes déformées par la transcription qui valent prononciation (« un morceau de médisque »).
# Les mots du patient valent aussi : « les vertèbres qui sont cassées » est une fracture.
LESIONS_ENTENDUES = {"lésion méniscale": r"menisc|menisq|medisq|menisk", "fracture": r"fractur|casse",
                     "rupture": r"ruptur|rompu|romp", "entorse": r"entors|foul", "déchirure": r"dechir",
                     "luxation": r"luxa|luxe|deboit|demis"}
# Mention niée (« pas de fracture », « Fracture non évaluée ») : rien n'est affirmé.
LESION_NIEE = r"(pas d[eu]?|sans|aucune?|absence d[eu]?|ni)\s+(\w+\s+){0,2}$"


# Signes d'examen : même faute que la lésion jamais prononcée. Banc du 12/10/2026 : « Atrophie
# visible du quadriceps gauche » écrit pour un bilan où ni le mot ni l'idée (fonte, volume,
# « moins de muscle ») n'apparaissent. Les équivalents oraux valent prononciation.
SIGNES_EXAMEN = {"atrophie": r"atroph|amyotroph|fonte musculaire", "épanchement": r"epanchement",
                 "œdème": r"oedem", "hématome": r"hematome", "ecchymose": r"ecchymo", "rougeur": r"rougeur|erythem",
                 "chaleur locale": r"chaleur", "crépitation": r"crepit", "contracture": r"contractur"}
SIGNES_EXAMEN_ENTENDUS = {
    "atrophie": (r"atroph|fonte|fondu|volume (musculaire|du muscle|de la cuisse|du mollet|du quadri)|moins de muscle|moins muscle|perdu du muscle"
                 r"|(cuisse|mollet|muscle|quadri\w*|jambe|bras|epaule)[^.?!]{0,25}(plus fine?|moins grosse?|maigri|fondu)"),
    "épanchement": r"epanchement|gonfl|liquide|glacon|choc rotulien|enfl",
    "œdème": r"oedem|gonfl|enfl|gros",
    "hématome": r"hematome|bleu|sang", "ecchymose": r"ecchymo|bleu|hematome",
    "rougeur": r"rouge", "chaleur locale": r"chaud|chaleur",
    "crépitation": r"crepit|craqu|crisse|frott|grince",
    "contracture": r"contractur|tendu|dur\b|noeud|tension|crispe"}


def lesions_non_dites(extraction, transcription, notes=""):
    """Termes de lésion présents dans l'extraction, jamais prononcés dans la séance."""
    return _termes_non_dits(extraction, transcription, notes, LESIONS, LESIONS_ENTENDUES, "diagnostic à confirmer")


# Tests nommés (éponymes, sigles) : un nom de test écrit que la séance ne prononce jamais — « Lachman » pour un tiroir
# décrit sans son nom, « Slump » au membre supérieur (audit des contrôles du 07/11/2026). Les formes déformées par la
# transcription valent prononciation. Pas de « patte » (patte d'oie) ni de mots courants.
TESTS_NOMMES = {
    "Lachman": r"lachman|lakman", "Lasègue": r"lasegue|la segue|lassegue|lasseg", "Slump": r"slump|slomp",
    "Neer": r"\bneer\b|\bnir\b", "Hawkins": r"hawkins?|aukins", "Jobe": r"\bjobe?\b", "Gerber": r"gerber|lift.?off",
    "Speed": r"\bspeed\b", "Yergason": r"yergason", "O'Brien": r"o.?brien", "McMurray": r"m[ac] ?murray",
    "Thessaly": r"thessal", "Apley": r"apley", "Trendelenburg": r"trendelen", "Thomas": r"\bthomas\b", "Ober": r"\bober\b",
    "FABER": r"\bfaber\b|patrick", "FADIR": r"\bfadir\b", "Spurling": r"spurling", "Phalen": r"phalen", "Tinel": r"tinel",
    "Finkelstein": r"finkelstein", "Thompson": r"thomps", "Schober": r"schober", "Romberg": r"romberg", "Kemp": r"\bkemp\b",
    "Cozen": r"cozen", "TUG": r"\btug\b|up and go", "Tinetti": r"tinetti", "Berg": r"\bberg\b"}


def tests_non_dits(extraction, transcription, notes=""):
    """Tests nommés dans l'extraction, jamais prononcés dans la séance."""
    return _termes_non_dits(extraction, transcription, notes, TESTS_NOMMES, {}, "test à confirmer")


# Constat NÉGATIF jamais vérifié : « pas de chaleur, pas de rougeur » écrit pour une séance qui n'en parle pas. Un
# négatif inventé est une information médicale fausse au même titre qu'un positif (audit du 07/11/2026). Les mots
# entendus sont ceux des signes d'examen ; « infection » et « fièvre » s'y ajoutent hors du champ des signes d'alerte.
NEGATIFS = dict(SIGNES_EXAMEN, infection=r"infect|septique", fievre=r"fievre|febri")
NEGATIFS_ENTENDUS = dict(SIGNES_EXAMEN_ENTENDUS, infection=r"infect|septique|pus\b|antibio", fievre=r"fievre|temperature|febri")
NEGATION = r"(?:pas d[eu']?\s*|sans |aucune? |absence d[eu']?\s*|ni |non |ni d[eu']?\s*)"


def negatifs_non_verifies(extraction, transcription, notes=""):
    """Constats négatifs (« pas de chaleur ») sur un signe dont la séance ne parle jamais."""
    source = _sans_accent((transcription or "") + "\n" + (notes or "")).lower()
    jamais = {nom: motif for nom, motif in NEGATIFS.items() if not re.search(r"\b(" + NEGATIFS_ENTENDUS[nom] + r")", source)}
    trouves, vus = [], set()
    if not jamais:
        return trouves
    for champ, valeur in _parcourir(extraction):
        if champ.startswith("diagnostic.signes_alerte"):
            continue                          # déjà traité : retiré par signes_alerte_non_abordes
        plat = _sans_accent(str(valeur)).lower()
        for nom, motif in jamais.items():
            if nom in vus or not re.search(NEGATION + r"(?:\w+\s+){0,2}?(?:" + motif + r")", plat):
                continue
            vus.add(nom)
            trouves.append({"champ": champ, "valeur": _court(" ".join(str(valeur).split())),
                            "probleme": f"constat négatif sur « {nom.replace('fievre', 'fièvre')} » : la séance n'en parle "
                                        f"jamais — à retirer s'il n'a pas été vérifié"})
    return trouves


def exercices_qui_sont_des_tests(extraction):
    """Programme à domicile qui reprend un test de l'examen (« Test de force », « avant les tests ») : l'exercice
    fait en séance n'est pas une consigne pour la maison (défaut relevé à chaque relecture depuis le 01/11/2026)."""
    pc = (extraction or {}).get("prise_en_charge") or {}
    trouves = []
    for i, ex in enumerate(pc.get("exercices_a_domicile") or pc.get("programme_hep") or [], 1):
        texte = " ".join(str(v) for v in (ex.values() if isinstance(ex, dict) else [ex]))
        plat = _sans_accent(texte).lower()
        # Un test cité entre parenthèses décrit l'exercice (« mobilisation … (test de tension nerveuse) », un vrai
        # exercice à domicile) : fausse alerte sur le banc du 07/11/2026.
        if re.search(r"\btests? d[eu'](?!\s*ressenti)|\btests? \w+ (positif|negatif)|\btesting\b|dynamometr|\bbilan\b",
                     re.sub(r"\([^)]*\)", " ", plat)) or re.search(r"(avant|apres|pour) les tests", plat):
            trouves.append({"champ": f"prise_en_charge.exercices_a_domicile[{i}]", "valeur": _court(texte),
                            "probleme": "exercice à domicile qui ressemble à un test de l'examen — à retirer du "
                                        "programme s'il n'a pas été prescrit pour la maison"})
    return trouves


def signes_examen_non_dits(extraction, transcription, notes=""):
    """Signes d'examen affirmés dans l'extraction, que la séance n'évoque jamais."""
    return _termes_non_dits(extraction, transcription, notes, SIGNES_EXAMEN, SIGNES_EXAMEN_ENTENDUS, "constat à confirmer")


# Organe jamais prononcé : « Nodule thyroïdien » écrit pour « j'ai un nodule » (la parathormone
# était en cause ; banc du 12/10/2026), « cancer de l'ovaire » deviné sur « ambiance sérénale »
# (banc du 05/10/2026). Une reconstruction TRACÉE — glande surrénale (transcrit : « … ») — n'est
# pas signalée : la consigne la demande et la forme entendue est sous les yeux du relecteur.
ORGANES = {"thyroïde": r"thyro", "parathyroïde": r"parathyro", "surrénale": r"surrenal", "rein": r"reins?\b|renal|renaux",
           "foie": r"foie|hepati", "poumon": r"poumon|pulmon", "cœur": r"c(?:oe|œ)ur|cardiaq", "ovaire": r"ovair|ovarien",
           "utérus": r"uterus|uterin", "prostate": r"prostat", "pancréas": r"pancrea", "intestin": r"intestin",
           "estomac": r"estomac", "sein": r"mammair"}


def organes_non_dits(extraction, transcription, notes=""):
    """Organes nommés dans l'extraction, jamais prononcés dans la séance (sauf reconstruction tracée)."""
    return _termes_non_dits(extraction, transcription, notes, ORGANES, {}, "organe à confirmer", trace=True)


# Année impossible : postérieure à la séance, ou antérieure à la naissance du patient. « Basket arrêté
# fin 2005 » chez une patiente de 16 ans : Whisper a écrit 2005 pour 2025, le modèle l'a recopié, et
# le contrôle des nombres ne pouvait rien voir — le nombre est dans la transcription (banc du 13/10/2026,
# seul signalement sur 127 comptes rendus).
ANNEE = re.compile(r"\b(19\d\d|20\d\d)\b")


def annees_impossibles(extraction, jour):
    """Années de l'extraction postérieures à la séance (`jour` = « jj-mm-aaaa ») ou antérieures à la naissance."""
    m = re.search(r"(\d{4})$", str(jour or ""))
    if not m:
        return []
    seance = int(m.group(1))
    age = re.search(r"\d{1,3}", str(((extraction or {}).get("identite_patient") or {}).get("age") or ""))
    naissance = seance - int(age.group(0)) - 1 if age else None
    trouves, vus = [], set()
    for champ, valeur in _parcourir(extraction):
        for a in sorted({int(x) for x in ANNEE.findall(str(valeur))} - vus):
            if a > seance:
                raison = f"l'année {a} est postérieure à la séance"
            elif naissance and a < naissance:
                raison = f"l'année {a} est antérieure à la naissance (âge : {age.group(0)} ans)"
            else:
                continue
            vus.add(a)
            trouves.append({"champ": champ, "valeur": _court(" ".join(str(valeur).split())),
                            "probleme": raison + " — date mal transcrite ? à confirmer"})
    return trouves


# Séance antérieure jamais évoquée : « Bilan de suivi », « amélioration par rapport à la séance
# précédente » écrits pour un premier bilan (Diboun, banc du 12/10/2026). Le moment « séance
# précédente » d'une MESURE n'est pas visé : il désigne aussi des valeurs d'une prise en charge
# antérieure (« 34 à gauche, 32 à droite, le 30 juillet 2025, à la fin de la rééducation »).
SUIVI_ECRIT = re.compile(r"seance precedente|bilan de suivi|derniere seance|par rapport a la (derniere|precedente)"
                         r"|depuis la derniere (seance|fois)")
SUIVI_DIT = re.compile(r"derniere seance|seance precedente|seance d.avant|on s.etait vus?|la (premiere|derniere) fois qu.on"
                       r" (s.est|s.etait) vus?|la derniere fois (on|vous|tu|que)|on avait (fait|mesure|teste)|premier bilan"
                       r"|a l.epoque|fin de (la|ta|votre) reeducation|depuis la derniere fois"
                       r"|depuis le debut de la (prise en charge|reeducation)")


def seance_anterieure_inventee(extraction, transcription, notes=""):
    """Séance antérieure (« suivi », « séance précédente ») écrite alors que la séance n'en évoque aucune."""
    if SUIVI_DIT.search(_sans_accent((transcription or "") + "\n" + (notes or "")).lower()):
        return []
    for champ, valeur in _parcourir(extraction):
        if not champ.endswith(".moment") and SUIVI_ECRIT.search(_sans_accent(str(valeur)).lower()):
            return [{"champ": champ, "valeur": _court(" ".join(str(valeur).split())),
                     "probleme": "séance antérieure jamais évoquée pendant la séance — premier bilan ? à confirmer"}]
    return []


# Question posée à la forme négative suivie d'un « oui » ou d'un « non » nu : « Et la nuit, ça ne te
# réveille pas ? Ça ne te fait pas mal ? — Oui. » Le 27B comme le 35B en ont tiré « douleur nocturne
# présente » (Nourel, banc du 12/10/2026 ; aucune règle de consigne n'a suffi). On ne signale que si
# l'extraction AFFIRME le symptôme de la question : seul cas où la réponse a pu être mal lue.
SYMPTOMES_QUESTION = {"douleur ou réveil nocturne": r"nuit|reveill|nocturne", "fourmillements": r"fourmill|picot|engourd",
                      "gonflement": r"gonfl|enfl", "fièvre": r"fievre", "chute": r"tomb|chute", "blocage": r"bloqu|blocage"}
_PHRASE = re.compile(r"[^.?!]+[.?!]?")
_QUESTION_NIEE = re.compile(r"\b(ne|n)\b[^.?!]{0,60}\b(pas|plus|jamais)\b")
_ECRIT_NIE = re.compile(r"\b(pas d|pas de|sans|aucune?|absence|ni|non|ne\b[^;.]*\bpas)\b")


def questions_negatives_ambigues(extraction, transcription, notes=""):
    """Symptôme affirmé dans l'extraction après une question à la forme négative suivie d'un oui/non nu."""
    phrases = [p.strip() for l in (transcription or "").split("\n") for p in _PHRASE.findall(l) if p.strip()]
    candidats, bloc = [], []
    for p in phrases:
        plat = _sans_accent(p).lower()
        if plat.endswith("?"):
            bloc.append((p, plat))
            continue
        if bloc and re.match(r"(oui|non|si)\b", plat) and len(plat.split()) <= 6:
            for nom, motif in SYMPTOMES_QUESTION.items():
                q = next((q for q, qp in bloc if _QUESTION_NIEE.search(qp) and re.search(motif, qp)), None)
                if q:
                    candidats.append((nom, motif, q, p.split()[0].strip(",.!")))
        bloc = []
    trouves, vus = [], set()
    for nom, motif, question, reponse in candidats:
        if nom in vus:
            continue
        for champ, valeur in _parcourir(extraction):
            segments = re.split(r"\s*;\s*|\.\s+|,\s*", _sans_accent(str(valeur)).lower())
            if any(re.search(motif, s) and not _ECRIT_NIE.search(s) for s in segments):
                vus.add(nom)
                trouves.append({"champ": champ, "valeur": _court(" ".join(str(valeur).split())),
                                "probleme": f"{nom} affirmé, mais la question était posée à la forme négative "
                                            f"(« {_court(question, 70)} — {reponse.capitalize()} ») : sens ambigu, à confirmer"})
                break
    return trouves


def _termes_non_dits(extraction, transcription, notes, termes, entendus, suite, trace=False):
    source = _sans_accent((transcription or "") + "\n" + (notes or "")).lower()
    # Un terme prononcé dans la séance n'est jamais signalé : ce test ne dépend pas du champ, il est fait une fois par
    # terme (il était refait pour chaque champ : ~2 s de contrôles par bilan, presque tout ici ; 07/11/2026).
    jamais_dits = {nom: motif for nom, motif in termes.items()
                   if not re.search(r"\b(" + entendus.get(nom, motif) + r")", source)}
    trouves, vus = [], set()
    if not jamais_dits:
        return trouves
    for champ, valeur in _parcourir(extraction):
        plat = _sans_accent(str(valeur)).lower()
        for nom, motif in jamais_dits.items():
            if nom in vus:
                continue
            affirmees = [m for m in re.finditer(r"\b(" + motif + r")\w*", plat)
                         if not re.search(LESION_NIEE, plat[max(0, m.start() - 30):m.start()])
                         and not re.match(r"\s*(non (evalue|precise|recherche|teste)|exclue?|ecartee?|absente?)", plat[m.end():])
                         and not (trace and "transcrit" in plat[m.end():m.end() + 80])]
            if not affirmees:
                continue
            vus.add(nom)
            trouves.append({"champ": champ, "valeur": _court(" ".join(str(valeur).split())),
                            "probleme": f"« {nom} » n'est jamais prononcé dans la transcription — {suite}"})
    return trouves


# ── R2 : appariement d'un côté explicitement énoncé ─────────────────────────
# « Donc tu as un genou au dessus de la rotule, à gauche 34 cm » : le 27B a écrit « 34 cm
# (5 cm au-dessus rotule droite) ». Les deux côtés étant prononcés ailleurs dans le bilan, le
# contrôle de latéralité ne pouvait rien voir. Ici on ne vérifie pas qu'un côté a été
# prononcé, mais qu'il est rattaché au BON nombre.
CHIFFRE = r"\d+(?:[.,]\d+)?"
COTE_MOT = r"droites?|droits?|gauches?"
# Un côté et un nombre séparés par au plus 12 caractères, SANS franchir une virgule ni un
# point-virgule : « à gauche 34 », « 54 à droite ». Sans la borne, « opéré il y a 25 ans du
# genou droit » apparierait 25 et droit ; sans l'interdit de séparateur, « 39 cm à gauche,
# 37 cm » apparierait aussi 37 à gauche.
# La fenêtre ne franchit ni virgule, ni point-virgule, ni FIN DE PHRASE : « et 8 kilos à
# gauche. C'est 4,8. » appariait « gauche » avec le 4,8 de la phrase suivante.
FENETRE = r"[^\d;,.\n]{0,12}?"
APRES = re.compile(r"(" + COTE_MOT + r")" + FENETRE + r"(" + CHIFFRE + r")", re.I)
AVANT = re.compile(r"(" + CHIFFRE + r")" + FENETRE + r"(" + COTE_MOT + r")", re.I)
# En dessous de ce seuil, un nombre voisin d'un côté est trop souvent une coïncidence
# (« 2 ans », « 3 fois »). Les cotations 2/5 et 3/5 ne sont donc pas appariées : leur
# latéralité reste couverte par le contrôle de présence d'un côté, pas par celui-ci.
APPARIEMENT_MIN = 4.0
UNITE_COLLEE = re.compile(r"\s*(cm|mm|kg|kilos?|degres|°)", re.I)
# Dans l'extraction, un champ se lit par segments : un modèle écrit « 34 cm à droite, 39 cm à
# gauche » et les deux côtés sont présents dans le champ. Prendre une fenêtre de caractères
# autour du nombre y voit TOUJOURS les deux côtés, donc ne signale jamais rien.
# La virgule sépare deux segments SAUF entre deux chiffres : « test de poussée : 4,8 kg
# (côté droit) » produisait les segments « … : 4 » et « 8 kg (côté droit) », donc un faux
# signalement sur un 8 qui n'existe pas (constaté au banc du 06/10/2026).
SEGMENT = re.compile(r"(?<!\d),(?!\d)|[;\n·]")


def _cote_de(mot):
    return "gauche" if _sans_accent(mot).lower().startswith("gauche") else "droit"


def _appariements(texte):
    """[(valeur, unité, côté)] pour les nombres collés à un côté nommé."""
    plat = MILLIERS.sub("", _sans_accent(texte or ""))
    out = []
    for motif, (i_cote, i_nb) in ((APRES, (1, 2)), (AVANT, (2, 1))):
        for m in motif.finditer(plat):
            debut = m.start(i_nb)
            # « 4 sur 5 » : le 5 est le dénominateur d'une cotation, pas une mesure.
            if plat[max(0, debut - 5):debut].lower().rstrip().endswith(("sur", "/")):
                continue
            try: valeur = float(m.group(i_nb).replace(",", "."))
            except ValueError: continue
            if valeur < APPARIEMENT_MIN:
                continue
            u = UNITE_COLLEE.match(plat, m.end(i_nb))
            out.append((valeur, _unite_lisible(u.group(1)) if u else "",
                        _cote_de(m.group(i_cote))))
    return out


def _cotes_par_valeur(texte):
    par = {}
    for valeur, _, cote in _appariements(texte):
        par.setdefault(valeur, set()).add(cote)
    return par


def _mesures_structurees(extraction, moments=None):
    """[(chemin, texte, côté)] pour chaque élément portant « cote » et « valeurs ».

    Depuis le 06/10/2026 les mesures sont structurées : la valeur et son côté sont dans DEUX
    champs du même élément. Les règles qui cherchent un côté à côté d'un nombre seraient
    devenues muettes sans prévenir ; on recompose donc chaque élément en un seul segment."""
    out = []

    def visiter(noeud, chemin=""):
        if isinstance(noeud, dict):
            if "cote" in noeud and "valeurs" in noeud:
                cote = _cotes_presentes(str(noeud.get("cote") or ""))
                if len(cote) == 1 and (moments is None or noeud.get("moment") in moments):
                    out.append((chemin, f"{noeud.get('valeurs')} {noeud.get('unite') or ''}".strip(),
                                next(iter(cote))))
                return
            for k, v in noeud.items():
                visiter(v, f"{chemin}.{k}" if chemin else k)
        elif isinstance(noeud, list):
            for i, v in enumerate(noeud):
                visiter(v, f"{chemin}[{i + 1}]")

    visiter(extraction)
    return out


def appariements_errones(extraction, transcription, notes=""):
    """Nombres rattachés dans l'extraction au côté opposé à celui qui a été énoncé.

    On n'exploite que les appariements NON AMBIGUS de la transcription : une valeur associée
    à un seul côté. Une valeur dite des deux côtés n'apprend rien."""
    attendus = {v: next(iter(c)) for v, c in
                _cotes_par_valeur((transcription or "") + "\n" + (notes or "")).items()
                if len(c) == 1}
    if not attendus:
        return []
    trouves = []
    for chemin, texte, cote in _mesures_structurees(extraction):
        for m in re.finditer(CHIFFRE, MILLIERS.sub("", texte)):
            try: n = float(m.group(0).replace(",", "."))
            except ValueError: continue
            if attendus.get(n) and attendus[n] != cote:
                trouves.append({"champ": chemin, "valeur": _court(f"{texte} — {cote}"),
                                "probleme": f"« {_nb(n)} » est rattaché à {cote}, or la "
                                            f"transcription l'énonce à {attendus[n]}"})
                break
    for champ, valeur in _parcourir(extraction):
        for segment in SEGMENT.split(str(valeur)):
            plat = MILLIERS.sub("", _sans_accent(segment))
            cotes = _cotes_presentes(plat)
            if len(cotes) != 1:         # segment sans côté, ou qui parle des deux : muet
                continue
            cote = next(iter(cotes))
            for m in re.finditer(CHIFFRE, plat):
                debut = m.start()
                if plat[max(0, debut - 5):debut].lower().rstrip().endswith(("sur", "/")):
                    continue
                try: n = float(m.group(0).replace(",", "."))
                except ValueError: continue
                if attendus.get(n) and attendus[n] != cote:
                    trouves.append({
                        "champ": champ, "valeur": _court(" ".join(segment.split())),
                        "probleme": f"« {_nb(n)} » est rattaché à {cote}, or la transcription "
                                    f"l'énonce à {attendus[n]}"})
                    break
    return trouves


# ── R3 : cohérence d'un écart annoncé avec les valeurs par côté ─────────────
# Le 27B écrit « 2 cm de plus à 5 cm au-dessus de la rotule à droite » ET « 39 cm (gauche),
# 34 cm (droite) » : l'écart annoncé ne se retrouve pas dans ses propres valeurs, et le côté
# qu'il dit le plus gros est le plus petit. Chacune des deux moitiés est plausible seule.
ECART = re.compile(r"(" + CHIFFRE + r")\s*(cm|mm|kg|kilos?|degres|°)?\s*de\s+(plus|moins)"
                   r"\D{0,40}?(" + COTE_MOT + r")", re.I)


def ecarts_incoherents(extraction):
    """Écarts entre côtés annoncés par l'extraction que ses propres valeurs contredisent.

    Les valeurs par côté et l'écart annoncé se trouvent souvent dans des champs différents :
    on raisonne donc sur tout l'examen clinique, pas champ par champ."""
    ensemble = " ; ".join(str(v) for _, v in _parcourir(extraction))
    # Les valeurs se comparent PAR UNITÉ : un écart en centimètres ne se vérifie pas contre des
    # kilos. Sans ce tri, le produit croisé de toutes les valeurs finit par retrouver n'importe
    # quel écart par hasard, et la règle ne prouve plus rien.
    par_unite = {}
    for valeur, unite, cote in _appariements(ensemble):
        par_unite.setdefault(unite, {}).setdefault(cote, set()).add(valeur)
    # Mesures structurées : seulement celles DU JOUR — un écart énoncé porte sur la séance,
    # le comparer à une valeur préopératoire produirait une fausse contradiction.
    for _, texte, cote in _mesures_structurees(extraction, moments=("ce jour",)):
        u = UNITE_COLLEE.search(" " + texte)
        unite = _unite_lisible(u.group(1)) if u else ""
        for m in re.finditer(CHIFFRE, MILLIERS.sub("", texte)):
            try: v = float(m.group(0).replace(",", "."))
            except ValueError: continue
            if v >= APPARIEMENT_MIN:
                par_unite.setdefault(unite, {}).setdefault(cote, set()).add(v)
    trouves = []
    for m in ECART.finditer(MILLIERS.sub("", _sans_accent(ensemble))):
        try: ecart = float(m.group(1).replace(",", "."))
        except ValueError: continue
        if ecart < 0.01:
            continue
        sens, cote = m.group(3).lower(), _cote_de(m.group(4))
        cotes = par_unite.get(_unite_lisible(m.group(2)) if m.group(2) else "") or {}
        paires = [(abs(d - g), d, g) for d in (cotes.get("droit") or ())
                  for g in (cotes.get("gauche") or ())]
        correspond = [(d, g) for (diff, d, g) in paires if abs(diff - ecart) < 0.01]
        annonce = " ".join(m.group(0).split())
        if not correspond:
            if paires:
                trouves.append({"champ": "examen_clinique", "valeur": _court(annonce),
                                "probleme": f"l'écart annoncé de {_nb(ecart)} ne se retrouve "
                                            f"dans aucune paire de valeurs par côté de "
                                            f"l'extraction"})
            continue
        d, g = correspond[0]
        plus_grand = "droit" if d > g else "gauche"
        attendu = cote if sens == "plus" else ("gauche" if cote == "droit" else "droit")
        if plus_grand != attendu:
            trouves.append({"champ": "examen_clinique", "valeur": _court(annonce),
                            "probleme": f"« {annonce} » contredit les valeurs de l'extraction "
                                        f"({_nb(d)} à droite, {_nb(g)} à gauche)"})
    return trouves


# ── R4 : un côté rattaché à une articulation jamais nommée avec ce côté ─────
# « Douleur clavicule gauche » : le patient parle de « la clavicule » sans dire laquelle. Le
# contrôle de présence d'un côté ne voit rien, puisque « gauche » est prononcé ailleurs
# (pour le genou). Même faute chez une patiente dont le modèle écrit « genou droit gonflé »
# quand la transcription dit « remonter ce côté-là ». Une règle de prompt explicite n'a pas
# suffi (banc du 06/10/2026) : on vérifie que l'articulation a été NOMMÉE avec ce côté.
#
# On ne regarde que les articulations et segments osseux. Un muscle hérite du côté de son
# membre (« le quadriceps » du genou opéré) et le praticien le nomme rarement avec son côté :
# le contrôler ferait du bruit.
# « Pointe des pieds » est un test, « à pied » une marche : pas le pied comme articulation (audit du 07/11/2026 :
# « montée sur la pointe des pieds douloureuse côté droit » signalé comme pied droit sans appui).
SITES = {"genou": r"genou", "cheville": r"chevill", "epaule": r"epaule", "hanche": r"hanche",
         "coude": r"coude", "poignet": r"poignet", "main": r"\bmains?\b",
         "pied": r"(?<!pointe des )(?<!pointe de )(?<!pointe du )(?<!sur les )(?<!\ba )\bpieds?\b(?! joints| nus)",
         "clavicule": r"clavicul", "omoplate": r"omoplate|scapula", "rotule": r"rotule",
         "talon": r"talon", "avant-bras": r"avant-bras"}
PROXIMITE = 80          # caractères, dans la même phrase : « ton genou gauche est gonflé »
# Le praticien établit souvent le côté au niveau du MEMBRE (« sur la jambe gauche ») sans
# nommer l'articulation avec ce côté : un côté énoncé pour la jambe vaut pour le genou, la
# cheville et le pied. Sans cela, la règle faisait autant de faux positifs que de vrais.
MEMBRES = ((r"\bjambes?\b|membre inferieur|cuisse", ("genou", "cheville", "pied", "rotule", "talon", "hanche")),
           (r"\bbras\b|membre superieur", ("epaule", "coude", "poignet", "main", "avant-bras",
                                            "clavicule", "omoplate")))


def _phrases(texte):
    return [p for p in re.split(r"(?<=[.!?])\s+|\n", _sans_accent(texte or "").lower()) if p.strip()]


# Question de côté posée et tranchée (« C'est à droite ou à gauche ? — C'est gauche. ») : la réponse vaut pour
# l'articulation dont on parle, même si le mot n'est pas redit. Audit des contrôles du 07/11/2026 : la neutralisation
# retirait le côté de l'épaule douloureuse dans les 28 comptes rendus d'un même bilan, dit seulement ainsi.
# Aussi « T'as deux côtés ou que du côté droit ? — Côté droit. » : une question qui porte sur le côté, puis une
# réponse qui en nomme un dans ses cinq premiers mots. Le côté vaut pour l'articulation dont on parle et pour les
# autres articulations du même membre (une plainte du tendon d'Achille droit rend « cheville droite » appuyée).
# Seulement une VRAIE question de choix : « plus costaud du gauche que du droit ? » (une comparaison) et « à droite
# et gauche ? » (un test des deux côtés) n'établissent aucun côté. La réponse ne doit nommer qu'un seul côté.
QUESTION_COTE = re.compile(r"(?:\b(?:a )?droite ou (?:a |du )?gauche|\b(?:a )?gauche ou (?:a |du )?droite?|\bquel cote|\bdeux cotes ou (?:que )?(?:du )?cote (?:droit|gauche))"
                           r"\s*\?\s*([^.?!\n]{0,40})")
SUJET_AVANT = 600       # caractères avant la question où chercher l'articulation dont on parle
MEMBRE_DU_SITE = {site: sites for _, sites in MEMBRES for site in sites}


def _ancres(transcription, notes=""):
    """(articulation, côté) effectivement nommés ensemble dans la transcription ou les notes."""
    source = _phrases((transcription or "") + "\n" + (notes or ""))
    ancres = set()
    for ph in source:
        for site, motif in SITES.items():
            for m in re.finditer(motif, ph):
                fen = ph[max(0, m.start() - PROXIMITE):m.end() + PROXIMITE]
                for cote in _cotes_presentes(fen):
                    ancres.add((site, cote))
        for motif, sites in MEMBRES:
            for m in re.finditer(motif, ph):
                fen = ph[max(0, m.start() - 25):m.end() + 25]
                for cote in _cotes_presentes(fen):
                    ancres.update((site, cote) for site in sites)
    plat = _sans_accent((transcription or "") + "\n" + (notes or "")).lower()
    frequences = {site: len(re.findall(motif, plat)) for site, motif in SITES.items()}
    principal = max(frequences, key=frequences.get) if any(frequences.values()) else None
    for q in QUESTION_COTE.finditer(plat):
        dits = _cotes_presentes(q.group(1))
        if len(dits) != 1:
            continue
        cote = next(iter(dits))
        avant = plat[max(0, q.start() - SUJET_AVANT):q.start()]
        sujets = [site for site, motif in SITES.items() if re.search(motif, avant)] or ([principal] if principal else [])
        for site in sujets:
            ancres.update((s, cote) for s in (site,) + tuple(MEMBRE_DU_SITE.get(site, ())))
    return ancres


# Côté atteint perdu (banc du 07/11/2026) : selon le tirage, Flash-Next range parfois un côté pourtant dit
# (« la jambe gauche, la jambe blessée ») dans « à vérifier » et n'en écrit plus aucun, ni dans l'extraction ni dans le
# compte rendu. Les contrôles précédents vérifient ce qui est écrit, pas ce qui manque. Sur 254 comptes rendus relus à
# l'aveugle, « aucun côté dans le CR alors que la séance en cite au moins 3 » a désigné 35 oublis de côté, sans fausse
# alerte.
COTE_DIT = re.compile(r"\b(droite?s?|gauches?)\b")
# Seuls « droite » et « gauche » comptent comme côté écrit : « bilatéral » et « des deux côtés » servent surtout à
# comparer (« pas de différence des deux côtés ») et masquaient 12 des 35 oublis relevés.
COTE_ECRIT = COTE_DIT
DROIT_SANS_COTE = re.compile(r"\btout droit\b|\bdroits? (de|d'|a |au |aux )|\b(le|du|au|pas|aucun) droits?\b")


def cote_absent_du_cr(cr, transcription, notes="", mini=3):
    """Compte rendu sans aucun côté alors que la séance en nomme au moins `mini` fois."""
    dits = COTE_DIT.findall(DROIT_SANS_COTE.sub(" ", _sans_accent(f"{transcription}\n{notes}").lower()))
    if len(dits) < mini or COTE_ECRIT.search(_sans_accent(cr or "").lower()):
        return []
    gauche = sum(d.startswith("gauche") for d in dits)
    detail = " ; ".join(x for x in (f"« gauche » {gauche} fois" if gauche else "",
                                     f"« droit(e) » {len(dits) - gauche} fois" if len(dits) - gauche else "") if x)
    return [{"champ": "compte rendu", "probleme": "aucun côté écrit alors que la séance en nomme : côté atteint à préciser",
             "valeur": detail}]


def cotes_sans_ancrage(extraction, transcription, notes=""):
    """Articulations dotées d'un côté dans l'extraction, jamais nommées avec ce côté."""
    ancres = _ancres(transcription, notes)
    trouves, vus = [], set()
    for champ, valeur in _parcourir(extraction):
        # Phrase par phrase : « genou gauche : 90 degrés. Extension passive (main du praticien en
        # contact) » donnait « main gauche » (banc du 12/10/2026).
        for segment in (ph for seg in SEGMENT.split(str(valeur)) for ph in re.split(r"(?<=[.!?])\s+", seg)):
            plat = _sans_accent(segment).lower()
            cotes = _cotes_presentes(_sans_accent(segment))
            if len(cotes) != 1:
                continue
            cote = next(iter(cotes))
            for site, motif in SITES.items():
                if re.search(motif, plat) and (site, cote) not in ancres and (site, cote) not in vus:
                    vus.add((site, cote))
                    trouves.append({
                        "champ": champ, "valeur": _court(" ".join(segment.split())),
                        "probleme": f"« {site} {cote} » : la transcription ne nomme jamais "
                                    f"{'la' if site in ('cheville', 'epaule', 'hanche', 'main', 'clavicule', 'omoplate', 'rotule') else 'le'} "
                                    f"{site} avec ce côté — côté à confirmer"})
    return trouves


# Signe d'alerte (catégorie) : (ce qui le désigne dans l'extraction, ce qui montre dans la
# transcription que le sujet a été abordé). Les preuves sont larges à dessein : au moindre
# signe que la question a été posée, l'élément est gardé.
SIGNES_ALERTE = {
    "fièvre": (r"fievre|febri|temperature", r"fievre|temperature|febri|degres de fievre"),
    # « Ça vous faisait prendre beaucoup de poids », « votre poids s'était stabilisé » (Mme T) ;
    # jamais « mettre du poids sur la jambe », qui est de la charge.
    "perte de poids": (r"poids|amaigr|maigri",
                       r"(perte|prise) de poids|(perdu|pris|prendre|perdre|regagne|repris|reprendre|gagne)( \w+){0,2} (de |du )?poids"
                       r"|maigri|amaigr|kilos? (en moins|en plus|perdus|pris)|poids[^.?!]{0,30}(stable|stabilis|bouge|change|varie)"),
    "cancer": (r"cancer|tumeur|neoplas|oncolog|lymphome", r"cancer|tumeur|chimio|radiother|lymphome|metasta|oncolog"),
    "troubles sphinctériens": (r"sphinct|urinaire|incontinen|vesic|selles|queue de cheval", r"sphinct|urin|selles|incontinen|vessie|pipi|toilettes"),
    "douleur nocturne": (r"nocturne|la nuit|nuit|reveil", r"nuit|nocturne|reveil|dormir|dors|dort|sommeil|couche"),
    # Preuve NEUROLOGIQUE seulement (07/11/2026) : « faiblesse », « déficit », « perte de force » et « électri » seuls
    # gardaient « pas de déficit neurologique » dans presque tout bilan, où ils parlent de force musculaire (« une petite
    # faiblesse au niveau des abdos ») ou d'un exercice (« l'électricité »). Bancs s20_* : 4 négatifs jamais recherchés
    # retirés, les 8 bilans où la question est posée gardés (« sensations de faiblesse dans la jambe ? », « fourmillement
    # dans le bras ? », « perte de force dans un bras ? », « irritation au niveau du nerf, la racine »).
    "déficit neurologique": (r"neurolog|deficit|fourmill|paresthes|engourd|sensiti|motric",
                             r"fourmill|engourd|picot|neurolog|paralys|paresthes|decharges? electrique|electrique dans"
                             r"|comme (une |de l.)?electri|(perte|trouble|baisse)s? de (la )?sensibilit"
                             r"|sensibilite (est |qui est )?(perturb|diminu|alter)|sensations? de faiblesse"
                             r"|faiblesses? dans (la |le |les |l.)?(jambe|bras|main|pied|cuisse|mollet|doigt)|perte de force dans"
                             r"|compression (nerveuse|du nerf|de la racine|d.un nerf)|\bnerf|\bracine|radicul|sciati|cruralg|nevralg|reflexe"),
    "perte d'appétit": (r"appetit", r"appetit|faim|mange"),
    "fatigue": (r"fatigue|asthenie|epuise", r"fatigu|epuis|creve|asthenie"),
    "chute": (r"chute", r"chute|tombe|tomber|tombee"),
    "troubles de l'équilibre": (r"equilibre|vertige", r"equilibre|vertige|tourne la tete|la tete qui tourne"),
}
ELEMENTS_SIGNES = re.compile(r"\s*;\s*|\.\s+(?=[A-ZÀ-Ý])|,\s*(?=(?:pas|aucune?|ni|absence|sans)\b)", re.I)


# Exemples de déformations cités dans la consigne d'extraction (02_extraction_system.md) : le
# modèle les recopie parfois dans ses incertitudes alors que personne ne les a prononcés
# (« Le praticien mentionne 'ambiance sérénale'… », banc du 12/10/2026).
EXEMPLES_CONSIGNE = ("ambiance serenale", "cortico-serenalome", "cortensil", "liprane", "vasocelulaires")


# Une incertitude sur un MOT (« Le terme « aléasique » pour l'élastique… ») n'a sa place dans
# « À vérifier » que si elle touche une information clinique : la consigne l'exige déjà, le 27B
# l'ignore (Mme M, banc du 12/10/2026 : 15 entrées, presque toutes des mots courants déformés).
SUR_UN_MOT = re.compile(r"^\W*(le |la |les )?(terme|mot|expression|formulation)s?\b", re.I)
PORTEE_CLINIQUE = re.compile(
    r"\d|droit|gauche|lateralit|\bcote|medic|traitement|molecul|posolog|\bdose|diagnost|patholog|lesion|fractur|"
    r"ruptur|tendin|tendon|\bnerf|nerv|racine|sciatiq|crural|\birm\b|\bradio|echograph|scanner|douleur|douloureu|\beva\b|"
    r"anteceden|chirurg|\bopere|operation|diabet|coagul|cancer|tumeur|allerg|\btests?\b|\bsignes?\b|\bmuscl|articul|"
    r"ligament|menisq|\bos\b|osseu|cartilag|glande|organe|vertebr|rachis|\bdisque|herni|arthr|fessier|ischio|quadri|"
    r"mollet|chevill|genou|hanche|epaule|\bcoude|poignet|\bdos\b|lombai|cervica|fievre|febri|infect|inflamm|gonfl|"
    r"oedem|hemato|\bsang|cardi|respir|poumon|\brein|\bfoie|thyro|hormon|grossesse|enceinte|contracept|pilule|"
    r"anticoag|cortico|surrenal|thrombo|tendinite|bursite|arthrose|algie|ectomie|plastie|pathie|cellulaire|carcinome|"
    r"sarcome|lymphome|adenome|chimio|radiother|fatigu|symptom|vertige|nause|engourd|fourmill", re.I)


def _nom_de_medicament(plat):
    """Un terme CITÉ (entre guillemets) qui est un nom de médicament du lexique (« Doliprane »)."""
    import lexique as LX
    noms = LX.charge()
    cites = " ".join(re.findall(r"[«\"'‘’]\s*([^«»\"'‘’]{2,60}?)\s*[»\"'‘’]", plat))
    return any(m in noms and m not in LX.NEUTRES for m in re.findall(r"[a-z][a-z-]{4,}", cites))


def incertitudes_utiles(incertitudes, transcription, notes=""):
    """Incertitudes du modèle, sans celles qui citent un exemple de la consigne jamais prononcé,
    ni celles qui ne portent que sur un mot courant mal transcrit, ni les redites : M NL (banc
    du 12/10/2026) en avait 15, les trois mêmes recopiées cinq fois."""
    source = _sans_accent((transcription or "") + "\n" + (notes or "")).lower()
    gardees, vues = [], set()
    for x in incertitudes or []:
        plat = _sans_accent(str(x)).lower()
        cle = " ".join(re.findall(r"\w+", plat))
        if cle in vues:
            continue
        vues.add(cle)
        if any(e in plat and e not in source for e in EXEMPLES_CONSIGNE):
            continue
        if SUR_UN_MOT.match(plat) and not PORTEE_CLINIQUE.search(plat) and not _nom_de_medicament(plat):
            continue
        gardees.append(x)
    return gardees


def sans_identite(extraction):
    """Nom et adresse entendus pendant le bilan : jamais écrits (le dossier ne porte que le code du
    patient, le nom vit dans le coffre). Constaté le 27/10/2026 : trois bilans portaient le nom ou
    l'adresse du patient en clair dans « Informations du patient »."""
    ident = (extraction or {}).get("identite_patient")
    if isinstance(ident, dict):
        for champ in ("nom", "coordonnees"):
            if champ in ident:
                ident[champ] = "non évalué"
    return extraction


def signes_alerte_non_abordes(extraction, transcription, notes=""):
    """Retire de "diagnostic.signes_alerte" les signes que la séance n'a JAMAIS abordés.
    Renvoie (extraction corrigée, éléments retirés).

    Le modèle recopie la liste d'exemples de sa consigne comme des signes recherchés : « pas de
    fièvre ; pas de troubles sphinctériens » dans un compte rendu où ces questions n'ont jamais
    été posées — 5 signes sur 21 au banc 27B du 07/10/2026, et le 35B fait de même. Écrire « pas
    de fièvre » sans l'avoir demandé est une information médicale fausse. Un élément dont AUCUN
    des sujets n'apparaît dans la transcription (ni dans les notes) est retiré ; un élément sans
    sujet reconnu est gardé."""
    diag = (extraction or {}).get("diagnostic")
    if not isinstance(diag, dict) or not isinstance(diag.get("signes_alerte"), str):
        return extraction, []
    texte = diag["signes_alerte"].strip()
    if not texte or _sans_accent(texte).lower().startswith("non evalue"):
        return extraction, []
    source = _sans_accent((transcription or "") + "\n" + (notes or "")).lower()
    gardes, retires = [], []
    for element in [e.strip(" .,;") for e in ELEMENTS_SIGNES.split(texte) if e.strip(" .,;")]:
        e = _sans_accent(element).lower()
        sujets = [nom for nom, (dans_extraction, _) in SIGNES_ALERTE.items() if re.search(dans_extraction, e)]
        if sujets and not any(re.search(SIGNES_ALERTE[nom][1], source) for nom in sujets):
            retires.append({"champ": "diagnostic.signes_alerte", "valeur": element,
                            "probleme": "signe d'alerte jamais abordé pendant la séance : retiré du compte rendu"})
        else:
            gardes.append(element)
    if not retires:
        return extraction, []
    corrigee = json.loads(json.dumps(extraction))
    corrigee["diagnostic"]["signes_alerte"] = " ; ".join(gardes) if gardes else "non évalué"
    return corrigee, retires


def neutraliser_cotes_sans_ancrage(extraction, transcription, notes=""):
    """Remplace par « côté non précisé » le côté d'une articulation que la transcription ne
    nomme JAMAIS avec ce côté. Renvoie (extraction corrigée, corrections faites).

    Aucune règle de prompt n'a empêché « douleur clavicule gauche » quand le patient parle de
    « la clavicule » sans dire laquelle (sept versions de prompts, banc du 07/10/2026). Le
    contrôle R4, lui, le détecte avec une précision mesurée de 10 sur 10 : on applique par le
    code la règle que le modèle n'applique pas.

    Toutes les occurrences sont traitées — la même articulation latéralisée revient souvent
    dans trois ou quatre champs —, y compris les éléments STRUCTURÉS dont le côté est dans un
    champ « cote » séparé (antécédent « Traumatisme clavicule », cote « gauche »). Dans un
    texte, seul le mot de côté le plus proche de l'articulation est remplacé :
    « genou gauche (post-op), clavicule gauche » garde le genou."""
    import copy
    ancres = _ancres(transcription, notes)
    e = copy.deepcopy(extraction)
    corrections = []

    def sites_du(texte):
        plat = _sans_accent(texte).lower()
        return [(site, m) for site, motif in SITES.items() for m in re.finditer(motif, plat)]

    # Le côté SUIT le mot qu'il qualifie (« clavicule gauche », « genou droit ») : on ne
    # rattache à l'articulation qu'un mot de côté placé juste après elle, sans ponctuation
    # entre les deux. Une fenêtre symétrique attribuait à la clavicule le « gauche » de
    # « quadriceps gauche. Douleur à la clavicule », et à la hanche le « droit » de « (hanche)
    # et droit (fessier) » — deux côtés justes retirés (contrôle du 07/10/2026).
    # Même rattachement quand le côté est seul entre parenthèses ou après deux-points
    # (« clavicule (gauche) », « clavicule : gauche ») : forme fréquente chez les modèles, que
    # R4 signalait mais que la neutralisation laissait passer (contrôle du 07/10/2026).
    APRES_SITE = re.compile(r"^[^,;.():\n]{0,15}?(\(\s*|:\s*)?\b(droite?s?|gauches?)\b(\s*\))?")

    def corriger_texte(texte):
        modifie = False
        for site, motif in SITES.items():
            depart = 0
            while True:
                plat = _sans_accent(texte).lower()
                ms = re.compile(motif).search(plat, depart)
                if not ms:
                    break
                fin_site = re.match(r"\w*", plat[ms.end():]).end() + ms.end()   # « claviculaire »
                mc = APRES_SITE.match(plat[fin_site:])
                depart = ms.end()
                if not mc:
                    continue
                cote = "droit" if mc.group(2).startswith("droit") else "gauche"
                if (site, cote) in ancres:
                    continue
                a_, b_ = fin_site + mc.start(2), fin_site + mc.end(2)
                nouveau = "(côté non précisé)"
                if mc.group(1) and mc.group(3):          # « (gauche) » entier : pas de double parenthèse
                    a_, b_ = fin_site + mc.start(1), fin_site + mc.end(3)
                elif mc.group(1):                        # « : gauche », « (gauche, gênante) »
                    nouveau = "côté non précisé"
                texte = texte[:a_] + nouveau + texte[b_:]
                modifie = True
        return texte, modifie

    def visiter(noeud, chemin=""):
        if isinstance(noeud, dict):
            # Élément structuré : le côté est dans « cote », l'articulation dans le libellé.
            # PAS les mesures : leur « site » décrit la position de test (« genou fléchi à
            # 80 degrés »), et leur côté vient de l'annonce de la série, vérifiée par la règle
            # d'appariement. Les neutraliser retirait des côtés JUSTES (constaté sur Planchot).
            if isinstance(noeud.get("cote"), str) and "valeurs" not in noeud:
                cote = next(iter(_cotes_presentes(noeud["cote"])), None)
                texte = " ".join(str(noeud.get(k) or "") for k in ("libelle", "site", "mesure"))
                # Côté retiré seulement si AUCUNE articulation du libellé n'est nommée avec ce côté : « genou et
                # clavicule » (gauche) perdait le côté du genou, dit, parce que la clavicule ne l'était pas (audit 07/11).
                sites = sites_du(texte)
                if cote and sites and all((site, cote) not in ancres for site, _ in sites):
                    avant = f"{texte.strip()} ({noeud['cote']})"
                    noeud["cote"] = "côté non précisé"
                    corrections.append({"champ": f"{chemin}.cote", "valeur": _court(avant),
                                        "probleme": "côté retiré : la transcription ne nomme jamais "
                                                    "cette articulation avec ce côté — à préciser"})
            for k in list(noeud):
                if k == "cote":
                    continue
                c = f"{chemin}.{k}" if chemin else k
                if isinstance(noeud[k], str):
                    nv, modifie = corriger_texte(noeud[k])
                    if modifie:
                        corrections.append({"champ": c, "valeur": _court(noeud[k]),
                                            "probleme": "côté retiré : la transcription ne nomme jamais "
                                                        "cette articulation avec ce côté — à préciser"})
                        noeud[k] = nv
                else:
                    visiter(noeud[k], c)
        elif isinstance(noeud, list):
            for i, v in enumerate(noeud):
                c = f"{chemin}[{i + 1}]"
                if isinstance(v, str):
                    nv, modifie = corriger_texte(v)
                    if modifie:
                        noeud[i] = nv
                else:
                    visiter(v, c)

    visiter(e)
    return e, corrections

# ── rendu pour la section « À vérifier » du compte rendu ────────────────────
INCERTITUDES_MAX = 3


def bloc_a_verifier(incertitudes, anomalies_, manquantes, tronque=(), boucle=False,
                    doses=(), noms=(), manquees=(), appariements=(), ecarts=(), sans_ancrage=(),
                    discordances=(), trous=(), coupures=(), signes_retires=()):
    """Section « À vérifier » complète, du plus grave au moins grave.

    L'ordre est celui de la relecture : d'abord ce qui invalide le compte rendu entier
    (réponse coupée, boucle), puis MÉDICAMENTS ET DOSES, puis les chiffres et les côtés, les
    sections vides, et enfin les doutes que le modèle déclare lui-même.

    Les médicaments passent avant le reste parce que c'est là que se trouvent les erreurs
    qu'une relecture ne rattrape pas : un nom déformé par la transcription (« liprane » pour
    Doliprane) et une unité impossible (« 7000 grammes » de corticoïde) se lisent comme des
    données plausibles. Un chiffre ou un côté faux, lui, saute aux yeux du praticien qui a
    fait le bilan."""
    lignes = []

    def mmss(s):
        return f"{int(s) // 60} min {int(s) % 60:02d}"
    # Un moment de la séance que le micro n'a pas enregistré (micro coupé, Mac en veille,
    # application fermée) n'est NI dans l'audio NI dans la transcription : rien d'autre ne
    # peut le signaler. Il passe donc avant tout le reste.
    if coupures:
        lignes.append("**Enregistrement : moment(s) de la séance non enregistré(s)** — ce qui a été "
                      "dit pendant ces coupures manque au compte rendu :\n")
        for c in coupures:
            if c.get("diffus"):
                quand = f"réparti sur toute la séance, environ {mmss(c.get('perdu_s', 0))} au total"
            elif c.get("fin"):
                quand = f"à partir de {mmss(c.get('a_s', 0))} d'enregistrement, jusqu'à la fin de la séance"
            else:
                quand = (f"à {mmss(c.get('a_s', 0))} d'enregistrement, environ "
                         f"{max(1, int(round(c.get('perdu_s', 0))))} s perdues")
            lignes.append(f"- {quand} — {c.get('raison', 'coupure')}")
        lignes.append("")
    # Un passage de séance que Whisper n'a pas transcrit manque au compte rendu entier : c'est
    # la première chose à savoir avant de relire quoi que ce soit (trous.py).
    if trous:
        lignes.append("**Transcription : passage(s) raté(s) par Whisper au premier essai** — "
                      "réécouter ou relire ces moments de l'enregistrement :\n")
        for t in trous:
            etat = (f"retranscrit ({t['mots_avant']} → {t['mots_apres']} mots)" if t.get("repare")
                    else "TOUJOURS INCOMPLET : ce passage peut manquer au compte rendu")
            lignes.append(f"- de {mmss(t['debut_s'])} à {mmss(t['fin_s'])} — {t['raison']} — {etat}")
        lignes.append("")
    if boucle:
        lignes.append("**L'extraction s'est répétée jusqu'à épuiser son budget : la fin du bilan "
                      "manque et ce qui précède peut contenir des redites. Relancez le bilan.**\n")
    if tronque:
        quoi = " et ".join(tronque)
        lignes.append(f"**Réponse du modèle coupée ({quoi}) : la fin peut manquer. "
                      f"À relire en entier, et à relancer si nécessaire.**\n")
    if noms or doses:
        lignes.append("**Médicaments et doses — à confirmer AVANT toute relecture du reste** "
                      "(contrôle automatique) :\n")
        for d in list(noms) + list(doses):
            lignes.append(f"- {d['champ']} — {d['probleme']} · « {d['valeur']} »")
        lignes.append("")
    if discordances or appariements or ecarts or manquees or sans_ancrage:
        lignes.append("**Mesures et côtés — à confirmer sur la transcription** "
                      "(contrôle automatique) :\n")
        for d in list(discordances) + list(appariements) + list(sans_ancrage) + list(ecarts) + list(manquees):
            lignes.append(f"- {d['champ']} — {d['probleme']} · « {d['valeur']} »")
        lignes.append("")
    if signes_retires:
        lignes.append("**Signes d'alerte retirés : jamais abordés pendant la séance** (contrôle "
                      "automatique) — à rechercher à la prochaine séance si nécessaire :\n")
        for d in signes_retires:
            lignes.append(f"- {d['valeur']}")
        lignes.append("")
    if anomalies_:
        lignes.append("**Valeurs introuvables dans la transcription** (contrôle automatique, "
                      "à confirmer avant d'envoyer) :\n")
        for a in anomalies_:
            lignes.append(f"- {a['champ']} — {a['probleme']} · « {a['valeur']} »")
        lignes.append("")
    if manquantes:
        lignes.append("**Sections non renseignées par l'extraction :**\n")
        for m in manquantes:
            lignes.append(f"- {m['champ']} — {m['probleme']}")
        lignes.append("")
    if incertitudes:
        # Les incertitudes viennent classées par importance (consigne d'extraction). Audit des contrôles du 07/11/2026
        # (161 jugées) : utiles à 65 % au 1er rang, 38 % au 2e, 17 % ensuite ; les 3 premières gardent 84 % des utiles.
        lignes.append("**Incertitudes relevées à l'extraction :**\n")
        for x in incertitudes[:INCERTITUDES_MAX]:
            lignes.append(f"- {x}")
        if len(incertitudes) > INCERTITUDES_MAX:
            lignes.append(f"- (et {len(incertitudes) - INCERTITUDES_MAX} autre(s), moins importante(s) selon le modèle)")
        lignes.append("")
    if not lignes:
        return ""
    return "\n\n---\n\n## À vérifier\n\n" + "\n".join(lignes).rstrip() + "\n"
