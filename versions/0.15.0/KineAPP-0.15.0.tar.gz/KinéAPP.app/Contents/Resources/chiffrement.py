# -*- coding: utf-8 -*-
"""Chiffrement des données de l'app sur le disque (bilans, transcriptions, comptes rendus,
ordonnances, brouillons, fiches de la base).

Clé : 32 octets tirés au hasard à l'activation, gardés par le coffre d'identité (compte système à
part, illisible par la session) ; remise au serveur par la fenêtre après le déverrouillage, gardée
en mémoire seulement. Code de secours : la même clé, écrite en groupes de 4 caractères, à noter par
le praticien ; outils/dechiffrer_secours.py (ou openssl) déchiffre tout sans KinéAPP.

Format d'un fichier ou d'un document chiffré :
    « KENC1\\0 » | iv (16 octets) | AES-256-CBC (bourrage PKCS#7) | HMAC-SHA256 (32 octets)
Clés dérivées : chiffrement = HMAC-SHA256(clé, « kineapp-chiffrement »),
                authentification = HMAC-SHA256(clé, « kineapp-authentification ») ; le HMAC porte
sur l'en-tête, l'iv et le texte chiffré (chiffrer puis authentifier). AES de CommonCrypto (macOS).

Lecture : un fichier chiffré se déchiffre (clé exigée), un fichier en clair (d'avant) se lit tel
quel. Écriture : chiffrée dès que le chiffrement est actif et que le chemin est sous une racine
protégée ; sans clé, l'écriture est REFUSÉE (rien de clinique ne s'écrit en clair par mégarde).
"""
import base64, ctypes, hashlib, hmac, os, secrets, tempfile, threading

MAGIC = b"KENC1\x00"
ETAT = {"cle": None, "actif": False, "racines": []}
# Restent en clair : l'audio (écrit par l'enregistreur et lu par Whisper, temporaire), les fiches
# d'enregistrement et le type de bilan (code et date seulement), les journaux techniques.
EN_CLAIR = (".bilan.json", ".job.json", ".wav", ".m4a", ".caf", ".mp3", ".aac", ".log", ".DS_Store")
_VERROU = threading.Lock()


class Verrouille(PermissionError):
    """Données chiffrées et clé absente : KinéAPP doit être déverrouillée."""


# ── AES (CommonCrypto) ──────────────────────────────────────────────────────
_CC = {}


def _cccrypt():
    if "f" not in _CC:
        f = ctypes.CDLL("/usr/lib/system/libcommonCrypto.dylib").CCCrypt
        f.restype = ctypes.c_int32
        f.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_size_t,
                      ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t,
                      ctypes.POINTER(ctypes.c_size_t)]
        _CC["f"] = f
    return _CC["f"]


def _aes(operation, cle, iv, donnees):
    sortie = ctypes.create_string_buffer(len(donnees) + 16)
    n = ctypes.c_size_t(0)
    r = _cccrypt()(operation, 0, 1, cle, len(cle), iv, donnees, len(donnees), sortie, len(sortie), ctypes.byref(n))
    if r != 0:
        raise ValueError(f"AES : erreur {r}")
    return sortie.raw[:n.value]


def _cles(cle):
    return (hmac.new(cle, b"kineapp-chiffrement", hashlib.sha256).digest(),
            hmac.new(cle, b"kineapp-authentification", hashlib.sha256).digest())


def chiffrer(clair, cle=None):
    cle = cle or ETAT["cle"]
    if not cle:
        raise Verrouille("Chiffrement impossible : KinéAPP doit être déverrouillée.")
    k_chif, k_auth = _cles(cle)
    iv = secrets.token_bytes(16)
    corps = MAGIC + iv + _aes(0, k_chif, iv, bytes(clair))
    return corps + hmac.new(k_auth, corps, hashlib.sha256).digest()


def dechiffrer(blob, cle=None):
    cle = cle or ETAT["cle"]
    if not cle:
        raise Verrouille("Données chiffrées : KinéAPP doit être déverrouillée.")
    blob = bytes(blob)
    if not est_chiffre(blob) or len(blob) < len(MAGIC) + 16 + 16 + 32:
        raise ValueError("Contenu chiffré abîmé.")
    k_chif, k_auth = _cles(cle)
    corps, tag = blob[:-32], blob[-32:]
    if not hmac.compare_digest(hmac.new(k_auth, corps, hashlib.sha256).digest(), tag):
        raise ValueError("Contenu chiffré abîmé ou clé différente.")
    return _aes(1, k_chif, corps[len(MAGIC):len(MAGIC) + 16], corps[len(MAGIC) + 16:])


def est_chiffre(blob):
    return bytes(blob[:len(MAGIC)]) == MAGIC


# ── clé et code de secours ──────────────────────────────────────────────────
def nouvelle_cle():
    return secrets.token_bytes(32)


def code_de_secours(cle):
    """Clé écrite pour être notée : 52 caractères (base 32), par groupes de 4."""
    t = base64.b32encode(cle).decode().rstrip("=")
    return "-".join(t[i:i + 4] for i in range(0, len(t), 4))


def cle_du_code(code):
    t = "".join(c for c in str(code or "").upper() if c.isalnum())
    t = t.replace("0", "O").replace("1", "I").replace("8", "B")      # lectures erronées fréquentes
    cle = base64.b32decode(t + "=" * (-len(t) % 8))
    if len(cle) != 32:
        raise ValueError("Code de secours incomplet.")
    return cle


def empreinte(cle):
    """Contrôle sans révéler la clé : la bonne clé est-elle posée ?"""
    return hmac.new(cle, b"kineapp-empreinte", hashlib.sha256).hexdigest()[:16]


def poser_cle(cle, racines=None):
    """Clé remise par la fenêtre (après déverrouillage) ; branchée sur la base de l'app."""
    import base
    with _VERROU:
        ETAT["cle"] = bytes(cle) if cle else None
        if racines is not None:
            ETAT["racines"] = list(racines)
        base.CODEC.update(chiffrer=(chiffrer if ETAT["cle"] and ETAT["actif"] else None),
                          dechiffrer=(dechiffrer if ETAT["cle"] else None), chiffre=est_chiffre,
                          exiger=ETAT["actif"])


def activer(actif, racines=None):
    with _VERROU:
        ETAT["actif"] = bool(actif)
        if racines is not None:
            ETAT["racines"] = list(racines)
    poser_cle(ETAT["cle"])


def oublier_cle():
    poser_cle(None)


# ── fichiers ────────────────────────────────────────────────────────────────
def proteger(chemin):
    """Ce fichier s'écrit-il chiffré ? (chiffrement actif et chemin sous une racine protégée)"""
    if not ETAT["actif"] or os.path.basename(chemin).endswith(EN_CLAIR):
        return False
    p = os.path.realpath(chemin)
    return any(p == r or p.startswith(r.rstrip(os.sep) + os.sep)
               for r in (os.path.realpath(x) for x in ETAT["racines"] if x))


def lire_octets(chemin):
    with open(chemin, "rb") as f:
        donnees = f.read()
    return dechiffrer(donnees) if est_chiffre(donnees) else donnees


def lire_texte(chemin, erreurs="strict"):
    return lire_octets(chemin).decode("utf-8", errors=erreurs)


def ecrire_octets(chemin, donnees, protege=None):
    """Écriture atomique (fichier voisin puis remplacement), chiffrée si le chemin est protégé."""
    if protege is None:
        protege = proteger(chemin)
    if protege:
        donnees = chiffrer(donnees)
    os.makedirs(os.path.dirname(chemin) or ".", exist_ok=True)
    tmp = f"{chemin}.{threading.get_ident()}.tmp"
    with open(tmp, "wb") as f:
        f.write(donnees)
    os.replace(tmp, chemin)


def ecrire_texte(chemin, texte, protege=None):
    ecrire_octets(chemin, texte.encode("utf-8"), protege)


def chiffrer_fichier(chemin):
    """Un fichier en clair d'une racine protégée, chiffré sur place (dates gardées). True si fait."""
    with open(chemin, "rb") as f:
        donnees = f.read()
    if est_chiffre(donnees):
        return False
    st = os.stat(chemin)
    ecrire_octets(chemin, donnees, protege=True)
    os.utime(chemin, ns=(st.st_atime_ns, st.st_mtime_ns))
    return True


def chiffrer_dossier(racine):
    """Tous les fichiers d'une racine protégée (hors fichiers cachés en clair voulus) : (chiffrés, déjà)."""
    faits = deja = 0
    for d, dirs, fichiers in os.walk(racine):
        dirs[:] = [x for x in dirs if not os.path.islink(os.path.join(d, x))]
        for f in fichiers:
            p = os.path.join(d, f)
            if os.path.islink(p) or f.endswith(EN_CLAIR) or f.endswith(".tmp"):
                continue
            if chiffrer_fichier(p):
                faits += 1
            else:
                deja += 1
    return faits, deja


DOSSIER_OUVERTURES = os.path.join(tempfile.gettempdir(), "kineapp-ouvertures")


def copie_en_clair(chemin):
    """Pour ouvrir un document dans Word ou l'aperçu : copie déchiffrée dans un dossier temporaire
    privé (700), sous le même nom ; elle est retirée à la fermeture de l'app et au lancement suivant."""
    os.makedirs(DOSSIER_OUVERTURES, mode=0o700, exist_ok=True)
    os.chmod(DOSSIER_OUVERTURES, 0o700)
    d = tempfile.mkdtemp(dir=DOSSIER_OUVERTURES)
    dest = os.path.join(d, os.path.basename(chemin))
    with open(os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "wb") as f:
        f.write(lire_octets(chemin))
    return dest


def retirer_copies():
    """Copies de lecture en clair retirées (elles ne sont que des copies : l'original chiffré reste)."""
    import shutil
    if os.path.isdir(DOSSIER_OUVERTURES):
        shutil.rmtree(DOSSIER_OUVERTURES, ignore_errors=True)
