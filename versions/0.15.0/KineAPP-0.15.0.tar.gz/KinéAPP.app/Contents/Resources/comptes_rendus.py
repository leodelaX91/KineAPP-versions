# -*- coding: utf-8 -*-
"""Comptes rendus de kinésithérapie destinés aux médecins prescripteurs.

Reprend le processus des instructions (prompts/07_compte_rendu_system.md) :
  1. analyse — le modèle présente les données disponibles et manquantes et pose
     ses questions (markdown autorisé : ce n'est pas le document envoyé) ;
  2. échange — le kinésithérapeute répond ;
  3. rédaction — le courrier final, en texte brut.
Un compte rendu part d'un bilan (bilan + notes de suivi du patient) ou est
« libre » (uniquement ce que le kinésithérapeute saisit), et peut être lié plus
tard à un patient.

Stockage : une fiche JSON par compte rendu dans les données de l'app
(conversation, texte, lien patient) ; le .docx va dans le dossier choisi.
"""
import datetime, json, os, re, subprocess, sys, uuid

CODE = os.path.dirname(os.path.abspath(__file__))
import base
DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
FICHES = os.path.join(DATA, "comptes_rendus")
INSTRUCTIONS = os.path.join(CODE, "prompts", "07_compte_rendu_system.md")

TYPES = ["Bilan initial", "Évolution", "Retour au sport", "Alerte médicale"]
TITRES_SECTIONS = ["Motif et plaintes", "Examen clinique", "Éléments ayant retenu mon attention",
                   "Antécédents notables", "Questions"]
MAX_NOTES = 12000          # caractères de notes de suivi injectés (les plus récentes d'abord)


# En-tête et signature : réglés dans Paramètres (CONFIG["entete"]), jamais dans le prompt.
CHAMPS_ENTETE = ["nom", "titre", "profession", "rpps", "numero_am", "telephone", "email",
                 "cabinet", "adresse"]


def instructions(praticien=None):
    with open(INSTRUCTIONS, encoding="utf-8") as f:
        t = f.read()
    nom = ((praticien or {}).get("nom") or "").strip()
    return t.replace("{{praticien}}", nom or "le kinésithérapeute")


def _typo(t):
    """Apostrophe typographique (« Cabinet d’Annecy ») : l'en-tête et la signature viennent des
    Paramètres, souvent tapés avec l'apostrophe droite, que le contrôle du courrier refuse."""
    return re.sub(r"(?<=\w)'(?=\w)", "’", t)


def lignes_entete(p):
    """Même présentation que l'ordonnance : téléphone en +33, « France » après l'adresse."""
    from ordonnances import telephone_international
    p = {k: _typo(str(v).strip()) for k, v in (p or {}).items() if v}
    ids = [x for x in (p.get("rpps") and f"RPPS : {p['rpps']}",
                       p.get("numero_am") and f"N° Assurance Maladie : {p['numero_am']}") if x]
    adresse = p.get("adresse", "")
    if adresse and not adresse.lower().endswith("france"):
        adresse += ", France"
    tel = p.get("telephone") and "Tél. " + telephone_international(p["telephone"])
    return [x for x in (" ".join(filter(None, (p.get("nom"), p.get("titre")))),
                        " — ".join(ids),
                        " — ".join(filter(None, (tel, p.get("email")))),
                        p.get("cabinet"), adresse) if x]


def lignes_signature(p):
    p = p or {}
    return [_typo(x) for x in ((p.get("nom") or "").strip(), (p.get("profession") or "").strip()) if x]


def composer(corps, praticien):
    """Pose l'en-tête et la signature des Paramètres autour du corps du courrier.
    Retire d'abord ceux que le modèle aurait écrits malgré la consigne."""
    ent, sig = lignes_entete(praticien), lignes_signature(praticien)
    connues = {l.lower() for l in ent + sig}
    lignes = (corps or "").strip().split("\n")
    while lignes and (not lignes[0].strip() or lignes[0].strip().lower() in connues
                      or re.search(r"\bRPPS\b|\bAdeli\b|Assurance Maladie", lignes[0], re.I)):
        lignes.pop(0)
    while lignes and (not lignes[-1].strip() or lignes[-1].strip().lower() in connues):
        lignes.pop()
    morceaux = []
    if ent:
        morceaux.append("\n".join(ent))
    morceaux.append("\n".join(lignes))
    texte = "\n\n".join(morceaux)
    return texte + ("\n" + "\n".join(sig) if sig else "")


def aujourd_hui():
    return datetime.date.today().strftime("%d/%m/%Y")


def _patient_et_date(nom_bilan):
    """« Mme Exemplaire_03-09-2026 » -> (« Mme Exemplaire », « 03/09/2026 »)."""
    m = re.match(r"^(.*)_(\d{2})-(\d{2})-(\d{4})(?:_\d+)?$", nom_bilan or "")
    return (m.group(1), f"{m.group(2)}/{m.group(3)}/{m.group(4)}") if m else (nom_bilan or "", "")


# ── Contexte du premier message ─────────────────────────────────────────────
def bilan_pour_courrier(texte):
    """Bilan sans ses sections de travail : « À vérifier » (contrôles automatiques, bruit pour un
    courrier) retirée ; « Corrections à reporter » (précisions du praticien que la correction
    automatique n'a pas su placer) gardée à part, car elle prévaut sur le texte. -> (texte, précisions)."""
    morceaux = re.split(r"\n-{3,}\n", texte or "")
    corps, precisions = [morceaux[0]], []
    for m in morceaux[1:]:
        titre = m.strip().split("\n", 1)[0].strip("# ").strip().lower()
        if titre.startswith("à vérifier") or titre.startswith("a vérifier"):
            continue
        if titre.startswith("corrections à reporter"):
            precisions += [l.strip()[2:] for l in m.split("\n") if l.strip().startswith("- ")]
            continue
        corps.append(m)
    return "\n---\n".join(corps).strip(), precisions


def contexte_initial(type_cr, destinataire="", infos="", nom_bilan=None, texte_bilan="", notes=None,
                     precedent=None, direct=True):
    """Premier message. precedent : (date, texte) du premier bilan, pour un courrier d'évolution.
    direct : le courrier est rédigé tout de suite (sinon : analyse des données d'abord, ancien parcours)."""
    lignes = [f"Type de compte rendu : {type_cr}",
              f"Date du jour (date du courrier) : {aujourd_hui()}",
              f"Destinataire : {destinataire.strip() or 'non nommé'}"]
    if infos.strip():
        lignes += ["", "=== INFORMATIONS DU KINÉSITHÉRAPEUTE (ce que le courrier doit dire) ===", infos.strip()]
    if nom_bilan:
        patient, date_bilan = _patient_et_date(nom_bilan)
        texte, precisions = bilan_pour_courrier(texte_bilan)
        lignes += [f"Patient (d'après le nom du dossier) : {patient}"]
        if precedent and precedent[1].strip():
            ancien, prec_ancien = bilan_pour_courrier(precedent[1])
            lignes += ["", f"=== PREMIER BILAN (début de la prise en charge, du {precedent[0]}) ===", ancien]
            precisions = prec_ancien + precisions
        lignes += ["", f"=== BILAN KINÉSITHÉRAPIQUE{' LE PLUS RÉCENT' if precedent else ''} (du {date_bilan or 'date non précisée'}) ===",
                   texte or "(vide)"]
        if precisions:
            lignes += ["", "=== PRÉCISIONS DU PRATICIEN (prévalent sur le texte du bilan) ==="] + [f"- {x}" for x in precisions]
        notes = notes or []
        if notes:
            # Du plus récent au plus ancien pour choisir ce qui tient, puis présentées dans l'ordre du temps.
            gardees, total, coupe = [], 0, False
            for n in notes:
                bloc = f"[{n.get('nom', '')}]\n{(n.get('texte') or '').strip()}"
                if total + len(bloc) > MAX_NOTES:
                    coupe = True
                    break
                gardees.append((n.get("mtime", 0), bloc)); total += len(bloc)
            lignes += ["", "=== SUIVI DEPUIS LE BILAN (séances dans l'ordre du temps, puis mesures et questionnaires) ==="]
            if coupe:
                lignes.append("(séances plus anciennes non incluses, faute de place)")
            lignes += [b for _, b in sorted(gardees, key=lambda x: x[0])]
    else:
        lignes += ["", "Compte rendu libre : aucun bilan de patient n'est fourni. "
                       "Utilise uniquement les informations ci-dessus."]
    if direct:
        lignes += ["", CONSIGNE_REDACTION]
    else:
        lignes += ["", "Applique le processus de la section 3 : présente les données disponibles, "
                       "les données manquantes avec une question précise pour chacune, et indique "
                       "lesquelles sont bloquantes. Ne rédige pas encore le courrier. " + FIN_ETAT]
    return "\n".join(lignes)


# Ligne finale d'état : l'app la lit pour indiquer si l'on peut rédiger.
ETAT_PRET, ETAT_MANQUE = "ÉTAT : PRÊT À RÉDIGER", "ÉTAT : INFORMATIONS MANQUANTES"
FIN_ETAT = (f"Termine ta réponse par une dernière ligne, exactement « {ETAT_PRET} » si toutes les "
            f"données essentielles sont disponibles, sinon « {ETAT_MANQUE} ».")
MARQUE_CONSIGNE = "[Consigne de l’application]"
CONSIGNE_ECHANGE = (
    f"{MARQUE_CONSIGNE} Intègre ces informations. Indique brièvement ce qui reste manquant ou à "
    "confirmer, avec une question précise pour chaque point, et ce qui est bloquant ; s’il ne manque "
    "plus rien d’essentiel, dis-le simplement. Une donnée que le kinésithérapeute déclare indisponible "
    "ne se redemande pas : elle sera écrite [À COMPLÉTER] et n’est plus bloquante. Ne rédige pas "
    "encore le courrier. " + FIN_ETAT)


def sans_reflexion(reponse):
    """Retire un raisonnement resté dans le texte (balise </think> non interprétée par
    le moteur). Renvoie "" si la réponse n'est QUE du raisonnement (« Thinking Process: »
    sans balise de fin) : elle ne doit pas passer pour un courrier."""
    t = (reponse or "").strip()
    if "</think>" in t:
        t = t.rsplit("</think>", 1)[1].strip()
    if re.match(r"(?:<think>\s*)?(?:Thinking Process|Here'?s a thinking process|Analyze the Request)\b", t, re.I):
        return ""
    return t


def etat(reponse):
    """(texte sans la ligne d'état, True si prêt / False si manquant / None si absente)."""
    lignes = (reponse or "").rstrip().split("\n")
    for i in range(len(lignes) - 1, max(-1, len(lignes) - 4), -1):
        l = re.sub(r"[*_`#>«»\s]", "", lignes[i]).upper()
        if l.startswith("ÉTAT:") or l.startswith("ETAT:"):
            pret = "PRÊT" in l or "PRET" in l
            return "\n".join(lignes[:i] + lignes[i + 1:]).rstrip(), pret
    return reponse, None


CONSIGNE_REDACTION = (
    "Rédige maintenant le compte rendu. Respecte la sélection et la longueur (section 3 : 150 à 250 mots), "
    "la structure (section 7) et le format de sortie (section 6) : texte brut sans aucun markdown, titres "
    "de section seuls sur leur ligne sans deux-points, apostrophes et guillemets typographiques. N'invente "
    "aucune donnée : une donnée indispensable qui manque s'écrit [À COMPLÉTER]. Réponds uniquement par le "
    "courrier, sans commentaire avant ni après.")
# Modification demandée par le kinésithérapeute après la rédaction : le courrier est réécrit en entier.
CONSIGNE_MODIFICATION = (
    f"{MARQUE_CONSIGNE} Réécris le courrier complet en appliquant cette demande, et seulement elle ; "
    "garde tout le reste tel quel. Mêmes règles : aucune donnée inventée, texte brut, apostrophes "
    "typographiques. Réponds uniquement par le courrier.")


# ── Mise en forme : uniquement la forme, jamais le fond ─────────────────────
def nettoyer(texte):
    """Retire les marques markdown qui auraient échappé au modèle et pose les
    apostrophes et guillemets typographiques. Ne touche pas au contenu."""
    n = 0
    sortie = []
    for ligne in (texte or "").replace("\r", "").split("\n"):
        avant = ligne
        if re.fullmatch(r"\s*(```.*|[-*_=]{3,}|\|?[\s:|-]*-{3,}[\s:|-]*)\s*", ligne):
            n += 1                                           # clôtures, séparateurs
            continue
        ligne = re.sub(r"^\s{0,3}#{1,6}\s+", "", ligne)      # titres markdown
        ligne = re.sub(r"^\s*(?:[-*•·]|\d{1,2}[.)])\s+", "", ligne)   # puces, numérotation
        ligne = re.sub(r"\*\*(.+?)\*\*|__(.+?)__", lambda m: m.group(1) or m.group(2), ligne)
        ligne = re.sub(r"(?<![\w*])\*([^\s*][^*]*?)\*(?![\w*])", r"\1", ligne)
        s = ligne.strip()
        if s.startswith("|") and s.endswith("|"):              # ligne de tableau
            ligne = " ; ".join(c.strip() for c in s.strip("|").split("|") if c.strip())
        titre = ligne.strip().rstrip(" :").strip()
        if titre in TITRES_SECTIONS:
            ligne = titre                                     # titre sans deux-points
        ligne = re.sub(r"(?<=\w)'(?=\w)", "’", ligne)
        ligne = re.sub(r'"([^"\n]+)"', "« \\1 »", ligne)
        if ligne != avant:
            n += 1
        sortie.append(ligne.rstrip())
    texte = re.sub(r"\n{3,}", "\n\n", "\n".join(sortie)).strip()
    return texte, n


# Mots qui changent la prise en charge : écrits dans le courrier mais absents des données, ils sont
# signalés (banc du 27/10/2026 : « fracture opérée » pour une fracture traitée par plâtre, opération refusée).
MOTS_SENSIBLES = ("opéré", "opérée", "opérés", "opérées", "rompu", "rompue", "rupture", "luxé", "luxée", "luxation",
                  "prothèse", "infiltration", "infiltré", "infiltrée", "arthroscopie", "ligamentoplastie", "suture",
                  "ostéosynthèse", "fracture", "fracturé", "fracturée", "plâtre", "attelle", "botte", "béquilles")


def _plat(t):
    import unicodedata
    t = unicodedata.normalize("NFD", (t or "").lower().replace("’", "'"))
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


def source_du_courrier(fiche):
    """Tout ce que le modèle a reçu pour ce courrier (données, réponses et demandes du kinésithérapeute)."""
    return "\n".join(m["content"] for m in (fiche or {}).get("messages", []) if m.get("role") == "user")


IMAGERIE = r"\b(?:imagerie|irm|radio(?:graphie)?s?|echographi\w*|scanner|scintigraphi\w*)\b"


def faits_a_verifier(lettre, source):
    """Ce que le courrier affirme et que les données ne contiennent pas : chiffres (hors pourcentages,
    calculés, et dates), scores sur 10 et mots sensibles, hors section « Questions » (une question peut
    évoquer un examen) ; dans les questions, une imagerie que rien n'évoque."""
    if not source:
        return []
    lignes = (lettre or "").split("\n")                     # corps : du titre à « Bien cordialement »
    debut = next((i for i, l in enumerate(lignes) if l.startswith("Compte rendu")), 0)
    fin = next((i for i, l in enumerate(lignes) if l.startswith("Bien cordialement")), len(lignes))
    corps, *questions = re.split(r"(?m)^Questions\s*$", "\n".join(lignes[debut:fin]))
    corps = re.sub(r"(?<=\d)[\s\u202f\u00a0](?=\d{3}\b)", "", corps)          # « 2 000 » -> « 2000 »
    corps = re.sub(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b|\bJ\+\d+\b|RPPS[^\n]*|Tél\.[^\n]*|N° Assurance Maladie[^\n]*", " ", corps)
    src, src_mots = _plat(source), set(re.findall(r"[a-z']+", _plat(source)))
    src_nombres = {n.replace(",", ".") for n in re.findall(r"\d+(?:[.,]\d+)?",
                                                       re.sub(r"(?<=\d)[\s\u202f\u00a0](?=\d{3}\b)", "", source))}
    chirurgie = re.search(r"operat|opere|chirurg|ligamentoplast|arthroscop|meniscectom|prothes|osteosynth|suture", src)
    sans_chirurgie = re.search(r"operation refusee|refus\w* (?:de l'|l')?operation|traitement conservateur|non opere", src)
    out = []
    # Question d'imagerie alors que le dossier ne parle d'aucun examen : la consigne du prompt ne suffit
    # pas (6 courriers sur 10 au banc du 27/10/2026, « imagerie de contrôle » sur une évolution favorable).
    if questions and re.search(IMAGERIE, _plat(questions[0])) and not re.search(IMAGERIE, src) \
            and "type de compte rendu : alerte" not in src:
        out.append("question d'imagerie alors que les données ne parlent d'aucun examen : utile ?")
    # Score sur 10 (douleur, effort) : le score lui-même doit être dans les données, pas seulement le chiffre
    # (« 3/10 au repos » inventé passait parce qu'un « 3 » figurait ailleurs : « 3 mois », banc du 27/10/2026).
    scores = {n.replace(",", ".") for n in re.findall(r"(\d+(?:[.,]\d+)?)\s*(?:/|sur)\s*10\b", _plat(source))
              + re.findall(r"\b(?:eva|ens|en|rpe|douleur)\b[^\d\n]{0,15}(\d+(?:[.,]\d+)?)(?!\s*(?:/|sur)\s*10)", _plat(source))}
    for m in re.finditer(r"(?<![\d.,])(\d+(?:[.,]\d+)?)\s*/\s*10\b", corps):
        n = m.group(1).replace(",", ".")
        if n not in scores:
            ligne = corps[corps.rfind("\n", 0, m.start()) + 1:].split("\n", 1)[0].strip()
            out.append(f"« {n}/10 » : ce score n'est pas dans les données : {ligne[:90]}")
    for m in re.finditer(r"(?<![/\d.,])(\d+(?:[.,]\d+)?)(\s*%)?", corps):        # « /10 » : une échelle, pas un fait
        n = m.group(1).replace(",", ".")
        if m.group(2) or n in src_nombres or n.rstrip("0").rstrip(".") in src_nombres \
                or re.match(r"\s*/\s*10\b", corps[m.end():]):
            continue
        ligne = corps[corps.rfind("\n", 0, m.start()) + 1:].split("\n", 1)[0].strip()
        out.append(f"« {n} » absent des données : {ligne[:90]}")
    for mot in MOTS_SENSIBLES:
        if not re.search(rf"(?<![a-zà-ÿ]){mot}(?![a-zà-ÿ])", corps.lower()):
            continue
        if mot.startswith("opér"):                  # « opéré » : faux si aucune chirurgie, ou si elle a été refusée
            if sans_chirurgie or not chirurgie:
                out.append(f"« {mot} » : les données ne parlent d'aucune intervention" if not sans_chirurgie
                           else f"« {mot} » : les données parlent d'un traitement sans opération, à vérifier")
            continue
        if _plat(mot) not in src_mots:
            out.append(f"« {mot} » : ce mot n'apparaît pas dans les données")
    return out[:8]


def verifier(texte, praticien=None, source=""):
    """Contrôles automatisables de la checklist (section 9) ; avec la source, les faits non retrouvés."""
    t = texte or ""
    mots = len(t.split())
    ent, sig = lignes_entete(praticien), lignes_signature(praticien)
    manquants = [l for l in ent if l not in t]
    # « [À COMPLÉTER] » et ses variantes (« [ÂGE À COMPLÉTER] », « [CÔTÉ À COMPLÉTER] », « [X] »)
    a_completer = len(re.findall(r"\[[^\]\n]*À COMPLÉTER[^\]\n]*\]|\[X\]", t, re.I))
    markdown = re.findall(r"(?m)^\s*(#{1,6}\s|[-*•]\s|\d{1,2}[.)]\s|\|)|\*\*|```", t)
    fin = t[-250:]
    faits = faits_a_verifier(t, source) if source else []
    return [
        {"libelle": "En-tête complet", "ok": bool(ent) and not manquants,
         "detail": "à renseigner dans Paramètres" if not ent
                   else ("manque : " + " / ".join(manquants) if manquants else "")},
        {"libelle": "Date présente", "ok": bool(re.search(
            r"\b\d{1,2}/\d{1,2}/\d{4}\b|\b\d{1,2} (janvier|février|mars|avril|mai|juin|juillet|août|"
            r"septembre|octobre|novembre|décembre) \d{4}\b", t, re.I)), "detail": ""},
        {"libelle": "Données à compléter", "ok": a_completer == 0,
         "detail": f"{a_completer} mention(s) [À COMPLÉTER]" if a_completer else "aucune"},
        {"libelle": "Signature", "ok": bool(sig) and all(l in fin for l in sig),
         "detail": "" if sig else "à renseigner dans Paramètres"},
        {"libelle": "Zéro markdown", "ok": not markdown,
         "detail": f"{len(markdown)} marque(s) restante(s)" if markdown else ""},
        {"libelle": "Apostrophes typographiques", "ok": "'" not in t and '"' not in t, "detail": ""},
        {"libelle": "Une page maximum", "ok": mots <= 480, "detail": f"{mots} mots"},
    ] + ([{"libelle": "Faits à vérifier", "ok": not faits, "detail": " ; ".join(faits) if faits else "tous retrouvés dans les données"}]
         if source else [])


# ── Fiches ──────────────────────────────────────────────────────────────────
def creer(type_cr, destinataire, infos, nom_bilan, systeme, premier_message):
    fiche = {"id": uuid.uuid4().hex[:12], "cree": datetime.datetime.now().strftime("%d-%m-%Y %H:%M"),
             "type": type_cr if type_cr in TYPES else TYPES[0], "destinataire": destinataire,
             "infos": infos, "bilan": nom_bilan or None, "statut": "brouillon",
             "messages": [{"role": "system", "content": systeme},
                          {"role": "user", "content": premier_message}],
             "texte": "", "fichier": "", "moteur": "", "modele": ""}
    sauver(fiche)
    return fiche


def charger(cid):
    return base.lire("cr", os.path.basename(str(cid or ""))) if cid else None


def sauver(fiche):
    base.ecrire("cr", fiche["id"], fiche)


def mettre_a_la_corbeille(cid):
    """Brouillon retiré de la liste, gardé dans la base (récupérable), jamais effacé."""
    f = charger(cid)
    if f:
        with base.transaction():
            base.ecrire("cr_corbeille", f["id"], dict(f, retire=datetime.datetime.now().strftime("%d/%m/%Y %H:%M")))
            base.retirer("cr", f["id"])
    return bool(f)


def resume(f):
    patient = _patient_et_date(f["bilan"])[0] if f.get("bilan") else None
    return {"id": f["id"], "cree": f["cree"], "type": f["type"], "statut": f["statut"],
            "bilan": f.get("bilan"), "patient": patient, "fichier": f.get("fichier") or "",
            "fichier_existe": bool(f.get("fichier")) and os.path.isfile(f["fichier"]),
            "tours": sum(1 for m in f["messages"] if m["role"] == "assistant")}


def liste(bilan=None, non_lies=False):
    out = []
    for _, f in base.tous("cr"):
        if bilan is not None and f.get("bilan") != bilan:
            continue
        if non_lies and f.get("bilan"):
            continue
        out.append(resume(f))
    out.sort(key=lambda r: datetime.datetime.strptime(r["cree"], "%d-%m-%Y %H:%M"), reverse=True)
    return out


def _nom_fichier(f):
    date = datetime.date.today().strftime("%d-%m-%Y")
    if f.get("bilan"):
        base = f"{_patient_et_date(f['bilan'])[0]}_CR {f['type']}_{date}"
    else:
        base = f"CR libre_{f['type']}_{date}_{datetime.datetime.now():%H%M}"
    return re.sub(r'[/\\:]', "-", base)


def enregistrer(fiche, texte, dossier):
    """Écrit le .docx du compte rendu (réécrit le même fichier s'il existe déjà)."""
    os.makedirs(dossier, exist_ok=True)
    if fiche.get("fichier") and os.path.dirname(fiche["fichier"]) == dossier:
        docx = fiche["fichier"]
    else:
        base = _nom_fichier(fiche)
        docx, i = os.path.join(dossier, base + ".docx"), 2
        while os.path.exists(docx):
            docx = os.path.join(dossier, f"{base} ({i}).docx"); i += 1
    import chiffrement, make_docx
    chiffrement.ecrire_octets(docx, make_docx.docx_octets(texte))      # chiffré si le dossier l'est
    fiche.update(texte=texte, fichier=docx, statut="enregistré",
                 enregistre=datetime.datetime.now().strftime("%d-%m-%Y %H:%M"))
    sauver(fiche)
    return docx


def lier(fiche, nom_bilan):
    """Rattache un compte rendu à un patient ; renomme le .docx d'un compte rendu libre."""
    fiche["bilan"] = nom_bilan
    ancien = fiche.get("fichier") or ""
    if ancien and os.path.isfile(ancien) and os.path.basename(ancien).startswith("CR libre_"):
        base = f"{_patient_et_date(nom_bilan)[0]}_CR {fiche['type']}_{fiche['cree'][:10]}"
        base = re.sub(r'[/\\:]', "-", base)
        nouveau, i = os.path.join(os.path.dirname(ancien), base + ".docx"), 2
        while os.path.exists(nouveau):
            nouveau = os.path.join(os.path.dirname(ancien), f"{base} ({i}).docx"); i += 1
        os.replace(ancien, nouveau)
        fiche["fichier"] = nouveau
    sauver(fiche)
    return fiche
