# KinéAPP — règles de travail pour Claude

App locale d'un kinésithérapeute : fenêtre Swift (`source/KineAPP.swift`) + serveur Python sans
dépendance (`ui/server.py`, 127.0.0.1) + coffre d'identité (`coffre/`, compte `_kinecoffre`).
Réponses en français. Architecture et menaces : `docs/ISOLATION.md`.

## Organisation du code

- Serveur : `ui/server.py` (table des routes : `@route("GET", "/api/…")`, une méthode par adresse) ;
  modules à la racine : `base.py` (SQLite : fiches, dictées, comptes rendus, ordonnances),
  `chiffrement.py`, `journal.py` (événements JSON sans nom, erreurs typées), `session.py`,
  `audio.py`, `source.py` (relecture à côté de la transcription), `amplitudes.py`, etc.
  Une seule file de traitement (`ordonnanceur()`), état poussé à la page par `/api/evenements`.
- Moteurs (0.13) : `moteurs.py` (Splash, moteur principal ; llama.cpp, secours si Splash a un problème) ;
  trois modes (`modeles_llm.py` : rapide 35B IQ3_S, qualité 27B UD-Q3_K_XL, qualité rapide Flash-Next Q2_0),
  fichiers figés par commit et SHA-256, téléchargés depuis l'app, le cache Hugging Face du Mac est reconnu ;
  `moteurs_integres.py` + `outils/moteur_recu.py` + `outils/installer.sh --moteurs-seuls` (versions publiées
  lues sur GitHub une fois par jour si autorisé dans Paramètres → Réseau, archive vérifiée, installée avec le mot de passe
  administrateur, ancienne version gardée ; whisper.cpp vient avec les bibliothèques ggml de son llama.cpp) ;
  `materiel.py` (RAM, macOS). MTPLX, Unsloth Studio et les moteurs externes ne sont plus utilisés (0.13).
- Page : `ui/index.html` (balisage seul), `ui/app.css`, `ui/js/NN-domaine.js` chargés dans l'ordre ;
  appels de démarrage dans `99-demarrage.js`. Aucun code dans le balisage (CSP `script-src 'self'`) :
  un bouton porte `data-click="fonction"` (+ `data-args` JSON), et la fonction doit figurer dans
  `GESTES` (`18-gestes.js`) ; dans un gabarit, `${geste('click', 'fonction', args…)}`.
- Erreur tolérée : `JO.ignoree(e)` plutôt qu'un `except Exception: pass` muet.

## Configurations de la chaîne des bilans

`chaines.json` : configurations gardées (réglage `configuration_chaine`, Paramètres → Mode de rédaction ;
défaut `v8` = sans contre-lecture, consignes nettoyées, questions séparées). Chacune fixe la contre-lecture,
le jeu de consignes (`prompts/variantes/<jeu>/` remplace les fichiers qu'il contient) et la passe des questions.
Ne jamais retirer une configuration du banc : y noter les résultats. Pour un nouveau modèle, les rejouer toutes
sur le banc (`~/Documents/KinéAPP/Bancs/q16/banc0711`, PLAN.md ; `CONFIG["configuration_chaine"]` avant
`process_job`) puis relecture à l'aveugle, et changer `defaut` seulement si une autre est meilleure.

## Emplacements

- Copie de développement (ici) : `~/Developer/KineAPP-dev`, dépôt git externe :
  `export GIT_DIR=~/Developer/KineAPP.git GIT_WORK_TREE=~/Developer/KineAPP-dev`.
- App installée : `/Applications/KinéAPP.app`, propriété root. On ne la modifie jamais
  directement : tout passe par la mise à jour (plus bas).
- Données : dossier `KinéAPP`, dans `~/Documents` ou sur `~/Desktop` selon le réglage
  `emplacement` de `ui_config.json` (Bilans, Transcriptions, Comptes rendus, Ordonnances,
  Bibliothèque, Diagnostics, Bancs, Rapports) ; réglages `~/Library/Application Support/BilanKine`.
  L'ancien dossier « Suivi Kiné » n'est plus lu par l'app (retiré le 18/10/2026).
- Problèmes signalés par l'utilisateur : `<dossier KinéAPP>/Diagnostics/diagnostic_*.md`
  (sans nom) ; échecs d'installation : `mise-a-jour_*.log` au même endroit ; journal du serveur :
  `~/Library/Logs/KinéAPP/serveur.log` ; événements (codes d'erreur) : `evenements.jsonl` à côté.
- Chiffrement (si activé) : les données de l'app sont chiffrées sur le disque ; sans la clé (coffre
  verrouillé), l'app répond 423. Ne jamais lire le code de secours. Exception à « rien n'est effacé
  définitivement » : les copies déchiffrées temporaires (`$TMPDIR/kineapp-ouvertures`) sont
  effacées, ce ne sont que des copies.

## Confidentialité — non négociable

- Aucune donnée patient ne quitte le Mac ; les moteurs écoutent sur 127.0.0.1 ; pas
  de télémétrie. Seuls des mots-clés cliniques anonymes peuvent sortir (PubMed, recherche HAS).
- Ne jamais lire le coffre (`/Library/Application Support/KineAPP/Coffre`), ni demander son mot de
  passe, ni chercher à relier un code « Mme P-XXXXXX » à un nom. Ne jamais afficher un nom de
  fichier patient : compter, masquer.
- Reproduire un problème sur données fictives (`tests/donnees_fictives.py`, serveur de test des
  tests), pas en ouvrant les bilans réels. Lire un bilan réel seulement si l'utilisateur le demande.
- Jamais de remplacement de texte « en minuscules » à l'aveugle dans les données.
- Apple Notes : module retiré (17/10/2026), ne pas le réintroduire. Notes « Suivi Kiné » et vocabulaire de
  Whisper retirés (18/10/2026), ne pas les réintroduire. Rien n'est effacé définitivement : Corbeille.
- Splash toujours `--offline`, jamais `SPLASH_HIDDEN_LOG` ni `--persistent-cache`. Ne rien supprimer dans les dossiers de modèles.
- Questionnaires sous licence : score seulement. Interface sans émoji (sauf ⚙︎ ✓ ✕ ● ■) ; dates
  jour/mois/année.
- Ne pas affaiblir `outils/garde_fous.py` ni les invariants qu'il contrôle. Une nouvelle adresse
  Internet = demander d'abord à l'utilisateur ; elle ne s'installera que par le Terminal.

## Corriger un problème ou ajouter une fonction

1. Lire le dernier diagnostic (`<dossier KinéAPP>/Diagnostics`).
2. Modifier ici, dans la copie de développement ; un commit par étape, terminé par
   `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`.
3. Ajouter ou adapter un contrôle dans `tests/controles_<domaine>.py` (lanceur : `tests/test_kineapp.py`).
4. Vérifier qu'aucun banc ne tourne (`ps -axo command | grep -E 'banc_|serve-native|llama-server|enchainer'`) :
   les tests arrêtent les moteurs. Ne jamais fermer la KinéAPP de l'utilisateur.
5. `python3 tests/test_kineapp.py` : tout doit réussir (Python du système ou celui de l'app,
   `~/.local/share/uv/python/cpython-3.13-macos-aarch64-none/bin/python3`). La réussite est notée
   pour l'arbre exact testé (`.tests-reussis.json`) ; `… test_kineapp.py <mot>` ne lance qu'une
   partie des contrôles et ne note rien.
6. Valider exactement ce code (`git add -A && git commit`), ou commit puis tests.
7. Dire à l'utilisateur : Paramètres → Mises à jour et problèmes → Installer la mise à jour. Il
   voit la liste des changements et les parties sensibles touchées. En cas de souci : « Revenir à
   la version précédente ».

L'installateur refuse (et la version en place reste) si : modifications non validées, liens
symboliques, tests non réussis sur ce commit, garde-fous non conformes (jugés par le contrôleur
déjà installé), compilation ou signature en échec. La mise à jour ne touche jamais aux données.
Je ne peux pas faire `sudo` : l'installation complète (`sudo ./outils/installer.sh`) se fait par
l'utilisateur, dans le Terminal de macOS.

## Versions publiées (autres Mac, canal GitHub)

- Numéro de version : `version.json` (affiché dans l'app avec la mention bêta). L'augmenter avant
  de publier ; garder `statut` à « bêta » tant que l'utilisateur ne décide pas autrement.
- Publier = `./outils/publier.sh` (avec l'accord de l'utilisateur) : commit testé, garde-fous
  conformes, étiquette `vX.Y.Z` signée par `~/.ssh/kineapp_publication`, envoi de main et de
  l'étiquette. Les autres Mac n'installent que des étiquettes signées par une clé de
  `outils/publication/signataires_autorises` de LEUR app installée, plus récentes que la leur.
- Ne jamais changer `outils/publication/signataires_autorises` sans l'accord de l'utilisateur.
- Procédure pour les autres : `docs/INSTALLATION.md`.

## Sauvegarde sur GitHub (code seulement)

- Dépôt privé `leodelaX91/KineAPP`, remote `origin` = `git@github-kineapp:leodelaX91/KineAPP.git` :
  clé de déploiement à part (`~/.ssh/github_kineapp`, alias `github-kineapp` dans `~/.ssh/config`).
  Ne jamais modifier le bloc `Host github.com` de `~/.ssh/config` : il sert à un autre projet de
  l'utilisateur.
- Envoi seulement (sauvegarde) : l'installateur ne prend JAMAIS le code sur GitHub.
- Crochet `pre-push` du dépôt : `outils/verifier_envoi.py` (aucun nom de patient dans l'historique,
  garde-fous conformes). Ne jamais le contourner (`--no-verify` interdit).
- `git push` uniquement avec l'accord de l'utilisateur, après des tests réussis.
- Historique publié depuis le 17/10/2026 (un seul commit de départ) : l'historique de développement
  d'avant contient d'anciens noms de patients (exemples retirés du code le 13/10) ; il reste sur ce
  Mac sous `refs/archives/historique-local`, jamais envoyé. Mots repérés qui ne sont pas des
  patients : empreintes dans `outils/envoi_ignores.txt` (tri par l'utilisateur, `--montrer` dans
  SON Terminal ; je ne lance jamais `--montrer`). Le test « Noms possibles dans le code » applique la
  même règle pendant le développement : s'il échoue, reformuler (pas de « civilité + Nom » dans le
  code ou la doc, écrire par exemple l'auteur sans civilité) plutôt que de demander un tri.
