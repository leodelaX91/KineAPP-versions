# -*- coding: utf-8 -*-
"""Sauvegarde chiffrée des données patients sur un disque externe.

Principe
  - Sur le disque choisi, une image disque macOS chiffrée AES-256 (sparsebundle) :
    « KinéAPP Sauvegarde.sparsebundle ». Illisible sans le mot de passe, même disque volé.
  - Chaque sauvegarde est un instantané daté (Instantanés/AAAA-MM-JJ_HHMM) : les fichiers
    inchangés sont des liens vers l'instantané précédent (rsync --link-dest), donc une
    sauvegarde quotidienne ne recopie que ce qui a changé. On garde les N derniers.
  - Les données restent à leur place : on copie, on ne déplace rien.

Mot de passe
  - Conservé dans le Trousseau macOS (session de l'utilisateur). Jamais dans un fichier,
    jamais en argument de commande (transmis par l'entrée standard), jamais renvoyé par l'API.
  - Perdu = sauvegarde irrécupérable : c'est le prix du chiffrement.
"""
import datetime, json, os, plistlib, re, shutil, subprocess, tempfile, threading, time

IMAGE = "KinéAPP Sauvegarde.sparsebundle"
ICLOUD_DEFAUT = os.path.expanduser("~/Library/Mobile Documents/com~apple~CloudDocs/KinéAPP Sauvegardes")
PREFIXE_ARCHIVE = "KinéAPP_"
VOLUME_IMAGE = "KinéAPP Sauvegarde"
TROUSSEAU_SERVICE = os.environ.get("KINEAPP_TROUSSEAU") or "KinéAPP sauvegarde chiffrée"
TROUSSEAU_COMPTE = "sauvegarde"
EXCLUSIONS = [".DS_Store", "*.tmp", "*.part", "*.wav", "models/", "entrees/", "journaux/"]

ETAT = {"en_cours": False, "message": "", "erreur": ""}
_VERROU = threading.Lock()


class ErreurSauvegarde(RuntimeError):
    pass


def _run(args, entree=None, timeout=600):
    """Toujours une entrée standard fournie : hdiutil ne doit jamais attendre le clavier."""
    return subprocess.run(args, input=(entree if entree is not None else ""), capture_output=True,
                          text=True, timeout=timeout)


# ── mot de passe (Trousseau) ────────────────────────────────────────────────
def mot_de_passe():
    r = _run(["security", "find-generic-password", "-a", TROUSSEAU_COMPTE, "-s", TROUSSEAU_SERVICE, "-w"], timeout=30)
    if r.returncode != 0:
        return ""
    try:                                   # stocké en hexadécimal UTF-8 (accents, guillemets…)
        return bytes.fromhex(r.stdout.strip()).decode("utf-8")
    except ValueError:
        return ""


def _memoriser(mdp):
    commande = (f'add-generic-password -U -a {TROUSSEAU_COMPTE} -s "{TROUSSEAU_SERVICE}" '
                f'-w {mdp.encode("utf-8").hex()}\n')
    r = _run(["security", "-i"], entree=commande, timeout=30)       # par stdin : rien dans `ps`
    if mot_de_passe() != mdp:
        raise ErreurSauvegarde("Impossible d'enregistrer le mot de passe dans le Trousseau : " + (r.stderr or r.stdout)[-200:])


# ── disques ─────────────────────────────────────────────────────────────────
def volumes_externes():
    """Disques montés hors disque système : clés, disques USB/Thunderbolt, réseau exclu."""
    out = []
    for nom in sorted(os.listdir("/Volumes")) if os.path.isdir("/Volumes") else []:
        chemin = os.path.join("/Volumes", nom)
        if nom == VOLUME_IMAGE or not os.path.ismount(chemin) or os.path.realpath(chemin) == "/":
            continue
        try:
            info = plistlib.loads(subprocess.run(["diskutil", "info", "-plist", chemin], capture_output=True,
                                                 timeout=20).stdout)
        except Exception:
            continue
        if info.get("Internal") and not info.get("RemovableMedia"):
            continue                                # partitions du disque interne (Recovery…)
        if (info.get("BusProtocol") or "") in ("Disk Image",) or info.get("VirtualOrPhysical") == "Virtual" and not info.get("RemovableMedia"):
            continue
        try:
            libre = shutil.disk_usage(chemin).free
        except Exception:
            libre = 0
        out.append({"chemin": chemin, "nom": nom, "libre_go": round(libre / 1e9, 1),
                    "format": info.get("FilesystemName") or info.get("FilesystemType") or "",
                    "image_existe": os.path.isdir(os.path.join(chemin, IMAGE))})
    return out


def _image(volume):
    return os.path.join(volume, IMAGE)


def _attacher(volume, mdp, point=None, visible=False):
    args = ["hdiutil", "attach", "-stdinpass"]
    if not visible:
        args += ["-nobrowse", "-mountpoint", point]
    r = _run(args + [_image(volume)], entree=mdp, timeout=120)
    if r.returncode != 0:
        if "authentification" in (r.stderr + r.stdout).lower() or "authentication" in (r.stderr + r.stdout).lower():
            raise ErreurSauvegarde("Mot de passe incorrect pour la sauvegarde de ce disque.")
        raise ErreurSauvegarde("Ouverture de l'image chiffrée impossible : " + (r.stderr or r.stdout).strip()[-300:])
    return r.stdout


def _detacher(point):
    for essai in range(5):
        r = _run(["hdiutil", "detach", point] + (["-force"] if essai >= 3 else []), timeout=60)
        if r.returncode == 0 or not os.path.ismount(point):
            return True
        time.sleep(2)
    return False


def creer_ou_verifier(volume, mdp):
    """Crée l'image chiffrée si elle n'existe pas ; sinon vérifie que le mot de passe l'ouvre.
    Puis enregistre le mot de passe dans le Trousseau."""
    if len(mdp) < 10:
        raise ErreurSauvegarde("Mot de passe trop court : 10 caractères au minimum.")
    if not os.path.isdir(volume):
        raise ErreurSauvegarde("Disque introuvable : branchez-le puis réessayez.")
    if os.path.isdir(_image(volume)):
        point = tempfile.mkdtemp(prefix="kineapp-sauvegarde-")
        try:
            _attacher(volume, mdp, point)
        finally:
            _detacher(point)
            shutil.rmtree(point, ignore_errors=True)
    else:
        r = _run(["hdiutil", "create", "-size", "2t", "-type", "SPARSEBUNDLE", "-fs", "APFS",
                  "-encryption", "AES-256", "-stdinpass", "-volname", VOLUME_IMAGE, _image(volume)],
                 entree=mdp, timeout=300)
        if r.returncode != 0 or not os.path.isdir(_image(volume)):
            raise ErreurSauvegarde("Création de l'image chiffrée impossible : " + (r.stderr or r.stdout).strip()[-300:])
    _memoriser(mdp)


def changer_mot_de_passe(volume, ancien, nouveau):
    if len(nouveau) < 10:
        raise ErreurSauvegarde("Nouveau mot de passe trop court : 10 caractères au minimum.")
    r = _run(["hdiutil", "chpass", "-oldstdinpass", "-newstdinpass", _image(volume)],
             entree=ancien + "\0" + nouveau, timeout=120)
    if r.returncode != 0:
        raise ErreurSauvegarde("Changement refusé (ancien mot de passe incorrect ?).")
    try:
        _memoriser(nouveau)
    except ErreurSauvegarde:
        raise ErreurSauvegarde("Le mot de passe de l'image a bien été changé, mais le Trousseau n'a pas pu "
                               "l'enregistrer : saisissez le NOUVEAU mot de passe dans « Définir le mot de passe ».")


# ── sauvegarde ──────────────────────────────────────────────────────────────
def sauvegarder(volume, sources, garder=30):
    """sources : [(nom affiché, chemin)]. Renvoie un résumé ; lève ErreurSauvegarde."""
    if not _VERROU.acquire(blocking=False):
        raise ErreurSauvegarde("Une sauvegarde est déjà en cours.")
    point = None
    try:
        ETAT.update(en_cours=True, erreur="", message="Préparation…")
        mdp = mot_de_passe()
        if not mdp:
            raise ErreurSauvegarde("Aucun mot de passe de sauvegarde : définissez-le dans Paramètres.")
        if not os.path.isdir(volume):
            raise ErreurSauvegarde("Disque de sauvegarde non branché.")
        if not os.path.isdir(_image(volume)):
            raise ErreurSauvegarde("Pas encore d'image chiffrée sur ce disque : définissez le mot de passe dans Paramètres.")
        point = tempfile.mkdtemp(prefix="kineapp-sauvegarde-")
        ETAT["message"] = "Ouverture de l'image chiffrée…"
        _attacher(volume, mdp, point)

        racine = os.path.join(point, "Instantanés")
        os.makedirs(racine, exist_ok=True)
        precedents = sorted(d for d in os.listdir(racine) if re.fullmatch(r"\d{4}-\d{2}-\d{2}_\d{4,6}", d))
        horodatage = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
        cible = os.path.join(racine, horodatage + ".partiel")
        os.makedirs(cible)
        manifeste = {"date": datetime.datetime.now().strftime("%d/%m/%Y %H:%M"), "sources": {}}
        for nom, chemin in sources:
            if not chemin or not os.path.isdir(chemin):
                manifeste["sources"][nom] = {"chemin": chemin, "absent": True}
                continue
            ETAT["message"] = f"Copie : {nom}…"
            args = ["rsync", "-a", "--stats"] + [f"--exclude={e}" for e in EXCLUSIONS]
            if precedents:
                lien = os.path.join(racine, precedents[-1], nom)
                if os.path.isdir(lien):
                    args.append(f"--link-dest={lien}")
            r = _run(args + [chemin.rstrip("/") + "/", os.path.join(cible, nom) + "/"], timeout=6 * 3600)
            if r.returncode not in (0, 24):                   # 24 : fichier disparu pendant la copie
                raise ErreurSauvegarde(f"Copie de « {nom} » interrompue : " + (r.stderr or r.stdout).strip()[-300:])
            fichiers = re.search(r"Number of files:\s*([\d,.]+)", r.stdout)
            manifeste["sources"][nom] = {"chemin": chemin, "fichiers": (fichiers.group(1) if fichiers else "?")}
        with open(os.path.join(cible, "LISEZMOI.txt"), "w", encoding="utf-8") as f:
            f.write("Sauvegarde KinéAPP du " + manifeste["date"] + "\n\nChaque dossier est une copie complète, "
                    "lisible directement. Pour restaurer, copiez les fichiers voulus à leur emplacement.\n")
        with open(os.path.join(cible, "manifeste.json"), "w", encoding="utf-8") as f:
            json.dump(manifeste, f, ensure_ascii=False, indent=2)
        final = os.path.join(racine, horodatage)
        os.rename(cible, final)                  # un instantané n'existe que s'il est complet

        ETAT["message"] = "Nettoyage des anciens instantanés…"
        tous = sorted(d for d in os.listdir(racine) if re.fullmatch(r"\d{4}-\d{2}-\d{2}_\d{4,6}", d))
        for vieux in tous[:-max(1, int(garder))]:
            shutil.rmtree(os.path.join(racine, vieux), ignore_errors=True)
        for reste in os.listdir(racine):          # instantanés interrompus lors d'une panne
            if reste.endswith(".partiel"):
                shutil.rmtree(os.path.join(racine, reste), ignore_errors=True)
        return {"date": manifeste["date"], "instantanes": min(len(tous), max(1, int(garder))),
                "sources": manifeste["sources"]}
    except ErreurSauvegarde as e:
        ETAT["erreur"] = str(e)
        raise
    except Exception as e:
        ETAT["erreur"] = f"Erreur inattendue : {e}"
        raise ErreurSauvegarde(ETAT["erreur"])
    finally:
        if point:
            ETAT["message"] = "Fermeture de l'image chiffrée…"
            _detacher(point)
            shutil.rmtree(point, ignore_errors=True)
        ETAT.update(en_cours=False, message="")
        _VERROU.release()


def taille_image_go(volume):
    """Place réellement occupée sur le disque externe (l'image ne grossit qu'à l'usage)."""
    r = _run(["du", "-sk", _image(volume)], timeout=120)
    try:
        return round(int(r.stdout.split()[0]) * 1024 / 1e9, 2)
    except (ValueError, IndexError):
        return None


# ── iCloud Drive (ou tout dossier synchronisé) : une archive chiffrée par soir ────
# Un sparsebundle (des milliers de fichiers) se synchronise mal et iCloud peut en évacuer
# des morceaux du Mac : ici, un fichier .dmg unique, compressé, chiffré AES-256, vérifié
# après écriture. Les données patients font quelques Mo : une copie complète par soir.
def definir_mot_de_passe(mdp, dossier=None):
    """Sans disque externe : enregistre le mot de passe. Si des archives existent déjà dans
    le dossier, il doit ouvrir la plus récente (sinon les anciennes deviendraient illisibles
    sans qu'on le sache)."""
    if len(mdp) < 10:
        raise ErreurSauvegarde("Mot de passe trop court : 10 caractères au minimum.")
    existantes = archives(dossier) if dossier else []
    if existantes:
        point = tempfile.mkdtemp(prefix="kineapp-verif-")
        try:
            _attacher_archive(existantes[0]["chemin"], mdp, point)
        finally:
            _detacher(point)
            shutil.rmtree(point, ignore_errors=True)
    _memoriser(mdp)


def archives(dossier):
    out = []
    for n in sorted(os.listdir(dossier), reverse=True) if dossier and os.path.isdir(dossier) else []:
        m = re.fullmatch(re.escape(PREFIXE_ARCHIVE) + r"(\d{4}-\d{2}-\d{2})_(\d{4})\.dmg", n)
        if m:
            chemin = os.path.join(dossier, n)
            out.append({"nom": n, "chemin": chemin, "date": datetime.datetime.strptime(m.group(1) + m.group(2), "%Y-%m-%d%H%M"),
                        "taille_mo": round(os.path.getsize(chemin) / 1e6, 1)})
    return out


def _attacher_archive(chemin, mdp, point=None, visible=False):
    args = ["hdiutil", "attach", "-stdinpass", "-readonly"] + ([] if visible else ["-nobrowse", "-mountpoint", point])
    r = _run(args + [chemin], entree=mdp, timeout=180)
    if r.returncode != 0:
        if re.search(r"authenti", r.stderr + r.stdout, re.I):
            raise ErreurSauvegarde("Mot de passe incorrect pour l'archive " + os.path.basename(chemin) + ".")
        raise ErreurSauvegarde("Ouverture de l'archive impossible : " + (r.stderr or r.stdout).strip()[-300:])
    return r.stdout


def _a_garder(liste, jours, semaines):
    """Les N plus récentes, plus la plus récente de chacune des M dernières semaines."""
    garder, semaines_vues = set(a["chemin"] for a in liste[:max(1, jours)]), set()
    for a in liste:
        semaine = a["date"].isocalendar()[:2]
        if semaine not in semaines_vues and len(semaines_vues) < semaines:
            semaines_vues.add(semaine)
            garder.add(a["chemin"])
    return garder


def sauvegarder_archive(dossier, sources, jours=14, semaines=8):
    if not _VERROU.acquire(blocking=False):
        raise ErreurSauvegarde("Une sauvegarde est déjà en cours.")
    travail = None
    try:
        ETAT.update(en_cours=True, erreur="", message="Préparation…")
        mdp = mot_de_passe()
        if not mdp:
            raise ErreurSauvegarde("Aucun mot de passe de sauvegarde : définissez-le dans Paramètres.")
        if not dossier:
            raise ErreurSauvegarde("Aucun dossier de sauvegarde choisi.")
        os.makedirs(dossier, exist_ok=True)
        travail = tempfile.mkdtemp(prefix="kineapp-archive-")
        copie = os.path.join(travail, "KinéAPP")
        os.makedirs(copie)
        manifeste = {"date": datetime.datetime.now().strftime("%d/%m/%Y %H:%M"), "sources": {}}
        for nom, chemin in sources:
            if not chemin or not os.path.isdir(chemin):
                manifeste["sources"][nom] = {"chemin": chemin, "absent": True}
                continue
            ETAT["message"] = f"Copie : {nom}…"
            r = _run(["rsync", "-a"] + [f"--exclude={e}" for e in EXCLUSIONS]
                     + [chemin.rstrip("/") + "/", os.path.join(copie, nom) + "/"], timeout=3600)
            if r.returncode not in (0, 24):
                raise ErreurSauvegarde(f"Copie de « {nom} » interrompue : " + (r.stderr or r.stdout).strip()[-300:])
            manifeste["sources"][nom] = {"chemin": chemin}
        with open(os.path.join(copie, "manifeste.json"), "w", encoding="utf-8") as f:
            json.dump(manifeste, f, ensure_ascii=False, indent=2)
        horodatage = datetime.datetime.now().strftime("%Y-%m-%d_%H%M")
        final = os.path.join(dossier, f"{PREFIXE_ARCHIVE}{horodatage}.dmg")
        partiel = os.path.join(travail, "archive.dmg")           # écrite hors iCloud, déplacée une fois complète
        ETAT["message"] = "Chiffrement de l'archive…"
        r = _run(["hdiutil", "create", "-srcfolder", copie, "-encryption", "AES-256", "-stdinpass",
                  "-format", "ULFO", "-volname", "KinéAPP Sauvegarde", partiel], entree=mdp, timeout=3600)
        if r.returncode != 0 or not os.path.isfile(partiel):
            raise ErreurSauvegarde("Création de l'archive chiffrée impossible : " + (r.stderr or r.stdout).strip()[-300:])
        ETAT["message"] = "Vérification de l'archive…"
        point = os.path.join(travail, "verification")
        os.makedirs(point)
        _attacher_archive(partiel, mdp, point)
        try:
            if not os.path.isfile(os.path.join(point, "manifeste.json")):
                raise ErreurSauvegarde("Archive incomplète : vérification échouée.")
        finally:
            _detacher(point)
        shutil.move(partiel, final + ".part")
        os.replace(final + ".part", final)
        ETAT["message"] = "Rotation des anciennes archives…"
        liste = archives(dossier)
        garder = _a_garder(liste, jours, semaines)
        for a in liste:
            if a["chemin"] not in garder:
                os.remove(a["chemin"])
        return {"date": manifeste["date"], "fichier": final, "taille_mo": round(os.path.getsize(final) / 1e6, 1),
                "archives": len(archives(dossier))}
    except ErreurSauvegarde as e:
        ETAT["erreur"] = str(e)
        raise
    except Exception as e:
        ETAT["erreur"] = f"Erreur inattendue : {e}"
        raise ErreurSauvegarde(ETAT["erreur"])
    finally:
        if travail:
            shutil.rmtree(travail, ignore_errors=True)
        ETAT.update(en_cours=False, message="")
        _VERROU.release()


def ouvrir_archive(chemin):
    mdp = mot_de_passe()
    if not mdp:
        raise ErreurSauvegarde("Aucun mot de passe de sauvegarde enregistré.")
    sortie = _attacher_archive(chemin, mdp, visible=True)
    m = re.search(r"(/Volumes/.+)$", sortie.strip(), re.M)
    subprocess.run(["open", m.group(1).strip() if m else "/Volumes"])


def ouvrir_dans_finder(volume):
    """Monte la sauvegarde de façon visible (Finder) pour consulter ou restaurer."""
    mdp = mot_de_passe()
    if not mdp:
        raise ErreurSauvegarde("Aucun mot de passe de sauvegarde enregistré.")
    sortie = _attacher(volume, mdp, visible=True)
    m = re.search(r"(/Volumes/.+)$", sortie.strip(), re.M)
    chemin = m.group(1).strip() if m else "/Volumes/" + VOLUME_IMAGE
    subprocess.run(["open", os.path.join(chemin, "Instantanés") if os.path.isdir(os.path.join(chemin, "Instantanés")) else chemin])
    return chemin
