# -*- coding: utf-8 -*-
"""Base de données de l'app : un fichier SQLite (mode WAL), à la place des dizaines de fichiers JSON
lus, modifiés puis réécrits (une écriture simultanée pouvait en perdre une autre).

Une table de documents : (genre, clé) -> document JSON. Genres : « patient » (plan, séances,
questionnaires, force, prévention, programme), « dictee » (file des dictées de l'iPhone), « cr »
(comptes rendus), « ordonnance ». Les documents gardent leur forme d'avant : le reste du code ne
change pas de modèle, il change de rangement.

    modifier(genre, clé, f)   lecture, f(document), écriture : une seule transaction (BEGIN IMMEDIATE),
                              atomique entre fils ET entre processus (serveur et outils).

Chiffrement (chiffrement.py) : quand une clé est posée, chaque document est chiffré avant
d'être écrit ; un document en clair (d'avant le chiffrement) se lit toujours, et se réécrit chiffré.
La recherche dans le texte des bilans ne vit qu'en mémoire (rien du texte n'est écrit en clair ici).
"""
import json, os, sqlite3, threading, time
from contextlib import contextmanager

DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
CHEMIN = os.path.join(DATA, "kineapp.sqlite")
_LOCAL = threading.local()
CODEC = {"chiffrer": None, "dechiffrer": None, "chiffre": None, "exiger": False}   # posés par chiffrement.py

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents(genre TEXT NOT NULL, cle TEXT NOT NULL, donnees BLOB NOT NULL,
                                     maj REAL NOT NULL, PRIMARY KEY(genre, cle));
CREATE TABLE IF NOT EXISTS meta(cle TEXT PRIMARY KEY, valeur TEXT);
"""


def connexion():
    """Une connexion par fil (SQLite en mode WAL : lectures concurrentes, une écriture à la fois)."""
    c = getattr(_LOCAL, "c", None)
    if c is not None and getattr(_LOCAL, "chemin", None) == CHEMIN:
        return c
    os.makedirs(os.path.dirname(CHEMIN), exist_ok=True)
    c = sqlite3.connect(CHEMIN, timeout=30, isolation_level=None, check_same_thread=False)
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=NORMAL")
    c.execute("PRAGMA busy_timeout=30000")
    c.execute("PRAGMA secure_delete=ON")           # contenu remplacé ou retiré : écrasé, pas laissé dans le fichier
    c.executescript(SCHEMA)
    with _sans_erreur():
        os.chmod(CHEMIN, 0o600)
    _LOCAL.c, _LOCAL.chemin = c, CHEMIN
    return c


@contextmanager
def _sans_erreur():
    try:
        yield
    except OSError:
        pass


def _encoder(doc):
    brut = json.dumps(doc, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if CODEC["chiffrer"]:
        return CODEC["chiffrer"](brut)
    if CODEC.get("exiger"):                 # chiffrement actif, clé absente : rien ne s'écrit en clair
        import chiffrement
        raise chiffrement.Verrouille("Chiffrement actif : KinéAPP doit être déverrouillée pour écrire.")
    return brut


def _decoder(blob):
    blob = bytes(blob)
    if CODEC["chiffre"] and CODEC["chiffre"](blob):
        if not CODEC["dechiffrer"]:
            import chiffrement
            raise chiffrement.Verrouille("Données chiffrées : KinéAPP doit être déverrouillée.")
        blob = CODEC["dechiffrer"](blob)
    return json.loads(blob.decode("utf-8"))


@contextmanager
def transaction():
    """Transaction d'écriture : tout ou rien, sans écriture concurrente pendant ce temps."""
    c = connexion()
    if getattr(_LOCAL, "profondeur", 0):
        _LOCAL.profondeur += 1
        try:
            yield c
        finally:
            _LOCAL.profondeur -= 1
        return
    c.execute("BEGIN IMMEDIATE")
    _LOCAL.profondeur = 1
    try:
        yield c
    except BaseException:
        c.execute("ROLLBACK")
        raise
    else:
        c.execute("COMMIT")
    finally:
        _LOCAL.profondeur = 0


def lire(genre, cle):
    r = connexion().execute("SELECT donnees FROM documents WHERE genre=? AND cle=?", (genre, cle)).fetchone()
    return _decoder(r[0]) if r else None


def ecrire(genre, cle, doc):
    with transaction() as c:
        c.execute("INSERT INTO documents(genre, cle, donnees, maj) VALUES(?,?,?,?) "
                  "ON CONFLICT(genre, cle) DO UPDATE SET donnees=excluded.donnees, maj=excluded.maj",
                  (genre, cle, _encoder(doc), time.time()))


def retirer(genre, cle):
    with transaction() as c:
        c.execute("DELETE FROM documents WHERE genre=? AND cle=?", (genre, cle))


def tous(genre):
    """[(clé, document)] dans l'ordre d'écriture."""
    return [(k, _decoder(d)) for k, d in
            connexion().execute("SELECT cle, donnees FROM documents WHERE genre=? ORDER BY rowid", (genre,))]


def modifier(genre, cle, f, defaut=None):
    """Lecture puis écriture dans la même transaction ; f renvoie le nouveau document (None : retirer)."""
    with transaction() as c:
        r = c.execute("SELECT donnees FROM documents WHERE genre=? AND cle=?", (genre, cle)).fetchone()
        doc = f(_decoder(r[0]) if r else defaut)
        if doc is None:
            c.execute("DELETE FROM documents WHERE genre=? AND cle=?", (genre, cle))
        else:
            c.execute("INSERT INTO documents(genre, cle, donnees, maj) VALUES(?,?,?,?) "
                      "ON CONFLICT(genre, cle) DO UPDATE SET donnees=excluded.donnees, maj=excluded.maj",
                      (genre, cle, _encoder(doc), time.time()))
        return doc


def remplacer_genre(genre, docs):
    """Tous les documents d'un genre remplacés d'un coup (liste ordonnée [(clé, document)])."""
    with transaction() as c:
        c.execute("DELETE FROM documents WHERE genre=?", (genre,))
        t = time.time()
        c.executemany("INSERT INTO documents(genre, cle, donnees, maj) VALUES(?,?,?,?)",
                      [(genre, k, _encoder(d), t) for k, d in docs])


def meta(cle, valeur=None):
    c = connexion()
    if valeur is None:
        r = c.execute("SELECT valeur FROM meta WHERE cle=?", (cle,)).fetchone()
        return r[0] if r else None
    with transaction() as c:
        c.execute("INSERT INTO meta(cle, valeur) VALUES(?,?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur",
                  (cle, str(valeur)))
    return valeur


def point_de_controle():
    """Journal WAL reporté dans le fichier de la base : une copie de fichier (sauvegarde) est complète."""
    with _sans_erreur():
        connexion().execute("PRAGMA wal_checkpoint(TRUNCATE)")


def rechiffrer_tout():
    """Réécrit chaque document avec le codec courant (chiffrement activé, ou clé changée), puis purge
    le fichier : pages libérées et journal WAL gardaient les anciennes versions, en clair."""
    with transaction() as c:
        lignes = c.execute("SELECT genre, cle, donnees FROM documents").fetchall()
        for g, k, d in lignes:
            c.execute("UPDATE documents SET donnees=? WHERE genre=? AND cle=?", (_encoder(_decoder(d)), g, k))
    purger()
    return len(lignes)


def purger():
    c = connexion()
    c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    c.execute("VACUUM")
    c.execute("PRAGMA wal_checkpoint(TRUNCATE)")


def importer_anciens(dossier_data, corbeille):
    """Anciennes fiches JSON (patients, comptes rendus, ordonnances, file des dictées) versées dans la
    base, une seule fois ; les fichiers d'origine partent ensuite à la Corbeille (jamais effacés).
    Renvoie le nombre de documents importés."""
    n, verses = 0, []
    for genre, sous in (("patient", "patients"), ("cr", "comptes_rendus"), ("ordonnance", "ordonnances")):
        d = os.path.join(dossier_data, sous)
        for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if not f.endswith(".json"):
                continue
            p = os.path.join(d, f)
            try:
                doc = json.load(open(p, encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if lire(genre, f[:-5]) is None:
                ecrire(genre, f[:-5], doc)
                n += 1
            verses.append(p)
    file_d = os.path.join(dossier_data, "dictees", "file.json")
    if os.path.isfile(file_d):
        try:
            l = json.load(open(file_d, encoding="utf-8")) or []
        except (OSError, ValueError):
            l = None
        if isinstance(l, list):
            if not tous("dictee"):
                remplacer_genre("dictee", [(x["id"], x) for x in l if isinstance(x, dict) and x.get("id")])
                n += len(l)
            verses.append(file_d)
    if verses:
        corbeille(verses)
    return n
