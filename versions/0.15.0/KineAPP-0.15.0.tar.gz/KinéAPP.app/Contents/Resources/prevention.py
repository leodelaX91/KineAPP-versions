# -*- coding: utf-8 -*-
"""Les deux missions de prévention du masseur-kinésithérapeute.

1. Repérage de la fragilité de la personne de 70 ans ou plus (AMK 10, avenant 7), selon la
   méthodologie ICOPE de l'OMS : étape 1 (6 fonctions), alertes et compte rendu au médecin traitant.
2. Mon Bilan Prévention (arrêté du 28 juillet 2026) : fiche d'aide au repérage des risques par
   tranche d'âge, tests cliniques, priorisation et Plan Personnalisé de Prévention.

Les données (questions, seuils, conditions de facturation) sont dans prevention/*.json, reprises des
documents officiels. Aucun modèle de langage n'intervient : les documents produits reprennent la saisie.
"""
import datetime, html as _html, json, os, re, subprocess, tempfile

CODE = os.path.dirname(os.path.abspath(__file__))
DOSSIER = os.path.join(CODE, "prevention")
_CACHE = {}


def donnees(nom):
    if nom not in _CACHE:
        with open(os.path.join(DOSSIER, nom + ".json"), encoding="utf-8") as f:
            _CACHE[nom] = json.load(f)
    return _CACHE[nom]


def icope():
    return donnees("icope")


def mbp():
    return donnees("mbp")


def tranche_pour_age(age):
    """Tranche d'âge du bilan de prévention, ou None (bornes incluses)."""
    try:
        age = int(age)
    except (TypeError, ValueError):
        return None
    for cle, (mini, maxi) in {"18-25": (18, 25), "45-50": (45, 50), "60-65": (60, 65), "70-75": (70, 75)}.items():
        if mini <= age <= maxi:
            return cle
    return None


def _oui(v):
    return str(v) in ("1", "oui", "Oui", "True", "true")


def alertes_icope(reponses):
    """Alertes de l'étape 1 : une par fonction, avec la conduite à tenir."""
    out = []
    for f in icope()["fonctions"]:
        regle, alerte = f.get("alerte") or {}, False
        for iid in regle.get("si_oui", []):
            alerte = alerte or _oui(reponses.get(iid))
        for iid in regle.get("si_non", []):
            v = reponses.get(iid)
            alerte = alerte or (v not in (None, "") and not _oui(v))
        sup = regle.get("si_superieur")
        if sup:
            try:
                alerte = alerte or float(str(reponses.get(sup["item"], "")).replace(",", ".")) >= sup["valeur"]
            except ValueError:
                pass
        if alerte:
            out.append({"fonction": f["nom"], "texte": f["texte_alerte"], "conduite": f["conduite"]})
    return out


def _lignes(items, reponses, avec_non=False):
    """Réponses saisies, mises en forme ; les cases non cochées sont ignorées."""
    out = []
    for it in items:
        v = reponses.get(it["id"])
        if v in (None, ""):
            continue
        if it["type"] == "case":
            if _oui(v):
                out.append(f"- {it['texte']}")
        elif it["type"] == "oui_non":
            if _oui(v) or avec_non:
                out.append(f"- {it['texte']} : {'oui' if _oui(v) else 'non'}")
        else:
            unite = (" " + it["unite"]) if it.get("unite") else ""
            out.append(f"- {it['texte']} : {v}{unite}")
    return out


def texte_icope(patient, seance, entete_nom=""):
    """Compte rendu du repérage de la fragilité, à adresser au médecin traitant."""
    d, rep = icope(), seance.get("reponses") or {}
    alertes = alertes_icope(rep)
    L = [f"# Repérage de la fragilité (ICOPE étape 1)", "",
         f"**Patient** : {patient}", f"**Date du repérage** : {seance.get('date', '')}",
         f"**Réalisé par** : {entete_nom or 'masseur-kinésithérapeute'}", ""]
    if seance.get("prescripteur"):
        L += [f"**À l'attention du Dr {seance['prescripteur']}**", ""]
    L += ["## Résultat du dépistage", ""]
    if alertes:
        L.append(f"{len(alertes)} alerte(s) sur les 6 fonctions explorées :")
        L += [f"- **{a['fonction']}** : {a['texte']}. Conduite proposée : {a['conduite']}" for a in alertes]
    else:
        L.append("Aucune alerte sur les 6 fonctions explorées (cognition, nutrition, vision, audition, santé mentale, mobilité).")
    L += ["", "## Détail des réponses", ""]
    for f in d["fonctions"]:
        lignes = _lignes(f["items"], rep, avec_non=True)
        if lignes:
            L += [f"### {f['nom']}"] + lignes + [""]
    if seance.get("suites"):
        L += ["## Suites données", "", f"- {seance['suites']}", ""]
    if seance.get("commentaire"):
        L += ["## Observations", "", seance["commentaire"], ""]
    L += ["## Suivi", "", d["suivi"], "",
          "*Repérage réalisé selon le formulaire ICOPE MONITOR étape 1 de l'OMS. Ce compte rendu est transmis pour information "
          "et, en cas d'alerte, pour évaluation approfondie ou bilan gériatrique.*"]
    return "\n".join(L)


def texte_mbp(patient, seance, entete_nom=""):
    """Plan Personnalisé de Prévention et synthèse du repérage des risques."""
    d = mbp()
    tr = d["tranches"].get(seance.get("tranche") or "", {})
    rep, ppp = seance.get("reponses") or {}, seance.get("ppp") or {}
    L = ["# Plan Personnalisé de Prévention", "",
         f"**Personne** : {patient}", f"**Date du bilan** : {seance.get('date', '')}",
         f"**Tranche d'âge** : {tr.get('libelle', '')}", f"**Réalisé par** : {entete_nom or 'masseur-kinésithérapeute'}", "",
         "*Rédaction partagée entre la personne et le professionnel de santé, à l'issue de l'entretien.*", ""]
    for cle in d["ppp"]:
        valeur = (ppp.get(cle) or "").strip()
        L += [f"## {cle}", "", valeur or "—", ""]
    tests = [t for t in tr.get("tests", []) if _oui(rep.get("test::" + t))]
    if tests:
        L += ["## Tests réalisés pendant le bilan", ""] + [f"- {t}" for t in tests] + [""]
    repere = []
    for sec in tr.get("sections", []):
        lignes = _lignes(sec["items"], rep)
        if lignes:
            repere += [f"### {sec['nom']}"] + lignes + [""]
    if repere:
        L += ["## Repérage des risques", ""] + repere
    if seance.get("orientations"):
        L += ["## Orientations proposées", ""] + [f"- {o}" for o in seance["orientations"]] + [""]
    if seance.get("opposition_transmission"):
        L += ["*La personne s'oppose à la transmission de ce document à son médecin traitant.*", ""]
    else:
        L += ["*Document destiné à la personne, déposé dans Mon espace santé ou transmis au médecin traitant avec son accord.*", ""]
    return "\n".join(L)


def resume(seance):
    """Une ligne pour l'historique et les comptes rendus."""
    if seance.get("type") == "icope":
        n = len(alertes_icope(seance.get("reponses") or {}))
        return (f"Repérage de la fragilité (ICOPE) du {seance.get('date')} : "
                + (f"{n} alerte(s) — " + ", ".join(a["fonction"] for a in alertes_icope(seance.get("reponses") or {})) if n
                   else "aucune alerte"))
    tr = mbp()["tranches"].get(seance.get("tranche") or "", {})
    priorites = (seance.get("ppp") or {}).get("Mes priorités en santé", "").strip().replace("\n", " ; ")
    return (f"Mon Bilan Prévention {tr.get('libelle', '')} du {seance.get('date')}"
            + (f" — priorités : {priorites}" if priorites else ""))


def nom_fichier(patient, seance):
    quoi = "Reperage fragilite ICOPE" if seance.get("type") == "icope" else "Plan personnalise de prevention"
    date = (seance.get("date") or datetime.date.today().strftime("%d/%m/%Y")).replace("/", "-")
    return f"{patient}_{quoi}_{date}".replace("/", "-").replace("\\", "-")


# ── Autoquestionnaire (rempli par la personne) ───────────────────────────────
FREQ_PHQ4 = {"Jamais": 0, "Plusieurs jours": 1, "Plus de sept jours": 2, "Presque tous les jours": 3}


def questions_auto(tranche):
    return mbp().get("autoquestionnaires", {}).get(tranche, [])


def phq4(tranche, auto):
    """PHQ-4 : les 4 questions « Au cours des 2 dernières semaines… » (0 à 3 chacune).
    Anxiété = nervosité + inquiétude ; dépression = intérêt + tristesse ; dépistage positif si sous-score ≥ 3."""
    qs = [q for q in questions_auto(tranche) if q["texte"].startswith("Au cours des 2 dernières semaines")]
    if len(qs) != 4:
        return None
    vals = [FREQ_PHQ4.get(auto.get(q["id"])) for q in qs]
    if any(v is None for v in vals):
        return None
    anx, dep = vals[0] + vals[1], vals[2] + vals[3]
    total = anx + dep
    niveau = "normal" if total <= 2 else "léger" if total <= 5 else "modéré" if total <= 8 else "sévère"
    return {"total": total, "anxiete": anx, "depression": dep, "niveau": niveau,
            "texte": (f"PHQ-4 : {total}/12 ({niveau}) ; anxiété {anx}/6" + (" (dépistage positif)" if anx >= 3 else "")
                      + f" ; dépression {dep}/6" + (" (dépistage positif)" if dep >= 3 else ""))}


_A_EXPLORER = [  # (motif dans la question, réponses qui alertent, message, urgent)
    (r"idées noires", ("Oui, des idées noires/suicidaires", "Oui, une ou des tentative(s) de suicide", "Oui, une ou des tentatives de suicide"),
     "Idées suicidaires ou antécédent de tentative : évaluer le risque, orienter sans délai (médecin, 3114)", True),
    (r"victime de violences", ("Oui",), "Violences déclarées : écouter, orienter (3919, 119, médecin)", True),
    (r"douleurs dans la poitrine", ("Oui",), "Douleur thoracique à l'effort : orienter vers le médecin", True),
    (r"gonflements importants", ("Oui",), "Œdèmes des membres inférieurs : orienter vers le médecin", False),
    (r"essoufflé", ("Oui",), "Essoufflement inhabituel : explorer (débitmétrie) et orienter si besoin", False),
    (r"toux grasse", ("Oui",), "Toux grasse fréquente : explorer, débitmétrie de pointe", False),
    (r"pauses respiratoires", ("Oui",), "Pauses respiratoires ou ronflements : suspicion d'apnée du sommeil", False),
    (r"voir moins bien", ("Oui",), "Baisse de vision ressentie : test d'acuité, orientation ophtalmologique", False),
    (r"entendre moins bien", ("Oui",), "Baisse d'audition ressentie : test de la voix chuchotée", False),
    (r"oublier des choses", ("Oui",), "Plainte mnésique : test des 3 mots (ICOPE)", False),
    (r"fumez-vous", ("Oui, je fume", "Oui, je vapote"), "Tabac ou vapotage : test de Fagerström, conseil d'arrêt", False),
    (r"boissons alcoolisées :", None, "Consommation d'alcool au-delà des repères : questionnaire FACE ou AUDIT", False),
    (r"autres substances", ("Oui, du cannabis", "Oui, d’autres drogues", "Oui, du protoxyde d’azote"), "Consommation de substances : questionnaire CAST", False),
    (r"activités physiques dynamiques", ("Jamais", "1 à 2 fois par semaine"), "Activité physique insuffisante", False),
    (r"assis\(e\) ou allongé\(e\)", ("Plus de 7 heures",), "Sédentarité importante (plus de 7 h assis par jour)", False),
    (r"fruits et légumes", ("De temps en temps", "Rarement", "Jamais"), "Consommation de fruits et légumes insuffisante", False),
    (r"prévention des chutes", ("Non",), "Logement non adapté à la prévention des chutes", False),
    (r"certains gestes de la vie quotidienne", None, "Difficultés dans les gestes de la vie quotidienne : repérage de la perte d'autonomie", False),
    (r"variation de votre poids", ("Oui, un amaigrissement",), "Amaigrissement récent : rechercher une dénutrition", False),
    (r"à jour de vos vaccins", ("Non", "Je ne sais pas"), "Vaccinations à vérifier (carnet de vaccination)", False),
    (r"dépistage du cancer colorectal", ("Oui, il y a plus de 2 ans", "Non, jamais"), "Dépistage du cancer colorectal à proposer", False),
    (r"mammographie", ("Oui, il y a plus de 2 ans", "Non, jamais"), "Dépistage du cancer du sein à proposer", False),
]


def points_a_explorer(tranche, auto):
    out = []
    for q in questions_auto(tranche):
        v = auto.get(q["id"])
        if v in (None, "", []):
            continue
        for motif, reponses, message, urgent in _A_EXPLORER:
            if re.search(motif, q["texte"]):
                valeurs = v if isinstance(v, list) else [v]
                if reponses is None:            # choix multiple : toute case cochée alerte
                    touche = [x for x in valeurs if not x.startswith(("Aucune", "Non concerné", "Vous ne buvez pas"))]
                else:
                    touche = [x for x in valeurs if x in reponses]
                if touche:
                    out.append({"question": q["id"], "message": message, "urgent": urgent, "reponse": ", ".join(touche)})
                break
    return out


# ── Documents PDF (HTML local converti par outils/html2pdf, sans réseau) ─────

STYLE = """<style>
body{font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:10.5pt;color:#111;line-height:1.35}
h1{font-size:16pt;color:#0f766e;margin:0 0 4px} h2{font-size:12pt;color:#0f766e;border-bottom:1px solid #cfe7e3;padding-bottom:2px;margin:14px 0 6px}
.entete{font-size:9pt;color:#444;margin-bottom:10px;white-space:pre-line} .meta{color:#444;margin-bottom:8px}
table{width:100%;border-collapse:collapse} td{vertical-align:top;padding:4px 6px;border-bottom:1px solid #eee}
td.q{width:62%} td.r{font-weight:600} .vide{color:#999;font-weight:400} .alerte{color:#b91c1c;font-weight:600}
.note{font-size:9pt;color:#555;margin-top:12px} .bloc{border:1px solid #ddd;border-radius:6px;padding:6px 8px;min-height:28px;white-space:pre-wrap}
tr,li{page-break-inside:avoid} h2{page-break-after:avoid}
</style>"""


def _e(x):
    return _html.escape(str(x if x is not None else ""))


def _page(titre, corps, entete_lignes):
    return (f"<html><head><meta charset='utf-8'><title>{_e(titre)}</title>{STYLE}</head><body>"
            f"<div class='entete'>{_e(chr(10).join(entete_lignes))}</div>{corps}</body></html>")


def html_autoquestionnaire(patient, seance, entete_lignes):
    tr = seance.get("tranche") or ""
    auto = seance.get("auto") or {}
    corps = [f"<h1>Autoquestionnaire — Mon Bilan Prévention {_e(mbp()['tranches'].get(tr, {}).get('libelle', ''))}</h1>",
             f"<div class='meta'>{_e(patient)} — rempli le {_e(seance.get('auto_rempli_le') or seance.get('date', ''))}</div>"]
    section = None
    for q in questions_auto(tr):
        if q["section"] != section:
            if section is not None:
                corps.append("</table>")
            section = q["section"]
            corps.append(f"<h2>{_e(section)}</h2><table>")
        v = auto.get(q["id"])
        if isinstance(v, list):
            v = " ; ".join(v)
        if q["id"] + "_autre" in auto:
            v = f"{v} ({auto[q['id'] + '_autre']})"
        rep = f"{_e(v)}{(' ' + _e(q.get('unite'))) if v not in (None, '') and q.get('unite') else ''}" if v not in (None, "") else "<span class='vide'>sans réponse</span>"
        corps.append(f"<tr><td class='q'>{_e(q['texte'])}</td><td class='r'>{rep}</td></tr>")
    if section is not None:
        corps.append("</table>")
    score = phq4(tr, auto)
    if score:
        corps.append(f"<p class='note'>{_e(score['texte'])} (calculé à partir des 4 questions sur les 2 dernières semaines).</p>")
    return _page("Autoquestionnaire", "".join(corps), entete_lignes)


def html_fiche(patient, seance, entete_lignes):
    tr = mbp()["tranches"].get(seance.get("tranche") or "", {})
    rep = seance.get("reponses") or {}
    corps = [f"<h1>Fiche d'aide au repérage des risques — {_e(tr.get('libelle', ''))}</h1>",
             f"<div class='meta'>{_e(patient)} — bilan du {_e(seance.get('date', ''))}</div>"]
    tests = [t for t in tr.get("tests", []) if _oui(rep.get("test::" + t))]
    if tests:
        corps.append("<h2>Examen clinique réalisé</h2><ul>" + "".join(f"<li>{_e(t)}</li>" for t in tests) + "</ul>")
    for sec in tr.get("sections", []):
        lignes = [l[2:] for l in _lignes(sec["items"], rep)]
        if lignes:
            corps.append(f"<h2>{_e(sec['nom'])}</h2><ul>" + "".join(f"<li>{_e(l)}</li>" for l in lignes) + "</ul>")
    a_explorer = points_a_explorer(seance.get("tranche") or "", seance.get("auto") or {})
    if a_explorer:
        corps.append("<h2>Points repérés dans l'autoquestionnaire</h2><ul>" + "".join(
            f"<li class='{'alerte' if a['urgent'] else ''}'>{_e(a['message'])} — réponse : {_e(a['reponse'])}</li>" for a in a_explorer) + "</ul>")
    if seance.get("commentaire"):
        corps.append(f"<h2>Observations</h2><div class='bloc'>{_e(seance['commentaire'])}</div>")
    return _page("Fiche de repérage", "".join(corps), entete_lignes)


def html_ppp(patient, seance, entete_lignes):
    d = mbp()
    tr = d["tranches"].get(seance.get("tranche") or "", {})
    ppp = seance.get("ppp") or {}
    corps = ["<h1>Plan Personnalisé de Prévention</h1>",
             f"<div class='meta'>{_e(patient)} — bilan du {_e(seance.get('date', ''))} — {_e(tr.get('libelle', ''))}</div>",
             "<p class='note'>Rédaction partagée (par la personne et le professionnel de santé), à l'issue de l'intervention brève.</p>"]
    for cle in d["ppp"]:
        corps.append(f"<h2>{_e(cle)}</h2><div class='bloc'>{_e(ppp.get(cle, ''))}</div>")
    if seance.get("orientations"):
        corps.append("<h2>Orientations proposées</h2><ul>" + "".join(f"<li>{_e(o)}</li>" for o in seance["orientations"]) + "</ul>")
    corps.append("<p class='note'>Changer d'habitude n'est pas facile. Échanger avec une ou plusieurs personnes de confiance sur vos objectifs "
                 "est un facteur de succès important pour maintenir votre motivation. Plus de ressources sur monbilanprevention.fr.</p>")
    corps.append("<p class='note'>" + ("☒" if seance.get("opposition_transmission") else "☐")
                 + " Je m'oppose à ce que ce document soit communiqué à mon médecin traitant.</p>")
    return _page("Plan Personnalisé de Prévention", "".join(corps), entete_lignes)


def html_questionnaires(patient, lignes, entete_lignes):
    corps = ["<h1>Questionnaires remplis</h1>", f"<div class='meta'>{_e(patient)}</div>",
             "<ul>" + "".join(f"<li>{_e(l)}</li>" for l in lignes) + "</ul>"]
    return _page("Questionnaires remplis", "".join(corps), entete_lignes)


def en_pdf(html_texte, chemin_pdf):
    """HTML -> PDF avec l'outil local (WebKit). Aucun accès réseau."""
    outil = os.path.join(CODE, "outils", "html2pdf")
    with tempfile.TemporaryDirectory() as tmp:
        source = os.path.join(tmp, "document.html")
        with open(source, "w", encoding="utf-8") as f:
            f.write(html_texte)
        r = subprocess.run([outil, source, chemin_pdf], capture_output=True, timeout=60)
    if r.returncode != 0 or not os.path.isfile(chemin_pdf):
        raise RuntimeError("La conversion en PDF a échoué.")
    import chiffrement
    if chiffrement.proteger(chemin_pdf):           # écrit en clair par l'outil : chiffré aussitôt
        chiffrement.chiffrer_fichier(chemin_pdf)
    return chemin_pdf


def exporter_mbp(dossier_patient, patient, seance, entete_lignes, questionnaires_lignes=()):
    """Écrit les PDF du bilan dans « <dossier du patient>/Mon bilan prévention/ »."""
    dossier = os.path.join(dossier_patient, "Mon bilan prévention")
    os.makedirs(dossier, exist_ok=True)
    date = (seance.get("date") or "").replace("/", "-")
    tranche = seance.get("tranche") or ""
    fichiers = []
    documents = [(f"{date} Plan personnalisé de prévention.pdf", html_ppp(patient, seance, entete_lignes)),
                 (f"{date} Fiche d'aide au repérage des risques {tranche} ans.pdf", html_fiche(patient, seance, entete_lignes))]
    if seance.get("auto"):
        documents.append((f"{date} Autoquestionnaire {tranche} ans.pdf", html_autoquestionnaire(patient, seance, entete_lignes)))
    if questionnaires_lignes:
        documents.append((f"{date} Questionnaires remplis.pdf", html_questionnaires(patient, list(questionnaires_lignes), entete_lignes)))
    for nom, contenu in documents:
        chemin = os.path.join(dossier, nom.replace("/", "-"))
        fichiers.append(en_pdf(contenu, chemin))
    return dossier, fichiers
