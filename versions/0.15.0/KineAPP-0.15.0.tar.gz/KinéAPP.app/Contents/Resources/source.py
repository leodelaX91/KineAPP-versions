# -*- coding: utf-8 -*-
"""Relecture d'un bilan à côté de sa source : pour une ligne du bilan, les passages de la
transcription où elle a été dite. Calcul seul (aucun modèle) : rien n'est ajouté au traitement.

Un passage est une phrase de la transcription, avec ses voisines. Sa note : les NOMBRES de la ligne
qu'il contient (en chiffres ou en mots, « dix-huit » = 18), les CÔTÉS, puis les mots cliniques en
commun (5 premières lettres : « fléchit » et « flexion » ne se rapprochent pas, « douleurs » et
« douloureux » si). Les nombres pèsent le plus : c'est d'eux que dépend la justesse d'un bilan.
Positions renvoyées en caractères du texte original de la transcription.
"""
import re

import verification as VE

# Mots trop fréquents pour situer un passage.
VIDES = set("""avec dans pour mais plus moins tres bien fait faire etre avoir comme alors donc cette cela
ceci elle elles nous vous ils leur leurs quand aussi encore apres avant depuis entre sans sous chez
patient patiente madame monsieur bilan seance examen niveau point points cote cotes""".split())


UNITES = {"zero": 0, "un": 1, "une": 1, "deux": 2, "trois": 3, "quatre": 4, "cinq": 5, "six": 6, "sept": 7, "huit": 8,
          "neuf": 9, "dix": 10, "onze": 11, "douze": 12, "treize": 13, "quatorze": 14, "quinze": 15, "seize": 16,
          "vingt": 20, "vingts": 20, "trente": 30, "quarante": 40, "cinquante": 50, "soixante": 60}
MOT = re.compile(r"\d+(?:[.,]\d+)?|[A-Za-zÀ-ÿ]+")


def nombres_situes(texte):
    """[(début, fin, valeur)] : nombres en chiffres, et en mots (« cent dix » = 110, « trente et un » = 31,
    « quatre-vingt-dix » = 90, « un virgule cinq » = 1,5)."""
    texte = texte or ""
    jetons = [(m.start(), m.end(), m.group(0)) for m in MOT.finditer(texte)]
    out, i = [], 0
    while i < len(jetons):
        d, f, w = jetons[i]
        if w[0].isdigit():
            out.append((d, f, float(w.replace(",", ".")))); i += 1
            continue
        mot = VE._sans_accent(w).lower()
        if mot not in UNITES and mot not in ("cent", "cents", "mille"):
            i += 1
            continue
        total = courant = 0
        debut, fin, prec, j = d, f, "", i
        while j < len(jetons):
            m_ = VE._sans_accent(jetons[j][2]).lower()
            if j > i and not re.fullmatch(r"[\s-]*", texte[jetons[j - 1][1]:jetons[j][0]]):
                break                                   # ponctuation : un autre nombre commence
            if j > i and m_ in UNITES and not _enchaine(prec, m_):
                break                                   # « trois quatre » : deux nombres
            if m_ == "et" and prec in ("vingt", "trente", "quarante", "cinquante", "soixante") and j + 1 < len(jetons) \
                    and VE._sans_accent(jetons[j + 1][2]).lower() in ("un", "une", "onze"):
                j += 1
                continue
            if m_ in UNITES:
                v = UNITES[m_]
                courant += 76 if m_.startswith("vingt") and prec == "quatre" else v     # quatre-vingt(s) = 80
            elif m_ in ("cent", "cents"):
                courant = (courant or 1) * 100
            elif m_ == "mille":
                total, courant = total + (courant or 1) * 1000, 0
            elif m_ == "virgule" and j + 1 < len(jetons) and VE._sans_accent(jetons[j + 1][2]).lower() in UNITES:
                dec = UNITES[VE._sans_accent(jetons[j + 1][2]).lower()]
                courant += dec / (10 if dec < 10 else 100)
                fin, j = jetons[j + 1][1], j + 2
                break
            else:
                break
            fin, prec, j = jetons[j][1], m_, j + 1
        out.append((debut, fin, float(total + courant)))
        i = max(j, i + 1)
    return out


DIZAINES = ("vingt", "vingts", "trente", "quarante", "cinquante", "soixante")


def _enchaine(prec, mot):
    """Le mot prolonge-t-il le nombre en cours ? (« vingt-deux », « soixante-dix », « dix-sept »,
    « quatre-vingts », « cent trois »)"""
    if prec in ("cent", "cents", "mille", "et"):
        return True
    if prec in DIZAINES:
        return UNITES[mot] < 20 and (UNITES[mot] < 10 or prec == "soixante" or prec.startswith("vingt"))
    if prec == "dix":
        return mot in ("sept", "huit", "neuf")
    if prec == "quatre":
        return mot.startswith("vingt")
    return False


def _valeurs(texte):
    return {v for _, _, v in nombres_situes(texte)} | VE._nombres_du_texte(texte)


SYNONYMES = {"eva": {"doule"}, "douleur": {"doule"}, "flexion": {"plier", "plie"}, "extension": {"tendr"}}


def _mots_cles(t):
    mots = re.findall(r"[a-z]{3,}", VE._sans_accent(t).lower())
    cles = {m[:5] for m in mots if len(m) >= 4 and m not in VIDES}
    for m in mots:
        cles |= SYNONYMES.get(m, set())
    return cles


def phrases(transcription):
    """[(début, fin)] des phrases de la transcription (positions dans le texte original)."""
    out, debut = [], 0
    for m in re.finditer(r"[.!?…]+(?=\s)|\n+", transcription or ""):
        fin = m.end()
        if transcription[debut:fin].strip():
            out.append((debut, fin))
        debut = fin
    if (transcription or "")[debut:].strip():
        out.append((debut, len(transcription)))
    return out


def _nombres_ligne(ligne):
    """Nombres d'une ligne du bilan, sans ceux qui n'apprennent rien (0, 1, 2, 3, 10, 100) — sauf une
    note sur dix (« 3/10 ») : là, le 3 est la mesure."""
    sur = {float(a.replace(",", ".")) for a in re.findall(r"(\d+(?:[.,]\d+)?)\s*/\s*10\b", ligne)}
    return {v for v in VE._nombres_du_texte(ligne) if v not in VE.TOLERES} | sur


def passages(transcription, ligne, maxi=3):
    """Passages de la transcription les plus proches de la ligne : [{"debut", "fin", "note",
    "nombres": [[début, fin], …]}], du plus probable au moins probable ; [] si rien de net."""
    nombres = _nombres_ligne(ligne)
    cotes = VE._cotes_presentes(ligne)
    cles = _mots_cles(ligne)
    if not (nombres or cles):
        return []
    ph = phrases(transcription)
    notes = []
    for i, (d, f) in enumerate(ph):
        texte = transcription[d:f]
        trouves = nombres & _valeurs(texte)
        communs = cles & _mots_cles(texte)
        note = 3 * len(trouves) + len(communs) + (1 if cotes and cotes & VE._cotes_presentes(texte) else 0)
        # un nombre de la ligne retrouvé, ou deux mots cliniques au moins : sinon ce n'est pas un passage
        if trouves or len(communs) >= 2:
            notes.append((note, i, trouves))
    notes.sort(key=lambda x: (-x[0], x[1]))
    out = []
    for note, i, trouves in notes[:maxi]:
        d, f = ph[max(0, i - 1)][0], ph[min(len(ph) - 1, i + 1)][1]       # avec les phrases voisines
        out.append({"debut": d, "fin": f, "note": note, "nombres": _positions_nombres(transcription, ph[i], trouves)})
    return out


def _positions_nombres(transcription, phrase, valeurs):
    """Où sont dits les nombres retrouvés, dans la phrase (chiffres ou mots), pour les surligner."""
    d, f = phrase
    return [[d + a, d + b] for a, b, v in nombres_situes(transcription[d:f]) if v in valeurs]


def absents(transcription, ligne):
    """Nombres de la ligne dits nulle part dans la transcription : à relire en priorité. Une valeur
    calculée à partir des autres nombres dits de la ligne (écart, somme, pourcentage : « 18 kg à
    droite, 31 kg à gauche, écart de 13 kg », « symétrie 58 % ») n'est pas signalée."""
    nombres = _nombres_ligne(ligne) | {v for v in VE._nombres_du_texte(ligne)}
    dits = _valeurs(transcription or "")
    retrouves = sorted(nombres & dits)
    calcules = set()
    for a in retrouves:
        for b in retrouves:
            if a != b:
                calcules |= {round(abs(a - b), 1), round(a + b, 1)}
                if b:
                    calcules |= {float(round(100 * a / b)), float(round(100 * (b - a) / b))}
    return sorted(v for v in _nombres_ligne(ligne) - dits if round(v, 1) not in calcules)
