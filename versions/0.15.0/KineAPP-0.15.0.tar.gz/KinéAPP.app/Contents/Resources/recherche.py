# -*- coding: utf-8 -*-
"""Recherche documentaire du chat : PubMed, texte intégral PMC, HAS et bibliothèque locale.

Confidentialité
  - Vers Internet ne partent que des termes cliniques génériques produits par le modèle
    local puis filtrés (lettres seulement, pas de chiffres, aucun mot du nom du dossier),
    ou des identifiants publics d'articles (PMID, PMCID). Jamais la question ni le bilan.
  - Sans terme exploitable, aucune recherche n'est lancée.
  - La bibliothèque locale, ses passages et leurs vecteurs ne quittent pas le Mac ; les
    embeddings sont calculés par le llama-server de l'app, qui n'écoute que sur 127.0.0.1.

Chaîne PubMed (mesurée sur 8 questions réelles, voir l'historique du projet)
  1. termes structurés (pathologie + synonymes, intervention + variantes, type de question) ;
  2. requêtes en « OU » par bloc, filtres de qualité adaptés au type, 2010+, humains ;
  3. 20 à 45 candidats, reclassés localement par embeddings (seuil relatif + niveau de
     preuve), BM25 si les embeddings sont indisponibles ;
  4. extraits : conclusions et résultats d'abord ; option texte intégral PMC.
"""
import array, datetime, json, math, os, re, signal, socket, sqlite3, subprocess, threading, time, unicodedata, zipfile
import urllib.parse, urllib.request
import xml.etree.ElementTree as ET

import modeles_llm as MLL
import moteurs_integres as MI
from concurrent.futures import ThreadPoolExecutor

DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
NCBI = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
BIOC = "https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_json/{}/unicode"
UA = {"User-Agent": "KineAPP/1.0"}


def _http(url, data=None, headers=None, timeout=30):
    req = urllib.request.Request(url, data=data, headers=headers or UA)
    return urllib.request.urlopen(req, timeout=timeout).read().decode("utf-8", "ignore")


# ════════════════════════════════════════════════════════════════════════════
# Embeddings locaux (llama-server, 127.0.0.1)
# ════════════════════════════════════════════════════════════════════════════
class Embeddings:
    """Vecteurs calculés en local par le llama-server de l'app, avec un modèle DÉDIÉ.

    Un modèle d'embedding de 0,6 Go place les formulations proches au même endroit de
    l'espace ; un modèle de conversation n'est pas entraîné pour cela et coûterait cent fois
    plus par extrait. Le serveur est lancé à la demande puis arrêté : il ne prend pas la
    mémoire du modèle de rédaction. Si le binaire ou le modèle manquent, l'appelant se
    replie sur la recherche plein texte (FTS5).
    """
    BINAIRE = MI.integre("llama")
    DOSSIERS = ("~/.cache/huggingface/hub", os.path.join(MLL.DOSSIER, "embedding"))
    # Par ordre de préférence. EmbeddingGemma 2 (17/10/2026) : sur 32 questions françaises de
    # kinésithérapie et 52 passages (anglais et français, dont 20 pièges proches), bon passage en
    # tête 31 fois sur 32 avec ses consignes, contre 28 pour bge-m3 ; 1,8 fois plus rapide,
    # 40 % de mémoire en moins.
    NOMS = ("embeddinggemma", "bge-m3", "nomic-embed", "multilingual-e5", "gte-")
    PIDF = os.path.join(DATA, "embeddings.pid")

    def __init__(self):
        self._port = 0
        self._verrou = threading.Lock()
        self.erreur = ""
        self.choisi = ""          # chemin imposé par les Paramètres ; sinon découverte

    # ── modèle et binaire ──────────────────────────────────────────────────
    def disponibles(self):
        """Tous les modèles d'embedding présents sur le disque, pour les Paramètres."""
        out, vus = [], set()
        for racine in (os.path.expanduser(d) for d in self.DOSSIERS):
            if not os.path.isdir(racine):
                continue
            for base, _, fichiers in os.walk(racine, followlinks=True):
                for f in sorted(fichiers):
                    if not f.endswith(".gguf") or not any(n in f.lower() for n in self.NOMS):
                        continue
                    p = os.path.join(base, f)
                    reel = os.path.realpath(p)
                    if reel in vus:
                        continue
                    vus.add(reel)
                    try: go = os.path.getsize(reel) / 1e9
                    except OSError: go = 0.0
                    out.append({"id": p, "nom": f[:-len(".gguf")], "taille": f"{go:.1f} GB"})
        return out

    def modele(self):
        """Celui choisi dans les Paramètres s'il existe encore, sinon le premier trouvé
        dans l'ordre de préférence des NOMS."""
        if self.choisi and os.path.isfile(os.path.realpath(self.choisi)):
            return self.choisi
        for motif in self.NOMS:
            for racine in (os.path.expanduser(d) for d in self.DOSSIERS):
                if not os.path.isdir(racine):
                    continue
                for base, _, fichiers in os.walk(racine, followlinks=True):
                    for f in sorted(fichiers):
                        if f.endswith(".gguf") and motif in f.lower():
                            return os.path.join(base, f)
        return ""

    def installe(self):
        return os.path.isfile(self.BINAIRE) and bool(self.modele())

    def identite(self):
        """Ce qui distingue les vecteurs d'un modèle de ceux d'un autre (nom du fichier)."""
        return os.path.basename(self.modele())

    def _prefixe(self, requete):
        """Consignes attendues par le modèle : EmbeddingGemma (sans elles : 25/32 au lieu de 31/32),
        nomic-embed et e5 ; bge-m3 n'en veut pas (il serait dégradé)."""
        nom = os.path.basename(self.modele()).lower()
        if "embeddinggemma" in nom:
            return "task: search result | query: " if requete else "title: none | text: "
        if "nomic" in nom:
            return "search_query: " if requete else "search_document: "
        if "e5" in nom:
            return "query: " if requete else "passage: "
        return ""

    # ── cycle de vie du serveur ────────────────────────────────────────────
    def _en_marche(self):
        if not self._port:
            return False
        try:
            _http(f"http://127.0.0.1:{self._port}/v1/models", timeout=3); return True
        except Exception:
            return False

    def assurer(self):
        """Démarre le serveur d'embeddings si besoin. False => repli plein texte."""
        if not os.path.isfile(self.BINAIRE):
            self.erreur = "llama-server n'est pas installé"
            return False
        modele = self.modele()
        if not modele:
            self.erreur = ("aucun modèle d'embedding sur le disque (attendu : un .gguf "
                           "nommé bge-m3, nomic-embed ou multilingual-e5)")
            return False
        with self._verrou:
            if self._en_marche():
                self.erreur = ""
                return True
            try:
                with socket.socket() as sock:
                    sock.bind(("127.0.0.1", 0))
                    port = sock.getsockname()[1]
                # Regroupement (pooling) lu dans le fichier du modèle : « cls » pour bge-m3, « mean »
                # pour EmbeddingGemma, nomic et e5 (imposer « cls » dégradait ces derniers).
                cmd = [self.BINAIRE, "--model", modele, "--embedding",
                       "--host", "127.0.0.1", "--port", str(port), "--no-webui",
                       "--gpu-layers", "999", "--ctx-size", "8192", "--ubatch-size", "2048"]
                pr = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self._port = port
                with open(self.PIDF, "w") as f:
                    f.write(str(pr.pid))
                t0 = time.time()
                while time.time() - t0 < 180:
                    if pr.poll() is not None:
                        self._port = 0
                        self.erreur = "le serveur d'embeddings s'est arrêté au démarrage"
                        return False
                    if self._en_marche():
                        self.erreur = ""
                        return True
                    time.sleep(1)
                self.arreter()
                self.erreur = "le serveur d'embeddings n'a pas répondu en 180 s"
                return False
            except Exception as e:
                self.erreur = str(e)
                return False

    def vecteurs(self, textes, requete=False, lot=32):
        """Vecteurs normalisés (cosinus)."""
        pre = self._prefixe(requete)
        out = []
        for i in range(0, len(textes), lot):
            body = json.dumps({"input": [pre + t[:2000] for t in textes[i:i + lot]]}).encode()
            d = json.loads(_http(f"http://127.0.0.1:{self._port}/v1/embeddings", body,
                                 {"Content-Type": "application/json"}, timeout=600))
            for x in d["data"]:
                v = x["embedding"]
                if v and isinstance(v[0], list):        # llama.cpp peut renvoyer [[...]]
                    v = v[0]
                n = math.sqrt(sum(a * a for a in v)) or 1.0
                out.append([a / n for a in v])
        return out

    def arreter(self):
        """Rend la mémoire dès que l'indexation est finie, et à la fermeture de l'app."""
        pid = None
        try:
            pid = int(open(self.PIDF).read().strip())
        except Exception:
            pid = None
        if pid:
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try:
                    cmd = subprocess.run(["ps", "-o", "command=", "-p", str(pid)],
                                         capture_output=True, text=True, timeout=10).stdout
                    if "llama-server" not in cmd:
                        break
                    os.kill(pid, sig)
                    time.sleep(1 if sig == signal.SIGTERM else 0.3)
                except (ProcessLookupError, subprocess.SubprocessError):
                    break
        self._port = 0
        try: os.remove(self.PIDF)
        except OSError: pass


EMB = Embeddings()


def _produit(u, v):
    return sum(a * b for a, b in zip(u, v))


# ════════════════════════════════════════════════════════════════════════════
# Termes de recherche (modèle local) et confidentialité
# ════════════════════════════════════════════════════════════════════════════
SYS_TERMES = """Tu prépares une recherche bibliographique pour un kinésithérapeute.
À partir de la question et des éléments cliniques du bilan, réponds en JSON :
{"type": "traitement" | "diagnostic" | "pronostic" | "prevention" | "autre",
 "condition": [terme principal anglais, puis 2 à 3 synonymes employés dans les titres d'articles],
 "mesh_condition": [0 à 2 descripteurs MeSH exacts],
 "intervention": [0 à 4 termes anglais : l'intervention, le test ou le facteur étudié, avec ses variantes
                  d'écriture ; vide si la question ne vise pas une intervention précise],
 "question_en": "la question clinique reformulée en une phrase anglaise générique",
 "mots_cles_fr": [2 à 5 mots-clés cliniques français : pathologie, intervention]}
Règles : termes cliniques génériques uniquement. JAMAIS de nom, d'initiale, d'âge chiffré, de date,
de lieu ni de profession. Aucun chiffre. Chaque terme fait 1 à 4 mots."""


def sections_utiles(bilan, n=1500):
    """Motif et diagnostic kiné : assez pour nommer la pathologie, lu vite par le modèle."""
    out, garde = [], False
    for l in (bilan or "").splitlines():
        if l.lstrip().startswith("#"):
            garde = bool(re.search(r"motif|diagnostic|probl[eè]me", l, re.I))
        if garde:
            out.append(l)
    texte = "\n".join(out).strip()
    if not texte:                          # bilan sans titres : tout sauf l'identité
        texte = "\n".join(l for l in (bilan or "").splitlines()
                          if not re.search(r"nom|prénom|né[e]? le|âge|adresse|téléphone|profession", l, re.I))
    return texte[:n]


_IDENTITE = re.compile(r"nom|pr[ée]nom|n[ée]e? le|naissance|[âa]ge|adresse|t[ée]l[ée]phone"
                       r"|courriel|mail|profession|employeur|entreprise|club|ville|commune"
                       r"|mutuelle|s[ée]curit[ée] sociale|num[ée]ro", re.I)
_BANALS = {"mme", "monsieur", "madame", "patient", "patiente", "ans", "the", "and",
           "profession", "adresse", "nom", "prenom", "prénom", "age", "âge", "ville",
           "club", "employeur", "entreprise", "naissance", "telephone", "téléphone",
           "commune", "courriel", "mail", "numero", "numéro", "mutuelle"}


def _interdits(nom_dossier, bilan=""):
    """Mots que l'on n'envoie jamais à un service extérieur : ceux du nom de dossier du
    patient et ceux des lignes d'identité du bilan (employeur, ville, club, profession…).
    Sans cela, un détail identifiant écrit dans la question pouvait partir vers PubMed."""
    mots = set(re.findall(r"[A-Za-zÀ-ÿ]{3,}", nom_dossier or ""))
    for ligne in (bilan or "").splitlines():
        if _IDENTITE.search(ligne):
            mots |= set(re.findall(r"[A-Za-zÀ-ÿ]{3,}", ligne))
    bas = {w.lower() for w in mots}
    return (bas | {_sans_accent(w) for w in bas}) - _BANALS


# Éponymes et échelles qui s'écrivent avec une majuscule dans une question et peuvent partir.
EPONYMES = {"osgood", "schlatter", "hoffa", "lasegue", "achille", "achilles", "sever", "sinding", "larsen", "dupuytren",
            "quervain", "hawkins", "neer", "jobe", "patte", "lachman", "mcmurray", "thessaly", "ober", "trendelenburg",
            "faber", "fadir", "apley", "cobb", "scheuermann", "perthes", "baker", "morton", "haglund", "kienbock",
            "colles", "bankart", "tinel", "phalen", "finkelstein", "spurling", "adson", "roos", "maigne", "kendall",
            "borg", "womac", "koos", "visa", "oswestry", "dash", "lysholm", "tegner", "constant", "ikdc", "berg",
            "tinetti", "nordic", "copenhagen", "parkinson", "alzheimer", "crohn", "paget", "sudeck", "raynaud",
            "guillain", "barre", "charcot", "volkmann", "galeazzi", "monteggia", "pouteau", "segond", "stener",
            "bennett", "rolando", "hill", "sachs", "lca", "lcp", "irm", "fifa", "ffr", "has", "pubmed", "cochrane"}


def _noms_propres(question):
    """Mots à majuscule au milieu d'une phrase de la question (pas après un point) : un nom de patient
    tapé dans la question ne part jamais, même si le serveur ne le connaît pas (mode coffre)."""
    out = set()
    for m in re.finditer(r"(?<![.!?:\n])\s+([A-ZÀ-Ý][A-Za-zÀ-ÿ'\-]{2,})", question or ""):
        mot = m.group(1).strip("-'")
        parties = [p for p in re.split(r"[-']", mot) if p]
        if any(_sans_accent(p).lower() not in EPONYMES for p in parties):
            out |= {mot.lower(), _sans_accent(mot).lower()} | {p.lower() for p in parties} | {_sans_accent(p).lower() for p in parties}
    return out - _BANALS


def _sans_accent(t):
    return "".join(c for c in unicodedata.normalize("NFD", t) if not unicodedata.combining(c))


CODE_PATIENT = re.compile(r"(?i)\bP-[23456789BCDFGHJKMNPQRSTVWXZ]{6}\b")     # code du coffre d'identité


def _propres(termes, interdits, francais=False):
    motif = r"[^A-Za-zÀ-ÿ\- ']" if francais else r"[^A-Za-z\- ']"
    out = []
    for t in termes or []:
        if CODE_PATIENT.search(str(t)):          # un code de patient ne part jamais, même pseudonyme
            continue
        # Hors français : on ÔTE les accents au lieu de les remplacer par une espace.
        # Sinon « Chambéry » devenait « chamb ry » et échappait aux mots interdits.
        t = str(t) if francais else _sans_accent(str(t))
        t = " ".join(re.sub(motif, " ", t).split()).strip(" -'").lower()
        if not t or len(t) < 3 or len(t.split()) > 4 or any(w in interdits for w in t.split()):
            continue
        if t not in out:
            out.append(t)
    return out


def termes(appel_json, question, bilan, nom_dossier):
    """appel_json(system, user) -> texte JSON du modèle local. Renvoie un dict nettoyé,
    ou None si aucun terme de pathologie exploitable (alors : pas de recherche)."""
    ctx = "QUESTION : " + question
    extrait = sections_utiles(bilan)
    if extrait:
        ctx += "\n\nÉLÉMENTS DU BILAN :\n" + extrait
    try:
        brut = appel_json(SYS_TERMES, ctx) or ""
        d = json.loads(brut[brut.find("{"):brut.rfind("}") + 1])
    except Exception:
        return None
    interdits = _interdits(nom_dossier, bilan) | _noms_propres(question)
    t = {"type": d.get("type") if d.get("type") in FILTRES else "autre",
         "condition": _propres(d.get("condition"), interdits),
         "mesh": _propres(d.get("mesh_condition"), interdits),
         "intervention": _propres(d.get("intervention"), interdits),
         "mots_cles_fr": _propres(d.get("mots_cles_fr"), interdits, francais=True)}
    q = " ".join(re.sub(r"[^A-Za-z\-' ,?]", " ", str(d.get("question_en") or "")).split())
    t["question_en"] = " ".join(w for w in q.split() if w.lower().strip(",?") not in interdits)
    return t if t["condition"] else None


# ════════════════════════════════════════════════════════════════════════════
# PubMed
# ════════════════════════════════════════════════════════════════════════════
FILTRES = {   # « Clinical Queries » de PubMed, version étroite
    "traitement": '(randomized controlled trial[pt] OR (randomized[tiab] AND controlled[tiab] AND trial[tiab]))',
    "prevention": '(randomized controlled trial[pt] OR (randomized[tiab] AND controlled[tiab] AND trial[tiab]))',
    "diagnostic": '(specificity[tiab] OR sensitivity[tiab] OR "diagnostic accuracy"[tiab])',
    "pronostic": '(prognos*[tiab] OR (first[tiab] AND episode[tiab]) OR cohort[tiab] OR "return to sport"[tiab])',
    "autre": "",
}
SYNTHESES = ('(systematic[sb] OR Meta-Analysis[pt] OR Guideline[pt] OR "Practice Guideline"[pt] '
             'OR guideline*[ti] OR "clinical practice guideline"[tiab])')
BORNES = ' AND ("2010"[dp] : "3000"[dp]) AND (english[la] OR french[la]) NOT (animals[mh] NOT humans[mh])'


class NCBI_:
    def __init__(self):
        self._dernier = 0.0
        self._verrou = threading.Lock()
        self.cle = ""

    def get(self, chemin, **params):
        with self._verrou:                   # 3 requêtes/s sans clé d'API, 10 avec
            attente = (0.11 if self.cle else 0.34) - (time.time() - self._dernier)
            if attente > 0:
                time.sleep(attente)
            self._dernier = time.time()
        if self.cle:
            params["api_key"] = self.cle
        return _http(f"{NCBI}/{chemin}?" + urllib.parse.urlencode(params))


NC = NCBI_()


def _esearch(term, retmax):
    d = json.loads(NC.get("esearch.fcgi", db="pubmed", retmode="json", sort="relevance",
                          retmax=retmax, term=term)).get("esearchresult", {})
    return d.get("idlist", []), int(d.get("count", 0) or 0)


def _efetch(ids):
    if not ids:
        return []
    root = ET.fromstring(NC.get("efetch.fcgi", db="pubmed", retmode="xml", id=",".join(ids)))
    arts = []
    for a in root.findall(".//PubmedArticle"):
        t = a.find(".//ArticleTitle")
        sections = [((ab.get("Label") or ab.get("NlmCategory") or "").upper(),
                     " ".join("".join(ab.itertext()).split()))
                    for ab in a.findall(".//Abstract/AbstractText")]
        pmid = a.findtext(".//PMID") or ""
        arts.append({
            "pmid": pmid,
            "titre": " ".join("".join(t.itertext()).split()) if t is not None else "",
            "sections": sections,
            "resume": " ".join((l + " : " if l else "") + x for l, x in sections),
            "types": [p.text for p in a.findall(".//PublicationType") if p.text],
            "annee": a.findtext(".//JournalIssue/PubDate/Year")
                     or (a.findtext(".//JournalIssue/PubDate/MedlineDate") or "")[:4],
            "revue": a.findtext(".//Journal/ISOAbbreviation") or a.findtext(".//Journal/Title") or "",
            "pmcid": next((x.text or "" for x in a.findall(".//ArticleId") if x.get("IdType") == "pmc"), ""),
            "url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"})
    ordre = {p: i for i, p in enumerate(ids)}
    return sorted(arts, key=lambda x: ordre.get(x["pmid"], 999))


def _bloc(liste, mesh=()):
    parts = [f'"{x}"[tiab]' for x in liste] + [f'"{m}"[mh]' for m in mesh]
    return "(" + " OR ".join(parts) + ")" if parts else ""


def pubmed_candidats(t, kind):
    """Du plus précis (pathologie ET intervention) au plus large ; 45 candidats au plus."""
    filtres = [SYNTHESES] if kind == "guidelines" else [f for f in (SYNTHESES, FILTRES[t["type"]]) if f]
    C, I = _bloc(t["condition"], t["mesh"]), _bloc(t["intervention"])
    pmids, precis, requetes = [], set(), []
    for base, niveau in ((" AND ".join(filter(None, (C, I))), 1), (C, 2)):
        if niveau == 2 and (not I or len(pmids) >= 15):
            continue
        for filtre in filtres:
            term = f"({base}) AND {filtre}{BORNES}"
            ids, total = _esearch(term, 20)
            requetes.append({"requete": term, "total": total})
            for i in ids:
                if i not in pmids:
                    pmids.append(i)
                    if niveau == 1 and I:
                        precis.add(i)
    if len(pmids) < 8:                                   # repli : sans filtre de qualité
        term = f"({C}){BORNES}"
        ids, total = _esearch(term, 20)
        requetes.append({"requete": term, "total": total})
        pmids += [i for i in ids if i not in pmids]
    arts = _efetch(pmids[:45])
    for a in arts:
        a["precis"] = a["pmid"] in precis
    return arts, requetes


def poids_preuve(a):
    types = " ".join(a.get("types") or []).lower()
    titre = a.get("titre", "").lower()
    if "guideline" in types or "guideline" in titre:
        p = 1.35
    elif "meta-analysis" in types or "systematic review" in types or "systematic review" in titre:
        p = 1.3
    elif "randomized controlled trial" in types:
        p = 1.15
    else:
        p = 1.0
    if not a.get("resume"):
        p *= 0.5
    try:
        if int(a.get("annee") or 0) >= 2018:
            p *= 1.1
    except ValueError:
        pass
    return p


def niveau_preuve(a):
    types = " ".join(a.get("types") or []).lower()
    titre = a.get("titre", "").lower()
    if "guideline" in types or "guideline" in titre:
        return "recommandation"
    if "meta-analysis" in types:
        return "méta-analyse"
    if "systematic review" in types or "systematic review" in titre:
        return "revue systématique"
    if "randomized controlled trial" in types:
        return "essai randomisé"
    if "review" in types:
        return "revue"
    return ""


def _tokens(t):
    return re.findall(r"[a-zà-ÿ][a-zà-ÿ\-]{2,}", (t or "").lower())


def bm25(docs_tokens, requete, k1=1.4, b=0.75):
    N = len(docs_tokens) or 1
    moy = (sum(map(len, docs_tokens)) / N) or 1
    q = set(requete)
    df = {w: sum(1 for d in docs_tokens if w in d) for w in q}
    scores = []
    for d in docs_tokens:
        s = 0.0
        for w in q:
            f = d.count(w)
            if f:
                s += math.log(1 + (N - df[w] + 0.5) / (df[w] + 0.5)) * f * (k1 + 1) / (f + k1 * (1 - b + b * len(d) / moy))
        scores.append(s)
    return scores


def classer_articles(t, arts, k=6):
    """Embeddings locaux + seuil relatif (écarte le hors-sujet) + niveau de preuve.
    Repli BM25 si les embeddings sont indisponibles."""
    if not arts:
        return [], "aucun"
    try:
        if not EMB.assurer():
            raise RuntimeError(EMB.erreur)
        v = EMB.vecteurs([t["question_en"] or " ".join(t["condition"] + t["intervention"])], requete=True)[0]
        docs = EMB.vecteurs([a["titre"] + ". " + a["resume"][:1500] for a in arts])
        for a, d in zip(arts, docs):
            a["pertinence"] = _produit(v, d)
        seuil, methode = max(a["pertinence"] for a in arts) - 0.06, "embeddings"
    except Exception:
        s = bm25([_tokens(a["titre"]) * 2 + _tokens(a["resume"]) for a in arts],
                 _tokens(" ".join(t["condition"] + t["intervention"] * 2 + [t["question_en"]])))
        haut = max(s) or 1.0
        for a, x in zip(arts, s):
            a["pertinence"] = x / haut
        seuil, methode = 0.6, "mots-clés"
    garde = [a for a in arts if a["pertinence"] >= seuil]
    bonus = lambda a: 1.1 if a.get("precis") else 1.0
    return sorted(garde, key=lambda a: -a["pertinence"] * poids_preuve(a) * bonus(a))[:k], methode


def extrait(a, n=1100):
    """Conclusions et résultats d'abord : ce que le modèle doit citer."""
    prio = lambda lab: min([v for k, v in (("CONCLU", 0), ("RESULT", 1), ("FINDING", 1), ("DISCUSS", 2))
                            if k in lab] or [5])
    secs = sorted(a.get("sections") or [], key=lambda s: prio(s[0]))
    return " ".join((l.title() + " : " if l else "") + x for l, x in secs)[:n] or a.get("resume", "")[:n]


# ── texte intégral (PMC, libre accès) ───────────────────────────────────────
def _paragraphes_pmc(pmcid):
    d = json.loads(_http(BIOC.format(pmcid), timeout=40))
    out = []
    for coll in (d if isinstance(d, list) else [d]):
        for doc in coll.get("documents", []):
            for p in doc.get("passages", []):
                inf = p.get("infons", {})
                sec = (inf.get("section_type") or "").upper()
                txt = " ".join((p.get("text") or "").split())
                if (inf.get("type") or "").lower().startswith("paragraph") and len(txt) > 200 \
                        and not sec.startswith(("REF", "ACK", "COMP_INT", "AUTH_CONT", "SUPPL", "FIG", "TABLE")):
                    out.append({"section": sec, "texte": txt})
    return out


def texte_integral(t, arts, par_article=2, total=6):
    """Paragraphes les plus proches de la question dans les articles en libre accès.
    Seul le PMCID part au NCBI. Nécessite les embeddings."""
    libres = [a for a in arts if a.get("pmcid")]
    if not libres or not EMB.assurer():
        return 0, len(libres)
    with ThreadPoolExecutor(max_workers=3) as ex:
        resultats = list(ex.map(lambda a: (a, _essai(_paragraphes_pmc, a["pmcid"])), libres))
    blocs = [(a, p) for a, ps in resultats for p in (ps or [])]
    if not blocs:
        return 0, len(libres)
    v = EMB.vecteurs([t["question_en"]], requete=True)[0]
    vecs = EMB.vecteurs([p["texte"] for _, p in blocs])
    notes = sorted(((_produit(v, x), a, p) for (a, p), x in zip(blocs, vecs)), key=lambda z: -z[0])
    compte, n = {}, 0
    for s, a, p in notes:
        if compte.get(a["pmid"], 0) >= par_article or n >= total:
            continue
        a.setdefault("passages", []).append({"section": p["section"], "texte": p["texte"][:1200]})
        compte[a["pmid"]] = compte.get(a["pmid"], 0) + 1
        n += 1
    return n, len(libres)


def _essai(f, *args):
    try:
        return f(*args)
    except Exception:
        return None


# ── HAS ──────────────────────────────────────────────────────────────────────
def has(t, k=3):
    """Recommandations HAS via DuckDuckGo : uniquement les mots-clés français filtrés."""
    mots = t.get("mots_cles_fr") or []
    if not mots:
        return []
    body = urllib.parse.urlencode({"q": "site:has-sante.fr recommandation " + " ".join(mots[:4])}).encode()
    try:
        html = _http("https://lite.duckduckgo.com/lite/", data=body,
                     headers={"User-Agent": "Mozilla/5.0", "Content-Type": "application/x-www-form-urlencoded"})
    except Exception:
        return []
    out = []
    for u, titre in re.findall(r'<a[^>]+href="(https?://[^"]+)"[^>]*>(.*?)</a>', html, re.S):
        titre = " ".join(re.sub("<[^>]+>", "", titre).split()).replace("&#x27;", "’")
        if "has-sante.fr" in u and titre and all(u != o["url"] for o in out):
            out.append({"titre": titre, "url": u})
        if len(out) >= k:
            break
    return out


# ════════════════════════════════════════════════════════════════════════════
# Bibliothèque locale
# ════════════════════════════════════════════════════════════════════════════
DOSSIERS = ["Formations", "Articles", "Revues narratives", "Autres"]
EXTENSIONS = (".pdf", ".docx", ".pptx", ".txt", ".md")
BASE = os.path.join(DATA, "bibliotheque.sqlite")
TAILLE, CHEVAUCHEMENT = 1100, 150

INDEX = {"en_cours": False, "message": "", "fait": 0, "total": 0, "fin": ""}
_VERROU_INDEX = threading.Lock()

JXA_PDF = ('ObjC.import("PDFKit"); function run(a){ var d=$.PDFDocument.alloc.initWithURL('
           '$.NSURL.fileURLWithPath(a[0])); if(!d) return "null"; var o=[]; '
           'for(var i=0;i<d.pageCount;i++){ var s=d.pageAtIndex(i).string; o.push(s? s.js : ""); } '
           'return JSON.stringify(o); }')


def creer_dossiers(racine):
    for d in DOSSIERS:
        os.makedirs(os.path.join(racine, d), exist_ok=True)


def _base():
    os.makedirs(DATA, exist_ok=True)
    c = sqlite3.connect(BASE, timeout=30)
    c.executescript("""
        CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY, chemin TEXT UNIQUE, dossier TEXT,
            titre TEXT, mtime REAL, taille INTEGER, pages INTEGER, etat TEXT, erreur TEXT, indexe_le TEXT);
        CREATE TABLE IF NOT EXISTS passages(id INTEGER PRIMARY KEY, doc_id INTEGER, rang INTEGER,
            page INTEGER, texte TEXT, vecteur BLOB);
        CREATE INDEX IF NOT EXISTS passages_doc ON passages(doc_id);
        CREATE VIRTUAL TABLE IF NOT EXISTS passages_fts USING fts5(texte, tokenize='unicode61 remove_diacritics 2');
        CREATE TABLE IF NOT EXISTS meta(cle TEXT PRIMARY KEY, valeur TEXT);
    """)
    return c


def modele_des_vecteurs(c):
    r = c.execute("SELECT valeur FROM meta WHERE cle='modele_vecteurs'").fetchone()
    return r[0] if r else None


def vecteurs_a_jour(c):
    """Les vecteurs gardés viennent-ils du modèle actuel ? Ceux d'un autre modèle ne se comparent
    pas (autre espace, autre dimension) : la recherche s'en passe jusqu'au recalcul."""
    m = modele_des_vecteurs(c)
    if m is None:            # avant le 17/10/2026 le modèle n'était pas noté : vecteurs d'origine inconnue
        return c.execute("SELECT 1 FROM passages WHERE vecteur IS NOT NULL LIMIT 1").fetchone() is None
    return m == EMB.identite()


def vecteurs_perimes():
    """Vecteurs de la bibliothèque calculés avec un autre modèle (ou un modèle inconnu)."""
    try:
        return EMB.installe() and not vecteurs_a_jour(_base())
    except Exception:
        return False


def _pages(chemin):
    """Texte par page (PDF) ou par diapositive (PPTX) ; un seul bloc sinon."""
    ext = os.path.splitext(chemin)[1].lower()
    if ext == ".pdf":
        r = subprocess.run(["osascript", "-l", "JavaScript", "-e", JXA_PDF, chemin],
                           capture_output=True, text=True, timeout=300)
        pages = json.loads(r.stdout or "null")
        if pages is None:
            raise ValueError("PDF illisible")
        return pages
    if ext == ".docx":
        with zipfile.ZipFile(chemin) as z:
            root = ET.fromstring(z.read("word/document.xml"))
        w = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
        return ["\n".join("".join(x.text or "" for x in p.iter(w + "t")) for p in root.iter(w + "p"))]
    if ext == ".pptx":
        with zipfile.ZipFile(chemin) as z:
            noms = sorted((n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                          key=lambda n: int(re.findall(r"\d+", n)[-1]))
            a = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
            return ["\n".join("".join(x.text or "" for x in p.iter(a + "t"))
                              for p in ET.fromstring(z.read(n)).iter(a + "p")) for n in noms]
    with open(chemin, encoding="utf-8", errors="ignore") as f:
        return [f.read()]


def _decouper(pages):
    """Passages d'environ 1 100 caractères, coupés en fin de phrase, avec chevauchement."""
    out = []
    for num, texte in enumerate(pages, 1):
        t = re.sub(r"-\n(?=[a-zà-ÿ])", "", texte or "")          # césures de fin de ligne
        t = " ".join(t.split())
        i = 0
        while i < len(t):
            fin = min(len(t), i + TAILLE)
            if fin < len(t):
                coupe = max(t.rfind(". ", i + TAILLE // 2, fin), t.rfind("; ", i + TAILLE // 2, fin))
                fin = coupe + 1 if coupe > 0 else fin
            morceau = t[i:fin].strip()
            if len(morceau) > 80:
                out.append((num, morceau))
            if fin >= len(t):
                break
            i = max(fin - CHEVAUCHEMENT, i + 1)
    return out


def indexer(racine, vecteurs=True):
    """Indexation incrémentale : nouveaux fichiers, modifiés, supprimés ; puis vecteurs
    manquants (si les embeddings sont disponibles). Une seule indexation à la fois."""
    if not _VERROU_INDEX.acquire(blocking=False):
        return
    try:
        INDEX.update(en_cours=True, message="Recherche des fichiers…", fait=0, total=0)
        creer_dossiers(racine)
        fichiers = {}
        for d in DOSSIERS:
            for base, _, noms in os.walk(os.path.join(racine, d)):
                for n in noms:
                    if n.lower().endswith(EXTENSIONS) and not n.startswith((".", "~$")):
                        p = os.path.join(base, n)
                        fichiers[p] = (d, os.stat(p))
        c = _base()
        connus = {r[0]: (r[1], r[2], r[3]) for r in c.execute("SELECT chemin, id, mtime, taille FROM documents")}
        for chemin, (doc_id, _, _) in connus.items():
            if chemin not in fichiers:
                _supprimer_doc(c, doc_id)
        a_faire = [p for p, (_, st) in fichiers.items()
                   if p not in connus or connus[p][1] != st.st_mtime or connus[p][2] != st.st_size]
        INDEX.update(total=len(a_faire))
        for n, chemin in enumerate(a_faire, 1):
            dossier, st = fichiers[chemin]
            INDEX.update(fait=n - 1, message=f"Lecture de {os.path.basename(chemin)}")
            if chemin in connus:
                _supprimer_doc(c, connus[chemin][0])
            titre = os.path.splitext(os.path.basename(chemin))[0]
            try:
                pages = _pages(chemin)
                morceaux = _decouper(pages)
                etat, erreur = ("indexé", "") if morceaux else ("vide", "aucun texte (PDF scanné ?)")
            except Exception as e:
                pages, morceaux, etat, erreur = [], [], "erreur", str(e)[:200]
            cur = c.execute("INSERT INTO documents(chemin, dossier, titre, mtime, taille, pages, etat, erreur, "
                            "indexe_le) VALUES(?,?,?,?,?,?,?,?,?)",
                            (chemin, dossier, titre, st.st_mtime, st.st_size, len(pages), etat, erreur,
                             datetime.datetime.now().strftime("%d/%m/%Y %H:%M")))
            for rang, (page, texte) in enumerate(morceaux):
                pid = c.execute("INSERT INTO passages(doc_id, rang, page, texte) VALUES(?,?,?,?)",
                                (cur.lastrowid, rang, page, texte)).lastrowid
                c.execute("INSERT INTO passages_fts(rowid, texte) VALUES(?,?)", (pid, texte))
            c.commit()
        if vecteurs:
            if EMB.installe() and not vecteurs_a_jour(c):
                c.execute("UPDATE passages SET vecteur=NULL")          # modèle changé : tout recalculer
                c.commit()
            if EMB.installe():
                c.execute("INSERT OR REPLACE INTO meta(cle, valeur) VALUES('modele_vecteurs', ?)", (EMB.identite(),))
                c.commit()
            manquants = c.execute("SELECT id, texte FROM passages WHERE vecteur IS NULL").fetchall()
            if manquants:
                if EMB.assurer():
                    INDEX.update(total=len(manquants), fait=0)
                    for i in range(0, len(manquants), 96):
                        lot = manquants[i:i + 96]
                        INDEX.update(fait=i, message=f"Calcul des vecteurs : {i} / {len(manquants)} passages")
                        for (pid, _), v in zip(lot, EMB.vecteurs([t for _, t in lot])):
                            c.execute("UPDATE passages SET vecteur=? WHERE id=?",
                                      (array.array("f", v).tobytes(), pid))
                        c.commit()
                    EMB.arreter()         # mémoire rendue dès la fin de l'indexation
                else:
                    INDEX["message"] = "Vecteurs non calculés : " + EMB.erreur
        c.close()
        INDEX.update(fin=datetime.datetime.now().strftime("%d/%m/%Y %H:%M"),
                     message="" if not INDEX["message"].startswith("Vecteurs non") else INDEX["message"])
    except Exception as e:
        INDEX["message"] = f"Erreur d'indexation : {e}"
    finally:
        INDEX["en_cours"] = False
        _VERROU_INDEX.release()


def _supprimer_doc(c, doc_id):
    for (pid,) in c.execute("SELECT id FROM passages WHERE doc_id=?", (doc_id,)).fetchall():
        c.execute("DELETE FROM passages_fts WHERE rowid=?", (pid,))
    c.execute("DELETE FROM passages WHERE doc_id=?", (doc_id,))
    c.execute("DELETE FROM documents WHERE id=?", (doc_id,))
    c.commit()


def etat_bibliotheque(racine):
    c = _base()
    par = {d: {"documents": 0, "passages": 0, "erreurs": 0} for d in DOSSIERS}
    for dossier, nd, err in c.execute("SELECT dossier, COUNT(*), SUM(etat != 'indexé') FROM documents GROUP BY dossier"):
        if dossier in par:
            par[dossier].update(documents=nd, erreurs=err or 0)
    for dossier, np_ in c.execute("SELECT d.dossier, COUNT(*) FROM passages p JOIN documents d ON d.id=p.doc_id "
                                  "GROUP BY d.dossier"):
        if dossier in par:
            par[dossier]["passages"] = np_
    sans_vecteur = c.execute("SELECT COUNT(*) FROM passages WHERE vecteur IS NULL").fetchone()[0]
    problemes = [{"titre": t, "dossier": d, "erreur": e} for t, d, e in
                 c.execute("SELECT titre, dossier, erreur FROM documents WHERE etat != 'indexé' LIMIT 20")]
    c.close()
    return {"racine": racine, "dossiers": par, "sans_vecteur": sans_vecteur, "problemes": problemes,
            "index": dict(INDEX), "embeddings": EMB.installe()}


def chemin_document(doc_id):
    c = _base()
    r = c.execute("SELECT chemin FROM documents WHERE id=?", (int(doc_id),)).fetchone()
    c.close()
    return r[0] if r else None


def chercher_bibliotheque(question, t, k=5, par_document=2):
    """Hybride : plein texte (FTS5, français et anglais) + embeddings (question française et
    anglaise), fusion par rangs réciproques, seuil relatif. Tout est local."""
    c = _base()
    if not c.execute("SELECT 1 FROM passages LIMIT 1").fetchone():
        c.close()
        return []
    mots = set()
    for x in (t or {}).get("mots_cles_fr", []) + (t or {}).get("condition", []) + (t or {}).get("intervention", []):
        mots.update(w for w in re.findall(r"[A-Za-zÀ-ÿ]{4,}", x))
    mots.update(w for w in re.findall(r"[A-Za-zÀ-ÿ]{5,}", question))
    rangs_fts = {}
    if mots:
        req = " OR ".join('"' + w.replace('"', "") + '"' for w in sorted(mots))
        try:
            for r, (pid,) in enumerate(c.execute(
                    "SELECT rowid FROM passages_fts WHERE passages_fts MATCH ? ORDER BY bm25(passages_fts) LIMIT 60",
                    (req,))):
                rangs_fts[pid] = r
        except sqlite3.OperationalError:
            pass
    sims = {}
    if vecteurs_a_jour(c) and EMB.assurer():
        # nomic-embed discrimine mal en français (un guide informatique y score presque comme une
        # formation sur le coude) : la question anglaise, quand elle existe, sert seule.
        requetes = [t["question_en"]] if t and t.get("question_en") else [question]
        vq = EMB.vecteurs(requetes, requete=True)
        for pid, blob in c.execute("SELECT id, vecteur FROM passages WHERE vecteur IS NOT NULL"):
            v = array.array("f")
            v.frombytes(blob)
            sims[pid] = max(_produit(q, v) for q in vq)
    rangs_emb = {pid: r for r, pid in enumerate(sorted(sims, key=lambda p: -sims[p])[:60])}
    fusion = {}
    for rangs in (rangs_fts, rangs_emb):
        for pid, r in rangs.items():
            fusion[pid] = fusion.get(pid, 0) + 1 / (60 + r)
    if sims:
        haut = max(sims.values())
        fusion = {p: s for p, s in fusion.items() if sims.get(p, 0) >= haut - 0.08}
    choisis, compte = [], {}
    for pid in sorted(fusion, key=lambda p: -fusion[p]):
        row = c.execute("SELECT p.texte, p.page, d.id, d.titre, d.dossier, d.chemin FROM passages p "
                        "JOIN documents d ON d.id=p.doc_id WHERE p.id=?", (pid,)).fetchone()
        if not row or compte.get(row[2], 0) >= par_document:
            continue
        compte[row[2]] = compte.get(row[2], 0) + 1
        choisis.append({"texte": row[0], "page": row[1], "doc_id": row[2], "titre": row[3],
                        "dossier": row[4], "pdf": row[5].lower().endswith(".pdf")})
        if len(choisis) >= k:
            break
    c.close()
    return choisis


# ════════════════════════════════════════════════════════════════════════════
# Sources numérotées pour le modèle, citations vérifiées
# ════════════════════════════════════════════════════════════════════════════
def sources_numerotees(articles=(), recos_has=(), passages_biblio=()):
    """(texte pour le modèle, liste pour l'interface). Une référence par article ou document."""
    lignes, liste, n = [], [], 0
    for a in articles:
        n += 1
        niv = niveau_preuve(a)
        bloc = f"[{n}] {a['titre']} — {a['revue']}, {a['annee']}" + (f" ({niv})" if niv else "") + f". PMID {a['pmid']}."
        bloc += "\nRésumé (conclusions et résultats) : " + extrait(a)
        for p in a.get("passages") or []:
            bloc += f"\nTexte intégral ({p['section'].lower() or 'extrait'}) : {p['texte']}"
        lignes.append(bloc)
        liste.append({"num": n, "type": "pubmed", "titre": a["titre"], "url": a["url"], "annee": a["annee"],
                      "revue": a["revue"], "niveau": niv, "pmc": a.get("pmcid") or "",
                      "texte_integral": bool(a.get("passages"))})
    for h in recos_has:
        n += 1
        lignes.append(f"[{n}] Recommandation HAS : {h['titre']} (seul le titre est disponible)")
        liste.append({"num": n, "type": "has", "titre": h["titre"], "url": h["url"]})
    par_doc = {}
    for p in passages_biblio:
        par_doc.setdefault(p["doc_id"], []).append(p)
    for doc_id, ps in par_doc.items():
        n += 1
        bloc = f"[{n}] Bibliothèque personnelle ({ps[0]['dossier']}) : {ps[0]['titre']}"
        for p in ps:
            bloc += f"\nExtrait p. {p['page']} : {p['texte']}"
        lignes.append(bloc)
        liste.append({"num": n, "type": "bibliotheque", "titre": ps[0]["titre"], "dossier": ps[0]["dossier"],
                      "doc_id": doc_id, "pages": sorted({p["page"] for p in ps})})
    return "\n\n".join(lignes), liste


CONSIGNE_CITATIONS = (
    "Appuie-toi sur ces sources. Après chaque information qui en provient, indique son numéro entre "
    "crochets, par exemple [2] ou [1][3]. N'utilise que les numéros de la liste, n'invente aucune "
    "référence ni aucun chiffre absent des extraits. Signale quand les sources ne répondent pas à la "
    "question, et distingue ce qui vient des sources de ce qui relève de ton raisonnement clinique.")


def verifier_citations(reponse, nb_sources):
    cites = {int(x) for x in re.findall(r"\[(\d{1,3})\]", reponse or "")}
    return {"citees": sorted(x for x in cites if 1 <= x <= nb_sources),
            "inexistantes": sorted(x for x in cites if not 1 <= x <= nb_sources)}
