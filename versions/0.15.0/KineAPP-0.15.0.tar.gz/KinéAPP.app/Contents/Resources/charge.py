# -*- coding: utf-8 -*-
"""Gestion de charge d'un patient : séances structurées, charge globale, charge par exercice,
programme par phases.

- Séance structurée (champ « charge » d'une séance de patients.py) : durée (min), exercices
  {nom, series, repetitions, charge_kg, duree_s, distance_m, cote, rpe, douleur, remarque}.
  Proposée par le modèle à partir de la dictée (prompts/09_charge_seance_system.md), puis
  CONTRÔLÉE ici : un nombre absent de la transcription est retiré (jamais de chiffre inventé).
- Charge de séance = RPE de la séance × durée en minutes (méthode « session-RPE », Foster 2001),
  charge hebdomadaire et variation d'une semaine à l'autre (repère : hausse marquée au-delà de
  30 %, à interpréter).
- Programme : un protocole de protocoles/ (phases, objectifs, critères de passage, consignes de
  charge), la date de début et la phase retenue par le praticien ; les semaines ne sont qu'un
  repère, la progression se fait sur critères.
"""
import datetime, json, os, re, unicodedata

ICI = os.path.dirname(os.path.abspath(__file__))
PROTOCOLES = os.path.join(ICI, "protocoles")
CHAMPS_EXO = ("nom", "series", "repetitions", "charge_kg", "duree_s", "distance_m", "cote", "rpe", "douleur", "remarque")
BORNES = {"series": (1, 50), "repetitions": (1, 500), "charge_kg": (0, 500), "duree_s": (1, 14400), "distance_m": (1, 100000),
          "rpe": (0, 10), "douleur": (0, 10)}
HAUSSE_MARQUEE = 30          # % d'une semaine à l'autre


# ── protocoles ───────────────────────────────────────────────────────────────
_CACHE = {}


def protocoles():
    if not _CACHE:
        for f in sorted(os.listdir(PROTOCOLES)) if os.path.isdir(PROTOCOLES) else []:
            if f.endswith(".json"):
                p = json.load(open(os.path.join(PROTOCOLES, f), encoding="utf-8"))
                _CACHE[p["id"]] = p
    return _CACHE


def resume_protocoles():
    return [{"id": p["id"], "nom": p["nom"], "court": p.get("court") or p["nom"], "region": p.get("region", "Autres"),
             "pathologie": p.get("pathologie", ""), "debut": p.get("debut", ""), "questionnaires": p.get("questionnaires", [])}
            for p in protocoles().values()]


def _date(txt):
    try:
        return datetime.datetime.strptime(str(txt or ""), "%d/%m/%Y").date()
    except ValueError:
        return None


def programme_valide(brut):
    """{protocole, debut (JJ/MM/AAAA), phase (id), criteres: {phase: [ids]}, notes} contrôlé."""
    b = brut if isinstance(brut, dict) else {}
    pid = str(b.get("protocole") or "")
    if pid and pid not in protocoles():
        raise ValueError("Protocole inconnu.")
    debut = str(b.get("debut") or "").strip()
    if debut and not _date(debut):
        raise ValueError("Date de début attendue au format jj/mm/aaaa.")
    p = protocoles().get(pid) or {}
    ids_phases = {ph["id"]: {c["id"] for c in ph.get("criteres", [])} for ph in p.get("phases", [])}
    phase = str(b.get("phase") or "")
    if phase and phase not in ids_phases:
        raise ValueError("Phase inconnue.")
    criteres = {}
    for ph, l in (b.get("criteres") or {}).items():
        if ph in ids_phases and isinstance(l, list):
            criteres[ph] = sorted({str(x) for x in l} & ids_phases[ph])
    return {"protocole": pid, "debut": debut, "phase": phase, "criteres": criteres, "notes": str(b.get("notes") or "")[:4000]}


def etiquette_programme(prog, aujourdhui=None):
    """Repère court pour la liste des patients : « LCA · phase 2/5 · S7 » (None sans protocole)."""
    e = etat_programme(prog, aujourdhui)
    if not e:
        return None
    ids = [ph["id"] for ph in e["protocole"]["phases"]]
    return {"court": e["protocole"].get("court") or e["protocole"]["nom"], "phase": ids.index(e["phase"]) + 1,
            "phases": len(ids), "semaines": e["semaines"]}


def etat_programme(prog, aujourdhui=None):
    """Protocole, semaines écoulées, phase indicative (d'après le délai) et phase retenue."""
    if not prog or not prog.get("protocole") or prog["protocole"] not in protocoles():
        return None
    p = protocoles()[prog["protocole"]]
    debut = _date(prog.get("debut"))
    semaines = None
    indicative = ""
    if debut:
        semaines = max(0, ((aujourdhui or datetime.date.today()) - debut).days) / 7
        for ph in p["phases"]:
            if semaines >= ph["semaines"][0]:
                indicative = ph["id"]
    retenue = prog.get("phase") or indicative or p["phases"][0]["id"]
    return {"protocole": p, "semaines": None if semaines is None else round(semaines, 1),
            "phase_indicative": indicative, "phase": retenue, "criteres": prog.get("criteres") or {},
            "notes": prog.get("notes", "")}


# ── séances structurées ──────────────────────────────────────────────────────
UNITES = ["zéro", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "douze", "treize",
          "quatorze", "quinze", "seize"]
DIZAINES = {20: "vingt", 30: "trente", 40: "quarante", 50: "cinquante", 60: "soixante"}
# Nombres approximatifs dictés (« une quinzaine de répétitions ») : le modèle les relève à la valeur ronde.
APPROX = {10: "dizaine", 12: "douzaine", 15: "quinzaine", 20: "vingtaine", 30: "trentaine", 40: "quarantaine",
          50: "cinquantaine", 100: "centaine"}


def _plat(t):
    t = unicodedata.normalize("NFD", t or "")
    return "".join(c for c in t if unicodedata.category(c) != "Mn").lower()


def en_lettres(n):
    """0 à 100 en lettres (« vingt-deux », « soixante-quinze ») : Whisper écrit parfois les nombres."""
    if n < 17:
        return [UNITES[n]]
    if n < 20:
        return ["dix-" + UNITES[n - 10], "dix " + UNITES[n - 10]]
    if n == 100:
        return ["cent"]
    if n < 70:
        d, u = n // 10 * 10, n % 10
        base = DIZAINES[d]
        if u == 0:
            return [base]
        if u == 1:
            return [base + " et un", base + "-et-un"]
        return [base + "-" + UNITES[u], base + " " + UNITES[u]]
    if n < 80:
        r = n - 60
        return [f"soixante-{x}" for x in en_lettres(r)] + [f"soixante {x}" for x in en_lettres(r)] + (["soixante et onze"] if n == 71 else [])
    r = n - 80
    if r == 0:
        return ["quatre-vingts", "quatre-vingt"]
    return [f"quatre-vingt-{x}" for x in en_lettres(r)] + [f"quatre-vingt {x}" for x in en_lettres(r)]


def present(valeur, texte):
    """Le nombre figure-t-il dans la transcription (en chiffres, avec virgule ou en lettres) ?"""
    if valeur is None:
        return True
    t = _plat(texte)
    v = float(valeur)
    formes = set()
    if v.is_integer():
        formes.add(str(int(v)))
        if 0 <= v <= 100:
            formes.update(_plat(x) for x in en_lettres(int(v)))
        if v == 1:
            formes.add("une")
        if int(v) in APPROX:
            formes.add(APPROX[int(v)])
    else:
        formes.update({str(v), str(v).replace(".", ",")})
        if (v * 2).is_integer() and v < 100:              # « 2 et demi », « deux et demi »
            formes.update({f"{int(v)} et demi"} | {_plat(x) + " et demi" for x in en_lettres(int(v))})
    for f in filter(None, formes):
        if re.search(r"(?<![\w,.])" + re.escape(f) + r"(?![\w]|[,.]\d)", t):
            return True
    return False


def _nombre(v):
    if v in (None, "") or isinstance(v, bool):
        return None
    try:
        return float(str(v).replace(",", ".").strip())
    except ValueError:
        return None


def seance_valide(brut, transcription=None):
    """Séance structurée proposée par le modèle (ou saisie) -> séance contrôlée.
    Avec la transcription, tout nombre qui n'y figure pas est retiré et signalé."""
    b = brut if isinstance(brut, dict) else {}
    retires = []

    def nombre(champ, v, ou):
        x = _nombre(v)
        if x is None:
            return None
        lo, hi = BORNES.get(champ, (0, 100000))
        if not lo <= x <= hi:
            retires.append(f"{ou} : {champ} hors limites ({v})")
            return None
        # Durées et distances peuvent être converties (« 2 minutes » -> 120 s) : vérifiées sous leur forme dite.
        if transcription is not None and champ not in ("duree_s", "distance_m"):
            if not present(x, transcription):
                retires.append(f"{ou} : {champ} {v} absent de la dictée")
                return None
        return int(x) if x.is_integer() else round(x, 2)

    out = {"exercices": []}
    d = _nombre(b.get("duree_min"))
    if d is not None:
        heures = d % 60 == 0 and transcription is not None and present(d / 60, transcription) and "heure" in _plat(transcription)
        if not 1 <= d <= 600:
            retires.append(f"séance : durée hors limites ({b.get('duree_min')})")
        elif transcription is not None and not (present(d, transcription) or heures):
            retires.append(f"séance : durée {b.get('duree_min')} min absente de la dictée")
        else:
            out["duree_min"] = int(d) if d.is_integer() else round(d, 1)
    for e in (b.get("exercices") or [])[:60]:
        if not isinstance(e, dict):
            continue
        nom = " ".join(str(e.get("nom") or "").split())[:120]
        if not nom:
            continue
        x = {"nom": nom}
        # Exercice dont aucun mot ne figure dans la dictée : gardé, mais signalé (nom reformulé, ou inventé).
        if transcription is not None:
            mots = [m for m in re.findall(r"[a-z]{4,}", _plat(nom))]
            if mots and not any(m[:5] in _plat(transcription) for m in mots):
                x["a_verifier"] = True
                retires.append(f"{nom} : exercice non retrouvé tel quel dans la dictée")
        for k in ("series", "repetitions", "charge_kg", "duree_s", "distance_m", "rpe", "douleur"):
            v = nombre(k, e.get(k), nom)
            if v is not None:
                x[k] = v
        cote = str(e.get("cote") or "").strip().upper()[:1]
        if cote in ("D", "G", "B"):
            x["cote"] = cote
        if e.get("remarque"):
            x["remarque"] = " ".join(str(e["remarque"]).split())[:200]
        out["exercices"].append(x)
    out["retires"] = retires
    return out


def libelle_exercice(e):
    """« 3 × 10 · 20 kg », « 4 × 45 s », « 2 km » (lecture du tableau)."""
    parts = []
    if e.get("series") and e.get("repetitions"):
        parts.append(f"{e['series']} × {e['repetitions']}")
    elif e.get("series") and e.get("duree_s"):
        parts.append(f"{e['series']} × {_duree(e['duree_s'])}")
    elif e.get("repetitions"):
        parts.append(f"{e['repetitions']} rép.")
    elif e.get("duree_s"):
        parts.append(_duree(e["duree_s"]))
    if e.get("charge_kg") is not None:
        parts.append(f"{_num(e['charge_kg'])} kg")
    if e.get("distance_m"):
        parts.append(f"{_num(e['distance_m'] / 1000)} km" if e["distance_m"] >= 1000 else f"{_num(e['distance_m'])} m")
    if e.get("cote"):
        parts.append({"D": "droite", "G": "gauche", "B": "bilatéral"}[e["cote"]])
    if e.get("rpe") is not None:
        parts.append(f"RPE {_num(e['rpe'])}")
    if e.get("douleur") is not None:
        parts.append(f"douleur {_num(e['douleur'])}/10")
    return " · ".join(parts) or (e.get("remarque") or "fait")


def _num(v):
    return str(int(v) if float(v).is_integer() else round(v, 1)).replace(".", ",")


def _duree(s):
    s = int(s)
    return f"{s // 60} min" + (f" {s % 60} s" if s % 60 else "") if s >= 60 else f"{s} s"


def cle_exercice(nom):
    return re.sub(r"[^a-z0-9]+", " ", _plat(nom)).strip()


def tonnage(e):
    if e.get("series") and e.get("repetitions") and e.get("charge_kg"):
        return e["series"] * e["repetitions"] * e["charge_kg"]
    return None


# ── tableau de gestion de charge ─────────────────────────────────────────────
def tableau(seances, max_colonnes=10):
    """Charge globale (par séance et par semaine) et charge par exercice, du plus ancien au plus récent."""
    lignes = []
    for s in seances:
        d = _date(s.get("date"))
        if not d:
            continue
        c = s.get("charge") or {}
        duree = c.get("duree_min")
        rpe = s.get("rpe")
        lignes.append({"id": s.get("id"), "date": s["date"], "jour": d, "duree_min": duree, "rpe": rpe,
                       "srpe": round(rpe * duree) if rpe is not None and duree else None,
                       "eva_max": s.get("eva_max"), "eva_moy": s.get("eva_moy"), "eva_reveil": s.get("eva_reveil"),
                       "a_relire": s.get("etat") == "a_relire",
                       "exercices": c.get("exercices") or []})
    lignes.sort(key=lambda x: x["jour"])
    semaines = {}
    for l in lignes:
        lundi = l["jour"] - datetime.timedelta(days=l["jour"].weekday())
        w = semaines.setdefault(lundi, {"debut": lundi.strftime("%d/%m/%Y"), "seances": 0, "charge": 0, "mesuree": 0})
        w["seances"] += 1
        if l["srpe"] is not None:
            w["charge"] += l["srpe"]
            w["mesuree"] += 1
    sem = [semaines[k] for k in sorted(semaines)]
    for i, w in enumerate(sem):
        prec = sem[i - 1] if i else None
        if prec and prec["charge"] and w["mesuree"]:
            w["variation_pct"] = round((w["charge"] - prec["charge"]) * 100 / prec["charge"])
            w["hausse_marquee"] = w["variation_pct"] > HAUSSE_MARQUEE
    # Semaines contiguës (une semaine sans séance compte 0), et moyenne des 4 semaines d'avant : la charge
    # de la semaine se lit par rapport à l'habitude récente (comme les tableaux de charge des préparateurs),
    # sans ratio aigu/chronique, trop discuté pour décider seul.
    hebdo = []
    if semaines:
        lundi, fin = min(semaines), max(semaines)
        while lundi <= fin:
            w = semaines.get(lundi) or {"debut": lundi.strftime("%d/%m/%Y"), "seances": 0, "charge": 0, "mesuree": 0}
            avant = [x["charge"] for x in hebdo[-4:]]
            prec = hebdo[-1]["charge"] if hebdo else 0
            variation = round((w["charge"] - prec) * 100 / prec) if prec and w["mesuree"] else None
            hebdo.append({"debut": w["debut"], "seances": w["seances"], "charge": w["charge"], "mesuree": w["mesuree"],
                          "moyenne_4": round(sum(avant) / len(avant)) if avant else None, "variation_pct": variation,
                          "hausse_marquee": variation is not None and variation > HAUSSE_MARQUEE})
            lundi += datetime.timedelta(days=7)
    # Exercices : une ligne par exercice (nom normalisé), une colonne par séance où il apparaît.
    cols = [l for l in lignes if l["exercices"]][-max_colonnes:]
    exos = {}
    for l in cols:
        for e in l["exercices"]:
            k = cle_exercice(e["nom"])
            x = exos.setdefault(k, {"nom": e["nom"], "cellules": {}, "tonnages": [], "points": []})
            x["nom"] = e["nom"]
            x["cellules"][l["id"]] = libelle_exercice(e)
            x["dernier"] = libelle_exercice(e)
            x["points"].append({"date": l["date"], "kg": e.get("charge_kg"), "tonnage": tonnage(e),
                                "volume": (e.get("series") or 1) * (e.get("repetitions") or 0) or e.get("duree_s")})
            t = tonnage(e)
            if t:
                x["tonnages"].append((l["date"], t))
    for x in exos.values():
        t = x.pop("tonnages")
        if len(t) >= 2 and t[0][1]:
            x["evolution_pct"] = round((t[-1][1] - t[0][1]) * 100 / t[0][1])
        if t:
            x["tonnage_dernier"] = t[-1][1]
    for l in lignes:
        l.pop("jour")
    return {"seances": lignes, "semaines": sem, "hebdo": hebdo, "colonnes": [{"id": l["id"], "date": l["date"]} for l in cols],
            "exercices": sorted(exos.values(), key=lambda x: _plat(x["nom"]))}


def texte_charge(seance):
    """Résumé d'une séance structurée pour les comptes rendus (exercices et charges)."""
    c = seance.get("charge") or {}
    l = [f"- {e['nom']} : {libelle_exercice(e)}" for e in c.get("exercices") or []]
    if c.get("duree_min"):
        l.insert(0, f"- Durée de la séance : {_num(c['duree_min'])} min")
    return "\n".join(l)
