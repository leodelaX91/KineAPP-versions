# -*- coding: utf-8 -*-
"""Les trois modes de rédaction de l'app et leurs modèles, téléchargeables depuis Paramètres → IA.

Fichiers publics sur Hugging Face, à une version figée (commit), vérifiés par leur empreinte
SHA-256 avant usage : aucune donnée patient ne sort. Téléchargement avec reprise, espace disque
contrôlé avant de commencer. Rien n'est retiré sans demande : un modèle retiré va à la Corbeille.
Un fichier déjà présent dans le cache Hugging Face du Mac est reconnu à son nom et à sa taille :
inutile de le télécharger une seconde fois, et il n'est jamais déplacé ni retiré.

Chaque mode a son modèle et son « brouillon » DFlash2 (décodage spéculatif de Splash).
"""
import glob, hashlib, os, shutil, subprocess, threading, time, urllib.request

import materiel as MAT

DATA = os.path.expanduser(os.environ.get("KINEAPP_DATA") or "~/Library/Application Support/BilanKine")
DOSSIER = os.path.join(DATA, "modeles_ia")
CACHE_HF = os.path.expanduser(os.environ.get("KINEAPP_CACHE_HF") or "~/.cache/huggingface/hub")
BASE_URL = "https://huggingface.co/"


def _f(depot, commit, chemin, taille, sha256):
    return {"depot": depot, "commit": commit, "chemin": chemin, "taille": taille, "sha256": sha256}


_B35 = ("incoai/Qwen3.6-35B-A3B-DFlash2", "51ef7b6923ad6c14cb1bb41c37a9041446496ab6")
_B27 = ("incoai/Qwen3.8-27B-DFlash2", "015e795645c74b1a0eeef3b570031fb62e769bc5")
_BFN = ("incoai/Qwen3.8-Flash-Next-DFlash2", "a22a1744e85c17364dcc54a6a420af7135d4c7f6")
_FN = ("ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-GGUF", "ed59f92082b1e93c0e96d60a8b11aab089b52f09")
# ram_min : mémoire en dessous de laquelle le mode n'est pas proposé. llama : le modèle peut aussi
# tourner sous llama.cpp, le moteur de secours (la table du Flash-Next demande Splash).
CATALOGUE = {
    "rapide": {
        "titre": "Mode rapide", "modele_nom": "Qwen3.6 35B-A3B · IQ3_S (Unsloth)", "ram_min": 16, "llama": True,
        "duree_min": 2.3, "note": "Le plus rapide. Point faible : les côtés (droite, gauche), à relire avec soin.",
        "modele": [_f("unsloth/Qwen3.6-35B-A3B-GGUF", "a483e9e6cbd595906af30beda3187c2663a1118c",
                      "Qwen3.6-35B-A3B-UD-IQ3_S.gguf", 13676723168,
                      "66a3ca888ce13482b40c333db2432c0ebde3a7b13754fc29f0c6f5e89703ec66")],
        "brouillon": [_f(*_B35, "config.json", 1291, "86d2e8e57e7c70bb867240708d00c0535ae9ed3c828dbdcb21584471c7bbce59"),
                      _f(*_B35, "model.safetensors", 1052513456, "d1f16c0ff85afbe6166fabfae998af3ec16fa11da87da4391b5e0e0a7c796a4d")]},
    "qualite": {
        "titre": "Mode qualité", "modele_nom": "Qwen3.8 27B · UD-Q3_K_XL (Unsloth)", "ram_min": 24, "llama": True,
        "duree_min": 9, "note": "Modèle complet, plus lent. Rédaction stable d'un passage à l'autre.",
        "modele": [_f("unsloth/Qwen3.8-27B-GGUF", "4ca720788d1e01f1bff70c033e0d0028fd02e502",
                      "Qwen3.8-27B-UD-Q3_K_XL.gguf", 13146393504,
                      "8c2a45ff85e7674ca185ec8eb6cdeab0e617ed9d8018caed0b64380eb2a67a5e")],
        "brouillon": [_f(*_B27, "config.json", 1239, "873e3556509b0da06e29654ba00d4944888d4b5e8a33afde25f7eb27d321e980"),
                      _f(*_B27, "model.safetensors", 3848817896, "67fc76d68dc5a9415511a4f394ef744d67510cd20e93b37cc2cc7d28e4bab65c")]},
    "qualite_rapide": {
        "titre": "Mode qualité rapide", "modele_nom": "Qwen3.8 Flash-Next · Q2_0 (ISTA)", "ram_min": 24, "llama": False,
        "duree_min": 6, "note": "Très gros téléchargement. Splash seulement : pas de secours llama.cpp pour ce mode.",
        "modele": [_f(*_FN, "Q2_0/Qwen3.8-Flash-Next-GSQ-RCO-Q2_0-00001-of-00002.gguf", 37623740192,
                      "69820c02ec7d0b45ef2ebb19d6620299db749fe2aded7f39f93c6b88b199b720"),
                   _f(*_FN, "Q2_0/Qwen3.8-Flash-Next-GSQ-RCO-Q2_0-00002-of-00002.gguf", 28800138432,
                      "316b46f3a2dbd68c900f43136ab9449f9dcc3725dfd8c794847c204bc161e113")],
        "brouillon": [_f(*_BFN, "config.json", 1236, "2409575986f9ea24d455343eb469c0e6940def5edab1d1be503bb8eb4cc3b1b9"),
                      _f(*_BFN, "model.safetensors", 1206140008, "d6723f2a359eaf33ec0c95f22ae8edda896774020c552296a85e1913b4d3186f")]},
}
# Hors des modes : le petit modèle qui permet de chercher dans la bibliothèque par le sens.
AUTRES = {"embedding": {"titre": "Modèle d'embedding", "modele": [_f("unsloth/embeddinggemma-2-GGUF", "031f0d4b35536f69ab3509d4893c923264fcf253",
                        "embeddinggemma-2-Q8_0.gguf", 309855520, "6f1bd4ac6c5df7444f9cca7ca36cafe6cfa34cd6f49fefb1e0b4be8143aed8bc")],
                        "brouillon": []}}
MODE_DEFAUT = "rapide"
PREFERENCE = ("qualite_rapide", "qualite", "rapide")     # à la première ouverture : le premier déjà sur le disque
ETAT = {"phase": "", "modele": "", "recu": 0, "total": 0, "erreur": "", "debut": 0}
_ANNULER = threading.Event()
_VERROU = threading.Lock()


def _info(m):
    return CATALOGUE.get(m) or AUTRES.get(m)


def fichiers(m):
    return [dict(f, partie=p) for p in ("modele", "brouillon") for f in _info(m)[p]]


def taille(m):
    return sum(f["taille"] for f in fichiers(m))


def _dans_app(m, f):
    return os.path.join(DOSSIER, m, f["partie"], os.path.basename(f["chemin"]))


def _taille_ok(p, f):
    try:
        return os.path.getsize(os.path.realpath(p)) == f["taille"]
    except OSError:
        return False


def _trouve_fichier(m, f):
    """Chemin du fichier : le dossier de l'app d'abord, puis le cache Hugging Face du Mac."""
    if _taille_ok(_dans_app(m, f), f):
        return _dans_app(m, f)
    depot = "models--" + f["depot"].replace("/", "--")
    for p in sorted(glob.glob(os.path.join(glob.escape(CACHE_HF), depot, "snapshots", "*", f["chemin"]))):
        if _taille_ok(p, f):
            return p
    return ""


def manquants(m):
    return [f for f in fichiers(m) if not _trouve_fichier(m, f)]


def present(m):
    return not manquants(m)


def chemins(m):
    """{"modele": fichier ou dossier à donner à Splash, "brouillon": dossier, "gguf": premier fichier}, ou None."""
    if m not in CATALOGUE or not present(m):
        return None
    trouves = {p: [_trouve_fichier(m, f) for f in fichiers(m) if f["partie"] == p] for p in ("modele", "brouillon")}
    gguf = trouves["modele"][0]
    return {"modele": os.path.dirname(gguf) if len(trouves["modele"]) > 1 else gguf,
            "brouillon": os.path.dirname(trouves["brouillon"][0]), "gguf": gguf}


def dans_app(m):
    return any(os.path.isfile(_dans_app(m, f)) for f in fichiers(m))


def premier_present():
    return next((m for m in PREFERENCE if present(m)), MODE_DEFAUT)


def modes(ram=None):
    """Les trois modes, pour les Paramètres : disponibles sur ce Mac et présents sur le disque ou non."""
    ram = ram or MAT.ram_go()
    out = []
    for m, info in CATALOGUE.items():
        reste = manquants(m)
        out.append({"id": m, "titre": info["titre"], "modele_nom": info["modele_nom"], "note": info["note"],
                    "duree_min": info["duree_min"], "taille": taille(m), "a_telecharger": sum(f["taille"] for f in reste),
                    "present": not reste, "dans_app": dans_app(m), "ram_min": info["ram_min"],
                    "assez_de_memoire": ram >= info["ram_min"], "llama": info["llama"]})
    return out


def _sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for bloc in iter(lambda: f.read(8 * 1024 * 1024), b""):
            if _ANNULER.is_set():
                raise InterruptedError
            h.update(bloc)
    return h.hexdigest()


def url(f, base_url=None):
    return f"{base_url or BASE_URL}{f['depot']}/resolve/{f['commit']}/{f['chemin']}"


def _telecharger_fichier(m, f, base_url):
    dest = _dans_app(m, f)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    part = dest + ".part"
    deja = os.path.getsize(part) if os.path.isfile(part) else 0
    ETAT["phase"] = "téléchargement"
    ETAT["recu"] += deja
    req = urllib.request.Request(url(f, base_url), headers={"User-Agent": "KineAPP"})
    if deja:
        req.add_header("Range", f"bytes={deja}-")
    with urllib.request.urlopen(req, timeout=60) as rep, open(part, "ab" if deja else "wb") as sortie:
        if deja and rep.status != 206:          # le serveur ne reprend pas : on recommence
            sortie.seek(0); sortie.truncate(); ETAT["recu"] -= deja
        while True:
            if _ANNULER.is_set():
                raise InterruptedError
            bloc = rep.read(1024 * 1024)
            if not bloc:
                break
            sortie.write(bloc)
            ETAT["recu"] += len(bloc)
    if os.path.getsize(part) != f["taille"]:
        raise RuntimeError("Téléchargement incomplet : relancez pour reprendre là où il s'est arrêté.")
    ETAT["phase"] = "vérification"
    if _sha256(part) != f["sha256"]:
        os.remove(part)
        raise RuntimeError("Le fichier téléchargé ne correspond pas au modèle officiel (empreinte différente) : il a été supprimé.")
    os.replace(part, dest)


def telecharger(m, base_url=None):
    """Télécharge et vérifie les fichiers qui manquent au mode m. Lève une exception en cas d'échec."""
    reste = manquants(m)
    os.makedirs(DOSSIER, exist_ok=True)
    deja = sum(os.path.getsize(_dans_app(m, f) + ".part") for f in reste if os.path.isfile(_dans_app(m, f) + ".part"))
    besoin, libre = sum(f["taille"] for f in reste) - deja, shutil.disk_usage(DOSSIER).free
    if libre < besoin + 2 * 1024**3:          # 2 Go de marge pour le système
        raise RuntimeError(f"Espace disque insuffisant : {besoin / 1e9:.1f} Go nécessaires, {libre / 1e9:.1f} Go libres.")
    ETAT.update(recu=0, total=sum(f["taille"] for f in reste))
    for f in reste:
        _telecharger_fichier(m, f, base_url)


def telecharger_fond(m, base_url=None):
    if not _info(m):
        raise ValueError("modèle inconnu")
    with _VERROU:
        if ETAT["phase"] in ("téléchargement", "vérification"):
            raise RuntimeError("Un téléchargement est déjà en cours.")
        if present(m):
            raise RuntimeError("Ce modèle est déjà sur le disque.")
        _ANNULER.clear()
        ETAT.update(phase="téléchargement", modele=m, recu=0, total=taille(m), erreur="", debut=time.time())

    def travail():
        try:
            telecharger(m, base_url)
            ETAT.update(phase="terminé", erreur="")
        except InterruptedError:
            ETAT.update(phase="annulé", erreur="")
        except Exception as e:
            ETAT.update(phase="erreur", erreur=str(e) or type(e).__name__)
    threading.Thread(target=travail, daemon=True).start()


def annuler():
    if ETAT["phase"] in ("téléchargement", "vérification"):
        _ANNULER.set()
        return True
    return False


def retirer(m, utilise):
    """Met à la Corbeille les fichiers téléchargés par l'app pour ce mode (jamais ceux du mode
    utilisé, ni ceux du cache Hugging Face, qui restent à leur place)."""
    if m not in CATALOGUE:
        raise ValueError("modèle inconnu")
    if m == utilise:
        raise RuntimeError("C'est le mode utilisé : choisissez-en d'abord un autre.")
    d = os.path.join(DOSSIER, m)
    if not dans_app(m):
        raise RuntimeError("Ce modèle n'est pas dans le dossier de l'app.")
    ok, err = corbeille(d)
    if not ok:
        raise RuntimeError(f"Mise à la Corbeille impossible : {err}")


def corbeille(p):
    r = subprocess.run(["/usr/bin/trash", p], capture_output=True, text=True)
    return r.returncode == 0, (r.stderr or r.stdout).strip()
