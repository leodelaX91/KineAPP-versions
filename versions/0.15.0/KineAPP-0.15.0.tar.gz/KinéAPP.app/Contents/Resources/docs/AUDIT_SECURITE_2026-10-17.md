# Audit de sécurité — KinéAPP 0.9.0 bêta (17/10/2026)

Périmètre : serveur de l'app (127.0.0.1), coffre d'identité, fenêtre native, installateur et
mises à jour (Mac de développement et canal GitHub signé), dictées de l'iPhone, sauvegarde GitHub,
interface. Méthode : relecture du code ajouté, tests automatiques (70/70), garde-fous de
confidentialité (contrôleur du code et contrôleur de l'app installée : conformes), recherche
statique des motifs dangereux (shell, eval, désérialisation, SQL construit : aucun), vérifications
sur le Mac (FileVault actif, clés).

## Vérifié, conforme

- Serveur : écoute 127.0.0.1 ; Host contrôlé (pas de « DNS rebinding ») ; écritures en JSON
  seulement et Origin contrôlée (pas de formulaire d'un site tiers) ; politique de contenu de la
  page ; garde réseau sur les sorties (urllib).
- Coffre : nouvelles routes (recherche d'un nom de dictée, pseudonymisation) derrière le jeton ;
  recherche en lecture seule (aucune fiche créée), homonymes signalés ; jeton en mémoire.
- Canal fenêtre ↔ serveur : secret aléatoire de 256 bits remis par l'entrée standard (ni argument
  ni environnement), comparé en temps constant ; requis pour remettre une dictée et pour lire une
  transcription brute ; un site tiers ne peut ni l'envoyer ni lire la réponse.
- Dictées : nom du patient seulement dans le nom du fichier iCloud, la mémoire de la fenêtre
  (oublié au verrouillage du coffre) et le coffre ; transcription brute en mémoire du serveur
  seulement ; copie sous nom neutre (600) relue avant la Corbeille ; aucune commande shell.
- Mises à jour, autres Mac : étiquette signée par une clé connue de l'app installée, plus récente,
  numéro cohérent avec le code ; garde-fous jugés par l'app installée ; aucune connexion par
  l'installateur ; recherche des versions sur clic seulement. Essais : version pirate, version
  non signée et ancienne version ré-étiquetée refusées.
- Mises à jour, ce Mac : commit propre, tests réussis sur l'arbre exact, garde-fous de l'app
  installée, mot de passe administrateur ; version précédente gardée.
- Sauvegarde GitHub : clé de déploiement limitée au dépôt (phrase de passe dans le trousseau) ;
  contrôle avant envoi (aucun nom de patient dans l'historique, garde-fous) ; historique d'avant
  la publication jamais envoyé.
- Interface : textes échappés (y compris les nouveaux tableaux et fenêtres).

## Corrigé pendant l'audit

- Échappement HTML : les nombres sont désormais convertis avant échappement (une valeur 0 ou
  numérique pouvait faire échouer l'affichage).
- Taille des requêtes bornée (200 Mo) : une requête démesurée n'est plus lue en mémoire.
- Fichiers créés par le serveur en 600 / 700 (umask), en plus du dossier de données en 700.

## Risques restants, par priorité

1. **Élevé si vous diffusez l'app — clé de publication sans phrase de passe**
   (`~/.ssh/kineapp_publication`). Un programme de votre session pourrait signer une version et,
   avec la clé de déploiement (utilisable sans vous via le trousseau), la publier : les autres Mac
   l'installeraient (leurs garde-fous s'appliqueraient quand même). À faire avant toute diffusion :
   `ssh-keygen -p -f ~/.ssh/kineapp_publication`, phrase de passe **non** enregistrée dans le
   trousseau, et lancer `./outils/publier.sh` vous-même dans le Terminal.
2. **Moyen — dictées de l'iPhone par iCloud** : voix et nom transitent par Apple, non HDS. Activer
   la Protection avancée des données ; taper le minimum ; voir docs/RGPD.md.
3. **Moyen — dictée faite sur le Mac** : les noms prononcés ne sont pas encore remplacés par les
   codes (contrairement à la dictée de l'iPhone). À corriger dans une prochaine version ; d'ici là,
   éviter de prononcer le nom.
4. **Moyen — copie de développement modifiable par la session** : un programme pourrait y valider
   du code et une fausse réussite des tests. Restent les garde-fous de l'app installée, la liste
   des changements montrée et le mot de passe administrateur : lisez la liste avant d'installer.
5. **Faible — bilans sous codes lisibles par les apps de votre session** (Documents). FileVault est
   actif ; verrouillez le Mac en partant ; retirez l'accès « Documents » aux assistants si voulu.
6. **Faible — Touch ID** : une fausse demande d'empreinte reste possible ; n'y répondre qu'après un
   clic dans KinéAPP.
7. **Information** : la sauvegarde chiffrée de l'app n'a pas de mot de passe défini (signalé au
   lancement) : aucune sauvegarde n'a lieu tant qu'il manque.
