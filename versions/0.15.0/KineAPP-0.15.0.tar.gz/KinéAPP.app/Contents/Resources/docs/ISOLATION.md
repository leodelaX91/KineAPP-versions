# Isolation des données patients (coffre d'identité)

Refonte du 13/10/2026. But : qu'aucune app ni aucun agent de la session (Claude Code, Hermes…) ne
puisse relier un nom de patient à son bilan, tout en gardant les moteurs intégrés (Splash, llama.cpp)
et la possibilité d'évaluer transcriptions, extractions et bilans avec Claude Code.

## Principe

- **Le nom ne vit que dans le coffre.** Les bilans, transcriptions, extractions, notes, comptes
  rendus et ordonnances ne portent qu'un code : « Mme P-K7Q3MX ». Le lien nom ↔ code, l'identité
  administrative (nom, prénom, date de naissance) et les documents nominatifs d'avant le coffre
  sont dans `/Library/Application Support/KineAPP/Coffre`, propriété du compte système
  `_kinecoffre` (droits 700) : votre session ne peut pas les lire, donc aucun outil lancé dans
  votre session non plus.
- **Le coffre est un service** (`coffre/coffre.py`) lancé par launchd sous `_kinecoffre`. Il écoute
  sur 127.0.0.1:47821 ; ce port est tenu par launchd dès le démarrage du Mac, même pendant un
  redémarrage du service : aucun programme ne peut se faire passer pour lui.
- **Mot de passe du coffre.** Tapé dans la fenêtre native de KinéAPP (champ sécurisé), jamais
  enregistré. Il ouvre une session en mémoire (12 h d'inactivité au plus) ; menu Coffre →
  Verrouiller, et verrouillage à la fermeture de l'app. PBKDF2-SHA256 600 000 itérations ;
  essais ratés ralentis (2, 4, 8 s… jusqu'à 5 min).
- **Dans l'interface**, le nom se tape dans un cadre du coffre (une autre origine web : la page de
  l'app ne peut pas en lire le contenu) qui ne lui renvoie qu'un code. Les noms affichés (liste des
  bilans, en-tête du patient, textes) sont de petits cadres du coffre posés sur les codes. Le jeton
  de session n'est remis par la fenêtre native qu'aux cadres du coffre, jamais à la page.
- **Documents nominatifs à la demande.** « Exporter avec le nom » : l'app remet au coffre le .docx
  codé ; le coffre y écrit le nom (et, pour une ordonnance, prénom, date de naissance, âge), puis
  vous choisissez où l'enregistrer. Le lien de téléchargement sert une fois. Après usage
  (impression, envoi), mettez le fichier à la Corbeille.

## Ce qui protège quoi

| Menace | Protection |
| --- | --- |
| Un agent ou une app lit vos fichiers | Les fichiers ne contiennent que des codes ; bilans, transcriptions, comptes rendus, ordonnances et fiches sont en plus chiffrés (AES-256, clé gardée par le coffre, remise au serveur seulement après déverrouillage) ; le coffre est illisible pour votre session |
| Il interroge le coffre | Rien sans jeton ; jeton seulement par le mot de passe |
| Il modifie l'app pour voler les noms | App et coffre appartiennent au système (root) : modification impossible sans mot de passe administrateur |
| Il interroge le serveur de l'app | Chaque lancement crée une session : la fenêtre seule reçoit le secret (entrée standard), échange un code d'entrée à usage unique contre un cookie protégé ; toute adresse de l'API refuse une requête sans lui |
| Il se fait passer pour le coffre ou le serveur de l'app | Port du coffre tenu par launchd (vérifié : aucun programme ne le prend pendant un redémarrage du service) ; si un programme de la session y écoute malgré tout, la fenêtre n'envoie ni mot de passe ni jeton et ne charge aucun cadre ; la fenêtre lit le port de SON serveur sur sa sortie et vérifie un serveur repris (interpréteur, script, environnement) |
| Il glisse du code dans une mise à jour | L'installateur n'installe que les fichiers suivis d'un commit, sans lien symbolique, montré avant confirmation, assemblés dans un dossier réservé à l'administrateur |
| Il injecte du code dans l'app ou le serveur | Runtime durci ; Python embarqué dans l'app (empreinte vérifiée à l'installation), lancé en mode isolé (-I) avec un environnement propre |
| Il piège le stockage web | La fenêtre n'écrit rien sur le disque (ni cache, ni stockage local) |
| Un texte piégé (sortie de modèle) dans la page | Textes échappés ; politique de contenu : aucun code dans la page (scripts de l'app seulement, gestes limités à une liste de fonctions), rien envoyé ailleurs qu'à son serveur |
| Perte du Mac / du disque | Sauvegardes chiffrées du coffre (AES-256, clé tirée de son mot de passe), copiées avec les sauvegardes de l'app |

## Ce qui reste à votre charge (risques résiduels)

- **Ne donnez pas** à un terminal ou à un agent l'autorisation « Accessibilité », « Enregistrement
  de l'écran », « Surveillance de l'entrée » ou « Outils de développement » (Réglages Système →
  Confidentialité) : elles permettent de lire l'écran ou les frappes, donc les noms. (Le mot de
  passe du coffre, lui, se tape dans un champ sécurisé du système.)
- **Mise à jour** : ce que vous installez avec le mot de passe administrateur devient du code de
  confiance. L'installateur montre les commits installés ; installez ce que vous avez demandé.
- **Blocage volontaire** : un programme de la session peut multiplier les faux mots de passe et
  imposer une attente (jusqu'à 5 min) avant le prochain essai ; il ne peut pas lire le coffre.
- **Le presse-papiers** est lisible par toute app : n'y copiez pas de nom.
- **Les documents exportés** sont nominatifs : mettez-les à la Corbeille après usage, et videz-la.
- **Apple Notes** : l'app ne les lit plus (module retiré le 17/10/2026). Les notes déjà présentes
  dans Notes gardent leur titre nominatif : ne donnez pas l'accès à Notes à un assistant.
- **Pièces déposées** dans le dossier d'un bilan (imagerie, courriers reçus) : si elles portent le
  nom, elles échappent au coffre.
- **Caches internes de l'app Claude** (`~/Library/Application Support/Claude` : IndexedDB, Local
  Storage) : formats binaires, non traités. Les transcripts de Claude Code et l'historique git, eux,
  sont pseudonymisés par la migration (voir plus bas).
- **Mot de passe administrateur** : tapé dans un terminal, il reste valable quelques minutes pour
  ce terminal. Installez dans le Terminal de macOS, puis tapez `sudo -k`.
- **Mot de passe du coffre perdu = noms perdus** (les bilans restent, sous leurs codes). Notez-le
  hors du Mac.

## Installation

App fermée, dans le Terminal de macOS (pas un terminal partagé avec un assistant) :

    cd ~/Developer/KineAPP-dev
    sudo ./outils/installer.sh
    sudo -k

L'installateur : crée le compte `_kinecoffre` ; compile la fenêtre native ; assemble et signe
l'app (runtime durci) ; garde Splash, llama.cpp et whisper.cpp dans l'app ; installe l'app comme code du
système (la version précédente est gardée dans `/Library/Application Support/KineAPP/Versions`) ;
demande le mot de passe du coffre ; propose la migration (répétition à blanc d'abord, puis
confirmation) ; lance le service du coffre. Répétition sans droits administrateur :
`KINECOFFRE_MDP_ESSAI=… ./outils/installer.sh --essai /dossier/essai` (dossier personnel fictif :
`python3 tests/donnees_fictives.py /dossier/essai/maison`).

Après l'installation, les mises à jour se font depuis l'app (section suivante).

Désinstaller le coffre (rien n'est effacé) : `sudo ./outils/desinstaller.sh`.

## Ouverture de l'app

Coffre installé : rien n'est visible avant le déverrouillage du coffre (mot de passe ou Touch ID).
« Annuler » laisse l'écran de verrouillage ; le bouton « Déverrouiller » le rouvre. Verrouiller le
coffre (menu Coffre, bouton, mise en veille avec Touch ID, session expirée) masque de nouveau
l'interface ; une séance en cours continue (le serveur n'est pas arrêté, seulement caché).

Si le coffre ne répond pas, l'écran propose « Réessayer » et « Ouvrir sans le coffre » (les noms
restent masqués), pour ne jamais bloquer une séance : un programme de la session ne peut pas
provoquer cette situation, le port du coffre étant tenu par le système. Menu KinéAPP → « Revenir à
la version précédente… » reste disponible même si l'interface ne s'ouvre plus.

Limite : cet écran protège la fenêtre de l'app. Chiffrement activé (Paramètres › Sécurité), les
fichiers du dossier KinéAPP sont illisibles hors de l'app ; restent en clair l'audio (en attente de
transcription, ou gardé selon le réglage de conservation), les fiches d'enregistrement et de type de
bilan (code et date) et les journaux techniques. Pour ouvrir
un document dans Word ou l'aperçu, l'app en fait une copie déchiffrée temporaire, retirée à la
fermeture. Verrouillez le Mac en partant (Touch ID ou mot de passe de session) et gardez FileVault
activé. En cas de problème avec l'app : `docs/SECOURS_DECHIFFREMENT.md` (code de secours).

## Touch ID

Paramètres → Coffre d'identité → **Activer Touch ID** (mot de passe du coffre, puis empreinte).

- La fenêtre crée une clé dans la puce de sécurité du Mac (Secure Enclave). Elle ne peut pas en
  sortir, ne sert qu'avec une empreinte, et devient inutilisable si les empreintes du Mac changent
  (Touch ID se désactive alors ; le mot de passe reprend). Le coffre ne garde que sa clé publique.
- Déverrouiller : le coffre envoie un défi à usage unique (60 s) ; l'empreinte autorise la puce à
  le signer ; le coffre vérifie la signature et ouvre la session. Le mot de passe n'est stocké nulle
  part, même chiffré.
- Le mot de passe reste demandé après un redémarrage du Mac ou du coffre (donc après une mise à
  jour de l'app), et tous les 7 jours : le coffre le garde dans sa propre mémoire (compte
  `_kinecoffre`, illisible par la session) pour ses sauvegardes chiffrées, 7 jours au plus.
- Avec Touch ID, le coffre se verrouille à la mise en veille et au verrouillage de l'écran ; au
  retour, la fenêtre de KinéAPP propose Touch ID.
- L'empreinte n'est demandée qu'après un clic dans KinéAPP (lancement, menu Coffre, bouton
  Déverrouiller, ou bouton « Touch ID » de la fenêtre qui s'ouvre quand un nom est demandé). Ne
  posez le doigt que dans ce cas, et si la demande vient de KinéAPP : un programme de la session
  pourrait afficher une fausse demande. Même alors, il obtiendrait une session jusqu'au prochain
  verrouillage, jamais le mot de passe.
- Activer Touch ID exige le mot de passe (une session ouverte par Touch ID ne peut pas enregistrer
  une autre clé) ; changer le mot de passe désactive Touch ID. Le journal des accès du coffre note
  activations, déverrouillages par Touch ID et refus.

## Mises à jour et problèmes

Paramètres → **Mises à jour et problèmes**.

- **Signaler un problème** : décrivez ce qui ne va pas ; l'app écrit un diagnostic dans
  `KinéAPP/Diagnostics` (version, réglages des moteurs, contrôles au lancement, bilans en
  échec sous leur numéro, refus réseau, fin des journaux). Aucun nom : tout nom écrit après une
  civilité (« Mme Dupont ») est retiré, les codes restent. Dites ensuite à Claude « voir le
  dernier diagnostic ».
- Claude corrige dans la copie de développement, ajoute un contrôle aux tests, lance tous les
  tests (la réussite est notée pour le code exact testé) et valide (commit).
- **Installer la mise à jour** : l'app montre ce qui change et signale les parties sensibles
  touchées (coffre, fenêtre, installateur, garde-fous, migration, contrôle réseau). Le mot de
  passe administrateur du Mac est demandé par macOS ; l'app redémarre et le coffre se reverrouille.
  Refusée pendant une séance, un traitement de bilan ou un banc d'essai.
- **Revenir à la version précédente** : remet la version d'avant (la version écartée est gardée).

Ce que l'installateur exige avant d'installer (sinon rien ne change, la version en place reste) :

1. un commit sans modification en attente ni lien symbolique ;
2. les tests réussis sur exactement ce code ;
3. les **garde-fous de confidentialité** (`outils/garde_fous.py`) conformes, jugés par le
   contrôleur de la version **déjà installée** : aucune adresse Internet hors des domaines connus
   (PubMed, recherche HAS, modèles de transcription, espaces de noms des documents), aucun outil
   réseau ni télémétrie, serveur et coffre sur 127.0.0.1 seulement, politique de contenu des pages,
   jeton du coffre, fenêtre non persistante et non inspectable, Python isolé. Une mise à jour ne
   peut donc pas assouplir les règles qui la jugent. Une version qui change les règles elles-mêmes
   (un nouveau site, par exemple) n'est jamais installée par le bouton : seulement dans le Terminal
   (`sudo ./outils/installer.sh`), après lecture du changement des règles ;
4. compilation et signature réussies.

La mise à jour ne touche qu'au code : ni mot de passe, ni rangement, ni migration ; données et
coffre intacts. Comptes rendus d'installation : `KinéAPP/Diagnostics/mise-a-jour_*.log`.
Journal du serveur : `~/Library/Logs/KinéAPP/serveur.log`. Après chaque mise à jour, macOS
redemande l'accès au micro (nouvelle signature de l'app).

Sans l'app (dans le Terminal) :
`sudo "/Applications/KinéAPP.app/Contents/Resources/outils/installer.sh" --mise-a-jour` ou `--revenir`.

## Migration des données existantes

Tant qu'elle n'est pas faite, les noms restent en clair dans les dossiers du dossier KinéAPP,
lisibles par toute app de la session : l'app le signale au lancement (contrôle « confidentialité »).
KinéAPP fermée, dans le Terminal : `sudo "/Applications/KinéAPP.app/Contents/Resources/outils/installer.sh"
--migration-seule`, puis répondre `o` (ou `oui`) après la répétition à blanc.

`outils/migration.py`, lancée par l'installateur : chaque patient trouvé (bilans, brouillons,
dossiers patients, ordonnances, notes, transcriptions) reçoit une fiche et un code dans le coffre ;
le nom est remplacé par le code dans les noms de fichiers et de dossiers, les textes et les .docx.
Les dates de modification sont conservées. Chaque original est d'abord copié dans les archives du
coffre, avec un manifeste. Les notes dont le titre ne désigne pas un patient reconnaissable (sans
civilité) partent aux archives du coffre. Le nom seul n'est remplacé dans les textes cliniques que
s'il n'est pas aussi un mot courant des bilans (un patient « Talon » ne fait pas disparaître le
talon). Historique (bancs d'essai, rapports, mémoire de l'assistant) : remplacé aussi.
Rien de nominatif n'est affiché, seulement des nombres.

## Comportements changés par la refonte

- La fenêtre affiche enfin les messages et confirmations de l'interface : avant, `alert()` ne
  montrait rien et `confirm()` répondait toujours « non » (suspendre le traitement, écarter un
  bilan, retirer une autorisation réseau… ne faisaient rien dans l'app). Les suppressions ainsi
  rendues possibles (modèle de bilan, brouillons d'ordonnance et de compte rendu) passent par la
  Corbeille.
- Le champ « photo » des tests de force fonctionne dans l'app (il était inopérant).
- Les préférences de l'interface (thème, onglet, colonne) sont gardées par l'app : elles se
  perdaient à chaque lancement (le port changeant, le navigateur les oubliait).
- Whisper : les deux modèles peuvent rester sur le disque ; on choisit, rien n'est retiré seul.

## Où sont les fichiers

- Dossier `KinéAPP`, dans Documents ou sur le Bureau (Paramètres → Général ; le changer déplace le
  dossier entier, sans copie ni effacement) : bilans, transcriptions, comptes rendus, ordonnances,
  bibliothèque, diagnostics, bancs d'essai, rapports (tous sous les codes des patients). Le
  rangement (`outils/ranger.py`, lancé par l'installateur) y regroupe d'anciens emplacements et
  respecte ce choix.
- `~/Library/Application Support/BilanKine` : données internes de l'app (brouillons, audio en
  attente, dossiers patients, réglages).
- `/Library/Application Support/KineAPP` : le coffre (noms, identités, archives nominatives),
  illisible pour votre session.

## Enregistrements audio

Paramètres → Enregistrements audio : après la rédaction du bilan, l'audio est effacé aussitôt (comme
avant la refonte) ou gardé 1, 7, 30 ou 90 jours ; un enregistrement qu'aucun bilan ne réclame
(séance interrompue, double clic) part à la Corbeille au bout de 1 à 90 jours. La liste montre
chaque enregistrement (date, durée, taille, état, patient, échéance) et permet de les mettre à la
Corbeille à la main — jamais la séance en cours ni un bilan qui attend son traitement. Les
échéances sont vérifiées au lancement puis toutes les heures.

## Dictées de l'iPhone et gestion de charge

Un Raccourci sur l'iPhone (bouton Action) : menu (note de séance, bilan initial, réévaluation,
courrier), nom du patient, enregistrement. Fichier « Usage__Nom saisi.m4a » déposé dans iCloud Drive /
KinéAPP-Dictées (date et heure : celles du fichier ; anciens noms « Nom__AAAA-MM-JJ_HHMM » et
sous-dossiers par usage aussi compris). Procédure : Paramètres → iPhone, et docs/RACCOURCI_IPHONE.md.

- Note de séance : décrite ci-dessous. Bilan initial et réévaluation : après le recueil du
  consentement (alerte du Raccourci, notée avec le bilan), l'audio entre dans la chaîne des bilans
  comme un enregistrement du Mac. **C'est alors toute la séance, voix du patient comprise, qui
  transite par iCloud** : Protection avancée des données indispensable, sinon enregistrer les
  bilans sur le Mac. Courrier : transcrit et pseudonymisé comme une note, puis compte rendu
  préparé (dernier bilan, suivi), analysé et rédigé, à relire ; rien n'est envoyé.

- **Exception assumée à « aucune donnée patient ne quitte le Mac »** (voir aussi docs/RGPD.md :
  iCloud n'est pas un hébergeur certifié HDS) : l'audio et le nom tapé
  transitent par iCloud (serveurs d'Apple) jusqu'à leur reprise. Activez la Protection avancée des
  données d'iCloud (chiffrement de bout en bout). Un fichier supprimé reste 30 jours dans
  « Supprimés récemment » d'iCloud Drive : à vider. Le nom est lisible dans le nom du fichier sur
  l'iPhone, le Mac et iCloud jusqu'à la reprise.
- La fenêtre de l'app lit le dossier (coffre ouvert, toutes les 2 minutes ou sur « Vérifier ») ;
  le coffre cherche le patient **sans jamais créer de fiche** (homonymes ou faute de frappe :
  « à attribuer », choix dans une fenêtre de l'app ; créer la fiche demande une confirmation).
  L'audio est copié sous un nom neutre, la copie relue, puis l'original va à la Corbeille.
- Le serveur ne reçoit que (identifiant, code du patient, date). Transcription et mise en forme
  par lots, seulement quand l'app ne fait rien d'autre (ni séance, ni bilan, ni banc d'essai).
- Noms prononcés : la transcription brute ne vit qu'en mémoire du serveur ; la fenêtre la fait
  pseudonymiser par le coffre avant toute écriture (canal réservé à la fenêtre : secret remis au
  serveur par son entrée standard). La dictée faite sur le Mac n'a pas encore cette étape : un nom
  prononcé pendant une dictée sur le Mac reste dans la note.
- La note arrive « à relire » (« À traiter », onglet Séances) : hors des comptes rendus tant qu'elle n'est pas relue.
- Exercices et charges relevés par le modèle (prompt 09) puis contrôlés : un nombre absent de la
  dictée est retiré, un exercice non retrouvé est signalé. Charge de séance = RPE × durée ;
  charge hebdomadaire et variation ; protocoles par phases (protocoles/*.json) : trames indicatives
  avec références, à adapter.

## Notes de suivi (dossier « Suivi Kiné »)

La synchronisation avec Apple Notes a été retirée le 17/10/2026, la lecture des notes du dossier
« Suivi Kiné » le 18/10/2026 : l'app ne lit ni ne touche plus ce dossier (il reste où il est). Les
fichiers de liens de l'ancienne synchronisation sont proposés à la Corbeille (Paramètres → Sécurité
et confidentialité). Les notes de séance viennent de la dictée (Mac ou iPhone, onglet Séances), et
les objectifs et le programme à domicile sont repris de chaque bilan.

## Transcripts de Claude Code et historique git

La migration remplace aussi les noms par les codes dans les transcripts et copies de fichiers de
Claude Code (`~/.claude/projects`, `~/.claude/file-history`, sessions de l'app Claude) et dans toute
l'histoire git du code : le lien avec les dossiers est gardé (les codes), le nom n'y est plus. Les
captures d'écran des transcripts, où un nom pouvait se lire, partent aux archives du coffre. La
réécriture git exige que le code actuel ressorte identique (sinon rien n'est touché) ; le dépôt
d'origine est gardé dans les archives du coffre. Claude doit être fermé : sinon l'installateur
remet cette partie à plus tard, et on la lance ensuite avec `sudo ./outils/installer.sh
--migration-seule`. Une migration relancée retrouve les noms dans le coffre.

## Travailler avec Claude Code

Claude Code garde l'accès aux transcriptions, extractions et bilans pour les évaluer : ils sont
codés. Il ne peut ni lire le coffre ni ouvrir de session (pas de mot de passe). Les bancs
d'essai continuent de fonctionner avec les codes.

## Développement

- Copie de développement : `~/Developer/KineAPP-dev` (`GIT_DIR=~/Developer/KineAPP.git
  GIT_WORK_TREE=~/Developer/KineAPP-dev`). L'app installée n'est plus modifiable directement.
- Règles de travail pour Claude : `CLAUDE.md` à la racine de la copie de développement.
- Tests : `python3 tests/test_kineapp.py` (jamais pendant un banc : ils arrêtent les moteurs) ;
  `python3 tests/test_kineapp.py coffre` pour les seuls contrôles dont le nom contient « coffre ».
  Ils comprennent le coffre, le mode coffre, la migration (données fictives), les garde-fous de
  confidentialité et ceux de la fenêtre native (`tests/essai_fenetre.swift`). Tout réussi :
  l'arbre testé est noté dans `.tests-reussis.json` (hors git).
- Garde-fous seuls : `python3 outils/garde_fous.py .`
- Coffre d'essai à l'écran : `KINECOFFRE_TEST=1 KINECOFFRE_MDP_TEST=… KINECOFFRE_PORT=… python3
  coffre/coffre.py` (le jeton d'essai n'existe qu'en mode d'essai), serveur avec
  `KINEAPP_COFFRE_PORT=…`.
