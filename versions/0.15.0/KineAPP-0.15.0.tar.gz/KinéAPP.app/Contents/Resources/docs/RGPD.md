# Données de santé : repères pour le cabinet (KinéAPP, version bêta)

Pas un avis juridique : points de vigilance et modèles à adapter. Références : RGPD (art. 9, 13,
30), Code de la santé publique (art. L1111-8 sur l'hébergement des données de santé), référentiel
de la CNIL pour les cabinets médicaux et paramédicaux.

## Ce que fait l'app

- Données traitées : identité (dans le coffre d'identité), bilans, notes de séance, mesures,
  questionnaires, enregistrements audio des séances (le temps du traitement, puis Corbeille selon
  le réglage), transcriptions.
- Lieu : ce Mac. Les modèles d'IA tournent en local ; aucune donnée n'est envoyée à un service
  d'IA. Exceptions, toutes à votre initiative : sauvegardes chiffrées (disque externe, iCloud
  chiffré sur le Mac avant l'envoi), recherche bibliographique (mots-clés cliniques anonymes),
  **dictées de l'iPhone** (voir plus bas).
- Traçabilité gardée avec chaque bilan : version de l'app, consentement à l'enregistrement
  (date), points vérifiés par le praticien et ses réponses, date de validation.

## Enregistrement audio de la séance

Le patient doit être informé avant l'enregistrement et pouvoir refuser (sans conséquence sur sa
prise en charge : vous prenez alors des notes). Au premier enregistrement d'un patient, l'app
demande de confirmer qu'il est informé et d'accord (le bouton de départ devient « Patient d'accord,
démarrer ») ; la date est gardée dans son dossier et avec chaque bilan. L'accord se retire à tout
moment (menu « … » du dossier) : il sera alors redemandé au prochain enregistrement.

Modèle d'information (affichage en salle d'attente et/ou oral) :

> Pour rédiger votre bilan, votre kinésithérapeute peut enregistrer la séance avec votre accord.
> L'enregistrement est traité uniquement sur son ordinateur, par un logiciel d'aide à la
> rédaction, et effacé une fois le bilan rédigé. Vous pouvez refuser, sans aucune conséquence sur
> votre prise en charge. Vos données sont conservées dans votre dossier de kinésithérapie ; vous
> pouvez y accéder, les faire rectifier ou vous opposer à leur traitement en vous adressant au
> cabinet. Réclamation possible auprès de la CNIL (cnil.fr).

## Dictées de l'iPhone : point de vigilance

L'audio et le nom tapé transitent par iCloud (Apple), qui **n'est pas un hébergeur certifié de
données de santé (HDS)**. Le dépôt, même temporaire, de données de santé identifiantes chez un
tiers peut relever de l'hébergement (art. L1111-8 CSP). Pour réduire le risque :
- activer la **Protection avancée des données** d'iCloud (chiffrement de bout en bout : Apple ne
  peut pas lire les fichiers) ;
- taper sur l'iPhone le minimum nécessaire (par exemple le nom sans le prénom) ;
- ne rien dicter d'inutile (pas de nom de tiers) ;
- vider « Supprimés récemment » d'iCloud Drive.
À défaut, préférer la dictée sur le Mac (onglet Séances du dossier), qui ne quitte pas l'ordinateur.

**Bilans enregistrés sur l'iPhone** (bilan initial, réévaluation) : c'est toute la séance, voix du
patient comprise, qui transite par iCloud. Le risque est bien plus élevé qu'avec une dictée du
praticien seul : réservez cet usage à une configuration avec la Protection avancée des données, ou
enregistrez les bilans sur le Mac. Le consentement du patient est demandé par le Raccourci avant
tout enregistrement (« Annuler » arrête tout) et noté avec le bilan.

## Registre des traitements (à tenir par le cabinet)

| Rubrique | Contenu proposé |
|---|---|
| Finalité | Prise en charge en kinésithérapie : bilans, suivi des séances, courriers |
| Base légale | Art. 9.2.h RGPD (prise en charge sanitaire par un professionnel de santé) |
| Personnes | Patients du cabinet |
| Données | Identité, données de santé, enregistrements audio (temporaires) |
| Destinataires | Le kinésithérapeute ; médecins destinataires des comptes rendus |
| Durée | Dossier : 20 ans après le dernier passage (référentiel CNIL des cabinets) ; audio : jusqu'à la rédaction (réglage de l'app) |
| Sécurité | Chiffrement du disque (FileVault), données de l'app chiffrées (AES-256, code de secours), coffre d'identité séparé, app protégée, accès à l'app par session de lancement, journal technique sans nom, sauvegardes chiffrées, verrouillage de session |
| Sous-traitants | Aucun pour le traitement ; Apple (iCloud) si dictées de l'iPhone ou sauvegarde iCloud |

## Logiciel en version bêta

KinéAPP est une aide à la rédaction expérimentale. Elle ne pose aucun diagnostic ; le praticien
relit, corrige et valide chaque document et en reste responsable. Une diffusion à d'autres
professionnels peut relever du règlement européen sur les dispositifs médicaux (2017/745) :
se renseigner avant.
