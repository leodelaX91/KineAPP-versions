# Raccourci iPhone « KinéAPP »

Un seul Raccourci pour quatre usages. Vous choisissez dans un menu ce que vous faites, vous tapez
le nom du patient, puis vous dictez ou vous écrivez. Le fichier arrive sur le Mac par iCloud Drive,
nommé par exemple `Bilan__Dupont Marie.m4a`, ou `Séance__Dupont Marie.txt` pour une note écrite.
KinéAPP lit l'usage avant les deux tirets bas et le nom après ; la date et l'heure sont celles de
l'enregistrement. Une note écrite suit le même traitement qu'une note dictée, sans transcription :
noms remplacés par les codes, mise en forme, charges relevées, note « à relire ». L'écrit sert aux
notes de séance et aux courriers ; un bilan s'enregistre toujours.

| Choix dans le menu | Ce que fait KinéAPP sur le Mac |
|---|---|
| Séance | Note mise en forme, charges relevées ; objectifs et programme à domicile mis à jour si vous en parlez. Tout arrive « à relire » : listé dans « À traiter », et dans l'onglet Séances du patient. |
| Bilan | Chaîne complète d'un bilan, comme un enregistrement fait sur le Mac : transcription, rédaction, points à vérifier. |
| Réévaluation | Pareil, comparé au dernier bilan du patient. |
| Courrier | Brouillon de compte rendu au médecin, préparé avec le dernier bilan et le suivi, à relire dans « Courriers et ordonnances ». |

Avant de commencer : iCloud Drive doit être activé sur l'iPhone, et le dossier `KinéAPP-Dictées`
visible dans l'app Fichiers (KinéAPP le crée sur le Mac).

## Les sept actions

Dans l'app **Raccourcis** : **+** en haut à droite, nommez le raccourci **KinéAPP**, puis ajoutez ces
actions dans l'ordre (cherchez chacune par son nom dans la barre du bas). Un Raccourci déjà créé
avec l'ancienne version (cinq actions) continue de marcher, sans le choix de l'écrit.

1. **Choisir dans le menu**. Remplacez les deux options proposées par quatre : Séance, Bilan,
   Réévaluation, Courrier.
   - Sous chaque option, ajoutez une action **Texte** contenant le même mot (Séance, Bilan,
     Réévaluation, Courrier).
   - Sous Bilan et Réévaluation seulement, ajoutez d'abord **Afficher l'alerte** : « Le patient
     accepte-t-il l'enregistrement ? ». C'est le recueil du consentement : « Annuler » arrête tout.
2. **Définir la variable** : nommez-la **Usage**.
3. **Demander une saisie** : question « Nom du patient ? ».
4. **Définir la variable** : nommez-la **Patient**.
5. **Choisir dans le menu** : question « Dicter ou écrire ? », deux options, Vocal et Texte.
   - Sous Vocal : **Enregistrer l'audio** (gardez les réglages proposés).
   - Sous Texte : **Demander une saisie**, question « Note ? ». Vous pouvez écrire, ou utiliser la
     dictée du clavier.
6. **Définir le nom**. Dans la case du nom, touchez *Variables* et choisissez **Usage**, tapez deux
   tirets bas `__`, puis choisissez **Patient**.
7. **Enregistrer le fichier**. Touchez la destination, choisissez iCloud Drive › `KinéAPP-Dictées`,
   et désactivez « Demander où enregistrer ».

Les deux variables évitent une confusion : l'app Raccourcis appelle les deux menus « Résultat du
menu » et les deux saisies « Saisie fournie ».

Pour le lancer d'un geste : Réglages de l'iPhone → **Bouton Action** → Raccourci → KinéAPP. Vous
pouvez aussi l'ajouter à l'écran d'accueil.

Plusieurs enregistrements le même jour, pour le même patient et le même usage, sont réunis :
- des dictées au fil de la séance donnent une seule note de séance ; les exercices s'additionnent,
  et pour la durée, le RPE et l'EVA, c'est la dernière valeur dite qui compte ;
- un bilan coupé par erreur puis repris donne un seul bilan. KinéAPP attend 10 minutes avant de le
  lancer. Une partie arrivée après la rédaction est ajoutée, et le bilan est refait tant qu'il
  n'est pas enregistré ;
- un deuxième courrier dicté complète le même brouillon.

Une note ou un courrier déjà validé n'est jamais modifié. Laissez décochée l'option « Remplacer »
de l'action Enregistrer le fichier : sinon, un second enregistrement effacerait le premier s'il
n'a pas encore été repris par le Mac.

Sans usage reconnu au début du nom (par exemple un ancien raccourci), la dictée est traitée comme
une note de séance. Un sous-dossier nommé d'après un usage (Séances, Bilans, Réévaluations,
Courriers) est aussi compris.

## Premier essai

1. Lancez le Raccourci depuis l'app Raccourcis, et autorisez le micro et l'accès au dossier.
2. Dictez quelques mots.
3. Sur le Mac, KinéAPP doit être ouverte et le coffre déverrouillé. La dictée apparaît en deux
   minutes environ, ou tout de suite avec Paramètres → iPhone → « Vérifier maintenant ».
4. Si le nom tapé ne correspond à aucun patient, KinéAPP demande à qui attribuer la dictée.
   C'est là que vous créez la fiche d'un nouveau patient.
5. Une note de séance pour un patient qui n'a encore aucun bilan dans KinéAPP apparaît dans le
   bandeau avec « Classer… » : créez son dossier de suivi, ou rattachez-la à un patient existant
   (nom mal tapé, par exemple).
6. Essayez aussi le choix « Texte » : le fichier doit arriver en `.txt`.

## Si la dictée arrive vide

KinéAPP signale « enregistrement silencieux ». Les causes à vérifier :
- **Écouteurs ou casque Bluetooth connectés**, même dans une autre pièce : l'iPhone enregistre
  par leur micro. Déconnectez-les avant de dicter.
- **L'écran pendant l'enregistrement** : gardez l'iPhone déverrouillé, sur l'écran de
  l'enregistrement, jusqu'à l'arrêt. Ne lancez pas le Raccourci par Siri.
- **L'accès au micro** : Réglages → Confidentialité et sécurité → Micro, « Raccourcis » doit être autorisé.

## Confidentialité

- **Transit par iCloud** : le nom tapé et l'audio passent par iCloud (serveurs d'Apple) jusqu'à
  leur reprise par le Mac, qui met ensuite l'original à la Corbeille. Activez la Protection
  avancée des données d'iCloud.
- **Fichiers supprimés** : ils restent 30 jours dans « Supprimés récemment » d'iCloud Drive.
- **Noms dans le traitement** : sur le Mac, seuls des codes passent dans le traitement. Pour les
  notes de séance et les courriers, les noms prononcés sont remplacés par les codes avant tout
  enregistrement.
- **Bilans dictés** : ils suivent le même circuit que les bilans enregistrés sur le Mac.
