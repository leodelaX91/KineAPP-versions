# Installer KinéAPP sur un autre Mac (version bêta)

KinéAPP est en **version bêta expérimentale** : une aide à la rédaction, qui ne pose aucun diagnostic
et ne remplace pas le jugement clinique. Chaque document doit être relu et validé par le praticien.

## Ce qu'il faut

- Un Mac **Apple Silicon** (M1 ou plus récent), macOS 13 ou plus récent, 16 Go de mémoire au moins. Modes de
  rédaction (Paramètres → IA) : 16 Go : mode rapide (35B) ; 24 Go et plus : les trois modes. Splash demande
  macOS 26.4 ou plus récent ; sinon llama.cpp le remplace (modes rapide et qualité).
- Rien d'autre : ni Terminal, ni compte GitHub, ni outils de développement.

## Installation (collègues)

1. Téléchargez le paquet d'installation : https://github.com/leodelaX91/KineAPP-versions/raw/main/KineAPP.pkg
2. Double-cliquez dessus. Si macOS refuse de l'ouvrir (« développeur non identifié ») : Réglages Système →
   Confidentialité et sécurité → en bas, **Ouvrir quand même**, puis confirmez.
3. « Continuer », puis le mot de passe du Mac. L'installateur vérifie que la version est signée par l'éditeur,
   crée le coffre d'identité et installe l'app, protégée, dans Applications.
4. KinéAPP s'ouvre : choisissez le **mot de passe du coffre** (10 caractères au moins), notez-le hors du Mac.
5. Paramètres → IA : téléchargez les moteurs et un modèle de rédaction.

Empreinte de la clé de publication (à confirmer avec Léo par un autre moyen que GitHub) :

    SHA256:0EN4ibYyYAsBokFh9gnYZaJd48TFKGVuPqyhVoOf45Q

En cas d'échec : journal dans /Library/Logs/KineAPP-installation.log (sans donnée patient).

## Mises à jour

KinéAPP vérifie une fois par jour si une nouvelle version est publiée (réglage « Prévenir quand une nouvelle
version est publiée », Paramètres → Mises à jour et problèmes ; seul un fichier public est lu sur GitHub) et le
signale. **Installer la mise à jour**, puis le mot de passe du Mac : l'app télécharge la version, vérifie sa
signature et son empreinte, et l'installe (rien à compiler). Une version n'est installée que si elle est signée
par la clé connue de l'app déjà installée, plus récente qu'elle, et conforme aux garde-fous de confidentialité.
La version remplacée est gardée ; « Revenir à la version précédente » la remet en place.

## Ancienne méthode (Terminal, développeurs)

    git clone https://github.com/leodelaX91/KineAPP.git ~/KineAPP-source   # dépôt privé : accès sur invitation
    cd ~/KineAPP-source && sudo ./outils/installer.sh --distribution && sudo -k

## Publication (éditeur)

`./outils/publier.sh` : étiquette signée du code, puis version construite (outils/construire_version.sh),
manifeste signé, paquet .pkg (outils/construire_pkg.sh), envoyés dans le dépôt public des versions
(outils/publication/canal.json, clone dans ~/Developer/KineAPP-versions). La clé de publication est demandée
pour chaque signature (`ssh-add --apple-use-keychain ~/.ssh/kineapp_publication` : une seule fois).

## Raccourci iPhone (facultatif)

Dicter une note de séance, enregistrer un bilan ou dicter un courrier depuis l'iPhone : procédure
dans Paramètres → iPhone, et dans docs/RACCOURCI_IPHONE.md.

## Confidentialité

Aucune donnée patient ne quitte le Mac. GitHub ne contient que le code de l'app. Les noms des
patients sont dans le coffre d'identité, sous un compte système séparé. Exception, si vous
utilisez le Raccourci iPhone : l'audio transite par iCloud jusqu'à sa reprise (voir docs/RGPD.md).

## Réglementaire

- Usage personnel et expérimental entre confrères. Une diffusion plus large d'un logiciel qui aide à
  rédiger des bilans peut relever du règlement européen sur les dispositifs médicaux : renseignez-vous
  avant.
- Questionnaires : certains sont sous licence (voir docs/LICENCES_QUESTIONNAIRES.md).
