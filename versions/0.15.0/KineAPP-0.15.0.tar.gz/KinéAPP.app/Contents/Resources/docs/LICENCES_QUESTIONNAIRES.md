# Licences des questionnaires (revue du 17/10/2026)

Pas un avis juridique : relevé des conditions publiées, à confirmer auprès des ayants droit
(Mapi Research Trust / ePROVIDE, auteurs) avant toute diffusion publique ou commerciale.
Champ `diffusion` de chaque fichier de `questionnaires/` : `libre`, `permission`, `licence`.

## Usage actuel (votre cabinet, dépôt privé) : sans problème
Usage clinique par un soignant, non commercial : tous les instruments ci-dessous sont utilisables.
Les instruments sous licence stricte sont déjà en mode « score seulement » (questions non reproduites).

## Non utilisables tels quels dans une app publique ou diffusée (texte complet reproduit)
| Instrument | Ayant droit | Condition |
|---|---|---|
| KOOS, HAGOS (et HOOS, FAOS déjà en score) | Mapi Research Trust depuis mai 2023 | autorisation toujours requise ; payant pour usage commercial et établissements |
| NDI | H. Vernon / Mapi | licence pour organisations, éditeurs de logiciels, usage commercial |
| PCS (version française PCS-CF) | M. Sullivan / Mapi | licence via ePROVIDE |
| QuickDASH | Institute for Work & Health | gratuit pour le soin ; intégration à un produit ou autre usage : autorisation écrite (licence logiciel payante) ; aucune modification |
| STarT Back | Keele University | gratuit non commercial ; produit commercial : licence Keele |
| Örebro (forme courte) | S. Linton | la permission de reproduction de la traduction KCE ne vaut pas pour nous : demander |
| PSEQ | M. Nicholas | licence demandée à l'auteur |
| DN4 | catalogue Mapi | conditions à consulter (souvent gratuit en soin, payant en commercial) |
| IKDC | AOSSM | formulaire gratuit en téléchargement ; conditions de reproduction dans un logiciel à confirmer |
| Échelle de Borg CR10 | BorgPerception (marque déposée) | libellés de l'échelle protégés : permission pour les reproduire |
| Barthel | Maryland State Medical Society | libre en non commercial, avec citation ; pas de modification |
| SRS-22r (déjà en score) | Scoliosis Research Society | autorisation à demander |

Déjà en « score seulement » (licence) : EQ-5D-5L, HADS, MNA-SF, MSIS-29, NPSI, ODI, Oxford épaule et
genou, PainDETECT, PDQ-39.

## Libres (publiés, usage clinique libre ; citer la référence)
10MWT, 6MWT, TUG, SPPB, Berg, Tinetti, Ashworth, Lysholm, Kujala/AKPS, CAIT, FAAM, VISA-A, VISA-P,
LEFS, SPADI, BCTQ, FABQ, TSK, CSI, EIFEL, PSFS, EVN, mini-GDS, FES-I, ACL-RSI, ALR-RSI, SI-RSI,
K-STARTS, S-STARTS, Ankle-GO, LANSS, S-LANSS, Fugl-Meyer, PHQ-9 et GAD-7 (Pfizer, usage libre),
tests bilatéraux.

## Points d'attention
- Traductions françaises reprises de formulaires FullPhysio (BCTQ, HAGOS, IKDC, SI-RSI) : vérifier
  qu'il s'agit du texte de la traduction validée publiée, pas d'une mise en forme propre à FullPhysio.
- LANSS : traduction française non validée (signalé dans la référence).
- Avant une diffusion : passer les instruments « licence » et « permission » en mode score, ou
  obtenir les autorisations.
