# Déchiffrer les données de KinéAPP en secours

Les bilans, transcriptions, comptes rendus, ordonnances et fiches de KinéAPP sont chiffrés sur le
disque. Normalement, l'app les déchiffre seule une fois le coffre déverrouillé. Ce mode d'emploi
sert si l'app ne fonctionne plus : il permet de récupérer une copie en clair avec le **code de
secours** noté à l'activation du chiffrement (52 caractères, par groupes de 4).

Sans ce code, et sans le coffre (ou une sauvegarde du coffre avec son mot de passe), les données
sont illisibles. Gardez-le hors de ce Mac : sur papier ou dans un gestionnaire de mots de passe.

## Avec l'outil de secours (recommandé)

L'outil `dechiffrer_secours.py` se trouve dans le dossier `Secours` du dossier KinéAPP (et dans
`outils/` du code de l'app). Il n'a besoin que du Python de macOS.

1. Ouvrez le Terminal (Applications › Utilitaires).
2. Tapez la commande suivante, en adaptant les chemins :
   ```bash
   python3 ~/Documents/KinéAPP/Secours/dechiffrer_secours.py ~/Documents/KinéAPP ~/Desktop/KinéAPP-en-clair
   ```
   - le premier chemin est le dossier chiffré ;
   - le second est un dossier **nouveau**, qui recevra la copie en clair.
3. Collez ou tapez le code de secours (il ne s'affiche pas), puis appuyez sur Entrée.

Le dossier chiffré n'est jamais modifié.

Pour les fiches (séances, programme, plan, dictées, comptes rendus en cours), lancez la même
commande sur le dossier des données de l'app :
```bash
python3 ~/Documents/KinéAPP/Secours/dechiffrer_secours.py ~/Library/Application\ Support/BilanKine ~/Desktop/KinéAPP-fiches
```
Chaque fiche devient un fichier JSON, dans le dossier `base`.

Une fois les données récupérées, mettez la copie en clair à la Corbeille dès qu'elle n'est plus
utile, puis videz la Corbeille.

## Sans aucun outil (openssl de macOS)

Chaque fichier chiffré est structuré ainsi :
- `KENC1` suivi d'un octet nul (6 octets) ;
- l'iv (16 octets) ;
- les données chiffrées en AES-256-CBC ;
- un code d'authentification (32 octets).

La clé AES se déduit du code de secours : HMAC-SHA256 de la clé, avec le message
« kineapp-chiffrement ». Un informaticien peut ainsi tout déchiffrer avec `openssl enc -d -aes-256-cbc`
(options `-K` et `-iv` en hexadécimal), après avoir retiré les 22 premiers et les 32 derniers octets
du fichier.
